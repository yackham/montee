/* Montée — résumé d'un import Ten'Up pour les notifications.
   Utilisé dans l'app (premier plan) et par l'app iPhone en arrière-plan (JavaScriptCore,
   sans page web) : ne dépend que de MonteeEngine et MonteeTenup.
   monteeSummary(payload, state) → JSON { title, body, state } ou { state } s'il n'y a rien de neuf. */
(function (root) {
  "use strict";
  var JOURS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  var MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  function jour(d) { return JOURS[d.getDay()] + " " + d.getDate() + " " + MOIS[d.getMonth()]; }
  function key(r) { return r.date + "|" + r.oppRank + "|" + r.result; }

  // Phrase d'état du classement, réutilisée par les notifications
  function statusLine(p) {
    var E = root.MonteeEngine;
    if (!p || p.status === "top") return "";
    var rel = jour(p.release);
    if (p.status === "montee") return "D'après Montée, tu montes à " + E.label(p.projected) + " le " + rel + ".";
    if (p.status === "descente") return "Attention : risque de descente à " + E.label(p.projected) + " le " + rel + ".";
    var nx = p.next;
    if (p.gap === 0 && p.needWin) return "Il te manque une victoire contre un " + nx.label + " pour monter le " + rel + ".";
    return "Bilan à " + nx.label + " : " + nx.total + " / " + nx.norme + " pts. Il en manque " + p.gap + " pour monter le " + rel + ".";
  }

  function monteeSummary(payloadStr, stateStr, todayIso) {
    var T = root.MonteeTenup, E = root.MonteeEngine;
    var pl = T.decode(payloadStr);
    if (!pl || pl.error) return null;
    var st = {};
    try { st = JSON.parse(stateStr || "{}") || {}; } catch (e) { st = {}; }
    var rows = T.rows(pl).filter(function (r) { return r.ok; });
    var known = st.keys || [];
    var fresh = rows.filter(function (r) { return known.indexOf(key(r)) < 0; });
    var rank = T.normRank(pl.profil && pl.profil.classement) || st.rank || "";
    var cur = E.idx(rank); if (cur == null) cur = -1;
    var today = todayIso ? E.parseDate(todayIso) : new Date();
    var matches = rows.map(function (r) { return { id: key(r), date: r.date, opp: r.opp, oppRank: r.oppRank, result: r.result, wo: r.wo, kind: r.kind }; });
    var p = E.project(matches, cur, st.sex === "F" ? "F" : "H", { today: today, extra: st.extra || 0 });
    var newState = JSON.stringify(Object.assign({}, st, { keys: rows.map(key), rank: rank }));
    // Premier import : on mémorise sans notifier
    if (!known.length || !fresh.length) return JSON.stringify({ state: newState });
    var f = fresh[0], title;
    if (fresh.length > 1) title = fresh.length + " nouveaux matchs sur Ten'Up";
    else {
      title = (f.result === "V" ? "Victoire" : "Défaite") + " contre " + (f.opp || "un " + f.oppRank) + " (" + f.oppRank + ")";
      if (f.result === "V" && p.next) {
        var pts = E.BAREME.win(E.idx(f.oppRank) - p.next.calc);
        if (pts > 0) title += " · +" + pts + " pts";
      }
    }
    return JSON.stringify({ title: title, body: statusLine(p), state: newState });
  }

  root.monteeSummary = monteeSummary;
  root.monteeStatusLine = statusLine;
})(this);
