/* Montée — liaison Ten'Up.
   Le script ci-dessous s'exécute DANS la page tenup.fft.fr, dans le navigateur du joueur
   (raccourci iPhone « Envoyer à Montée » ou favori sur ordinateur). Il utilise la session
   Ten'Up déjà ouverte : aucun mot de passe ne passe par Montée, aucun serveur.
   Il lit le palmarès, le profil, le bilan officiel et la simulation officielle, puis
   renvoie le tout à Montée (presse-papiers sur iPhone, adresse de la page sur ordinateur). */
(function (root) {
  "use strict";

  // ---- Code exécuté sur tenup.fft.fr (ne pas utiliser de variable extérieure) ----
  function tenupFetch(LIC, MODE, ORIGIN, KID) {
    // Fenêtre Montée affichée par-dessus Ten'Up (favori) : un bouton pour copier, un lien pour ouvrir Montée
    function panel(html) {
      var old = document.getElementById("montee-panel"); if (old) old.remove();
      var d = document.createElement("div"); d.id = "montee-panel";
      d.setAttribute("style", "position:fixed;inset:0;z-index:2147483647;background:rgba(18,18,18,.45);display:flex;align-items:flex-end;justify-content:center;font-family:-apple-system,system-ui,sans-serif");
      d.innerHTML = '<div style="width:100%;max-width:480px;background:#F6F2EC;color:#121212;border-radius:28px 28px 0 0;padding:24px 20px calc(28px + env(safe-area-inset-bottom));display:flex;flex-direction:column;gap:14px;box-sizing:border-box">' +
        '<div style="display:flex;align-items:center;gap:8px;font-weight:700;font-size:20px;letter-spacing:-.03em"><span style="width:26px;height:26px;border-radius:13px;background:#D4E64A;display:inline-block"></span>montée</div>' + html + "</div>";
      document.body.appendChild(d);
      return d;
    }
    function btn(label, primary) {
      return '<button type="button" style="min-height:56px;border:none;border-radius:28px;font-size:17px;font-weight:600;font-family:inherit;cursor:pointer;' +
        (primary ? "background:#121212;color:#fff" : "background:#fff;color:#121212") + '">' + label + "</button>";
    }
    function done(payload) {
      var s = "MONTEE1" + JSON.stringify(payload);
      if (MODE === "shortcut") return completion(s);
      if (MODE === "native") return ORIGIN(s);
      if (MODE === "bookmarklet") { location.href = ORIGIN + "/#import=" + encodeURIComponent(s); return; }
      var n = (payload.matches || []).length;
      var d = panel('<div style="font-size:24px;font-weight:600;letter-spacing:-.02em;line-height:1.15">Ton palmarès est prêt</div>' +
        '<div style="font-size:16px;color:#625B55">' + n + " match" + (n > 1 ? "s" : "") + " et ta simulation officielle.</div>" +
        btn("Copier pour Montée", true) + '<div id="montee-msg" style="font-size:15px;min-height:20px;color:#1F5C3F;font-weight:600"></div>' +
        btn("Fermer", false));
      var b = d.querySelectorAll("button");
      b[0].onclick = function () {
        var ok = function () {
          document.getElementById("montee-msg").textContent = "Copié ! Ouvre Montée et touche « Importer ».";
          b[0].textContent = "Copié ✓"; b[0].style.background = "#1F5C3F";
          b[1].textContent = "Ou ouvrir Montée directement"; b[1].onclick = function () { location.href = ORIGIN + "/#import=" + encodeURIComponent(s); };
        };
        var fb = function () {
          var t = document.createElement("textarea"); t.value = s; t.setAttribute("readonly", ""); t.style.cssText = "position:fixed;opacity:0";
          document.body.appendChild(t); t.select(); t.setSelectionRange(0, s.length); try { document.execCommand("copy"); } catch (e) {} t.remove(); ok();
        };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(s).then(ok, fb); else fb();
      };
      b[1].onclick = function () { d.remove(); };
    }
    function fail(msg) {
      if (MODE === "shortcut") return completion("MONTEE-ERR " + msg);
      if (MODE === "native") return ORIGIN("MONTEE-ERR " + msg);
      if (MODE === "bookmarklet") { alert("Montée : " + msg); return; }
      var dg = "MONTEE-DIAG " + JSON.stringify(DIAG);
      var d = panel('<div style="font-size:20px;font-weight:600">Ça n\'a pas marché</div><div style="font-size:16px;line-height:1.4">' + msg.charAt(0).toUpperCase() + msg.slice(1) + "</div>" + btn("Copier le diagnostic pour Claude", true) + btn("Fermer", false));
      var bs = d.querySelectorAll("button");
      bs[0].onclick = function () {
        var t = document.createElement("textarea"); t.value = dg; t.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(t); t.select();
        var fin = function () { bs[0].textContent = "Copié ✓"; };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(dg).then(fin, function () { try { document.execCommand("copy"); } catch (e) {} fin(); }); else { try { document.execCommand("copy"); } catch (e) {} fin(); }
        t.remove();
      };
      bs[1].onclick = function () { d.remove(); };
    }
    if (MODE === "overlay") panel('<div style="font-size:18px;font-weight:600">Lecture de ton palmarès…</div>');
    if (!/(^|\.)tenup\.fft\.fr$/.test(location.hostname)) {
      return fail("ouvre d'abord tenup.fft.fr, connecté à ton compte, puis relance.");
    }
    var base = location.origin + "/back/v1/personnes/";
    function j(url, method) {
      var o = { credentials: "include", method: method || "GET", headers: { "Accept": "application/json" } };
      if (method === "POST") { o.headers["Content-Type"] = "application/json"; o.body = "{}"; }
      return fetch(url, o).then(function (r) {
        if (r.status === 401 || r.status === 403) throw new Error("auth");
        if (!r.ok) throw new Error("http " + r.status);
        return r.json();
      });
    }
    var DIAG = { path: location.pathname, cands: [], probes: [], search: null };
    // Cherche l'identifiant Ten'Up du joueur : on rassemble les nombres candidats présents
    // dans la page, puis on demande à Ten'Up lequel correspond à un profil joueur.
    function findId() {
      var cands = [], add = function (x) { if (x && cands.indexOf(x) < 0 && cands.length < 25) cands.push(x); };
      if (KID) add(String(KID));
      var pm = location.pathname.match(/(\d{5,12})/g); (pm || []).forEach(add);
      try { (performance.getEntriesByType("resource") || []).forEach(function (e) { var mm = e.name.match(/personnes\/(\d{5,12})/); if (mm) add(mm[1]); }); } catch (e) {}
      var h = document.documentElement.innerHTML;
      [/back\/v1\/personnes\/(\d{5,12})/g, /\/palmares\/(\d{5,12})/g, /"(?:idPersonne|personneId|idCrm|idPersonneCrm|personId|userId|uid|id)"\s*:\s*"?(\d{5,12})/g,
        /(?:fiche|joueur|profil|personne|player)[^"'\s<>]{0,40}?(\d{6,12})/gi, /data-[a-z-]*id=["'](\d{5,12})["']/gi].forEach(function (re) {
        var mm; while ((mm = re.exec(h))) add(mm[1]);
      });
      Array.prototype.forEach.call(document.querySelectorAll("a[href]"), function (a) { var mm = (a.getAttribute("href") || "").match(/\/(\d{6,12})(?:[/?#]|$)/); if (mm) add(mm[1]); });
      DIAG.cands = cands.slice();
      var lic = LIC || ((document.body.innerText || "").match(/\b(\d{6,8}\s?[A-Z])\b/) || [])[1] || "";
      lic = lic.replace(/\s/g, "");
      function probe(i) {
        if (i >= cands.length) return Promise.reject(new Error("next"));
        var id = cands[i];
        return fetch(base + id + "/profil-joueur", { credentials: "include", headers: { "Accept": "application/json" } }).then(function (r) {
          DIAG.probes.push(id.slice(0, 3) + "…:" + r.status);
          if (!r.ok) throw 0;
          return r.json();
        }).then(function (p) {
          var ok = p && (p.numeroLicence || p.nom || p.prenom);
          if (ok && lic && p.numeroLicence && String(p.numeroLicence).replace(/\s/g, "").toUpperCase() !== lic.toUpperCase()) ok = false;
          if (!ok) throw 0;
          return id;
        }).catch(function (e) { if (e && e.message === "next") throw e; return probe(i + 1); });
      }
      function search() {
        if (!lic) return Promise.reject(new Error("noid"));
        return fetch(location.origin + "/recherche/joueurs/resultats", {
          method: "POST", credentials: "include",
          headers: { "Content-Type": "application/x-www-form-urlencoded", "X-Requested-With": "XMLHttpRequest" },
          body: "typeRecherche=licencie&sexe=INDIF&numero_licence=" + encodeURIComponent(lic)
        }).then(function (r) {
          DIAG.search = { status: r.status, type: r.headers.get("content-type") };
          return r.text();
        }).then(function (t) {
          DIAG.search.snippet = t.replace(/\s+/g, " ").slice(0, 300);
          if (/user\/login|login\.fft\.fr|queue-it/.test(t)) throw new Error("auth");
          var mm = t.match(/"link":"[^"]*?\/(\d{5,})"/) || t.match(/palmares\/(\d{5,})/) || t.match(/personnes\/(\d{5,})/);
          if (!mm) throw new Error("noid");
          return mm[1];
        });
      }
      return probe(0).catch(function () { return search(); });
    }
    findId().then(function (id) {
      var b = base + id;
      return Promise.all([
        j(b + "/palmares/tennis?millesime&mobile=false"),
        j(b + "/profil-joueur").catch(function () { return null; }),
        j(b + "/bilan-classement", "POST").catch(function () { return null; }),
        j(b + "/simulation-classement", "POST").catch(function () { return null; })
      ]).then(function (r) {
        var pal = r[0] || {}, ms = pal.matchs || pal.matches || [];
        var matches = ms.map(function (m) {
          var a = (m.adversaires || [])[0] || m.adversaire || {};
          var cl = a.classementLibelle || (a.classement && (a.classement.libelle || a.classement)) || "";
          return {
            date: m.date || m.dateMatch || "", v: m.victoireUtilisateur, wo: !!m.wo, ab: !!m.abandon, dq: !!m.disqualification,
            comp: m.nomHomologation || (m.competition && m.competition.libelle) || "",
            nom: [a.prenom, a.nom].filter(Boolean).join(" ") || (a.anonyme ? "Anonyme" : ""), cl: String(cl),
            sets: (m.sets || []).map(function (s) { return [s.scoreUtilisateur, s.scoreAdversaire, s.scoreTieBreak]; })
          };
        });
        var p = r[1] || {}, ct = p.classementTennis || {};
        done({
          v: 1, sv: "__SV__", at: new Date().toISOString(), id: id,
          profil: { prenom: p.prenom, nom: p.nom, sexe: p.sexe, licence: p.numeroLicence,
            classement: ct.dernierClassement && ct.dernierClassement.libelle, meilleur: ct.meilleurClassement && ct.meilleurClassement.libelle },
          matches: matches, raw: ms, bilan: r[2], simulation: r[3], sample: ms[0] || null
        });
      });
    }).catch(function (e) {
      var m = String((e && e.message) || e);
      fail(m === "auth" ? "connecte-toi à Ten'Up, puis relance." :
        m === "noid" ? "ouvre la page de ton palmarès sur Ten'Up (ou renseigne ton numéro de licence dans Montée), puis relance." :
          "Ten'Up n'a pas répondu (" + m + "). Réessaie dans un instant.");
    });
  }

  var VERSION = "1.9";
  // Version pour l'app iPhone : corps d'une fonction async (WKWebView callAsyncJavaScript)
  function nativeScript(licence, knownId) {
    return "return await new Promise(function (r) { (" + tenupFetch.toString().replace("__SV__", VERSION) + ")(" + JSON.stringify(licence || "") + ", \"native\", r, " + JSON.stringify(knownId || "") + "); });";
  }
  function script(licence, mode, origin) {
    return "(" + tenupFetch.toString().replace("__SV__", VERSION) + ")(" + JSON.stringify(licence || "") + "," + JSON.stringify(mode) + "," + JSON.stringify(origin || "") + ");";
  }
  function bookmarklet(licence, origin) {
    return "javascript:" + encodeURIComponent(script(licence, "overlay", origin));
  }

  // ---- Côté Montée : lecture de ce que renvoie le script ----
  function isoDate(s) {
    s = String(s || "");
    var m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return m[1] + "-" + m[2] + "-" + m[3];
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); if (m) return m[3] + "-" + ("0" + m[2]).slice(-2) + "-" + ("0" + m[1]).slice(-2);
    var d = new Date(s); if (!isNaN(d)) return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
    return "";
  }
  function normRank(c) {
    c = String(c || "").trim().toUpperCase().replace(/\s+/g, "");
    if (!c) return "";
    if (/^N\.?C\.?$|NONCLASS/.test(c)) return "NC";
    if (/^(N°|NO|N|#|TOP)\d+/.test(c)) return "N°";
    return c;
  }
  function kindOf(comp) {
    var c = String(comp || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (/championnat.*individ|indiv.*championnat/.test(c)) return "champ";
    if (/equipe|interclub|championnat/.test(c)) return "equipes";
    if (/libre/.test(c)) return "libre";
    return "tournoi";
  }
  function decode(text) {
    text = String(text || "").trim();
    if (text.indexOf("MONTEE-ERR") === 0) return { error: text.slice(11) };
    var i = text.indexOf("MONTEE1");
    if (i < 0) return null;
    try { return JSON.parse(text.slice(i + 7)); } catch (e) { return { error: "les données reçues sont incomplètes. Relance le raccourci." }; }
  }
  // Un match de double : deux adversaires, un partenaire, ou « double » dans son type
  function isDouble(m) {
    if (!m || typeof m !== "object") return false;
    if ((m.adversaires || []).length >= 2) return true;
    if (m.partenaire || m.partenaires || m.coequipier || m.equipier) return true;
    var keys = ["type", "typeMatch", "typeEpreuve", "typePartie", "discipline", "nature", "categorie", "libelleEpreuve", "epreuve", "specialite", "format"];
    for (var i = 0; i < keys.length; i++) {
      var v = m[keys[i]]; if (v && typeof v === "object") v = v.libelle || v.code || JSON.stringify(v);
      if (v && /doub|\bDM\b|\bDD\b|\bDX\b|mixte/i.test(String(v))) return true;
    }
    return /\bdouble/i.test(String(m.nomHomologation || ""));
  }
  function fromRaw(ms) {
    return ms.map(function (m) {
      var a = (m.adversaires || [])[0] || m.adversaire || {};
      var cl = a.classementLibelle || (a.classement && (a.classement.libelle || a.classement)) || "";
      return {
        date: m.date || m.dateMatch || "", v: m.victoireUtilisateur, wo: !!m.wo, ab: !!m.abandon, dbl: isDouble(m),
        comp: m.nomHomologation || (m.competition && m.competition.libelle) || "",
        nom: [a.prenom, a.nom].filter(Boolean).join(" ") || (a.anonyme ? "Anonyme" : ""), cl: String(cl),
        sets: (m.sets || []).map(function (s) { return [s.scoreUtilisateur, s.scoreAdversaire, s.scoreTieBreak]; })
      };
    });
  }
  function rows(payload) {
    var src = payload.raw && payload.raw.length ? fromRaw(payload.raw) : (payload.matches || []);
    return src.filter(function (m) { return !m.dbl; }).map(function (m) {
      var sets = (m.sets || []).filter(function (s) { return s && s[0] != null && s[1] != null; });
      var score = sets.map(function (s) { return s[0] + "-" + s[1] + (s[2] != null && s[2] !== "" ? "(" + s[2] + ")" : ""); }).join(" ");
      if (m.ab) score += (score ? " " : "") + "ab.";
      var res = m.v === true || m.v === "true" || m.v === 1 ? "V" : m.v === false || m.v === "false" || m.v === 0 ? "D" : "";
      var r = { date: isoDate(m.date), opp: m.nom || "", oppRank: normRank(m.cl), result: res, wo: !!m.wo, score: score, kind: kindOf(m.comp), comp: m.comp || "" };
      r.ok = !!(r.date && r.oppRank && r.result);
      return r;
    }).filter(function (r) { return r.date; });
  }
  // Simulation officielle : on garde l'essentiel, en tolérant les variations de format
  function official(payload) {
    var sim = payload.simulation || {}, bil = payload.bilan || {};
    var line = function (x) {
      return { c: x.classement && (x.classement.libelle || x.classement) || x.libelle || "", pts: x.pointsCumules, quota: x.quota, manque: x.pointsManquants, V: x.victoires, D: x.defaites };
    };
    return {
      at: payload.at, classement: payload.profil && payload.profil.classement,
      message: sim.messageSimulation || (sim.messages || []).join(" ") || "",
      simulation: (sim.resultatSimulation || []).map(line),
      bilans: (bil.bilans || []).map(line),
      calcule: bil.classement && (bil.classement.calcule || bil.classement.libelle) || ""
    };
  }

  function doublesCount(payload) { return payload.raw ? fromRaw(payload.raw).filter(function (m) { return m.dbl; }).length : 0; }
  var api = { nativeScript: nativeScript, VERSION: VERSION, doublesCount: doublesCount, isDouble: isDouble, script: script, bookmarklet: bookmarklet, decode: decode, rows: rows, official: official, normRank: normRank };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.MonteeTenup = api;
})(this);
