package fr.montennis.app;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Le plugin maison doit être enregistré avant super.onCreate
        registerPlugin(TenupPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
