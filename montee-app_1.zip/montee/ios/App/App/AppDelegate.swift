import UIKit
import Capacitor
import WebKit
import JavaScriptCore
import BackgroundTasks
import UserNotifications

// Montée — partie native iPhone.
// - TenupPlugin : connexion à Ten'Up dans une vraie page web (WKWebView), puis lecture du
//   palmarès avec la session du joueur, comme le fait le site lui-même.
// - Actualisation silencieuse (à l'ouverture et en arrière-plan) et notifications locales.
// Aucun serveur : les identifiants restent dans la WKWebView, les données sur le téléphone.

let kRefreshTaskId = "fr.montennis.app.refresh"

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: kRefreshTaskId, using: nil) { task in
            if let refresh = task as? BGAppRefreshTask {
                MonteeBackground.handle(task: refresh)
            } else {
                task.setTaskCompleted(success: true)
            }
        }
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        MonteeBackground.schedule()
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        return ApplicationDelegateProxy.shared.application(app, open: url, options: options)
    }

    func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
        return ApplicationDelegateProxy.shared.application(application, continue: userActivity, restorationHandler: restorationHandler)
    }
}

// Contrôleur principal : enregistre le plugin Ten'Up auprès de Capacitor.
class MainViewController: CAPBridgeViewController {
    override open func capacitorDidLoad() {
        bridge?.registerPluginInstance(TenupPlugin())
    }
}

// MARK: - Mémoire locale partagée entre l'app et l'arrière-plan

enum MonteeStore {
    private static let d = UserDefaults.standard
    static var script: String? {
        get { d.string(forKey: "montee.script") }
        set { d.set(newValue, forKey: "montee.script") }
    }
    static var state: String? {
        get { d.string(forKey: "montee.state") }
        set { d.set(newValue, forKey: "montee.state") }
    }
    static var pending: String? {
        get { d.string(forKey: "montee.pending") }
        set { d.set(newValue, forKey: "montee.pending") }
    }
    static var expiredNotified: Bool {
        get { d.bool(forKey: "montee.expiredNotified") }
        set { d.set(newValue, forKey: "montee.expiredNotified") }
    }
}

// MARK: - Lecture de Ten'Up dans une WKWebView

final class TenupFetcher: NSObject, WKNavigationDelegate {
    static let home = URL(string: "https://tenup.fft.fr/")!
    let webView: WKWebView
    private let script: String
    private var running = false
    private(set) var finished = false
    /// Appelé avec le texte renvoyé par le script ; renvoyer true pour arrêter.
    var onResult: ((String) -> Bool)?

    init(script: String, frame: CGRect = CGRect(x: 0, y: 0, width: 390, height: 844)) {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()   // cookies Ten'Up conservés entre deux lancements
        webView = WKWebView(frame: frame, configuration: config)
        self.script = script
        super.init()
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
    }

    func load(_ url: URL = TenupFetcher.home) {
        webView.load(URLRequest(url: url))
    }

    func stop() {
        finished = true
        webView.stopLoading()
        webView.navigationDelegate = nil
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        runScript()
    }

    /// Exécute le script Montée dans la page, uniquement sur tenup.fft.fr.
    func runScript() {
        guard !running, !finished, let host = webView.url?.host, host.hasSuffix("tenup.fft.fr") else { return }
        running = true
        webView.callAsyncJavaScript(script, arguments: [:], in: nil, in: .page) { [weak self] result in
            guard let self = self else { return }
            self.running = false
            if self.finished { return }
            var text = "MONTEE-ERR erreur inconnue"
            switch result {
            case .success(let value):
                if let s = value as? String { text = s }
            case .failure(let error):
                text = "MONTEE-ERR " + error.localizedDescription
            }
            if self.onResult?(text) == true { self.finished = true }
        }
    }
}

// Fenêtre de connexion : la vraie page Ten'Up, Montée lit le palmarès dès que c'est possible.
final class TenupConnectViewController: UIViewController {
    let fetcher: TenupFetcher
    var onDone: ((String?) -> Void)?
    private let status = UILabel()
    private var timer: Timer?
    private var closed = false

    init(script: String) {
        fetcher = TenupFetcher(script: script)
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) non utilisé") }

    override func viewDidLoad() {
        super.viewDidLoad()
        let linen = UIColor(red: 0.965, green: 0.949, blue: 0.925, alpha: 1)
        view.backgroundColor = linen

        let bar = UIView()
        bar.backgroundColor = linen
        let title = UILabel()
        title.text = "Connecte-toi à Ten'Up"
        title.font = .systemFont(ofSize: 17, weight: .semibold)
        status.text = "Montée récupère ton palmarès dès que tu es connecté."
        status.font = .systemFont(ofSize: 13)
        status.textColor = UIColor(red: 0.38, green: 0.36, blue: 0.33, alpha: 1)
        status.numberOfLines = 2
        let close = UIButton(type: .system)
        close.setTitle("Annuler", for: .normal)
        close.titleLabel?.font = .systemFont(ofSize: 17)
        close.tintColor = UIColor(red: 0.12, green: 0.36, blue: 0.25, alpha: 1)
        close.addTarget(self, action: #selector(cancelTapped), for: .touchUpInside)

        let web = fetcher.webView
        for v in [bar, web] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        for v in [title, status, close] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            title.topAnchor.constraint(equalTo: bar.topAnchor, constant: 14),
            title.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 20),
            close.centerYAnchor.constraint(equalTo: title.centerYAnchor),
            close.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -16),
            status.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 4),
            status.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 20),
            status.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -20),
            status.bottomAnchor.constraint(equalTo: bar.bottomAnchor, constant: -12),
            web.topAnchor.constraint(equalTo: bar.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            web.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        fetcher.onResult = { [weak self] text in
            guard let self = self else { return true }
            if text.hasPrefix("MONTEE1") { self.finish(text); return true }
            if text.contains("palmarès") || text.contains("licence") {
                self.status.text = "Connecté ! Ouvre ton palmarès pour terminer."
            }
            return false
        }
        fetcher.load()
        // La connexion peut se terminer sans rechargement complet : on réessaie régulièrement.
        timer = Timer.scheduledTimer(withTimeInterval: 6, repeats: true) { [weak self] _ in self?.fetcher.runScript() }
    }

    @objc private func cancelTapped() { finish(nil) }

    private func finish(_ text: String?) {
        if closed { return }
        closed = true
        timer?.invalidate()
        timer = nil
        fetcher.stop()
        let callback = onDone
        dismiss(animated: true) { callback?(text) }
    }
}

// Lecture silencieuse (WKWebView invisible), avec délai maximum.
enum TenupSilentRefresh {
    private static var current: TenupFetcher?

    static func run(script: String, timeout: TimeInterval = 25, completion: @escaping (String) -> Void) {
        DispatchQueue.main.async {
            current?.stop()
            let fetcher = TenupFetcher(script: script)
            current = fetcher
            var done = false
            let finish: (String) -> Void = { text in
                if done { return }
                done = true
                fetcher.onResult = nil
                fetcher.stop()
                fetcher.webView.removeFromSuperview()
                if current === fetcher { current = nil }
                completion(text)
            }
            fetcher.onResult = { text in finish(text); return true }
            // Une WKWebView attachée à une fenêtre exécute son JavaScript de façon plus fiable.
            if let window = UIApplication.shared.connectedScenes
                .compactMap({ ($0 as? UIWindowScene)?.windows.first }).first {
                fetcher.webView.isHidden = true
                window.addSubview(fetcher.webView)
            }
            fetcher.load()
            DispatchQueue.main.asyncAfter(deadline: .now() + timeout) { finish("MONTEE-ERR délai dépassé") }
        }
    }
}

// MARK: - Plugin Capacitor appelé depuis l'app web

@objc(TenupPlugin)
public class TenupPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "TenupPlugin"
    public let jsName = "Tenup"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "connect", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "refresh", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setState", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "takePending", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "logout", returnType: CAPPluginReturnPromise)
    ]

    @objc func connect(_ call: CAPPluginCall) {
        guard let script = call.getString("script"), !script.isEmpty else { call.reject("script manquant"); return }
        MonteeStore.script = script
        DispatchQueue.main.async {
            let vc = TenupConnectViewController(script: script)
            vc.modalPresentationStyle = .pageSheet
            vc.isModalInPresentation = true
            vc.onDone = { text in
                if let t = text {
                    MonteeStore.expiredNotified = false
                    call.resolve(["data": t])
                } else {
                    call.resolve(["cancelled": true])
                }
            }
            self.bridge?.viewController?.present(vc, animated: true)
        }
    }

    @objc func refresh(_ call: CAPPluginCall) {
        let script = call.getString("script") ?? MonteeStore.script ?? ""
        if script.isEmpty { call.reject("script manquant"); return }
        MonteeStore.script = script
        TenupSilentRefresh.run(script: script) { text in
            call.resolve(["data": text])
        }
    }

    @objc func setState(_ call: CAPPluginCall) {
        if let state = call.getString("state") { MonteeStore.state = state }
        if let script = call.getString("script"), !script.isEmpty { MonteeStore.script = script }
        MonteeBackground.schedule()
        call.resolve()
    }

    @objc func takePending(_ call: CAPPluginCall) {
        if let pending = MonteeStore.pending {
            MonteeStore.pending = nil
            call.resolve(["data": pending])
        } else {
            call.resolve()
        }
    }

    @objc func logout(_ call: CAPPluginCall) {
        MonteeStore.state = nil
        MonteeStore.pending = nil
        DispatchQueue.main.async {
            let store = WKWebsiteDataStore.default()
            let types = WKWebsiteDataStore.allWebsiteDataTypes()
            store.fetchDataRecords(ofTypes: types) { records in
                let tenup = records.filter { $0.displayName.contains("fft.fr") || $0.displayName.contains("queue-it") }
                store.removeData(ofTypes: types, for: tenup) { call.resolve() }
            }
        }
    }
}

// MARK: - Arrière-plan : nouveaux matchs et notifications

enum MonteeSummary {
    /// Calcule le résumé avec le même moteur que l'app (engine.js, tenup.js, summary.js).
    static func compute(payload: String, state: String) -> (title: String, body: String)? {
        guard let ctx = JSContext() else { return nil }
        for name in ["engine", "tenup", "summary"] {
            if let url = Bundle.main.url(forResource: name, withExtension: "js", subdirectory: "public"),
               let source = try? String(contentsOf: url, encoding: .utf8) {
                ctx.evaluateScript(source)
            }
        }
        guard let fn = ctx.objectForKeyedSubscript("monteeSummary"), !fn.isUndefined,
              let res = fn.call(withArguments: [payload, state]), !res.isUndefined, !res.isNull,
              let json = res.toString(), let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        if let newState = obj["state"] as? String { MonteeStore.state = newState }
        guard let title = obj["title"] as? String, let body = obj["body"] as? String else { return nil }
        return (title, body)
    }
}

enum MonteeBackground {
    static func schedule() {
        let request = BGAppRefreshTaskRequest(identifier: kRefreshTaskId)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 3 * 3600)
        try? BGTaskScheduler.shared.submit(request)
    }

    static func handle(task: BGAppRefreshTask) {
        schedule()
        guard let script = MonteeStore.script, MonteeStore.state != nil else {
            task.setTaskCompleted(success: true)
            return
        }
        var completed = false
        task.expirationHandler = {
            DispatchQueue.main.async {
                if !completed { completed = true; task.setTaskCompleted(success: false) }
            }
        }
        TenupSilentRefresh.run(script: script, timeout: 22) { text in
            DispatchQueue.main.async {
                if completed { return }
                completed = true
                if text.hasPrefix("MONTEE1") {
                    MonteeStore.pending = text
                    if let note = MonteeSummary.compute(payload: text, state: MonteeStore.state ?? "{}") {
                        notify(title: note.title, body: note.body)
                    }
                } else if text.contains("connecte-toi") && !MonteeStore.expiredNotified {
                    MonteeStore.expiredNotified = true
                    notify(title: "Ten'Up t'a déconnecté", body: "Ouvre Montée et reconnecte-toi pour suivre tes nouveaux matchs.")
                }
                task.setTaskCompleted(success: true)
            }
        }
    }

    static func notify(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        let request = UNNotificationRequest(identifier: "montee-\(Int(Date().timeIntervalSince1970))", content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
}
