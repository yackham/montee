# Fiche Google Play : Montée

Tout ce qu'il faut copier dans la Play Console, champ par champ.

## Informations générales (Fiche principale du Play Store)

| Champ | À mettre |
|---|---|
| Nom de l'appli (30 car. max) | `Montée – Classement tennis` |
| Description courte (80 car. max) | `Ton classement FFT recalculé avant la sortie : tu montes ou pas ?` |
| Icône de l'appli (512 × 512) | `icone-512.png` |
| Image de présentation (1024 × 500) | `feature-graphic-1024x500.png` |
| Captures téléphone (2 à 8) | les 6 images du dossier `captures/`, dans l'ordre 1 à 6 |
| Catégorie | Sports |
| Tags | Tennis, Statistiques sportives |
| Adresse e-mail de contact | `yann.munier21@gmail.com` |
| Site web | https://montennis.netlify.app |
| Règles de confidentialité | https://montennis.netlify.app/confidentialite.html |

> La page de confidentialité affiche cette adresse : redéploie `montee-netlify.zip` sur Netlify avant d'envoyer l'app pour examen.

## Description complète (4000 car. max)

```
Tu montes ce mois-ci ? Montée te le dit avant la sortie.

Montée récupère ton palmarès depuis ton compte Ten'Up et recalcule ton bilan comme le fait le classement mensuel FFT : 12 mois glissants, points de chaque victoire, victoires prises en compte, normes de chaque échelon.

CE QUE TU VOIS EN UN COUP D'ŒIL
• Si tu montes, te maintiens ou risques de descendre à la prochaine sortie
• Combien de points il te manque pour l'échelon d'au-dessus
• Contre quel classement une victoire suffit pour monter
• Les victoires qui vont sortir de tes 12 mois, et ce qu'elles te coûtent
• Quand tu montes : la fête, ton nouveau classement et l'objectif suivant

TES MATCHS, AUTOMATIQUEMENT
Connecte ton compte une fois, sur la page officielle Ten'Up. Montée vérifie ensuite tes nouveaux matchs et te prévient : nouveau match, points gagnés, montée ou pas. Tu peux aussi saisir un match à la main : le score se rentre en trois touches.

TES COURBES ET TES RECORDS
• L'évolution de ton bilan, mois par mois
• Contre quels classements tu gagnes et tu perds
• Tes records sur 12 mois : plus belle victoire, perfs, tie-breaks, remontées
• Où tu gagnes : tournoi, championnat, par équipes
• Ton temps de jeu, matchs et entraînements

TON MATÉRIEL
Note ta raquette, ton cordage et ta tension (y compris montants et travers différents), tes entraînements et ton ressenti. Montée estime tes heures de jeu sur chaque cordage, te prévient quand un monofilament approche des 20 heures et te dit avec quoi tu gagnes.

TES DONNÉES RESTENT CHEZ TOI
Pas de compte Montée, pas de serveur, pas de pub, pas de pisteur. Ton mot de passe Ten'Up n'est jamais vu par Montée. Tout reste sur ton téléphone.

Montée est une application indépendante. Elle n'est ni éditée, ni approuvée, ni soutenue par la Fédération Française de Tennis. Ten'Up est un service de la FFT. Les calculs sont indicatifs : seul le classement officiel fait foi.
```

## Contenu de l'appli (menu Règles et programmes › Contenu de l'appli)

**Règles de confidentialité** : `https://montennis.netlify.app/confidentialite.html`

**Annonces** : Non, mon appli ne contient pas d'annonces.

**Accès à l'appli** : « Toutes ou certaines fonctionnalités sont restreintes », puis ajoute une instruction :
- Nom : `Mode exemple (sans compte)`
- Instructions :
```
Montée n'a pas de compte propre. La connexion Ten'Up utilise le compte personnel FFT du joueur, sur la page officielle tenup.fft.fr affichée dans l'app ; l'app ne voit pas le mot de passe.
Pour voir toutes les fonctions sans compte : touchez « C'est parti », choisissez un classement (ex. 15/2), « Continuer », puis « Essayer avec un exemple ». Des données d'exemple sont chargées : accueil, détail du calcul, palmarès, courbes, matériel, entraînements.
```

**Classification du contenu** (questionnaire IARC)
- Catégorie : « Toutes les autres applications »
- Violence, peur, sexualité, langage, drogues, jeux d'argent : Non à tout
- Les utilisateurs peuvent-ils interagir ou échanger du contenu ? Non
- L'appli partage-t-elle la position de l'utilisateur ? Non
- Achats numériques ? Non
- Résultat attendu : PEGI 3 / Tous publics

**Public cible et contenu** : tranches d'âge **16-17 ans** et **18 ans et plus**. L'appli ne s'adresse pas aux enfants. N'attire pas involontairement les enfants : Oui (elle ne les attire pas).

**Sécurité des données**
- Votre appli collecte-t-elle ou partage-t-elle des types de données utilisateur obligatoires ? **Non**
- (Explication si on te la demande : tout est stocké sur le téléphone ; l'app n'envoie rien à un serveur. La page Ten'Up s'ouvre dans l'app, l'utilisateur s'y connecte directement auprès de la FFT.)

**Identifiant publicitaire** : Non, mon appli n'utilise pas l'identifiant publicitaire.

**Applis gouvernementales / financières / santé / actualités** : Non partout.

## Notes de version (à chaque envoi)

```
Première version de Montée sur Android : ton classement FFT recalculé avant la sortie, ton palmarès Ten'Up synchronisé, tes courbes et ton matériel.
```
