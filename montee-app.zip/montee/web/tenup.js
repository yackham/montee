/* Montée — liaison Ten'Up.
   Le script ci-dessous s'exécute DANS la page tenup.fft.fr, dans le navigateur du joueur
   (raccourci iPhone « Envoyer à Montée » ou favori sur ordinateur). Il utilise la session
   Ten'Up déjà ouverte : aucun mot de passe ne passe par Montée, aucun serveur.
   Il lit le palmarès, le profil, le bilan officiel et la simulation officielle, puis
   renvoie le tout à Montée (presse-papiers sur iPhone, adresse de la page sur ordinateur). */
(function (root) {
  "use strict";

  // ---- Code exécuté sur tenup.fft.fr (ne pas utiliser de variable extérieure) ----
  function tenupFetch(LIC, MODE, ORIGIN, KID) {
    // Fenêtre Montée affichée par-dessus Ten'Up (favori) : un bouton pour copier, un lien pour ouvrir Montée
    function panel(html) {
      var old = document.getElementById("montee-panel"); if (old) old.remove();
      var d = document.createElement("div"); d.id = "montee-panel";
      d.setAttribute("style", "position:fixed;inset:0;z-index:2147483647;background:rgba(18,18,18,.45);display:flex;align-items:flex-end;justify-content:center;font-family:-apple-system,system-ui,sans-serif");
      d.innerHTML = '<div style="width:100%;max-width:480px;background:#F6F2EC;color:#121212;border-radius:28px 28px 0 0;padding:24px 20px calc(28px + env(safe-area-inset-bottom));display:flex;flex-direction:column;gap:14px;box-sizing:border-box">' +
        '<div style="display:flex;align-items:center;gap:8px;font-weight:700;font-size:20px;letter-spacing:-.03em"><span style="width:26px;height:26px;border-radius:13px;background:#D4E64A;display:inline-block"></span>montée</div>' + html + "</div>";
      document.body.appendChild(d);
      return d;
    }
    function btn(label, primary) {
      return '<button type="button" style="min-height:56px;border:none;border-radius:28px;font-size:17px;font-weight:600;font-family:inherit;cursor:pointer;' +
        (primary ? "background:#121212;color:#fff" : "background:#fff;color:#121212") + '">' + label + "</button>";
    }
    function done(payload) {
      var s = "MONTEE1" + JSON.stringify(payload);
      if (MODE === "shortcut") return completion(s);
      if (MODE === "native") return ORIGIN(s);
      if (MODE === "bookmarklet") { location.href = ORIGIN + "/#import=" + encodeURIComponent(s); return; }
      var n = (payload.matches || []).length;
      var d = panel('<div style="font-size:24px;font-weight:600;letter-spacing:-.02em;line-height:1.15">Ton palmarès est prêt</div>' +
        '<div style="font-size:16px;color:#625B55">' + n + " match" + (n > 1 ? "s" : "") + " et ta simulation officielle.</div>" +
        btn("Copier pour Montée", true) + '<div id="montee-msg" style="font-size:15px;min-height:20px;color:#1F5C3F;font-weight:600"></div>' +
        btn("Fermer", false));
      var b = d.querySelectorAll("button");
      b[0].onclick = function () {
        var ok = function () {
          document.getElementById("montee-msg").textContent = "Copié ! Ouvre Montée et touche « Importer ».";
          b[0].textContent = "Copié ✓"; b[0].style.background = "#1F5C3F";
          b[1].textContent = "Ou ouvrir Montée directement"; b[1].onclick = function () { location.href = ORIGIN + "/#import=" + encodeURIComponent(s); };
        };
        var fb = function () {
          var t = document.createElement("textarea"); t.value = s; t.setAttribute("readonly", ""); t.style.cssText = "position:fixed;opacity:0";
          document.body.appendChild(t); t.select(); t.setSelectionRange(0, s.length); try { document.execCommand("copy"); } catch (e) {} t.remove(); ok();
        };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(s).then(ok, fb); else fb();
      };
      b[1].onclick = function () { d.remove(); };
    }
    function fail(msg) {
      if (MODE === "shortcut") return completion("MONTEE-ERR " + msg);
      if (MODE === "native") return ORIGIN("MONTEE-ERR " + msg);
      if (MODE === "bookmarklet") { alert("Montée : " + msg); return; }
      var dg = "MONTEE-DIAG " + JSON.stringify(DIAG);
      var d = panel('<div style="font-size:20px;font-weight:600">Ça n\'a pas marché</div><div style="font-size:16px;line-height:1.4">' + msg.charAt(0).toUpperCase() + msg.slice(1) + "</div>" + btn("Copier le diagnostic pour Claude", true) + btn("Fermer", false));
      var bs = d.querySelectorAll("button");
      bs[0].onclick = function () {
        var t = document.createElement("textarea"); t.value = dg; t.style.cssText = "position:fixed;opacity:0"; document.body.appendChild(t); t.select();
        var fin = function () { bs[0].textContent = "Copié ✓"; };
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(dg).then(fin, function () { try { document.execCommand("copy"); } catch (e) {} fin(); }); else { try { document.execCommand("copy"); } catch (e) {} fin(); }
        t.remove();
      };
      bs[1].onclick = function () { d.remove(); };
    }
    if (MODE === "overlay") panel('<div style="font-size:18px;font-weight:600">Lecture de ton palmarès…</div>');
    if (!/(^|\.)tenup\.fft\.fr$/.test(location.hostname)) {
      return fail("ouvre d'abord tenup.fft.fr, connecté à ton compte, puis relance.");
    }
    var base = location.origin + "/back/v1/personnes/";
    function j(url, method) {
      var o = { credentials: "include", method: method || "GET", headers: { "Accept": "application/json" } };
      if (method === "POST") { o.headers["Content-Type"] = "application/json"; o.body = "{}"; }
      return fetch(url, o).then(function (r) {
        if (r.status === 401 || r.status === 403) throw new Error("auth");
        if (!r.ok) throw new Error("http " + r.status);
        return r.json();
      });
    }
    var DIAG = { path: location.pathname, cands: [], probes: [], search: null };
    // Cherche l'identifiant Ten'Up du joueur : on rassemble les nombres candidats présents
    // dans la page, puis on demande à Ten'Up lequel correspond à un profil joueur.
    function findId() {
      var cands = [], add = function (x) { if (x && cands.indexOf(x) < 0 && cands.length < 25) cands.push(x); };
      if (KID) add(String(KID));
      var pm = location.pathname.match(/(\d{5,12})/g); (pm || []).forEach(add);
      try { (performance.getEntriesByType("resource") || []).forEach(function (e) { var mm = e.name.match(/personnes\/(\d{5,12})/); if (mm) add(mm[1]); }); } catch (e) {}
      var h = document.documentElement.innerHTML;
      [/back\/v1\/personnes\/(\d{5,12})/g, /\/palmares\/(\d{5,12})/g, /"(?:idPersonne|personneId|idCrm|idPersonneCrm|personId|userId|uid|id)"\s*:\s*"?(\d{5,12})/g,
        /(?:fiche|joueur|profil|personne|player)[^"'\s<>]{0,40}?(\d{6,12})/gi, /data-[a-z-]*id=["'](\d{5,12})["']/gi].forEach(function (re) {
        var mm; while ((mm = re.exec(h))) add(mm[1]);
      });
      Array.prototype.forEach.call(document.querySelectorAll("a[href]"), function (a) { var mm = (a.getAttribute("href") || "").match(/\/(\d{6,12})(?:[/?#]|$)/); if (mm) add(mm[1]); });
      DIAG.cands = cands.slice();
      var lic = LIC || ((document.body.innerText || "").match(/\b(\d{6,8}\s?[A-Z])\b/) || [])[1] || "";
      lic = lic.replace(/\s/g, "");
      function probe(i) {
        if (i >= cands.length) return Promise.reject(new Error("next"));
        var id = cands[i];
        return fetch(base + id + "/profil-joueur", { credentials: "include", headers: { "Accept": "application/json" } }).then(function (r) {
          DIAG.probes.push(id.slice(0, 3) + "…:" + r.status);
          if (!r.ok) throw 0;
          return r.json();
        }).then(function (p) {
          var ok = p && (p.numeroLicence || p.nom || p.prenom);
          if (ok && lic && p.numeroLicence && String(p.numeroLicence).replace(/\s/g, "").toUpperCase() !== lic.toUpperCase()) ok = false;
          if (!ok) throw 0;
          return id;
        }).catch(function (e) { if (e && e.message === "next") throw e; return probe(i + 1); });
      }
      function search() {
        if (!lic) return Promise.reject(new Error("noid"));
        return fetch(location.origin + "/recherche/joueurs/resultats", {
          method: "POST", credentials: "include",
          headers: { "Content-Type": "application/x-www-form-urlencoded", "X-Requested-With": "XMLHttpRequest" },
          body: "typeRecherche=licencie&sexe=INDIF&numero_licence=" + encodeURIComponent(lic)
        }).then(function (r) {
          DIAG.search = { status: r.status, type: r.headers.get("content-type") };
          return r.text();
        }).then(function (t) {
          DIAG.search.snippet = t.replace(/\s+/g, " ").slice(0, 300);
          if (/user\/login|login\.fft\.fr|queue-it/.test(t)) throw new Error("auth");
          var mm = t.match(/"link":"[^"]*?\/(\d{5,})"/) || t.match(/palmares\/(\d{5,})/) || t.match(/personnes\/(\d{5,})/);
          if (!mm) throw new Error("noid");
          return mm[1];
        });
      }
      return probe(0).catch(function () { return search(); });
    }
    findId().then(function (id) {
      var b = base + id;
      return Promise.all([
        j(b + "/palmares/tennis?millesime&mobile=false"),
        j(b + "/profil-joueur").catch(function () { return null; }),
        j(b + "/bilan-classement", "POST").catch(function () { return null; }),
        j(b + "/simulation-classement", "POST").catch(function () { return null; })
      ]).then(function (r) {
        var pal = r[0] || {}, ms = pal.matchs || pal.matches || [];
        var matches = ms.map(function (m) {
          var a = (m.adversaires || [])[0] || m.adversaire || {};
          var cl = a.classementLibelle || (a.classement && (a.classement.libelle || a.classement)) || "";
          return {
            date: m.date || m.dateMatch || "", v: m.victoireUtilisateur, wo: !!m.wo, ab: !!m.abandon, dq: !!m.disqualification,
            comp: m.nomHomologation || (m.competition && m.competition.libelle) || "",
            nom: [a.prenom, a.nom].filter(Boolean).join(" ") || (a.anonyme ? "Anonyme" : ""), cl: String(cl),
            sets: (m.sets || []).map(function (s) { return [s.scoreUtilisateur, s.scoreAdversaire, s.scoreTieBreak]; })
          };
        });
        var p = r[1] || {}, ct = p.classementTennis || {};
        done({
          v: 1, sv: "__SV__", at: new Date().toISOString(), id: id,
          profil: { prenom: p.prenom, nom: p.nom, sexe: p.sexe, licence: p.numeroLicence,
            classement: ct.dernierClassement && ct.dernierClassement.libelle, meilleur: ct.meilleurClassement && ct.meilleurClassement.libelle },
          matches: matches, raw: ms, bilan: r[2], simulation: r[3], sample: ms[0] || null
        });
      });
    }).catch(function (e) {
      var m = String((e && e.message) || e);
      fail(m === "auth" ? "connecte-toi à Ten'Up, puis relance." :
        m === "noid" ? "ouvre la page de ton palmarès sur Ten'Up (ou renseigne ton numéro de licence dans Montée), puis relance." :
          "Ten'Up n'a pas répondu (" + m + "). Réessaie dans un instant.");
    });
  }

  var VERSION = "1.9";
  // Version pour l'app iPhone : corps d'une fonction async (WKWebView callAsyncJavaScript)
  function nativeScript(licence, knownId) {
    return "return await new Promise(function (r) { (" + tenupFetch.toString().replace("__SV__", VERSION) + ")(" + JSON.stringify(licence || "") + ", \"native\", r, " + JSON.stringify(knownId || "") + "); });";
  }
  function script(licence, mode, origin) {
    return "(" + tenupFetch.toString().replace("__SV__", VERSION) + ")(" + JSON.stringify(licence || "") + "," + JSON.stringify(mode) + "," + JSON.stringify(origin || "") + ");";
  }
  function bookmarklet(licence, origin) {
    return "javascript:" + encodeURIComponent(script(licence, "overlay", origin));
  }

  // ---- Côté Montée : lecture de ce que renvoie le script ----
  function isoDate(s) {
    s = String(s || "");
    var m = s.match(/^(\d{4})-(\d{2})-(\d{2})/); if (m) return m[1] + "-" + m[2] + "-" + m[3];
    m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/); if (m) return m[3] + "-" + ("0" + m[2]).slice(-2) + "-" + ("0" + m[1]).slice(-2);
    var d = new Date(s); if (!isNaN(d)) return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
    return "";
  }
  function normRank(c) {
    c = String(c || "").trim().toUpperCase().replace(/\s+/g, "");
    if (!c) return "";
    if (/^N\.?C\.?$|NONCLASS/.test(c)) return "NC";
    if (/^(N°|NO|N|#|TOP)\d+/.test(c)) return "N°";
    return c;
  }
  // Type de compétition, d'après tout ce que Ten'Up dit du match (nom, type d'homologation, épreuve…)
  function kindOf(comp) {
    var c = " " + String(comp || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[_\-]+/g, " ") + " ";
    if (/match(s)? libre|\blibre\b/.test(c)) return "libre";
    if (/individuel|\bindiv\b|champ(\.|ionnat)? ind\b/.test(c)) return "champ";
    if (/tournoi|\bopen\b|\btmc\b|multi ?chances?|circuit|galaxie/.test(c)) return "tournoi";
    if (/equipe|interclub|rencontre|\bpoule\b|division|championnat|chpt|coupe|\+ ?\d\d\b|\d\d ?ans|plus de \d\d|seniors? plus|veterans?|\bhiver\b|\bete\b|printemps|automne|\S \/ \S/.test(c)) return "equipes";
    return "tournoi";
  }
  // Toutes les infos textuelles d'un match Ten'Up (sauf joueurs et sets), pour reconnaître la compétition
  function compText(m) {
    var out = [];
    (function walk(o, depth) {
      if (!o || depth > 2) return;
      Object.keys(o).forEach(function (k) {
        if (/^(adversaire|adversaires|partenaire|partenaires|coequipier|equipier|joueur|joueurs|sets|utilisateur)$/i.test(k)) return;
        var v = o[k];
        if (typeof v === "string" && v.length < 160 && !/^\d{4}-\d\d-\d\d/.test(v)) out.push(v);
        else if (v && typeof v === "object" && !Array.isArray(v)) walk(v, depth + 1);
      });
    })(m, 0);
    return out.join(" | ");
  }
  // Sets lus dans le bon sens : si le score contredit le résultat (Ten'Up écrit parfois le score
  // du point de vue du vainqueur), on le retourne. Pas sur un abandon : le score peut y être trompeur.
  function orientSets(sets, res, ab) {
    if (!sets.length || ab || (res !== "V" && res !== "D")) return sets;
    var w = 0, l = 0;
    sets.forEach(function (x) { if (+x[0] > +x[1]) w++; else if (+x[0] < +x[1]) l++; });
    if ((res === "D" && w > l) || (res === "V" && l > w)) return sets.map(function (x) { return [x[1], x[0], x[2]]; });
    return sets;
  }
  function decode(text) {
    text = String(text || "").trim();
    if (text.indexOf("MONTEE-ERR") === 0) return { error: text.slice(11) };
    var i = text.indexOf("MONTEE1");
    if (i < 0) return null;
    try { return JSON.parse(text.slice(i + 7)); } catch (e) { return { error: "les données reçues sont incomplètes. Relance le raccourci." }; }
  }
  // Un match de double : deux adversaires, un partenaire, ou « double » dans son type
  function isDouble(m) {
    if (!m || typeof m !== "object") return false;
    if ((m.adversaires || []).length >= 2) return true;
    if (m.partenaire || m.partenaires || m.coequipier || m.equipier) return true;
    var keys = ["type", "typeMatch", "typeEpreuve", "typePartie", "discipline", "nature", "categorie", "libelleEpreuve", "epreuve", "specialite", "format"];
    for (var i = 0; i < keys.length; i++) {
      var v = m[keys[i]]; if (v && typeof v === "object") v = v.libelle || v.code || JSON.stringify(v);
      if (v && /doub|\bDM\b|\bDD\b|\bDX\b|mixte/i.test(String(v))) return true;
    }
    return /\bdouble/i.test(String(m.nomHomologation || ""));
  }
  function fromRaw(ms) {
    return ms.map(function (m) {
      var a = (m.adversaires || [])[0] || m.adversaire || {};
      var rk = function (x) { return x ? String(x.classementLibelle || (x.classement && (x.classement.libelle || x.classement)) || x.classementDouble || "") : ""; };
      var cl = rk(a);
      var pa = m.partenaire || (m.partenaires || [])[0] || m.coequipier || m.equipier || null;
      return {
        oppRanks: (m.adversaires || []).map(rk), oppNames: (m.adversaires || []).map(function (x) { return [x.prenom, x.nom].filter(Boolean).join(" "); }),
        partnerRank: rk(pa), partner: pa ? [pa.prenom, pa.nom].filter(Boolean).join(" ") : "",
        date: m.date || m.dateMatch || "", v: m.victoireUtilisateur, wo: !!m.wo, ab: !!m.abandon, dbl: isDouble(m),
        comp: m.nomHomologation || (m.competition && m.competition.libelle) || "", ctx: compText(m),
        nom: [a.prenom, a.nom].filter(Boolean).join(" ") || (a.anonyme ? "Anonyme" : ""), cl: String(cl),
        sets: (m.sets || []).map(function (s) { return [s.scoreUtilisateur, s.scoreAdversaire, s.scoreTieBreak]; })
      };
    });
  }
  function rows(payload) {
    var src = payload.raw && payload.raw.length ? fromRaw(payload.raw) : (payload.matches || []);
    return src.filter(function (m) { return !m.dbl; }).map(function (m) {
      var res = m.v === true || m.v === "true" || m.v === 1 ? "V" : m.v === false || m.v === "false" || m.v === 0 ? "D" : "";
      var sets = orientSets((m.sets || []).filter(function (s) { return s && s[0] != null && s[1] != null; }), res, m.ab);
      var score = sets.map(function (s) { return s[0] + "-" + s[1] + (s[2] != null && s[2] !== "" ? "(" + s[2] + ")" : ""); }).join(" ");
      if (m.ab) score += (score ? " " : "") + "ab.";
      var r = { date: isoDate(m.date), opp: m.nom || "", oppRank: normRank(m.cl), result: res, wo: !!m.wo, score: score, kind: kindOf((m.comp || "") + " | " + (m.ctx || "")), comp: m.comp || "" };
      r.ok = !!(r.date && r.oppRank && r.result);
      return r;
    }).filter(function (r) { return r.date; });
  }
  // Matchs de double (pour le bonus des doubles au classement de simple)
  function doublesRows(payload) {
    if (!payload.raw || !payload.raw.length) return [];
    return fromRaw(payload.raw).filter(function (m) { return m.dbl; }).map(function (m) {
      var res = m.v === true || m.v === "true" || m.v === 1 ? "V" : m.v === false || m.v === "false" || m.v === 0 ? "D" : "";
      var sets = orientSets((m.sets || []).filter(function (s) { return s && s[0] != null && s[1] != null; }), res, m.ab);
      var ranks = (m.oppRanks || []).map(normRank).filter(Boolean);
      return { date: isoDate(m.date), result: res, wo: !!m.wo, dbl: true, oppRanks: ranks, oppRank: ranks[0] || "",
        opp: (m.oppNames || []).filter(Boolean).join(" / "), partner: m.partner || "", partnerRank: normRank(m.partnerRank) || "",
        score: sets.map(function (s) { return s[0] + "-" + s[1]; }).join(" "), comp: m.comp || "" };
    }).filter(function (r) { return r.date && r.result && r.oppRank; });
  }

  // Bonus double officiel : Ten'Up détaille, dans sa simulation, les points rapportés par
  // chaque victoire en double. On cherche ces lignes (deux adversaires + des points) sans
  // dépendre du nom exact des champs.
  var PTS_KEYS = ["points", "nbPoints", "pointsBonus", "bonus", "pointsDouble", "point", "valeur"];
  function nm(x) { return x && typeof x === "object" ? [x.prenom, x.nom].filter(Boolean).join(" ") || x.libelle || x.nomComplet || "" : String(x || ""); }
  function officialDoubles(obj) {
    var out = [], seen = 0;
    (function walk(o, depth, dbl) {
      if (!o || depth > 7 || seen > 5000) return; seen++;
      if (Array.isArray(o)) { o.forEach(function (x) { walk(x, depth + 1, dbl); }); return; }
      if (typeof o !== "object") return;
      var adv = Array.isArray(o.adversaires) ? o.adversaires : o.adversaire1 ? [o.adversaire1, o.adversaire2] : o.joueur1 && o.joueur2 ? [o.joueur1, o.joueur2] : null;
      var pts = null;
      for (var i = 0; i < PTS_KEYS.length && pts == null; i++) { var v = o[PTS_KEYS[i]]; if (v !== "" && v != null && isFinite(+v)) pts = +v; }
      if (adv && adv.length >= 2 && pts != null && (dbl || adv.filter(Boolean).length >= 2)) {
        var names = adv.map(nm).filter(Boolean);
        if (names.length >= 2) out.push({ names: names, pts: pts, w: adv.map(function (x) { return x && (x.classement != null ? (x.classement.valeur != null ? x.classement.valeur : x.classement.libelle || x.classement) : x.valeur != null ? x.valeur : x.classementLibelle); }) });
      }
      for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k) && o[k] && typeof o[k] === "object") walk(o[k], depth + 1, dbl || /doub/i.test(k));
    })(obj, 0, false);
    return out;
  }
  function skeleton(o, depth) {
    if (depth > 5) return "…";
    if (Array.isArray(o)) return o.length ? [skeleton(o[0], depth + 1), o.length] : [];
    if (o && typeof o === "object") { var r = {}; Object.keys(o).slice(0, 40).forEach(function (k) { r[k] = skeleton(o[k], depth + 1); }); return r; }
    return typeof o === "string" ? (o.length > 24 ? o.slice(0, 24) + "…" : o) : o;
  }

  // Simulation officielle : on garde l'essentiel, en tolérant les variations de format
  function official(payload) {
    var sim = payload.simulation || {}, bil = payload.bilan || {};
    var line = function (x) {
      return { c: x.classement && (x.classement.libelle || x.classement) || x.libelle || "", pts: x.pointsCumules, quota: x.quota, manque: x.pointsManquants, V: x.victoires, D: x.defaites };
    };
    return {
      at: payload.at, classement: payload.profil && payload.profil.classement,
      message: sim.messageSimulation || (sim.messages || []).join(" ") || "",
      simulation: (sim.resultatSimulation || []).map(line),
      doubles: officialDoubles(payload.simulation),
      simShape: skeleton(payload.simulation || null, 0),
      dblSample: payload.raw ? (payload.raw.filter(isDouble)[0] || null) : null,
      bilans: (bil.bilans || []).map(line),
      calcule: bil.classement && (bil.classement.calcule || bil.classement.libelle) || ""
    };
  }

  function doublesCount(payload) { return payload.raw ? fromRaw(payload.raw).filter(function (m) { return m.dbl; }).length : 0; }
  var api = { kindOf: kindOf, orientSets: orientSets, nativeScript: nativeScript, VERSION: VERSION, doublesCount: doublesCount, doublesRows: doublesRows, isDouble: isDouble, script: script, bookmarklet: bookmarklet, decode: decode, rows: rows, official: official, normRank: normRank };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.MonteeTenup = api;
})(this);
