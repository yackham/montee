/* Montée — résumé d'un import Ten'Up pour les notifications.
   Utilisé dans l'app (premier plan) et par l'app iPhone en arrière-plan (JavaScriptCore,
   sans page web) : ne dépend que de MonteeEngine et MonteeTenup.
   monteeSummary(payload, state) → JSON { title, body, state } ou { state } s'il n'y a rien de neuf. */
(function (root) {
  "use strict";
  var JOURS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  var MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  function jour(d) { return JOURS[d.getDay()] + " " + d.getDate() + " " + MOIS[d.getMonth()]; }
  function key(r) { return r.date + "|" + r.oppRank + "|" + r.result; }

  // Phrase d'état du classement, réutilisée par les notifications
  function statusLine(p) {
    var E = root.MonteeEngine;
    if (!p || p.status === "top") return "";
    var rel = jour(p.release);
    if (p.status === "montee") return "D'après Montée, tu montes à " + E.label(p.projected) + " le " + rel + ".";
    if (p.status === "descente") return "Attention : risque de descente à " + E.label(p.projected) + " le " + rel + ".";
    var nx = p.next;
    if (p.gap === 0 && p.needWin) return "Il te manque une victoire contre un " + nx.label + " pour monter le " + rel + ".";
    return "Bilan à " + nx.label + " : " + nx.total + " / " + nx.norme + " pts. Il en manque " + p.gap + " pour monter le " + rel + ".";
  }

  function monteeSummary(payloadStr, stateStr, todayIso) {
    var T = root.MonteeTenup, E = root.MonteeEngine;
    var pl = T.decode(payloadStr);
    if (!pl || pl.error) return null;
    var st = {};
    try { st = JSON.parse(stateStr || "{}") || {}; } catch (e) { st = {}; }
    var rows = T.rows(pl).filter(function (r) { return r.ok; });
    var known = st.keys || [];
    var fresh = rows.filter(function (r) { return known.indexOf(key(r)) < 0; });
    var rank = T.normRank(pl.profil && pl.profil.classement) || st.rank || "";
    var cur = E.idx(rank); if (cur == null) cur = -1;
    var today = todayIso ? E.parseDate(todayIso) : new Date();
    var matches = rows.map(function (r) { return { id: key(r), date: r.date, opp: r.opp, oppRank: r.oppRank, result: r.result, wo: r.wo, kind: r.kind }; });
    if (T.doublesRows) matches = matches.concat(T.doublesRows(pl));
    var p = E.project(matches, cur, st.sex === "F" ? "F" : "H", { today: today, extra: st.extra || 0 });
    var newState = JSON.stringify(Object.assign({}, st, { keys: rows.map(key), rank: rank }));
    // Premier import : on mémorise sans notifier
    var b0 = p.next || p.here;
    if (!known.length || !fresh.length) return JSON.stringify({ state: JSON.stringify(Object.assign({}, JSON.parse(newState), { status: p.status, total: b0 ? b0.total : null })) });
    var f = fresh[0], title, body = statusLine(p), rel = jour(p.release);
    var ptsOf = function (r) { if (r.result !== "V" || !p.next) return 0; return E.BAREME.win(E.idx(r.oppRank) - p.next.calc); };
    var what = function (r) { var x = ptsOf(r); return (r.result === "V" ? "Victoire" : "Défaite") + " contre " + (r.opp || "un " + r.oppRank) + " (" + r.oppRank + ")" + (x > 0 ? " : +" + x + " pts" : ""); };
    var prev = st.status || "";
    // Les changements de situation passent en titre : c'est ce que le joueur veut savoir
    if (p.status === "montee" && prev !== "montee") {
      title = "Tu montes à " + E.label(p.projected) + " !";
      body = (fresh.length > 1 ? fresh.length + " nouveaux matchs sur Ten'Up" : what(f)) + ". C'est dans la poche pour la sortie du " + rel + ".";
    } else if (p.status === "descente" && prev !== "descente") {
      title = "Attention : risque de descente à " + E.label(p.projected);
      body = (fresh.length > 1 ? fresh.length + " nouveaux matchs sur Ten'Up" : what(f)) + ". Il te manque " + (p.here.norme - p.here.total) + " pts pour te maintenir à la sortie du " + rel + ".";
    } else if (prev === "descente" && p.status !== "descente") {
      title = "Maintien assuré à " + (rank || "ton classement");
      body = (fresh.length > 1 ? fresh.length + " nouveaux matchs sur Ten'Up" : what(f)) + ". Tu restes " + rank + " à la sortie du " + rel + ".";
    } else {
      // Une défaite seule ne vaut une notification que si elle coûte des points (une victoire comptée en moins)
      var bil = p.next || p.here, tot = bil ? bil.total : null, lost = st.total != null && tot != null ? st.total - tot : 0;
      var onlyD = fresh.every(function (r) { return r.result !== "V"; });
      if (onlyD && lost <= 0) return JSON.stringify({ state: JSON.stringify(Object.assign({}, JSON.parse(newState), { status: p.status, total: tot })) });
      if (fresh.length > 1) title = fresh.length + " nouveaux matchs sur Ten'Up";
      else title = what(f).replace(" : +", " · +") + (onlyD && lost > 0 ? " · −" + lost + " pts" : "");
      if (onlyD && lost > 0) body = (fresh.length > 1 ? "Ces défaites réduisent" : "Elle réduit") + " le nombre de victoires qui comptent" + (fresh.length > 1 ? " (−" + lost + " pts)" : "") + ". " + body;
    }
    var b2 = p.next || p.here;
    newState = JSON.stringify(Object.assign({}, JSON.parse(newState), { status: p.status, total: b2 ? b2.total : null }));
    return JSON.stringify({ title: title, body: body, state: newState });
  }

  root.monteeSummary = monteeSummary;
  root.monteeStatusLine = statusLine;
})(this);
