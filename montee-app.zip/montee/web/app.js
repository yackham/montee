/* Montée — application (vanilla JS, sans serveur : tout reste sur l'appareil). */
(function () {
  "use strict";

  /* ================= À CONFIGURER ================= */
  var CONFIG = {
    // Lien de ta page de don (Lydia, PayPal, Ko-fi, Buy Me a Coffee, Tipeee…)
    DON_URL: "https://ko-fi.com/tamalousante",
    // Lien iCloud du raccourci iPhone « Envoyer à Montée » (Raccourcis › Partager › Copier le lien iCloud)
    SHORTCUT_URL: "",
    // Adresse pour les retours des joueurs (laisser vide pour masquer l'entrée)
    CONTACT_EMAIL: "yann.munier21@gmail.com",
    VERSION: "3.21.1",
    APPSTORE_ID: "6826303003" // identifiant Apple de l'app (10 chiffres), à remplir une fois l'app créée dans App Store Connect
  };
  /* ================================================= */

  var E = window.MonteeEngine, P = window.MonteeParser, T = window.MonteeTenup;
  // App iPhone (Capacitor) : plugins natifs
  var CAP = window.Capacitor;
  var NATIVE = !!(CAP && CAP.isNativePlatform && CAP.isNativePlatform());
  // Plugins natifs : registerPlugin vient de vendor/capacitor.js (sinon, ceux exposés par le pont natif)
  function plugin(name) { return CAP.registerPlugin ? CAP.registerPlugin(name) : (CAP.Plugins && CAP.Plugins[name]) || null; }
  var Tenup = NATIVE ? plugin("Tenup") : null;
  var LN = NATIVE ? plugin("LocalNotifications") : null;
  var AppP = NATIVE ? plugin("App") : null;
  var IOS = NATIVE && CAP.getPlatform && CAP.getPlatform() === "ios";
  if (IOS) document.documentElement.classList.add("ios");
  // Retour haptique : Taptic Engine sur iPhone, vibration courte sur Android
  // Mode match : l'écran reste allumé (si le téléphone le permet)
  var mmLock = null;
  function mmWake(on) {
    try {
      if (on && navigator.wakeLock && navigator.wakeLock.request) navigator.wakeLock.request("screen").then(function (l) { mmLock = l; }).catch(function () {});
      else if (!on && mmLock) { mmLock.release().catch(function () {}); mmLock = null; }
    } catch (e) {}
  }
  function haptic(style) {
    try {
      if (IOS && Tenup && Tenup.haptic) { var r = Tenup.haptic({ style: style || "light" }); if (r && r.catch) r.catch(function () {}); }
      // Android : on garde le comportement actuel (vibration seulement pour la fête de montée)
    } catch (e) {}
  }
  var KEY = "montee.v1";
  var app = document.getElementById("app");

  // ---------- Stockage ----------
  function blank() {
    return { v: 1, profile: { name: "", sex: "H", rank: "", licence: "" }, matches: [], rackets: [], trainings: [], tenup: { lastImport: null }, onboarded: false };
  }
  function load() {
    try { var raw = localStorage.getItem(KEY); if (raw) { var s = JSON.parse(raw); return Object.assign(blank(), s); } } catch (e) {}
    return blank();
  }
  var S = load();
  if (S.tenup && S.tenup.cred) { delete S.tenup.cred; try { localStorage.setItem("montee.v1", JSON.stringify(S)); } catch (e) {} }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { toast("Impossible d'enregistrer sur cet appareil."); } }

  var UI = { palTab: "all", matTab: "setup", projLevel: null, menu: false, draft: null, racketDraft: null, importText: "", importRows: null, toastMsg: "", toastT: 0, installEvt: null };

  // ---------- Utilitaires ----------
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function today() { var t = new Date(); t.setHours(0, 0, 0, 0); return t; }
  var MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  var MOIS_L = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  var JOURS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  function fdate(iso) { if (!iso) return "date ?"; var d = typeof iso === "string" ? E.parseDate(iso) : iso; return d.getDate() + " " + MOIS[d.getMonth()] + (d.getFullYear() !== today().getFullYear() ? " " + d.getFullYear() : ""); }
  function flong(d) { return JOURS[d.getDay()] + " " + d.getDate() + " " + MOIS_L[d.getMonth()]; }
  function plural(n, s, p) { return n + " " + (n > 1 ? (p || s + "s") : s); }
  // Classement « effectif » : dès qu'une montée est acquise pour la prochaine sortie, Montée te passe
  // au nouveau classement (S.ahead) et calcule la suite depuis là. Le classement officiel reste dans S.profile.rank.
  function effRank() { return S.ahead && S.ahead.rank ? S.ahead.rank : S.profile.rank; }
  function curIdx() { var i = E.idx(effRank()); return i == null ? -1 : i; }
  function refreshAhead() {
    var td = E.iso(today());
    if (S.ahead && S.ahead.release <= td) {
      // la sortie est passée : le classement anticipé devient le classement tout court
      if (S.ahead.from === S.profile.rank) S.profile.rank = S.ahead.rank;
      S.ahead = null; save();
    }
    var off = E.idx(S.profile.rank);
    if (off == null || off >= E.TOP) { if (S.ahead) { S.ahead = null; save(); } return; }
    var opts = { today: today(), extra: tenupExtra(E.nextRelease(today()), off) };
    var pr = E.project(allMatches(), off, S.profile.sex, opts);
    if (pr.status === "montee") {
      var a = { rank: lab(pr.projected), from: S.profile.rank, release: E.iso(pr.release) };
      if (!S.ahead || S.ahead.rank !== a.rank || S.ahead.from !== a.from || S.ahead.release !== a.release) { S.ahead = a; save(); }
    } else if (S.ahead) { S.ahead = null; save(); }
  }
  function lab(i) { return E.label(i); }
  function rackets() { return S.rackets; }
  function racket(id) { return S.rackets.filter(function (r) { return r.id === id; })[0]; }
  function bag() { return S.rackets.filter(function (r) { return !r.archived; }); } // raquettes « dans ton sac » (pas rangées)
  function sortedMatches() {
    return S.matches.slice().sort(function (a, b) {
      if (!a.date || !b.date) return (a.date ? 1 : 0) - (b.date ? 1 : 0) || ((b.officialPts || 0) - (a.officialPts || 0));
      return a.date < b.date ? 1 : a.date > b.date ? -1 : 0;
    });
  }
  // Simples + doubles : le moteur compte les doubles uniquement en bonus (barème des doubles)
  // Matchs qui comptent pour le classement : un match amical (non homologué) saisi à la main n'y entre pas.
  // Ceux qui viennent de Ten'Up sont homologués : ils comptent, quel que soit leur type.
  function counts(m) {
    if (m.kind === "amical" && isManual(m)) return false;
    // saisie en attente de vérification : seule la version Ten'Up compte (pas de double comptage)
    if (isManual(m) && (S.verify || []).some(function (v) { return v.id === m.id; })) return false;
    return true;
  }
  function allMatches() { return S.matches.filter(counts).concat(S.doubles || []); }
  function annotated(m) { return !!m.racketId || !!m.wo || !!m.noted; } // un WO ne s'est pas joué : rien à annoter

  function toast(msg) {
    UI.toastMsg = msg; clearTimeout(UI.toastT); haptic("light");
    var el = document.querySelector(".toast"); if (el) el.remove();
    var t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); t.textContent = msg; document.body.appendChild(t);
    UI.toastT = setTimeout(function () { t.remove(); }, 2800);
  }

  // ---------- Icônes ----------
  function svg(p, sw, extra) { return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (sw || 2) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (extra || "") + ">" + p + "</svg>"; }
  var I = {
    logo: function (s) { return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="14.5" fill="#D4E64A"/><path d="M4 9.5c3.6 3 3.6 10 0 13M28 9.5c-3.6 3-3.6 10 0 13" stroke="#FFFFFF" stroke-width="1.6" fill="none" stroke-linecap="round"/><path d="M9.5 19.5 16 13l6.5 6.5" stroke="#121212" stroke-width="3.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'; },
    back: svg('<path d="M19 12H5M11 6l-6 6 6 6"/>'),
    next: svg('<path d="M9 6l6 6-6 6"/>'),
    arrow: svg('<path d="M5 12h14M13 6l6 6-6 6"/>'),
    plus: svg('<path d="M12 5v14M5 12h14"/>', 2.6),
    check: svg('<path d="M5 12l5 5 9-10"/>', 2.8),
    lock: svg('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>', 2),
    cross: svg('<path d="M6 6l12 12M18 6 6 18"/>', 2.4),
    clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    home: svg('<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'),
    list: svg('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),
    chart: svg('<path d="M3 20h18M5 16l4-5 4 3 6-8"/>'),
    racket: svg('<ellipse cx="14.5" cy="8.5" rx="5.5" ry="6.5" transform="rotate(45 14.5 8.5)"/><path d="M10.6 12.4 4 19M3 18l3 3M11.5 6.5l6 6M14 4.6l5.4 5.4"/>'),
    heart: svg('<path d="M12 21s-7.5-4.6-9.5-9.3C1.1 8.3 3.3 4.5 7 4.5c2 0 3.6 1.1 5 3 1.4-1.9 3-3 5-3 3.7 0 5.9 3.8 4.5 7.2C19.5 16.4 12 21 12 21z"/>'),
    link: svg('<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'),
    user: svg('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
    save: svg('<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>'),
    phone: svg('<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>'),
    book: svg('<path d="M4 4h10a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"/><path d="M8 8h6M8 12h6"/>'),
    share: svg('<path d="M12 3v13M7 8l5-5 5 5M5 14v6h14v-6"/>'),
    mail: svg('<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 7l9 6 9-6"/>'),
    info: svg('<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>'),
    edit: svg('<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>'),
    warn: svg('<path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>'),
    spark: svg('<path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4"/>'),
    gear: svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
    more: svg('<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>', 2.4),
    camera: svg('<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>', 2),
    versus: svg('<circle cx="10" cy="10" r="6"/><path d="M14.5 14.5L20 20"/><circle cx="10" cy="8.5" r="2"/><path d="M6.8 13.2c.8-1.4 1.9-2 3.2-2s2.4.6 3.2 2"/>'),
    trash: svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>')
  };

  // ---------- Calculs partagés ----------
  function ctx() {
    var cur = curIdx(), sex = S.profile.sex;
    var opts = { today: today() };
    if (S.ahead) { var t = E.parseDate(S.ahead.release); t.setDate(t.getDate() + 1); opts.release = E.nextRelease(t); }
    opts.extra = tenupExtra(opts.release || E.nextRelease(today()), cur);
    var proj = E.project(allMatches(), cur, sex, opts);
    var drops = proj.status === "top" ? [] : E.dropOuts(allMatches(), cur, sex, opts).filter(function (x) { return x.pts > 0; });
    return { cur: cur, sex: sex, proj: proj, drops: drops, opts: opts };
  }
  function levelsAround(cur) {
    var c = cur < 0 ? 0 : cur, out = [];
    for (var i = Math.max(-1, c - 3); i <= Math.min(E.MAX_CALC, c + 3); i++) out.push(i);
    return out;
  }
  // Plus petit classement d'adversaire qui suffit pour monter avec une victoire
  function minWinToRise(c) {
    if (c.proj.status !== "maintien" && c.proj.status !== "descente" && c.proj.status !== "entree") return null;
    var lv = levelsAround(c.cur);
    for (var k = 0; k < lv.length; k++) {
      var s = E.simulateWin(allMatches(), c.cur, c.sex, lv[k], c.opts);
      if (s.after.projected > (c.cur < 0 ? 0 : c.cur)) return lv[k];
    }
    return undefined; // une victoire ne suffit pas
  }
  // ---- Pistes : le chemin le plus accessible pour monter (ou se maintenir) ----
  // Chaque piste est simulée avec le vrai calcul : les victoires ajoutées prennent la place des
  // plus faibles victoires comptées (elles ne rapportent donc que la différence), le nombre de
  // victoires comptées peut bouger avec V − E − 2I − 5G, et la victoire « au palier » est exigée.
  // On ne propose que des adversaires à ta portée (déjà battus), classés par probabilité de réussite
  // d'après ton palmarès.
  var pistesMemo = { key: "", val: null };
  var PRIOR = { "-3": 0.85, "-2": 0.75, "-1": 0.62, "0": 0.45, "1": 0.3, "2": 0.18, "3": 0.1 };
  function winChance(c, L) {
    var cur = c.cur < 0 ? 0 : c.cur, d = Math.max(-3, Math.min(3, L - cur)), v = 0, n = 0;
    S.matches.forEach(function (m) {
      if (m.wo || !(m.result === "V" || m.result === "D") || E.idx(m.oppRank) !== L) return;
      n++; if (m.result === "V") v++;
    });
    return (v + 4 * PRIOR[String(d)]) / (n + 4);
  }
  function maxBeaten() {
    var b = null;
    S.matches.forEach(function (m) { var o = E.idx(m.oppRank); if (m.result === "V" && !m.wo && o != null && (b == null || o > b)) b = o; });
    return b;
  }
  function pistes(c) {
    var p = c.proj;
    if (["maintien", "descente", "entree"].indexOf(p.status) < 0) return { goal: "", list: [] };
    var cur = c.cur < 0 ? 0 : c.cur, keep = p.status === "descente", target = keep ? cur : Math.min(cur + 1, E.MAX_CALC);
    var key = [S.matches.map(function (m) { return m.id + m.result + m.oppRank + m.date + m.kind; }).join(","), (S.doubles || []).length, c.cur, c.sex, E.iso(today()), JSON.stringify(c.opts.extra || 0), JSON.stringify(c.opts.release || "")].join("|");
    if (pistesMemo.key === key) return pistesMemo.val;
    var t = E.iso(today()), base = allMatches();
    var ok = function (levels) {
      var r = E.project(base.concat(levels.map(function (o, i) { return { id: "_sim" + i, date: t, result: "V", oppRank: lab(o), kind: "tournoi" }; })), c.cur, c.sex, c.opts);
      return (keep ? r.status !== "descente" : (r.projected > cur && r.status === "montee")) ? (keep ? r.here : r.next) : null;
    };
    var lo = Math.max(0, cur - 3), mb = maxBeaten(), reach = Math.min(target + 2, Math.max(mb == null ? cur : mb, cur));
    var chance = {}; for (var L = lo; L <= target + 2; L++) chance[L] = winChance(c, L);
    // Un adversaire mieux classé n'est jamais plus facile à battre qu'un moins bien classé :
    // quelques bons résultats contre les 15/3 ne rendent pas un 15/3 plus abordable qu'un 15/4.
    for (var L2 = lo + 1; L2 <= target + 2; L2++) chance[L2] = Math.min(chance[L2], chance[L2 - 1] * 0.97);
    function search(hi) {
      var found = [];
      // 1 victoire, puis 2, 3, 4 : on ne garde que les combinaisons minimales
      for (var k = 1; k <= 4; k++) {
        (function rec(start, acc) {
          if (acc.length === k) {
            if (found.some(function (f) { return isSub(f.levels, acc); })) return; // une partie suffit déjà
            var after = ok(acc);
            if (after) found.push({ levels: acc.slice(), after: after });
            return;
          }
          for (var L = start; L <= hi; L++) { acc.push(L); rec(L, acc); acc.pop(); }
        })(lo, []);
      }
      found.forEach(function (f) {
        f.k = f.levels.length; f.top = Math.max.apply(null, f.levels);
        f.p = f.levels.reduce(function (a, L) { return a * chance[L]; }, 1);
      });
      return found;
    }
    function isSub(a, b) { var bb = b.slice(); return a.every(function (x) { var i = bb.indexOf(x); if (i < 0) return false; bb.splice(i, 1); return true; }); }
    var found = search(reach), stretch = false;
    if (!found.length && reach < target + 2) { found = search(Math.min(target + 2, reach + 1)); stretch = found.length > 0; }
    found.sort(function (a, b) { return b.p - a.p || a.top - b.top || a.k - b.k; });
    var list = [];
    found.forEach(function (f) {
      if (list.length >= 3) return;
      // pas deux pistes trop proches : on veut des chemins vraiment différents
      if (list.some(function (x) { return x.k === f.k && x.top === f.top; })) return;
      list.push(f);
    });
    var one = found.filter(function (f) { return f.k === 1; }).sort(function (a, b) { return a.top - b.top; })[0];
    pistesMemo = { key: key, val: { goal: keep ? "keep" : "up", target: target, list: list, stretch: stretch, maxBeaten: mb, one: one } };
    return pistesMemo.val;
  }
  function pisteLabel(x) {
    var g = {}; x.levels.forEach(function (L) { g[L] = (g[L] || 0) + 1; });
    var ks = Object.keys(g).map(Number).sort(function (a, b) { return b - a; });
    return ks.map(function (L, i) {
      var n = g[L], w = i === 0 ? (n > 1 ? " victoires" : " victoire") : "";
      return n + w + " contre " + (n > 1 ? "des " : "un ") + lab(L);
    }).join(" et ");
  }
  function easiest(pl) { return pl.list[0] || null; }
  // Plus haut classement contre lequel tu gagnes au moins un match sur deux (2 matchs minimum)
  function plafondIdx(c) {
    var by = {};
    (c.proj.matches || []).forEach(function (m) { var o = E.idx(m.oppRank); if (o == null || m.wo || !(m.result === "V" || m.result === "D")) return; by[o] = by[o] || { v: 0, n: 0 }; by[o].n++; if (m.result === "V") by[o].v++; });
    var best = null; Object.keys(by).forEach(function (k) { var x = by[k]; if (x.n >= 2 && x.v * 2 >= x.n && (best == null || +k > best)) best = +k; });
    return best;
  }
  function countedMap(b) {
    var m = {}; if (!b) return m;
    b.counted.forEach(function (w) { m[w.m.id] = w.pts; });
    return m;
  }

  // Usure du cordage : on découpe les matchs d'une raquette en « cordages » successifs.
  // Un nouveau cordage commence quand : le match est coché « cordage neuf », une date de
  // cordage tombe juste avant lui, ou le cordage / la tension changent par rapport au match
  // précédent. Avant le premier de ces repères, l'usure est inconnue (on ne l'invente pas).
  // Changement de cordage déduit : seulement un autre nom de cordage (pas la tension, souvent corrigée après coup)
  function strKey(x) { return String(x || "").toLowerCase().replace(/[^a-z0-9]/g, ""); }
  function setupChanged(a, b) {
    return !!(strKey(a.string) && strKey(b.string) && strKey(a.string) !== strKey(b.string));
  }
  // Raquette par défaut : la principale si elle sert à ça, sinon la première qui sert à ça
  function racketFor(use) {
    var b = bag(), fits = function (r) { return !r.usage || r.usage === "both" || r.usage === use; };
    var main = b.filter(function (r) { return r.main; })[0];
    return (main && fits(main) ? main : b.filter(fits)[0]) || main || b[0] || null;
  }
  function defaultRacketId(x) {
    var m = racketFor(x && x.opp == null && x.oppRank == null ? "train" : "match");
    return m ? m.id : "";
  }
  function racketOf(x) { return x.racketId || defaultRacketId(x); }
  // ---------- Temps de jeu (estimation) ----------
  // Un jeu dure en moyenne 4 min (changements de côté compris), +10 min d'échauffement,
  // +6 min par jeu décisif, 15 min pour un super tie-break. Sans score : 1 h 30.
  var MIN_GAME = 4, WARMUP = 10, TB_EXTRA = 6, SUPER_TB = 15, DEFAULT_MATCH = 90;
  function setsOf(score) {
    var out = [];
    String(score || "").replace(/(\d{1,2})\s*[-\/]\s*(\d{1,2})(\s*\(\s*\d+(?:\s*[-\/]\s*\d+)?\s*\))?/g, function (_, x, y) { out.push([+x, +y]); return _; });
    return out;
  }
  function isSuperTb(st, i) { return i === 2 && (Math.max(st[0], st[1]) >= 10 || st[0] + st[1] === 1); }
  function isTb(st) { return (st[0] === 7 && st[1] === 6) || (st[0] === 6 && st[1] === 7); }
  function estMinutes(m) {
    if (m.wo) return 0;
    var sets = setsOf(m.score);
    if (!sets.length) return DEFAULT_MATCH;
    var t = WARMUP;
    sets.forEach(function (st, i) { t += isSuperTb(st, i) ? SUPER_TB : (st[0] + st[1]) * MIN_GAME + (isTb(st) ? TB_EXTRA : 0); });
    return Math.round(t / 5) * 5;
  }
  function playMinutes(x) { return x.minutes ? +x.minutes : x.opp != null || x.oppRank != null ? estMinutes(x) : 60; }
  function fmtDur(min) { var h = Math.floor(min / 60), mm = Math.round(min % 60); return h ? h + " h" + (mm ? " " + (mm < 10 ? "0" : "") + mm : "") : mm + " min"; }
  function fmtHours(min) { var h = min / 60; h = h < 10 ? Math.round(h * 2) / 2 : Math.round(h); return String(h).replace(".", ",") + " h"; }

  // Type de cordage : choisi sur la raquette, sinon deviné d'après le nom
  var STYPES = [["mono", "Monofilament (polyester)"], ["multi", "Multifilament"], ["hybride", "Hybride"], ["boyau", "Boyau naturel"], ["synth", "Synthétique"]];
  function guessType(name) {
    var n = String(name || "").toLowerCase();
    if (!n) return "";
    if (/hybrid|\+|\//.test(n)) return "hybride";
    if (/boyau|natural|\bgut\b|\bvs\b|tonic/.test(n) && !/syn/.test(n)) return "boyau";
    if (/multi|xcel|nxt|x-one|addi[cx]|origin|multifeel|pro'?s pro|touch|fusion|hydra/.test(n)) return "multi";
    if (/synth|nylon|syn ?gut|prince|tour ?gut/.test(n)) return "synth";
    if (/poly|mono|rpm|alu|lynx|hurricane|blast|4g|ice ?code|hyper|black ?code|razor|tour ?bite|cyclone|sonic|confidential|ghost|outlast|signum|solinco|kirschbaum|tornado|isospeed|co-?poly|spin/.test(n)) return "mono";
    return "";
  }
  function stringType(r) { return (r && (r.stringType || guessType(r.string))) || ""; }
  function typeLabel(t) { return (STYPES.filter(function (x) { return x[0] === t; })[0] || ["", ""])[1]; }
  var MONO_WARN = 15 * 60, MONO_MAX = 20 * 60;

  // Séances (matchs joués + entraînements) d'une raquette, dans l'ordre
  function playEvents(racketId) {
    var ev = [], td = E.iso(today());
    // Les matchs sans raquette (importés de Ten'Up, par exemple) comptent pour la raquette principale
    S.matches.forEach(function (m) { if (racketOf(m) === racketId && m.date && m.date <= td && !m.wo) ev.push({ o: m, t: "m", min: playMinutes(m) }); });
    (S.doubles || []).forEach(function (m) { if (racketOf(m) === racketId && m.date && m.date <= td && !m.wo) ev.push({ o: m, t: "m", min: playMinutes(m) }); });
    (S.trainings || []).forEach(function (t) { if (racketOf(t) === racketId && t.date && t.date <= td) ev.push({ o: t, t: "t", min: playMinutes(t) }); });
    return ev.sort(function (a, b) { return a.o.date < b.o.date ? -1 : a.o.date > b.o.date ? 1 : (a.t === b.t ? 0 : a.t === "t" ? -1 : 1); });
  }
  function stringInfo(racketId) {
    var r = racket(racketId), map = {};
    if (!r) return { map: map, last: null };
    var rs = (r.restrings || []).filter(Boolean).slice().sort();
    var prev = null, min = 0, nm = 0, nt = 0, known = false, since = null;
    playEvents(racketId).forEach(function (e) {
      var x = e.o;
      var restrungBefore = rs.filter(function (d) { return d <= x.date && (!prev || d > prev.date); });
      var start = x.newString || restrungBefore.length || (!rs.length && prev && setupChanged(prev, x));
      if (start || !prev) { min = 0; nm = 0; nt = 0; known = !!start; since = restrungBefore.length ? restrungBefore[restrungBefore.length - 1] : (start ? x.date : null); }
      map[x.id] = { min: min, known: known }; // usure du cordage au début de la séance
      min += e.min; if (e.t === "m") nm++; else nt++;
      prev = x;
    });
    var lastRs = rs.length ? rs[rs.length - 1] : null, last;
    if (lastRs && (!prev || lastRs > prev.date)) last = { min: 0, nm: 0, nt: 0, known: true, since: lastRs };
    else last = { min: min, nm: nm, nt: nt, known: prev ? known : false, since: since };
    return { map: map, last: last };
  }
  function stringAge(m) {
    var rid = racketOf(m);
    if (!rid || !m.date) return null;
    var i = stringInfo(rid).map[m.id];
    return i && i.known ? i.min : null;
  }
  // Casses : moyenne des heures de jeu au moment de casser (toutes raquettes)
  function breakAvg() {
    var b = []; S.rackets.forEach(function (r) { (r.breaks || []).forEach(function (x) { if (x.min > 0) b.push(x.min); }); });
    return b.length ? { avg: b.reduce(function (a, x) { return a + x; }, 0) / b.length, n: b.length } : null;
  }
  function brokenNow(r) {
    return r.brokenOpen ? (r.breaks || []).slice(-1)[0] || null : null;
  }
  // level : ok · soon (mono ≥ 15 h, ou proche de tes casses) · change (mono ≥ 20 h) · broken · unknown
  function racketStatus(r) {
    var l = stringInfo(r.id).last || { min: 0, nm: 0, nt: 0, known: false };
    var type = stringType(r), level = !l.known ? "unknown" : type === "mono" ? (l.min >= MONO_MAX ? "change" : l.min >= MONO_WARN ? "soon" : "ok") : "ok";
    var ba = breakAvg();
    if (level === "ok" && ba && l.min >= ba.avg * 0.85) level = "soon";
    if (brokenNow(r)) level = "broken";
    return { since: l.since, min: l.min, nm: l.nm, nt: l.nt, known: l.known, type: type, level: level, breakAvg: ba };
  }
  function fmtT(v) { return String(v).replace(".", ","); }
  function fmtTension(o) {
    if (!o || !o.tension) return "";
    return (o.tensionCross != null && o.tensionCross !== o.tension ? fmtT(o.tension) + " / " + fmtT(o.tensionCross) : fmtT(o.tension)) + " kg";
  }
  // Bloc tension : une valeur, ou montants et travers séparés
  function tensionHtml(o, target) {
    var split = o.tensionCross != null;
    var step = function (k, label) {
      var v = o[k] || 24;
      return '<div class="field inline"><span class="lbl">' + label + '</span><span class="stepper"><button data-a="tens" data-t="' + target + '" data-k="' + k + '" data-v="-0.5" aria-label="' + label + ' : baisser">−</button><span>' + fmtT(v) + ' kg</span><button data-a="tens" data-t="' + target + '" data-k="' + k + '" data-v="0.5" aria-label="' + label + ' : monter">+</button></span></div>';
    };
    return (split ? step("tension", "Montants") + step("tensionCross", "Travers") : step("tension", "Tension")) +
      '<label class="field inline check" style="margin:0"><span><span style="display:block">Tensions différentes</span><span class="small">Montants et travers cordés à des tensions différentes</span></span><input type="checkbox" role="switch" data-split="' + target + '"' + (split ? " checked" : "") + "></label>";
  }
  function setupLabel(m) {
    var r = racket(m.racketId);
    if (!r) return "";
    return r.name + (m.string ? " · " + m.string : "") + (m.tension ? " · " + fmtTension(m) : "");
  }

  // ---------- Routage ----------
  function route() { var h = location.hash.replace(/^#\/?/, ""); return h.split("?")[0]; }
  function go(path) { if (location.hash === "#/" + path) render(); else location.hash = "#/" + path; }
  var stack = [route()];
  function back() { if (stack.length > 1) history.back(); else go(""); }

  window.addEventListener("hashchange", function () {
    if (location.hash.indexOf("#import=") === 0) return handleImportHash();
    var r = route(); UI.sheet = null;
    if (r.split("/")[0] !== "objectif") { UI.goalEdit = false; UI.goalDraft = null; }
    UI.gEdit = null;
    // Position de défilement : gardée pour la page qu'on quitte, retrouvée quand on y revient
    var prev = stack[stack.length - 1], y = 0, backNav = stack.length > 1 && stack[stack.length - 2] === r;
    UI.scrollPos = UI.scrollPos || {};
    if (prev != null) UI.scrollPos[prev] = window.scrollY || document.documentElement.scrollTop || 0;
    if (backNav) { stack.pop(); y = UI.scrollPos[r] || 0; } else if (stack[stack.length - 1] !== r) { stack.push(r); delete UI.scrollPos[r]; }
    UI.menu = false; render(); window.scrollTo(0, y);
    if (y) requestAnimationFrame(function () { window.scrollTo(0, y); }); // après la mise en page (images, graphiques)
  });

  function handleImportHash() {
    var t = "";
    try { t = decodeURIComponent(location.hash.slice("#import=".length)); } catch (e) {}
    history.replaceState(null, "", location.pathname + "#/tenup");
    var pl = T.decode(t);
    if (pl) { importPayload(pl); return; }
    UI.importText = t; UI.importRows = rowsFromText(t);
    if (!S.onboarded) { S.onboarded = true; save(); }
    render();
  }

  // ---------- Rendu ----------
  // Les zones de texte grandissent avec ce qu'on écrit : on voit toujours toute sa note
  function growTa(el) { if (!el || !el.style) return; el.style.height = "auto"; el.style.height = Math.max(el.scrollHeight + 2, 0) + "px"; }
  function render() {
    var r = route(), parts = r.split("/"), html;
    UI.partyKey = null;
    if (!S.scoreV2) {
      // scores importés écrits du point de vue du vainqueur : on les remet dans ton sens
      S.scoreV2 = 1;
      S.matches.concat(S.doubles || []).forEach(function (m) {
        if (!m.score || /ab|abandon/i.test(m.score) || m.wo || !(m.result === "V" || m.result === "D") || isManual(m)) return;
        var st = setsOf(m.score), w = 0, l = 0;
        st.forEach(function (x) { if (x[0] > x[1]) w++; else if (x[0] < x[1]) l++; });
        if ((m.result === "D" && w > l) || (m.result === "V" && l > w)) m.score = m.score.replace(/(\d{1,2})\s*-\s*(\d{1,2})/g, function (_, a, b) { return b + "-" + a; });
      });
      save();
    }
    if (!S.surfV2) { S.surfV2 = 1; S.matches.forEach(function (m) { if (SURF_OLD[m.surface]) m.surface = SURF_OLD[m.surface]; }); save(); }
    if (!S.tenupRank && S.tenup && S.tenup.official && S.tenup.official.classement) { var tr = T.normRank(S.tenup.official.classement); if (tr && E.idx(tr) != null) { S.tenupRank = tr; save(); } }
    if (S.tenup && S.tenup.official && !S.tenup.cal && !S.tenup.calV2) { S.tenup.calV2 = 1; calibrateFromTenup(); save(); }
    // 3.10.1 : le calage ne doit plus inclure les saisies à la main (elles s'annulaient)
    if (S.tenup && S.tenup.official && !S.tenup.calV3) { S.tenup.calV3 = 1; calibrateFromTenup(); save(); }
    // 3.14.2 : les matchs saisis à la main étaient enregistrés avec source « manuel » et passaient pour des matchs Ten'Up
    // 3.16.3 : un « match libre » saisi à la main voulait dire « match d'entraînement » → type à part (le match libre homologué, lui, compte)
    if (!S.amicalV1) { S.amicalV1 = 1; S.matches.forEach(function (m) { if (m.kind === "libre" && isManual(m)) m.kind = "amical"; }); save(); }
    if (S.matches.some(function (m) { return m.source === "manuel"; })) { S.matches.forEach(function (m) { if (m.source === "manuel") m.source = "manual"; }); save(); }
    refreshAhead();
    if (S.ahead && S.onboarded) UI.partyKey = S.ahead.release + ">" + S.ahead.rank;
    if (!S.onboarded && (parts[0] === "" || parts[0] === "palmares" || parts[0] === "courbes")) { location.replace("#/bienvenue"); return; }
    switch (parts[0]) {
      case "bienvenue": html = V.welcome(); break;
      case "projection": html = V.projection(); break;
      case "simu": html = V.simu(); break;
      case "carte": html = V.carte(); break;
      case "palmares": html = V.palmares(); break;
      case "match": html = V.match(parts[1]); break;
      case "entrainement": html = V.entrainement(parts[1]); break;
      case "creneau": html = V.creneau(parts[1]); break;
      case "courbes": html = V.courbes(); break;
      case "perso": html = V.perso(parts[1]); break;
      case "materiel": html = V.materiel(); break;
      case "raquette": html = V.raquette(parts[1]); break;
      case "adversaire": html = V.adversaire(parts.slice(1).join("/")); break;
      case "niveau": html = V.niveau(); break;
      case "gagner": html = V.gagner(); break;
      case "objectif": html = V.objectif(); break;
      case "faf": html = V.faf(); break;
      case "joueur": html = V.joueur(parts[1]); break;
      case "moi": html = V.moi(); break;
      case "tenup": html = V.tenup(); break;
      case "profil": html = V.profil(); break;
      case "donnees": html = V.donnees(); break;
      case "methode": html = V.methode(); break;
      case "apropos": html = V.apropos(); break;
      case "reglages": html = V.reglages(); break;
      case "sante": html = V.sante(parts[1]); break;
      default: html = V.home();
    }
    // Onglet de la section courante, pour les pages en profondeur
    var TOPS = { "": "home", palmares: "palmares", courbes: "courbes", faf: "faf" };
    if (TOPS[parts[0]] != null) UI.lastTab = TOPS[parts[0]];
    // Pages en profondeur (fiche joueur, fiche de match, adversaire…) : la barre d'onglets reste là,
    // un seul tap pour revenir à l'accueil ou au palmarès. Pas sur les formulaires de saisie.
    var DEEP = ["simu", "carte", "joueur", "moi", "adversaire", "niveau", "gagner", "objectif", "projection", "materiel", "tenup", "profil", "reglages", "donnees", "methode", "apropos"];
    var deepOk = DEEP.indexOf(parts[0]) >= 0 || (parts[0] === "match" && parts[1] && parts[1] !== "new");
    if (deepOk && html.indexOf('class="tabbar"') < 0 && S.onboarded && !(parts[0] === "profil" && UI.profEdit)) {
      var sec = { joueur: "faf", moi: "faf", adversaire: "palmares", match: "palmares", niveau: "courbes", gagner: "courbes", projection: "home", simu: "home", carte: "home", objectif: "home" }[parts[0]] || UI.lastTab || "home";
      html = html.replace('<div class="screen"', '<div class="screen has-tabs"') + tabbar(sec);
    }
    if (UI.menu) html += menuHtml();
    if (UI.leaveAsk) html += leaveSheet();
    if (UI.sheet) html += sheetHtml();
    if (!UI.sheet && !UI.leaveAsk && notesDue()) html += notesHtml();
    document.body.classList.toggle("glow", ["", "bienvenue"].indexOf(parts[0]) < 0);
    document.body.classList.toggle("locked", !!(UI.menu || UI.rkMenu || UI.sheet || UI.leaveAsk || UI.notesOpen));
    app.innerHTML = html;
    Array.prototype.forEach.call(app.querySelectorAll("textarea"), growTa);
    var f = app.querySelector("[data-autofocus]"); if (f) f.focus();
    if (UI.fafFocus && parts[0] === "faf") { UI.fafFocus = false; var fq = document.getElementById("ff-q"); if (fq) setTimeout(function () { fq.focus(); }, 120); }
    if (UI.partyKey && S.celebrated !== UI.partyKey) { S.celebrated = UI.partyKey; save(); setTimeout(party, 350); }
    syncWidgets();
  }

  // ---------- Barre « Enregistrer » collée en bas + garde-fou au retour ----------
  function snap(o) { return JSON.stringify(o || {}, function (k, v) { return k.charAt(0) === "_" ? undefined : v; }); }
  function editCtx() {
    var r = route().split("/")[0];
    if ((r === "match" || r === "entrainement") && UI.draft) return { d: UI.draft, save: r === "match" ? "saveMatch" : "saveTraining" };
    if (r === "raquette" && UI.racketDraft) return { d: UI.racketDraft, save: "saveRacket" };
    return null;
  }
  function isDirty() { var e = editCtx(); return !!(e && UI.origKey === e.save + (e.d._for || "") && snap(e.d) !== UI.orig); }
  function saveBar(action, draft, isNew) {
    var key = action + (draft._for || "");
    if (UI.origKey !== key) { UI.origKey = key; UI.orig = snap(draft); }
    var dirty = snap(draft) !== UI.orig;
    return '<div class="savebar-space"></div><div class="savebar' + (dirty ? " dirty" : "") + (isNew ? "" : " existing") + '"><span class="sb-state">' + (isNew ? "Pas encore enregistré" : "Modifications non enregistrées") + "</span>" +
      '<button class="btn primary" data-a="' + action + '"' + (isNew || dirty ? "" : " disabled") + ">Enregistrer</button></div>";
  }
  function refreshSaveBar() {
    var b = app.querySelector(".savebar"); if (!b) return;
    var d = isDirty(), btn = b.querySelector("button");
    b.classList.toggle("dirty", d);
    if (btn && d) btn.disabled = false;
  }
  function leaveSheet() {
    return '<div class="sheet-bg" data-a="leaveStay"></div><div class="sheet" role="dialog" aria-modal="true" aria-label="Modifications non enregistrées"><b>Enregistrer tes modifications ?</b>' +
      '<span class="small">Tu as changé des choses sur cette page.</span>' +
      '<button class="btn primary" data-a="leaveSave">Enregistrer</button><button class="btn soft" data-a="leaveDiscard">Ne pas enregistrer</button><button class="linkbtn" data-a="leaveStay">Rester sur la page</button></div>';
  }
  function topbar(title, sub, right) {
    return '<div class="topbar"><button class="iconbtn" data-a="back" aria-label="Retour">' + I.back + "</button>" +
      '<div class="title" style="flex:1">' + (sub ? '<span class="small">' + esc(sub) + "</span>" : "") + "</div>" + (right || "") + "</div>" +
      (title ? "<h1>" + esc(title) + "</h1>" : "");
  }
  function tabbar(active) {
    var t = function (id, label, icon, path) {
      return '<a class="tab' + (active === id ? " on" : "") + '" href="#/' + path + '"' + (active === id ? ' aria-current="page"' : "") + ">" + icon + label + "</a>";
    };
    return '<div class="tabbar"><nav aria-label="Navigation principale">' +
      t("home", "Accueil", I.home, "") + t("palmares", "Palmarès", I.list, "palmares") +
      '<button class="plus" data-a="menu" aria-label="Ouvrir le menu : ajouter un match, un entraînement…" aria-haspopup="dialog">' + svg('<path d="M12 5v14M5 12h14"/>', 2.8, ' width="26" height="26"') + "</button>" +
      t("courbes", "Courbes", I.chart, "courbes") + t("faf", "Joueurs", I.versus, "faf") +
      "</nav></div>";
  }

  // ---------- Menu + ----------
  function isStandalone() { return (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone; }
  function menuHtml() {
    var item = function (a, ic, t, s, cls, extra) {
      return '<button class="menu-item ' + (cls || "") + '" data-a="' + a + '"' + (extra || "") + '><span class="ic">' + ic + "</span><span><b>" + t + '</b><span class="s">' + s + "</span></span></button>";
    };
    return '<div class="overlay" data-a="closeMenu"></div><div class="sheet menu-sheet" role="dialog" aria-modal="true" aria-label="Menu"><div class="sheet-inner"><span class="grab"></span>' +
      item("newMatch", I.plus, "Ajouter un match", "Score et matériel en 20 secondes") +
      item("newTraining", I.clock, "Ajouter un entraînement", "Compte dans l'usure du cordage") +
      item("goSimu", I.spark, "Et si…", "Simule tes prochains matchs") +
      item("goCarte", I.share, "Ta carte du mois", "Ton mois en une image, en story") +
      item("goTenup", I.link, "Actualiser depuis Ten'Up", S.tenup.lastImport ? "Dernier import le " + fdate(S.tenup.lastImport).replace(/\.$/, "") : "Récupère ton palmarès") +
      (NATIVE ? "" : item("don", I.heart, "Soutenir Montée", "Pour la garder gratuite et sans pub", "don")) +
      (isStandalone() || NATIVE ? "" : item("install", I.phone, "Installer l'application", "Sur ton écran d'accueil")) +
      item("share", I.share, "Partager Montée", "À ton partenaire, à ton club") +
      (CONFIG.CONTACT_EMAIL ? item("contact", I.mail, "Donner mon avis", "Une idée, un bug, un calcul faux ?") : "") +
      '<div class="menu-foot"><button class="linkbtn" data-a="goReglages">Réglages</button><i>·</i><button class="linkbtn" data-a="goApropos">À propos et calcul</button><i>·</i><span>v' + esc(CONFIG.VERSION) + "</span></div></div></div>";
  }

  var V = {};

  // ---------- Bienvenue ----------
  V.welcome = function () {
    var st = UI.wStep || 0, dots = '<div class="w-dots">' + [0, 1, 2].map(function (i) { return '<i class="' + (i === st ? "on" : "") + '"></i>'; }).join("") + "</div>";
    var it = function (ic, t) { return '<div class="alert"><span class="badge ok">' + ic + "</span><span>" + t + "</span></div>"; };
    var P = [
      { k: "1 / 3 · Ta projection", h: "Tu montes ce mois&#8209;ci&nbsp;?<br>On te le dit avant mardi.", l: "Ton bilan recalculé après chaque match, ce qui te manque pour l'échelon suivant, et la date de la sortie.",
        L: [it(I.check, "Ta prochaine sortie de classement, expliquée en une phrase"), it(I.spark, "« Et si… » : simule ton tournoi avant de le jouer")] },
      { k: "2 / 3 · Chaque match analysé", h: "Ce que valait<br>vraiment ton match.", l: "Les points qu'il t'a rapportés, le vrai niveau de ton adversaire, et ce qui a fait la différence : sets serrés, tie-breaks, raquette, cordage.",
        L: [it(I.racket, "Avec quelle raquette, quel cordage et quelle tension tu gagnes"), it(I.chart, "Tes courbes : niveau réel, plafond, mental, records")] },
      { k: "3 / 3 · Ton prochain adversaire", h: "Tape son nom.<br>Prépare ton match.", l: "Tes chances de le battre, son vrai niveau, et un plan de jeu en 3 points tiré de ses résultats et de tes notes.",
        L: [it(I.versus, "Suis tes adversaires : Montée te prévient s'ils montent"), it(svg('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'), "Tout reste sur ton téléphone, rien n'est envoyé")] }
    ][st];
    return '<div class="screen welcome">' +
      '<div class="brand">' + I.logo(30) + "montée" + (st < 2 ? '<button class="linkbtn w-skip" data-a="wSkip">Passer</button>' : "") + "</div>" +
      (st === 0 ? '<div class="welcome-ill">' + (window.MonteeIll ? window.MonteeIll.welcome() : "") + "</div>" : "") +
      '<span class="w-k">' + P.k + "</span>" +
      '<h1 class="xl">' + P.h + "</h1>" +
      '<p class="lead">' + P.l + "</p>" +
      '<div class="stack" style="margin-top:6px">' + P.L.join("") + "</div>" +
      '<div class="spacer"></div>' + dots +
      (st === 2 ? '<p class="small">Montée n\'est pas lié à la FFT ni à Ten\'Up. Le calcul est indicatif : seul le classement officiel fait foi.</p><a class="btn primary" href="#/tenup">C\'est parti</a>' :
        '<button class="btn primary" data-a="wNext">Suivant</button>') +
      "</div>";
  };

  // ---------- Profil ----------
  V.profil = function () {
    var p = S.profile, first = !S.onboarded;
    var opts = '<option value="">Choisis…</option><option value="NC"' + (p.rank === "NC" ? " selected" : "") + ">Non classé</option>" +
      E.ECHELONS.slice(0, 22).map(function (e) { return '<option value="' + e + '"' + (p.rank === e ? " selected" : "") + ">" + e + "</option>"; }).join("") +
      '<option value="N°"' + (p.rank === "N°" ? " selected" : "") + ">Numéroté (Top 100…)</option>";
    var fromTenup = !first && S.tenupRank && S.tenupRank === p.rank && !UI.profEdit;
    if (fromTenup) {
      var me = S.tenup.me || {}, full = [me.prenom, me.nom].filter(Boolean).join(" ") || p.name || "Toi", ph = myPhoto();
      var s0 = '<div class="screen">' + topbar("", "Mon profil");
      s0 += '<div class="card me-card"><button class="me-av" data-a="photoMenu" aria-label="Changer ma photo">' + (ph ? '<img src="' + ph + '" alt="">' : '<span>' + esc(initials(full)) + "</span>") + '<i class="me-cam">' + I.camera + "</i></button>" +
        '<div class="me-id"><b class="me-n">' + esc(full) + "</b>" + (me.club ? '<span class="me-club">' + esc(me.club) + "</span>" : "") + "</div>" +
        (function () {
          // Classement actuel en grand ; meilleur classement et statut à la prochaine sortie en dessous, plus discrets
          var c0 = ctx(), pr0 = c0.proj, d0 = pr0.release ? esc(fdate(pr0.release).replace(/\.$/, "")) : "";
          // Montée déjà acquise : ctx() calcule depuis le nouveau classement, on affiche donc la montée elle-même
          var AH = S.ahead && S.ahead.from === p.rank ? S.ahead : null;
          if (AH) { pr0 = { status: "montee", projected: E.idx(AH.rank) }; d0 = esc(fdate(E.parseDate(AH.release)).replace(/\.$/, "")); }
          var to = pr0.status === "montee" || pr0.status === "descente" ? '<span class="me-to ' + pr0.status + '"><i>' + (pr0.status === "montee" ? "↗" : "↘") + "</i>" + (AH ? esc(AH.rank) : lab(pr0.projected)) + "</span>" : "";
          var st = pr0.status === "montee" ? '<span class="me-st montee"><i>↑</i><span><b>Montée</b> le ' + d0 + "</span></span>"
            : pr0.status === "descente" ? '<span class="me-st descente"><i>↓</i><span><b>Descente</b> le ' + d0 + "</span></span>"
            : pr0.status === "maintien" ? '<span class="me-st maintien"><i>=</i><span><b>Maintien</b> le ' + d0 + "</span></span>" : "";
          return '<div class="me-rk2"><span class="k">Ton classement</span><b class="me-now">' + esc(p.rank) + to + "</b>" +
            (me.meilleur || st ? '<div class="me-sub">' + (me.meilleur ? '<span class="me-best"><span>Meilleur</span><b>' + esc(me.meilleur) + "</b></span>" : "") + st + "</div>" : "") + "</div>";
        })() +
        (S.ahead ? '<span class="me-ahead">' + I.check + " Montée te compte déjà " + esc(S.ahead.rank) + " pour la sortie du " + esc(fdate(S.ahead.release).replace(/\.$/, "")) + "</span>" : "") +
        '<span class="me-foot">' + I.link + " Ten'Up" + (me.licence ? " · licence " + esc(me.licence) : "") + (S.tenup.lastImport ? " · à jour du " + esc(fdate(S.tenup.lastImport).replace(/\.$/, "")) : "") + "</span></div>";
      s0 += goalRow() + matRow() + gameHtml();
      s0 += '<button class="linkbtn" data-a="profEdit" style="align-self:center;margin-top:6px">Corriger mon classement à la main</button>';
      if (UI.photoMenu) s0 += '<div class="sheet-bg" data-a="photoClose"></div><div class="sheet" role="dialog" aria-modal="true" aria-label="Ta photo"><b>Ta photo</b>' +
        '<button class="btn primary" data-a="photoPick">Choisir une photo</button>' +
        (S.profile.photoTU && S.profile.photo ? '<button class="btn soft" data-a="photoTenup">Reprendre celle de Ten\'Up</button>' : "") +
        (ph ? '<button class="btn soft danger" data-a="photoDel">Retirer la photo</button>' : "") +
        '<button class="linkbtn" data-a="photoClose">Annuler</button></div>';
      return s0 + "</div>";
    }
    return '<div class="screen">' + topbar(first ? "Sans Ten'Up" : "Mon profil", first ? "Saisis ton classement" : "") +
      '<div class="form">' +
      '<div class="field"><label for="pf-name">Prénom</label><input id="pf-name" type="text" autocomplete="given-name" data-f="profile.name" value="' + esc(p.name) + '" placeholder="Ex. : Yann"></div>' +
      '<div class="field"><span class="lbl">Classement</span><span class="small" style="margin-top:-4px">Les normes ne sont pas les mêmes chez les hommes et les dames.</span><div class="seg" role="group" aria-label="Classement hommes ou dames">' +
      '<button data-a="sex" data-v="H" class="' + (p.sex === "H" ? "on" : "") + '" aria-pressed="' + (p.sex === "H") + '">Messieurs</button>' +
      '<button data-a="sex" data-v="F" class="' + (p.sex === "F" ? "on" : "") + '" aria-pressed="' + (p.sex === "F") + '">Dames</button></div></div>' +
      '<div class="field inline"><label for="pf-rank">Classement actuel' + (S.ahead ? '<span class="small" style="display:block;font-weight:400">Montée te compte déjà ' + esc(S.ahead.rank) + " pour la sortie du " + esc(fdate(S.ahead.release).replace(/\.$/, "")) + "</span>" : "") + '</label><select id="pf-rank" data-f="profile.rank">' + opts + "</select></div>" +
      (NATIVE ? "" : '<div class="field"><label for="pf-lic">Numéro de licence FFT <span class="small">(facultatif)</span></label><input id="pf-lic" type="text" inputmode="text" autocapitalize="characters" autocorrect="off" spellcheck="false" autocomplete="off" data-f="profile.licence" value="' + esc(p.licence || "") + '" placeholder="Ex. : 1234567 A"><span class="small">Sert seulement au raccourci Ten\'Up, si ta page palmarès n\'est pas ouverte.</span></div>') +
      "</div>" +
      '<p class="small">Mets le classement affiché aujourd\'hui sur Ten\'Up. Tu le changeras après chaque sortie (on te le rappellera).</p>' + (first ? "" : goalRow() + matRow() + gameHtml()) +
      '<div class="spacer"></div>' +
      '<button class="btn primary" data-a="saveProfil"' + (p.rank ? "" : " disabled") + ">" + (first ? "Continuer" : "Enregistrer") + "</button>" +
      "</div>";
  };

  // ---------- Accueil ----------
  V.home = function () {
    var c = ctx(), p = c.proj, s = '<div class="screen has-tabs">';
    var d = today();
    s += '<div class="topbar"><div class="title"><span class="small">' + esc(flong(d).replace(/^./, function (x) { return x.toUpperCase(); })) + '</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">' + (S.profile.name ? "Salut " + esc(S.profile.name) : "Salut") + "</span></div>" +
      '<span class="top-actions"><button class="mechip' + (S.ahead ? " up" : "") + '" data-a="goProfil" aria-label="Mon profil, classement ' + esc(effRank() || "?") + '">' + (function () { var ph = myPhoto(), nm = S.profile.name || ((S.tenup.me || {}).prenom) || ""; return '<span class="av">' + (ph ? '<img src="' + esc(ph) + '" alt="">' : esc((nm.charAt(0) || "?").toUpperCase())) + "</span>"; })() + '<span class="rk">' + esc(effRank() || "?") + "</span>" + svg('<path d="M9 6l6 6-6 6"/>', 2.4) + '</button><button class="iconbtn gearbtn" data-a="goReglages" aria-label="Réglages">' + I.gear + "</button></span></div>";

    if (!S.matches.length) {
      s += '<div class="card balle"><span class="eyebrow">Pour commencer</span><span style="font-size:22px;font-weight:600;letter-spacing:-.02em;line-height:1.2">Récupère tes matchs des 12 derniers mois.</span><span style="font-size:15px">Sans eux, impossible de savoir si tu montes.</span></div>' +
        '<div class="stack"><a class="btn primary" href="#/tenup">' + I.link + " Récupérer depuis Ten'Up</a>" +
        '<button class="btn soft" data-a="newMatch">' + I.plus + " Ajouter un match à la main</button>" +
        '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button></div>';
      return s + "</div>" + tabbar("home");
    }
    if (p.status === "top") {
      s += '<div class="card ink"><span class="eyebrow" style="color:var(--hl)">Joueur numéroté</span><span style="font-size:20px;font-weight:600">Ton classement se joue au concours des meilleurs bilans : Montée ne peut pas le simuler.</span><span style="font-size:14px;color:#E6E0D8">Tes stats, tes courbes et ton matériel restent disponibles.</span></div>';
    } else s += heroHtml(c);
    var X = { verify: verifyHtml(), hc: hcHomeCard(), an: anHomeCard() };
    if (S.syncRecap && S.syncRecap.length && !UI.sheet && !UI.notesOpen) UI.sheet = { k: "recap" }; // récapitulatif après une synchro
    var B = {}; B.official = officialHtml(false);
    B.insight = insightHtml(c);
    if (p.status !== "top") { B.goal = goalLine(c) || goalInvite(c); B.defendAl = defendAlertHtml(c); }
    B.annoter = qaHtml();
    B.carte = cardHomeHtml();
    B.charge = chargeHtml();
    var stale = !S.tenup.lastImport || (today() - E.parseDate(S.tenup.lastImport)) / 864e5 > 6;
    if (stale) B.sync = '<a class="row" href="#/tenup" style="background:var(--card);border-radius:20px;text-decoration:none"><span class="badge ok">' + I.link + '</span><span class="grow"><span class="t">Actualiser depuis Ten\'Up</span><span class="s">' + (S.tenup.lastImport ? "Dernier import le " + esc(fdate(S.tenup.lastImport)) : "Récupère tes matchs et la simulation officielle") + "</span></span>" + I.next + "</a>";

    B.rate = rateCardHtml();
    B.slot = slotCardHtml();
    B.cordage = "";
    bag().forEach(function (r) {
      var st = racketStatus(r);
      if (st.level !== "soon" && st.level !== "change" && st.level !== "broken") return;
      var ref = wearRef(st), pc = Math.max(4, Math.min(100, Math.round(st.min / ref * 100)));
      var title = st.level === "broken" ? "Cordage cassé" : st.level === "change" ? "À recorder" : "Bientôt à recorder";
      var sub = st.level === "broken" ? "Dis-le quand c'est recordé, le compteur repart à zéro." :
        st.type === "mono" && st.min >= MONO_WARN ? (st.level === "change" ? "Au-delà de 20 h, un monofilament a perdu l'essentiel de sa tension : change-le." : "Un monofilament perd sa tension vers 20 h de jeu : songe à le changer.") :
          "Tu casses en général vers " + fmtHours(st.breakAvg.avg) + ".";
      B.cordage += '<div class="card strc' + (st.level === "soon" ? "" : " hot") + '"><a href="#/raquette/' + r.id + '" class="strc-a">' +
        '<span class="strc-top"><span class="eyebrow">' + I.warn + "Cordage · " + esc(r.name) + "</span>" + I.next + "</span>" +
        '<span class="strc-h">' + title + "</span>" +
        (st.level === "broken" ? "" : '<span class="strc-m"><span class="strc-bar"><i style="width:' + pc + '%"></i></span><span class="strc-v"><b>' + fmtHours(st.min) + "</b> / " + fmtHours(ref) + "</span></span>") +
        '<span class="small">' + sub + "</span></a>" +
        '<button class="btn balle small" data-a="quickRestring" data-id="' + r.id + '">J\'ai recordé aujourd\'hui</button></div>';
    });

    // conditions
    if (p.status !== "top") {
      var target = Math.min((c.cur < 0 ? 0 : c.cur) + 1, E.MAX_CALC);
      var winOk = p.next.winAtLevel;
      B.conditions = '<div class="grid2">' +
        '<div class="tile"><span class="badge ' + (winOk ? "ok" : "ko") + '">' + (winOk ? I.check : I.cross) + "</span><span>Victoire contre un " + lab(target) + " ou mieux : <b>" + (winOk ? "acquise" : "il en faut une") + "</b></span></div>" +
        (c.cur <= 0 ? '<div class="tile"><span class="badge ok">' + I.check + "</span><span>Pas de descente possible sous 40</span></div>" :
          '<div class="tile"><span class="badge ' + (p.margin >= 0 ? "ok" : "ko") + '">' + (p.margin >= 0 ? I.check : I.warn) + "</span><span>Maintien à " + esc(effRank()) + " : <b>" + (p.margin >= 0 ? "assuré" : "menacé") + "</b>, " + (p.margin >= 0 ? plural(p.margin, "pt") + " d'avance" : plural(-p.margin, "pt") + " de retard") + "</span></div>") +
        "</div>";
    }
    // victoires qui sortent
    B.drops = "";
    c.drops.forEach(function (x) {
      var when = x.leaves <= p.release ? fdate(x.leaves) : "";
      B.drops += '<div class="alert"><span class="badge ko">' + I.clock + "</span><span><b>Le " + esc(when) + "</b>, ta victoire contre " + esc(x.m.opp || "un " + x.m.oppRank) + " (" + esc(x.m.oppRank) + ", " + esc(fdate(x.m.date)) + ") sort de tes 12 mois. Déjà comptée ici : <span class=\"neg\">−" + x.pts + " pts</span> au bilan " + lab(Math.min((c.cur < 0 ? 0 : c.cur) + 1, E.MAX_CALC)) + ".</span></div>";
    });

    // forme + cordage
    var last = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); });
    var w12 = p.matches || [];
    var nv = w12.filter(function (m) { return m.result === "V"; }).length, nd = w12.filter(function (m) { return m.result === "D"; }).length;
    B.tiles = '<div class="grid2"><a class="tile" href="#/courbes"><span class="k">Forme · 5 derniers</span><span class="form-dots">' +
      last.slice(0, 5).map(function (m) { return '<span class="vd ' + m.result + '" aria-label="' + (m.result === "V" ? "Victoire" : "Défaite") + '">' + m.result + "</span>"; }).join("") +
      "</span><span>" + nv + " V · " + nd + " D sur 12 mois</span></a>";
    var rk = bag().filter(function (r) { return r.main; })[0] || bag()[0];
    if (rk) {
      var st = racketStatus(rk);
      var msg = st.level === "broken" ? '<span class="neg">Cordage cassé</span>' : !st.known ? "Indique quand tu l'as recordée" : st.level === "change" ? '<span class="neg">À recorder</span>' : st.level === "soon" ? '<span class="neg">Bientôt à recorder</span>' : !st.type ? "Précise le type de cordage" : st.type === "mono" ? "à recorder vers 20 h" : "de jeu sur le cordage";
      B.tiles += '<a class="tile" href="#/raquette/' + rk.id + '"><span class="k">' + esc(rk.name) + '</span><span class="v">' + (st.known ? "≈ " + fmtHours(st.min) : "Cordage ?") + "</span><span>" + msg + "</span></a>";
    } else {
      B.tiles += '<a class="tile" href="#/raquette/new"><span class="k">Ton matériel</span><span class="v">Ajoute ta raquette</span><span>Pour savoir avec quoi tu gagnes</span></a>';
    }
    B.tiles += "</div>";
    B.week = weekHtml();

    var todo = S.matches.filter(function (m) { return !annotated(m); }).length;
    if (todo) B.todo = '<button class="row" data-a="palTodo" style="background:var(--card);border-radius:20px"><span class="grow"><span class="t">' + plural(todo, "match", "matchs") + ' à annoter</span><span class="s">Raquette, cordage, ressenti : 20 secondes</span></span>' + I.next + "</button>";
    B.essayer = tryHtml();
    s += homeLayout(B, X);
    s += '<p class="small">Calcul indicatif d\'après le barème FFT. Seul le classement officiel fait foi.</p>';
    return s + "</div>" + tabbar("home");
  };

  // =====================================================================================
  // 3.11 : ton niveau de jeu, ce qui te fait gagner, objectif de saison, points à défendre
  // (carte proactive) et face-à-face avec n'importe quel joueur Ten'Up.
  // =====================================================================================
  function playedOf(ms) { return (ms || []).filter(function (m) { return !m.wo && !m.dbl && (m.result === "V" || m.result === "D") && E.idx(m.oppRank) != null; }); }
  function firstTue(y, m) { var d = new Date(y, m, 1); while (d.getDay() !== 2) d.setDate(d.getDate() + 1); return d; }
  function pct(v, n) { return n ? Math.round(v * 100 / n) : 0; }
  function initials(n) { var p = String(n || "").trim().split(/\s+/); return ((p[0] || "?")[0] + (p.length > 1 ? p[p.length - 1][0] : "")).toUpperCase(); }
  // Probabilité de gagner contre un adversaire `d` échelons au-dessus de soi (calée sur les résultats moyens)
  function lvP(d) { return 1 / (1 + Math.exp(0.75 * d + 0.2)); }
  // Résultat « nuancé » d'un match : une défaite accrochée compte un peu, un set pris davantage
  function tightSets(m) { return setsOf(m.score).filter(function (st, i) { return isTb(st) || isSuperTb(st, i) || Math.abs(st[0] - st[1]) <= 2; }).length; }
  function softY(m) {
    if (m.result === "V") return 1;
    var sets = setsOf(m.score), won = sets.filter(function (st) { return st[0] > st[1]; }).length;
    return won ? 0.3 : tightSets(m) ? 0.15 : 0;
  }
  function frac(p) {
    var F = [[1, 6], [1, 5], [1, 4], [1, 3], [2, 5], [1, 2], [3, 5], [2, 3], [3, 4], [4, 5], [9, 10]], b = F[0];
    F.forEach(function (f) { if (Math.abs(f[0] / f[1] - p) < Math.abs(b[0] / b[1] - p)) b = f; });
    return b[0] + " sur " + b[1];
  }
  // Le niveau qui explique le mieux les résultats (vraisemblance + léger rappel vers le classement officiel)
  function levelFit(ms, cur) {
    var lo = Math.max(0, cur - 4), hi = Math.min(E.MAX_CALC, cur + 4), ll = [];
    for (var L = lo; L <= hi; L++) {
      var s = -Math.pow(L - cur, 2) / 3.5;
      ms.forEach(function (m) { var p = lvP(E.idx(m.oppRank) - L), y = softY(m); s += y * Math.log(p) + (1 - y) * Math.log(1 - p); });
      ll.push({ L: L, s: s });
    }
    var mx = Math.max.apply(null, ll.map(function (x) { return x.s; })), tot = 0, mean = 0, best = ll[0];
    ll.forEach(function (x) { x.w = Math.exp(x.s - mx); tot += x.w; mean += x.w * x.L; if (x.s > best.s) best = x; });
    mean /= tot;
    // Garde-fous : sans aucune perf (victoire contre mieux classé), on ne place pas un joueur au-dessus de son classement ;
    // sans aucune contre-perf (défaite contre moins bien classé), pas en dessous. Battre beaucoup de joueurs moins bien
    // classés ne prouve pas un niveau supérieur.
    var perf = ms.some(function (m) { return m.result === "V" && E.idx(m.oppRank) > cur; });
    var contre = ms.some(function (m) { return m.result === "D" && E.idx(m.oppRank) < cur; });
    if (!perf && mean > cur + 0.25) mean = cur + 0.25;
    if (!contre && mean < cur - 0.25) mean = cur - 0.25;
    var bestL = best.L; if (!perf && bestL > cur) bestL = cur; if (!contre && bestL < cur) bestL = cur;
    return { best: bestL, mean: mean, conf: best.w / tot, n: ms.length };
  }
  // Niveau réel d'un adversaire passé : s'il est monté depuis (classement relu sur Ten'Up), on retient le plus haut.
  // Sert à ne pas compter comme contre-perf une défaite contre un joueur qui jouait déjà au-dessus de son classement.
  function oppEffIdx(m) {
    var o = E.idx(T.normRank(m.oppRank)), p = (S.anPal || {})[m.id];
    if (o == null || !p || !p.rank) return o;
    var r = E.idx(T.normRank(p.rank)); return r != null && r > o ? r : o;
  }
  function effMs(ms) { return (ms || []).map(function (m) { var o = E.idx(T.normRank(m.oppRank)), e = oppEffIdx(m); return e != null && o != null && e > o ? Object.assign({}, m, { oppRank: lab(e), oppRank0: m.oppRank, risen: e - o }) : m; }); }
  function levelNow(c) {
    var cur = c.cur < 0 ? 0 : c.cur, ms = playedOf(effMs(c.proj.matches));
    if (c.proj.status === "top" || ms.length < 8) return { n: ms.length, cur: cur };
    var f = levelFit(ms, cur); f.cur = cur; f.ms = ms; return f;
  }
  function levelHistory(cur) {
    var t = today(), out = [], all = S.matches.filter(counts);
    for (var k = 11; k >= 0; k--) {
      var rel = k ? firstTue(t.getFullYear(), t.getMonth() - k + 1) : t;
      var ms = playedOf(E.windowMatches(all, rel, rel, false));
      out.push({ d: rel, v: ms.length >= 6 ? levelFit(ms, cur).mean : null });
    }
    return out;
  }
  function levelReasons(f) {
    var g = {};
    f.ms.forEach(function (m) { var o = E.idx(m.oppRank); (g[o] = g[o] || { o: o, v: 0, n: 0, tight: 0, sets: 0, scores: [] }); g[o].n++; if (m.result === "V") g[o].v++; else { g[o].tight += tightSets(m); g[o].sets += setsOf(m.score).length; if (tightSets(m)) g[o].scores.push(m.score); } });
    var list = Object.keys(g).map(function (k) { return g[k]; }).filter(function (x) { return x.n >= 2; }).sort(function (a, b) { return b.n - a.n; }).slice(0, 3).sort(function (a, b) { return a.o - b.o; });
    return list.map(function (x) {
      var ex = lvP(x.o - f.cur), r = x.v / x.n, head = "Contre les " + lab(x.o) + ", ";
      if (r - ex >= 0.15) return head + "tu gagnes <b>" + x.v + " match" + (x.v > 1 ? "s" : "") + " sur " + x.n + "</b> : plus qu'on attend d'un " + lab(f.cur) + " (environ " + frac(ex) + ").";
      if (ex - r >= 0.15) {
        var t = head + "<b>" + x.v + " victoire" + (x.v > 1 ? "s" : "") + " sur " + x.n + "</b>, moins qu'on attend d'un " + lab(f.cur) + " (environ " + frac(ex) + ")";
        if (x.sets && x.tight * 2 >= x.sets) return t + ", mais <b>" + x.tight + " sets sur " + x.sets + " serrés</b>" + (x.scores.length ? " (" + esc(x.scores.slice(0, 2).join(", ")) + ")" : "") + " : l'écart est petit.";
        return t + ".";
      }
      return head + "<b>" + x.v + " victoire" + (x.v > 1 ? "s" : "") + " sur " + x.n + "</b> : " + (x.o === f.cur ? "tu joues à leur niveau." : "c'est ce qu'on attend d'un " + lab(f.cur) + ".");
    });
  }
  function levelSlider(f) {
    var lo = f.cur - 2, hi = f.cur + 2, pos = function (v) { return Math.max(0, Math.min(1, (v - lo) / (hi - lo))) * 100; };
    var ticks = ""; for (var L = lo; L <= hi; L++) ticks += '<span style="left:' + pos(L) + '%"' + (L === f.best ? ' class="on"' : "") + ">" + (L < 0 ? "" : lab(L)) + "</span>";
    return '<div class="lv-sl" role="img" aria-label="Niveau de jeu ' + lab(f.best) + ', classement officiel ' + lab(f.cur) + '"><span class="tr"></span><span class="off" style="left:' + pos(f.cur) + '%"></span><span class="dot" style="left:' + pos(f.mean) + '%"></span><div class="tk">' + ticks + "</div></div>";
  }
  function levelWord(f) { return f.conf >= 0.5 ? "solide" : "à confirmer"; }
  // « Tu es classé 15/4, mais tes résultats montrent un niveau 15/3. »
  function levelSentence(f) {
    var d = f.best - f.cur, c = lab(f.cur), b = lab(f.best);
    var t = d > 0 ? "Tu es classé " + c + ", mais tes résultats montrent un niveau " + b + "." : d < 0 ? "Tu es classé " + c + ", mais en ce moment tes résultats montrent plutôt un niveau " + b + "." : "Tu es classé " + c + ", et tes résultats montrent bien ce niveau.";
    return t + (f.conf >= 0.5 ? "" : " À confirmer avec quelques matchs de plus.");
  }
  function niveauCard(c) {
    var f = levelNow(c); if (c.proj.status === "top" || !f.ms) return f.n >= 3 && c.proj.status !== "top" ? '<div class="card" style="gap:6px">' + chead("niveau", "Ton niveau de jeu", "") + '<span style="font-size:15px">Encore ' + plural(8 - f.n, "match", "matchs") + " sur 12 mois et Montée te dit à quel niveau tu joues vraiment.</span></div>" : "";
    var diff = f.best - f.cur;
    return '<a class="card lv-card" href="#/niveau">' + chead("niveau", "Ton niveau de jeu", "D'après tes " + f.n + " matchs sur 12 mois") +
      '<div class="lv-big"><b>' + lab(f.best) + '</b></div><span class="lv-say">' + esc(levelSentence(f)) + "</span>" + levelSlider(f) +
      '<span class="small"><span class="lnk">Pourquoi ' + I.next + "</span></span></a>";
  }
  V.niveau = function () {
    var c = ctx(), f = levelNow(c);
    var s = '<div class="screen">' + topbar("Ton niveau de jeu", "Courbes");
    if (!f.ms) return s + '<div class="card"><b>Pas encore assez de matchs</b><span class="small">Il en faut au moins 8 sur 12 mois (tu en as ' + f.n + ").</span></div></div>";
    s += '<div class="card" style="gap:12px"><span class="eyebrow">D\'après tes ' + f.n + " matchs sur 12 mois</span>" +
      '<div class="lv-big"><b>' + lab(f.best) + '</b></div><span class="lv-say">' + esc(levelSentence(f)) + "</span>" + levelSlider(f) +
      '<span class="small">Le trait noir : ton classement officiel. Le point : le niveau que tes résultats montrent aujourd\'hui.</span></div>';
    var rs = levelReasons(f);
    if (rs.length) s += "<h2>Pourquoi " + lab(f.best) + '</h2><div class="card lv-why">' + rs.map(function (t, i) { return '<div class="lv-r"><span class="n">' + (i + 1) + "</span><span>" + t + "</span></div>"; }).join("") + "</div>";
    var h = levelHistory(f.cur), pts = h.filter(function (x) { return x.v != null; });
    if (pts.length >= 3) {
      var W = 320, H = 120, vals = pts.map(function (x) { return x.v; }).concat([f.cur]), mn = Math.floor(Math.min.apply(null, vals)) - 0.3, mxv = Math.ceil(Math.max.apply(null, vals)) + 0.3;
      var X = function (i) { return 8 + i * (W - 40) / 11; }, Y = function (v) { return 10 + (mxv - v) / (mxv - mn) * (H - 30); };
      var line = h.map(function (x, i) { return x.v == null ? null : X(i).toFixed(1) + "," + Y(x.v).toFixed(1); }).filter(Boolean).join(" ");
      var lastP = h[h.length - 1];
      var svgc = '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Évolution de ton niveau sur 12 mois">' +
        '<line x1="8" x2="' + (W - 32) + '" y1="' + Y(f.cur).toFixed(1) + '" y2="' + Y(f.cur).toFixed(1) + '" stroke="var(--muted)" stroke-dasharray="4 4"/>' +
        '<text x="' + (W - 28) + '" y="' + (Y(f.cur) + 4).toFixed(1) + '" font-size="10" fill="var(--muted)">' + lab(f.cur) + "</text>" +
        '<polyline points="' + line + '" fill="none" stroke="var(--chart-v)" stroke-width="2.6" stroke-linejoin="round" stroke-linecap="round"/>' +
        (lastP.v != null ? '<circle cx="' + X(11).toFixed(1) + '" cy="' + Y(lastP.v).toFixed(1) + '" r="5" fill="var(--chart-v)"/>' + (Math.round(lastP.v) === f.cur ? "" : '<text x="' + (W - 28) + '" y="' + (Y(lastP.v) + 4).toFixed(1) + '" font-size="11" font-weight="700" fill="var(--ink)">' + lab(Math.round(lastP.v)) + "</text>") : "") +
        [0, 4, 8, 11].map(function (i) { return '<text x="' + X(i).toFixed(1) + '" y="' + (H - 4) + '" text-anchor="middle" font-size="10" fill="var(--muted)">' + (i === 11 ? "auj." : MOIS[h[i].d.getMonth()]) + "</text>"; }).join("") + "</svg>";
      var first = pts[0], delta = pts[pts.length - 1].v - first.v, msg;
      if (delta >= 0.4) msg = "<b>En progrès depuis " + MOIS_L[first.d.getMonth()] + ".</b> " + (f.best > f.cur ? "Si ça continue, ton classement officiel devrait rattraper ton niveau." : "Continue comme ça.");
      else if (delta <= -0.4) msg = "<b>Un peu en retrait depuis " + MOIS_L[first.d.getMonth()] + ".</b> Les derniers mois pèsent moins lourd que tu ne crois : une bonne série suffit à repartir.";
      else msg = "<b>Stable depuis " + MOIS_L[first.d.getMonth()] + ".</b> Ton niveau bouge peu d'un mois à l'autre.";
      s += '<h2>Ton évolution</h2><div class="card chart" style="gap:10px">' + svgc + '<span style="font-size:15px;line-height:1.45">' + msg + "</span></div>";
    }
    s += '<p class="small">Calcul : pour chaque match, on regarde ce qu\'on attend d\'un joueur de chaque niveau face à cet adversaire, et on retient le niveau qui colle le mieux à tes résultats. Les sets serrés comptent un peu, même dans une défaite. Il faut au moins 8 matchs.</p>';
    return s + "</div>";
  };

  // ---------- Ce qui te fait gagner ----------
  function gainFactors() {
    var ms = playedOf(ctx().proj.matches).filter(function (m) { return !m.dbl; }), out = [];
    var split = function (list, fn) { var a = { v: 0, n: 0 }, b = { v: 0, n: 0 }; list.forEach(function (m) { var k = fn(m); if (k == null) return; var g = k ? a : b; g.n++; if (m.result === "V") g.v++; }); return [a, b]; };
    // cordage
    var withS = ms.filter(function (m) { return stringAge(m) != null; });
    var cs = split(withS, function (m) { return stringAge(m) < 600; });
    if (cs[0].n >= 4 && cs[1].n >= 4 && Math.abs(pct(cs[0].v, cs[0].n) - pct(cs[1].v, cs[1].n)) >= 20) {
      var fresh = pct(cs[0].v, cs[0].n) > pct(cs[1].v, cs[1].n), main = bag().filter(function (r) { return r.main; })[0], st = main && racketStatus(main);
      out.push({ k: "cordage", tag: "Cordage", title: fresh ? "Tu gagnes plus avec un cordage frais" : "Tu gagnes plus avec un cordage rodé",
        rows: [["Moins de 10 h de jeu", cs[0]], ["Plus de 10 h", cs[1]]],
        note: withS.length + " matchs annotés" + (fresh && st && st.known && st.min >= 600 ? " · Ta " + esc(main.name) + " a " + fmtHours(st.min) + " : recorde avant ton prochain tournoi." : "") + "." });
    }
    // endurance
    var es = split(ms, function (m) { return playMinutes(m) < 105; });
    if (es[0].n >= 4 && es[1].n >= 4 && Math.abs(pct(es[0].v, es[0].n) - pct(es[1].v, es[1].n)) >= 20) {
      var shortB = pct(es[0].v, es[0].n) > pct(es[1].v, es[1].n), three = ms.filter(function (m) { return setsOf(m.score).length === 3; }), tv = three.filter(function (m) { return m.result === "V"; }).length;
      out.push({ k: "endurance", tag: "Endurance", title: shortB ? "Les matchs longs te coûtent" : "Plus ça dure, mieux tu joues",
        rows: [["Matchs de moins de 1 h 45", es[0]], ["Au-delà de 1 h 45", es[1]]],
        note: (three.length >= 3 ? "En trois sets : " + tv + " victoire" + (tv > 1 ? "s" : "") + " sur " + three.length + ". " : "") + "Durées estimées d'après le score, ou corrigées par toi." });
    }
    // rythme : heures de jeu dans les 7 jours avant le match
    var bins = [[0, 120, "0-2 h"], [120, 240, "2-4 h"], [240, 360, "4-6 h"], [360, 1e9, "6 h +"]].map(function (b) { return { lo: b[0], hi: b[1], l: b[2], v: 0, n: 0 }; });
    var sessions = S.matches.concat(S.trainings || []).filter(function (x) { return x.date && !x.wo; });
    ms.forEach(function (m) {
      var d0 = E.parseDate(m.date), from = new Date(d0.getTime()); from.setDate(from.getDate() - 7);
      var f0 = E.iso(from), mins = 0;
      sessions.forEach(function (x) { if (x !== m && x.date >= f0 && x.date < m.date) mins += playMinutes(x); });
      var b = bins.filter(function (b) { return mins >= b.lo && mins < b.hi; })[0]; b.n++; if (m.result === "V") b.v++;
    });
    var allR = pct(ms.filter(function (m) { return m.result === "V"; }).length, ms.length), okB = bins.filter(function (b) { return b.n >= 3; });
    var bestB = okB.slice().sort(function (a, b) { return pct(b.v, b.n) - pct(a.v, a.n); })[0];
    if ((S.trainings || []).length >= 3 && okB.length >= 2 && bestB && pct(bestB.v, bestB.n) - allR >= 15)
      out.push({ k: "rythme", tag: "Rythme", title: "Ta bonne dose : " + bestB.l.replace("-", " à ").replace(" +", " et plus") + " de jeu la semaine d'avant", bins: bins, best: bestB, note: "Taux de victoire selon tes heures de jeu (matchs et entraînements) dans les 7 jours avant le match." });
    var annotated = ms.filter(function (m) { return stringAge(m) != null; }).length;
    return { list: out, n: ms.length, annotated: annotated };
  }
  function factorHtml(x) {
    var s = '<div class="card gf"><span class="gf-tag">' + esc(x.tag) + '</span><b class="gf-t">' + esc(x.title) + "</b>";
    if (x.rows) {
      var best = Math.max(pct(x.rows[0][1].v, x.rows[0][1].n), pct(x.rows[1][1].v, x.rows[1][1].n));
      s += x.rows.map(function (r) { var p = pct(r[1].v, r[1].n); return '<div class="gf-row"><span>' + r[0] + " <span class=\"muted\">· " + r[1].n + " matchs</span></span><b>" + p + ' %</b></div><div class="meter"><span class="track"><span class="fill" style="display:block;width:' + p + "%;background:" + (p === best ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span></div>'; }).join("");
    }
    if (x.bins) {
      s += '<div class="gf-bins">' + x.bins.map(function (b) { var p = pct(b.v, b.n), on = b === x.best; return '<div class="gb' + (on ? " on" : "") + '"><span class="p">' + (b.n ? p + " %" : "–") + '</span><span class="bar" style="height:' + Math.max(6, p * 0.7) + 'px"></span><span class="l">' + b.l + "</span></div>"; }).join("") + "</div>";
    }
    return s + '<span class="small">' + x.note + "</span></div>";
  }
  function gagnerCard() {
    var g = gainFactors(); if (g.n < 6) return "";
    if (!g.list.length) return g.annotated >= 1 ? '<a class="card" href="#/gagner" style="gap:6px;text-decoration:none;color:inherit">' + chead("gagner", "Ce qui te fait gagner", "") + '<span style="font-size:15px">Rien de net pour l\'instant. Annote encore quelques matchs (raquette, ressenti) pour en savoir plus.</span></a>' : "";
    var x = g.list[0];
    return '<a class="card" href="#/gagner" style="gap:8px;text-decoration:none;color:inherit">' + chead("gagner", "Ce qui te fait gagner", "Tes tendances personnelles") + '<span class="gf-tag">' + esc(x.tag) + '</span><b style="font-size:19px;letter-spacing:-.02em;line-height:1.25">' + esc(x.title) + "</b>" +
      '<span class="small">' + (g.list.length > 1 ? "Et " + plural(g.list.length - 1, "autre tendance", "autres tendances") + " · " : "") + '<span class="lnk">Voir le détail ' + I.next + "</span></span></a>";
  }
  V.gagner = function () {
    var g = gainFactors();
    var s = '<div class="screen">' + topbar("Ce qui te fait gagner", "Courbes") + '<p class="lead">Tes tendances personnelles, d\'après tes matchs et tes annotations. Montée n\'en parle que quand l\'écart est net.</p>';
    s += g.list.map(factorHtml).join("");
    var need = Math.max(0, 12 - g.annotated);
    s += '<div class="card gf soft"><span class="gf-tag">' + (g.list.length ? "Bientôt" : "Pas encore assez de données") + '</span><span style="font-size:15px;line-height:1.45">' + (g.list.length < 3 ? "Cordage, durée des matchs, heures de jeu avant le match… " : "") + (need ? "Annote encore " + plural(need, "match", "matchs") + " (raquette, ressenti) pour en savoir plus." : "Continue d'annoter tes matchs et tes entraînements : les tendances s'affinent.") + "</span></div>";
    return s + "</div>";
  };

  // ---------- Objectif de saison ----------
  function goalOptions() {
    var t = today(), y = t.getFullYear(), out = [];
    var add = function (d, l) { if ((d - t) / 864e5 > 60 && out.length < 3 && !out.some(function (o) { return E.iso(o.d) === E.iso(d); })) out.push({ d: d, l: l }); };
    var sept = firstTue(t.getMonth() >= 6 ? y + 1 : y, 8);
    if ((sept - t) / 864e5 < 120) sept = firstTue(sept.getFullYear() + 1, 8);
    add(sept, "Fin de saison · " + MOIS[8] + " " + sept.getFullYear());
    [2, 5].forEach(function (mo) { var d = firstTue(t.getMonth() >= mo ? y + 1 : y, mo); if (d < sept) add(d, MOIS_L[mo].replace(/^./, function (x) { return x.toUpperCase(); }) + " " + d.getFullYear()); });
    return out.sort(function (a, b) { return a.d - b.d; });
  }
  function monthsBetween(a, b) { return Math.max(0, (b - a) / (864e5 * 30.4)); }
  // Combien de victoires contre l'échelon juste en dessous de l'objectif suffiraient (ordre de grandeur)
  function winsFor(c, target) {
    var cur = c.cur < 0 ? 0 : c.cur, base = allMatches(), t = E.iso(today()), lvl = Math.max(0, target - 1);
    for (var n = 1; n <= 12; n++) {
      var fake = []; for (var i = 0; i < n; i++) fake.push({ id: "_g" + i, date: t, result: "V", oppRank: lab(i % 2 === 0 ? target : lvl), kind: "tournoi" });
      var r = E.project(base.concat(fake), c.cur, c.sex, c.opts);
      if (r.projected >= target) return { n: n, lvl: lvl };
    }
    return { n: 13, lvl: lvl };
  }
  function matchRate() { var ms = playedOf(ctx().proj.matches); return ms.length / 12; }
  function feasibility(c, target, by) {
    var w = winsFor(c, target), months = monthsBetween(today(), by), rate = matchRate();
    var me = c.cur < 0 ? 0 : c.cur, ch = (lvP(w.lvl - me) + lvP(target - me)) / 2;
    var expected = months * rate * ch * 1.25; // on progresse en jouant
    var r = expected / Math.max(1, w.n), k = r >= 1.4 ? "easy" : r >= 0.7 ? "ok" : r >= 0.35 ? "hard" : "far";
    var head = { easy: "Dans tes cordes", ok: "Ambitieux mais réaliste", hard: "Très ambitieux", far: "Hors de portée à cette date" }[k];
    var txt = "Il te faut environ <b>" + (w.n > 12 ? "plus de 12 victoires" : plural(w.n, "victoire")) + "</b> contre des " + lab(w.lvl) + " ou " + lab(target) + " d'ici " + MOIS_L[by.getMonth()] + ". " +
      "À ton rythme (" + (rate >= 1 ? "environ " + Math.round(rate) + " match" + (Math.round(rate) > 1 ? "s" : "") + " par mois" : "moins d'un match par mois") + ") et vu tes résultats à ce niveau, " + { easy: "c'est jouable sans forcer.", ok: "c'est jouable.", hard: "il faudra jouer plus ou viser une date plus lointaine.", far: "vise plutôt un échelon de moins ou une date plus lointaine." }[k];
    return { k: k, head: head, txt: txt, wins: w };
  }
  function goalPlan(c) {
    var g = S.goal; if (!g) return null;
    var cur = c.cur < 0 ? 0 : c.cur, by = E.parseDate(g.by), t = today(), p = c.proj, items = [];
    items.push({ kind: "done", when: E.parseDate(g.at), rank: lab(g.from), txt: "Point de départ" });
    items.push({ kind: "today", when: t });
    var reached = Math.max(cur, p.status === "montee" ? p.projected : cur);
    if (reached >= g.rank) {
      items.push({ kind: "goal", when: p.status === "montee" && cur < g.rank ? p.release : t, rank: lab(g.rank), txt: "Objectif atteint. Bravo ! Fixe-toi le suivant." });
      return { items: items, state: "atteint" };
    }
    // jalons : un échelon après l'autre, répartis jusqu'à l'échéance
    var steps = []; for (var r = cur + 1; r <= g.rank; r++) steps.push(r);
    var rels = []; var d = new Date(p.release.getTime()); while (d <= by) { rels.push(new Date(d.getTime())); d = E.nextRelease(d); }
    if (!rels.length) rels.push(by);
    var pl = pistes(c), one = pl.one;
    steps.forEach(function (r, i) {
      var idx = steps.length === 1 ? rels.length - 1 : Math.round(i * (rels.length - 1) / (steps.length - 1));
      if (i === 0 && (p.status === "montee" || (one && pl.goal === "up"))) idx = 0;
      var when = rels[Math.max(0, Math.min(rels.length - 1, idx))], last = r === g.rank;
      var txt = i === 0 && p.status === "montee" ? "Tu y es si rien ne bouge d'ici la sortie." :
        i === 0 && one ? "Une victoire contre un " + lab(one.top) + " suffit. Tu as " + p.next.total + " / " + p.next.norme + " pts." :
          last ? "Environ " + plural(winsFor(c, r).n, "victoire") + " contre des " + lab(r - 1) + " ou " + lab(r) + " d'ici là." :
            "Environ " + plural(winsFor(c, r).n, "victoire") + " contre des " + lab(r - 1) + " ou " + lab(r) + ".";
      items.push({ kind: last ? "goal" : "next", when: when, rank: lab(r), txt: txt });
    });
    // victoires qui sortent : de quoi garder son échelon
    var dz = defendThreat(c, by);
    if (dz) items.push({ kind: "keep", when: dz.rel, rank: "Garder " + lab(dz.calc), txt: dz.short });
    items.sort(function (a, b) { return a.when - b.when || (a.kind === "today" ? -1 : 0); });
    // dans les temps ?
    var span = Math.max(1, by - E.parseDate(g.at)), done = Math.min(1, Math.max(0, (t - E.parseDate(g.at)) / span));
    var expectNow = g.from + (g.rank - g.from) * done, have = p.status === "montee" ? p.projected : cur;
    var state = have >= expectNow + 0.5 ? "en avance" : have >= Math.floor(expectNow + 0.001) ? "dans les temps" : "en retard";
    return { items: items, state: state };
  }
  function goalLine(c) {
    var g = S.goal; if (!g) return "";
    var pl = goalPlan(c), nx = pl.items.filter(function (x) { return x.kind === "next" || x.kind === "goal"; })[0];
    var txt = pl.state === "atteint" ? "Objectif atteint !" : pl.state.replace(/^./, function (x) { return x.toUpperCase(); }) + (nx ? " · prochaine étape : " + nx.rank + " " + (nx.when - today() < 40 * 864e5 ? "le " + fdate(nx.when).replace(/\.$/, "") : "en " + MOIS_L[nx.when.getMonth()]) : "");
    return '<a class="goal-line" href="#/objectif"><span class="gl-tag">Objectif<br><b>' + lab(g.rank) + "</b></span><span class=\"grow\">" + esc(txt) + "</span>" + I.next + "</a>";
  }
  function myPhoto() { var p = S.profile; return p.photo === "none" ? "" : p.photo || p.photoTU || ""; }
  function moiRow() {
    return '<a class="row" href="#/moi" style="background:var(--card);border-radius:20px;margin-top:8px"><span class="grow"><span class="t">Toi contre toi</span><span class="s">Ce que tes adversaires voient de toi</span></span>' + I.next + "</a>";
  }
  function matRow() {
    return '<a class="row" href="#/materiel" style="background:var(--card);border-radius:20px;margin-top:8px"><span class="grow"><span class="t">Ton matériel</span><span class="s">' + (bag().length ? plural(bag().length, "raquette") + " · cordages, entraînements, semaine type" : "Raquettes, cordages, entraînements") + "</span></span>" + I.next + "</a>";
  }
  function goalRow() {
    var g = S.goal;
    return '<a class="row" href="#/objectif" style="background:var(--card);border-radius:20px;margin-top:8px"><span class="grow"><span class="t">' + (g ? "Mon objectif : " + lab(g.rank) : "Fixer mon objectif de saison") + '</span><span class="s">' + (g ? "En " + MOIS_L[E.parseDate(g.by).getMonth()] + " " + E.parseDate(g.by).getFullYear() + " · voir le plan" : "Un classement, une date : Montée trace le chemin") + "</span></span>" + I.next + "</a>";
  }
  function goalInvite(c) {
    if (S.goal || S.goalLater || c.proj.status === "top" || !S.matches.length || c.cur >= E.MAX_CALC) return "";
    return '<div class="card goal-inv"><span class="eyebrow">Nouveau · ton objectif</span><b style="font-size:20px;letter-spacing:-.02em;line-height:1.2">Jusqu\'où tu veux monter cette saison ?</b>' +
      '<span class="small">Choisis un classement et une date : Montée te trace le chemin, sortie par sortie.</span>' +
      '<div class="btn-pair"><a class="btn primary small" href="#/objectif">Fixer mon objectif</a><button class="btn soft small" data-a="goalLater">Plus tard</button></div></div>';
  }
  V.objectif = function () {
    var c = ctx(), cur = c.cur < 0 ? 0 : c.cur, g = S.goal;
    if (g && !UI.goalEdit) {
      var pl = goalPlan(c), by = E.parseDate(g.by);
      var s = '<div class="screen">' + topbar("", "Profil", '<button class="linkbtn" data-a="goalEdit" style="padding:0 6px">Modifier</button>') + "<h1>Objectif " + lab(g.rank) + "</h1>" +
        '<p class="lead" style="margin-top:-6px">En ' + MOIS_L[by.getMonth()] + " " + by.getFullYear() + ' · <b class="gstate ' + pl.state.replace(/ /g, "-") + '">' + pl.state + "</b></p>";
      s += '<div class="tl">' + pl.items.map(function (x) {
        if (x.kind === "today") return '<div class="tl-i today"><span class="tl-d"></span><span class="tl-w">Aujourd\'hui · ' + esc(fdate(x.when).replace(/\.$/, "")) + "</span></div>";
        return '<div class="tl-i ' + x.kind + '"><span class="tl-d">' + (x.kind === "done" ? I.check : x.kind === "goal" ? "★" : "") + '</span><span class="tl-w">' + (x.kind === "goal" ? MOIS_L[x.when.getMonth()] + " " + x.when.getFullYear() + " · objectif" : x.kind === "done" ? MOIS_L[x.when.getMonth()] + " " + x.when.getFullYear() : (x.when - today() < 40 * 864e5 ? fdate(x.when).replace(/\.$/, "") : MOIS_L[x.when.getMonth()])) + '</span><div class="tl-c"><b>' + esc(x.rank) + "</b><span>" + esc(x.txt) + "</span></div></div>";
      }).join("") + "</div>";
      s += '<p class="small">Le plan se recalcule après chaque match. Sur l\'accueil, une ligne te dit si tu es en avance, dans les temps ou en retard.</p>';
      return s + '<button class="linkbtn" data-a="goalDel" style="align-self:center">Retirer mon objectif</button></div>';
    }
    var opts = goalOptions(), d = UI.goalDraft || (UI.goalDraft = { rank: g ? g.rank : Math.min(cur + 1, E.MAX_CALC), by: g ? g.by : E.iso(opts[opts.length - 1].d) });
    var ranks = []; for (var r = cur + 1; r <= Math.min(E.MAX_CALC, cur + 6); r++) ranks.push(r);
    var s2 = '<div class="screen">' + topbar("Ton objectif", "Profil") +
      '<span class="lbl">Quel classement ?</span><div class="chips">' + ranks.map(function (r) { return '<button class="chip' + (d.rank === r ? " on" : "") + '" data-a="goalRank" data-v="' + r + '" aria-pressed="' + (d.rank === r) + '">' + lab(r) + "</button>"; }).join("") + "</div>" +
      '<span class="lbl">Pour quand ?</span><div class="chips">' + opts.map(function (o) { var v = E.iso(o.d); return '<button class="chip' + (d.by === v ? " on" : "") + '" data-a="goalBy" data-v="' + v + '" aria-pressed="' + (d.by === v) + '">' + esc(o.l) + "</button>"; }).join("") + "</div>";
    var f = feasibility(c, d.rank, E.parseDate(d.by));
    s2 += '<div class="card goal-feas ' + f.k + '"><span class="eyebrow">Faisable ?</span><b>' + f.head + '</b><span style="font-size:15px;line-height:1.45">' + f.txt + "</span></div>";
    return s2 + '<div class="spacer"></div><button class="btn primary" data-a="goalSave">Valider mon objectif</button></div>';
  };

  // ---------- Points à défendre : la menace qui arrive ----------
  // La prochaine sortie (après celle qui vient) où, sans nouvelle victoire, une victoire qui sort fait
  // perdre l'échelon (passage sous la norme). Rien sinon.
  function defendThreat(c, until) {
    var p = c.proj; if (p.status === "top" || c.cur <= 0) return null;
    var calc = p.status === "montee" ? p.projected : c.cur, all = allMatches(), rel = E.nextRelease(p.release), limit = until || new Date(today().getTime() + 150 * 864e5);
    var b0 = E.bilanAt(E.windowMatches(all, p.release, today()), calc, c.sex, c.cur, c.opts.extra);
    if (!b0.reached) return null;
    for (var k = 0; k < 6 && rel <= limit; k++) {
      var b = E.bilanAt(E.windowMatches(all, rel, today()), calc, c.sex, c.cur, c.opts.extra);
      if (!b.reached) {
        var gone = b0.counted.filter(function (w) { return w.m.date && E.plus12Months(E.parseDate(w.m.date)) <= rel; }).sort(function (a, b2) { return b2.pts - a.pts; });
        var fake = { id: "_d", date: E.iso(today()), result: "V", oppRank: lab(calc), kind: "tournoi" }, need = null;
        for (var L = Math.max(0, calc - 2); L <= calc + 1 && need == null; L++) { fake.oppRank = lab(L); if (E.bilanAt(E.windowMatches(all.concat([fake]), rel, today()), calc, c.sex, c.cur, c.opts.extra).reached) need = L; }
        var w0 = gone[0];
        return { rel: rel, calc: calc, lost: b0.total - b.total, total: b.total, norme: b.norme, b0: b0.total, gone: gone, need: need,
          short: (w0 ? "Ta victoire contre " + (w0.m.opp && !isAnon(w0.m.opp) ? w0.m.opp : "un " + w0.m.oppRank) + " sort" : "Des victoires sortent") + (need != null ? " : une victoire contre un " + lab(need) + " la remplace." : ".") };
      }
      rel = E.nextRelease(rel);
    }
    return null;
  }
  function defendAlertHtml(c) {
    var z = defendThreat(c); if (!z) return "";
    var w0 = z.gone[0], days = Math.round((z.rel - today()) / 864e5), months = Math.round(days / 30.4);
    var who = w0 ? "Ta victoire contre " + esc(w0.m.opp && !isAnon(w0.m.opp) ? w0.m.opp : "un " + w0.m.oppRank) + " (" + esc(w0.m.oppRank) + ")" + (z.gone.length > 1 ? " et " + plural(z.gone.length - 1, "autre") : "") : "Des victoires";
    var fill = Math.max(4, Math.min(100, z.total / z.norme * 100));
    return '<div class="card defend-al"><span class="eyebrow">Points à défendre</span><div class="da-top"><span class="da-date"><span>Avant le</span><b>' + z.rel.getDate() + "</b><span>" + MOIS[z.rel.getMonth()] + '</span></span><span style="font-size:15px;line-height:1.4"><b>' + who + " sort" + (z.gone.length > 1 ? "ent" : "") + " de tes 12 mois.</b> Sans nouvelle victoire d'ici là, ton bilan perd " + z.lost + " pts et tu repasses sous la norme " + lab(z.calc) + ".</span></div>" +
      '<div class="meter"><span class="track"><span class="fill" style="display:block;width:' + fill + '%;background:var(--terre)"></span></span></div>' +
      '<div class="da-foot"><span>Il reste <b>' + (months >= 2 ? months + " mois" : plural(days, "jour")) + "</b></span>" + (z.need != null ? "<span>1 victoire contre un " + lab(z.need) + " suffit</span>" : "<span>Il te faudra plusieurs victoires</span>") + "</div>" +
      '<a class="lnk" href="#/courbes">Voir ce qui sort à chaque sortie ' + I.next + "</a></div>";
  }

  // ---------- Face-à-face : n'importe quel joueur Ten'Up ----------
  function oppIndex() {
    var g = {};
    S.matches.forEach(function (m) {
      if (!m.opp || isAnon(m.opp) || m.wo || !(m.result === "V" || m.result === "D")) return;
      var k = nameKey(m.opp); if (k.length < 3) return;
      var x = g[k] = g[k] || { key: k, name: m.opp, rank: m.oppRank, v: 0, d: 0, last: "" };
      if (m.result === "V") x.v++; else x.d++;
      if ((m.date || "") > x.last) { x.last = m.date || ""; x.rank = m.oppRank; x.name = m.opp; }
      if (m.oid && (!x.oid || (m.date || "") >= (x.oidAt || ""))) { x.oid = m.oid; x.oidAt = m.date || ""; }
      if (m.olic) x.olic = m.olic; if (m.oclub) x.oclub = m.oclub; if (m.oyear) x.oyear = m.oyear;
    });
    return Object.keys(g).map(function (k) { return g[k]; }).sort(function (a, b) { return a.last < b.last ? 1 : -1; });
  }
  // Suggestions à la saisie : tes adversaires connus, écrits comme Ten'Up les écrit
  function oppDatalist() {
    return '<datalist id="opp-list">' + oppIndex().filter(function (x) { return !isAnon(x.name); }).map(function (x) { return '<option value="' + esc(x.name) + '">' + esc(x.rank || "") + "</option>"; }).join("") + "</datalist>";
  }
  // Découpages possibles d'un nom complet en prénom + nom, le plus probable d'abord
  // (« Julien MOREAU », « MOREAU Julien », « julien moreau », « MOREAU JULIEN », noms composés…)
  function nameSplits(full) {
    var p = String(full || "").replace(/[\u00a0\s]+/g, " ").trim().split(" ").filter(Boolean), out = [], add = function (pre, nom) {
      pre = pre.trim(); nom = nom.trim(); if (pre.length >= 2 && nom.length >= 2 && !out.some(function (o) { return o.prenom === pre && o.nom === nom; })) out.push({ prenom: pre, nom: nom });
    };
    if (p.length < 2) return out;
    var up = function (x) { return x.length > 1 && x === x.toUpperCase() && /[A-ZÀ-Ý]/.test(x); };
    var caps = p.filter(up), low = p.filter(function (x) { return !up(x); });
    if (caps.length && low.length) add(low.join(" "), caps.join(" "));
    add(p[0], p.slice(1).join(" "));
    add(p[p.length - 1], p.slice(0, -1).join(" "));
    if (p.length > 2) { add(p.slice(0, 2).join(" "), p.slice(2).join(" ")); add(p.slice(-2).join(" "), p.slice(0, -2).join(" ")); }
    return out;
  }
  function splitName(full) { return nameSplits(full)[0] || { prenom: "", nom: String(full || "").trim() }; }
  function tenupQuery(kind, args) {
    if (!NATIVE || !Tenup || !Tenup.query) return Promise.resolve({ error: "web" });
    return Tenup.query({ script: T.queryScript(kind, args) }).then(function (r) {
      var pl = T.decode((r && r.data) || "");
      if (!pl) return { error: "Ten'Up n'a pas répondu" };
      return pl;
    }, function (e) { return { error: String((e && e.message) || e) }; });
  }
  // Onglet Joueurs : une barre de recherche (qui filtre aussi tes adversaires), les résultats Ten'Up, tes adversaires
  var BELL = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>';
  var BELL_ON = '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" fill="none"/></svg>';
  function folStar(on, attrs) { return '<span class="fol-tap' + (on ? " on" : "") + '" role="button" aria-label="' + (on ? "Ne plus suivre" : "Suivre : être prévenu s'il monte ou bat un joueur de ton niveau") + '" ' + attrs + ">" + (on ? BELL_ON : BELL) + "</span>"; }
  // Suivre depuis une liste (sans ouvrir la fiche) : la fiche sera lue à la prochaine synchro
  function folAdd(hit, name, rank, club) {
    var id = String(hit.id); S.follow = S.follow || {};
    if (S.follow[id]) { delete S.follow[id]; save(); toast("Tu ne suis plus " + name + "."); render(); return; }
    var sc = (S.scout || {})[id];
    S.follow[id] = { id: id, name: name, rank: rank || "", club: club || "", hit: hit, snap: sc ? folSnap(sc) : null, at: sc ? Date.now() : 0, seen: true };
    save(); toast("Tu suis " + name + "."); render();
    if (LN && !S.notif && LN.requestPermissions) LN.requestPermissions().then(function (p) { S.notif = p && p.display === "granted"; save(); }).catch(function () {});
  }
  function knownRows(q) {
    var known = oppIndex(), k = nameKey(q || ""), qs = String(q || "").trim();
    var list = k ? known.filter(function (x) { return nameKey(x.name).indexOf(k) >= 0 || nameKey(x.name.split(" ").reverse().join(" ")).indexOf(k) >= 0; }) : known;
    var hl = function (nm) { if (!qs) return esc(nm); var i = nm.toLowerCase().indexOf(qs.toLowerCase()); return i < 0 ? esc(nm) : esc(nm.slice(0, i)) + "<mark>" + esc(nm.slice(i, i + qs.length)) + "</mark>" + esc(nm.slice(i + qs.length)); };
    var lim = UI.fafHits && !UI.fafAll && !k ? 5 : 1e9;
    var rows = list.slice(0, lim).map(function (x) {
      var fid = x.oid ? String(x.oid) : "", fon = fid && (S.follow || {})[fid];
      return '<button class="row" data-a="fafKnown" data-v="' + esc(x.key) + '"><span class="ini">' + esc(initials(x.name)) + '</span><span class="grow"><span class="t">' + hl(x.name) + ' <span class="muted" style="font-weight:400">· ' + esc(x.rank || "") + '</span></span><span class="s">' + (x.v ? x.v + " V" : "") + (x.v && x.d ? " · " : "") + (x.d ? x.d + " D" : "") + (x.last ? " · dernier match en " + MOIS[E.parseDate(x.last).getMonth()] : "") + "</span></span>" + (fid ? folStar(fon, 'data-a="followKnown" data-v="' + esc(x.key) + '"') : I.next) + "</button>";
    }).join("");
    var cta = qs.split(/\s+/).length >= 2 && NATIVE ? '<button class="row faf-cta" data-a="fafSearch"><span class="ini cta">' + svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>', 2.2) + '</span><span class="grow"><span class="t">Chercher « ' + esc(qs) + " » sur Ten'Up</span></span></button>" : "";
    var head = '<div class="blk-h"><span class="eyebrow">' + (k ? "Dans tes adversaires" : "Tes adversaires") + '</span><span class="cnt">' + (lim < list.length ? '<button class="linkbtn" data-a="fafAll" style="padding:0;min-height:0;font-size:inherit">' + list.length + " · voir tout ›</button>" : list.length) + "</span></div>";
    if (!known.length) return "";
    return head + (rows || '<span class="small" style="padding:6px 0 10px">Personne de ce nom dans tes adversaires.</span>') + cta;
  }
  V.faf = function () {
    var q = UI.faf || (UI.faf = { q: "" }), busy = UI.fafBusy, done = UI.fafHits && !busy && q.q === q.searched;
    var s = '<div class="screen has-tabs"><div class="topbar"><div class="title"><span class="small">Avant ton prochain match</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">Face-à-face</span></div></div>';
    s += '<div class="sbar' + (done ? " done" : "") + '">' + svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>', 2.2) +
      '<input id="ff-q" type="search" data-ff="q" value="' + esc(q.q || "") + '" placeholder="Prénom et nom" autocomplete="off" autocapitalize="words" enterkeyhint="search">' +
      (!done ? '<button class="sb-clr" data-a="fafClear" aria-label="Effacer"' + (q.q ? "" : " hidden") + ">" + I.cross + "</button>" : "") +
      (done ? '<button class="sb-x" data-a="fafClear" aria-label="Effacer la recherche">' + I.cross + "</button>" : '<button class="sb-go" data-a="fafSearch"' + (busy ? " disabled" : "") + ">" + (busy ? "…" : "Chercher") + "</button>") + "</div>";
    if (!UI.fafHits && !busy) s += '<span class="sb-hint">Prénom en entier : « Nicolas », pas « Nico ».' + (NATIVE ? "" : " La recherche sur Ten\'Up se fait depuis l\'appli.") + "</span>";
    if (UI.fafErr) s += '<div class="alert"><span class="badge ko">' + I.warn + "</span><span>" + esc(UI.fafErr) + "</span></div>";
    if (busy) s += '<div class="blk"><div class="blk-h"><span class="eyebrow">Sur Ten\'Up</span></div><span class="small" style="padding:4px 0 12px">Recherche en cours…</span></div>';
    var keys = {}; oppIndex().forEach(function (x) { keys[x.key] = x; });
    if (UI.fafHits && !busy) {
      if (!UI.fafHits.length) s += '<div class="blk nf-card"><div class="blk-h"><span class="eyebrow">Sur Ten\'Up</span></div><b>Aucun joueur ne correspond à ta recherche</b><span style="font-size:14px;line-height:1.45;padding-bottom:6px">Vérifie l\'orthographe et tape le prénom en entier. Le joueur est peut-être aussi anonyme sur Ten\'Up.</span>' +
        (UI.fafLocal ? '<a class="btn soft small" href="#/adversaire/' + encodeURIComponent(UI.fafLocal) + '" style="align-self:flex-start;background:var(--chip);margin-bottom:8px">Voir ta fiche sur lui</a>' : "") + "</div>";
      else s += '<div class="blk"><div class="blk-h"><span class="eyebrow">Sur Ten\'Up</span><span class="cnt">' + plural(UI.fafHits.length, "joueur") + "</span></div>" + UI.fafHits.map(function (h, i) {
        var nm = [h.prenom, h.nom].filter(Boolean).join(" "), k = nameKey(nm), k2 = nameKey([h.nom, h.prenom].join(" ")), seen = keys[k] || keys[k2];
        var me = S.tenup.id && String(S.tenup.id) === String(h.id), sub = [h.club, h.ville, h.age ? h.age + " ans" : ""].filter(Boolean).join(" · ");
        return '<button class="row hit" data-a="fafOpen" data-v="' + i + '"><span class="rk-b' + (h.rank ? "" : " ini") + '">' + esc(h.rank || initials(nm)) + '</span><span class="grow"><span class="t">' + esc(nm) + "</span>" + (sub ? '<span class="s">' + esc(sub) + "</span>" : "") + "</span>" + (me ? '<span class="tag me">C\'est toi</span>' : (h.played === true || (h.played == null && seen && UI.fafHits.filter(function (o) { return nameKey([o.prenom, o.nom].join(" ")) === nameKey(nm); }).length === 1)) ? '<span class="tag ok">Déjà joué</span>' : "") + (me ? I.next : folStar((S.follow || {})[String(h.id)], 'data-a="followHit" data-v="' + i + '"')) + "</button>";
      }).join("") + "</div>";
    }
    var fl = Object.keys(S.follow || {}).map(function (k) { return S.follow[k]; }), searching = !!(q.q && q.q.trim()) || UI.fafHits;
    var rec = Object.keys(S.scout || {}).map(function (k) { return { id: k, sc: S.scout[k] }; }).filter(function (x) { return x.sc && x.sc.hit && !(S.follow || {})[x.id]; }).sort(function (a, b) { return (b.sc.ts || 0) - (a.sc.ts || 0); }).slice(0, 8);
    var ft = UI.fafTab || (fl.length ? "suivis" : "adv");
    if (searching) ft = "adv";
    if (!searching) s += '<div class="faf-tabs">' + [["suivis", "Suivis", fl.length], ["adv", "Tes adversaires", oppIndex().length], ["rec", "Récents", rec.length]].map(function (x) { return '<button class="' + (ft === x[0] ? "on" : "") + '" data-a="fafTab" data-v="' + x[0] + '">' + x[1] + (x[2] ? " · " + x[2] : "") + "</button>"; }).join("") + "</div>";
    if (ft === "suivis") {
      s += '<div class="blk">' + (fl.length ? fl.sort(function (a, b) { return (b.newsAt || 0) - (a.newsAt || 0); }).map(function (f) {
        var nw = f.news && Date.now() - (f.newsAt || 0) < 14 * 864e5 ? f.news : null, sc = (S.scout || {})[f.id], sn = sc ? folSnap(sc) : f.snap || {};
        // Ce qu'il a fait à son dernier match, pas seulement la date
        var lm = sn.lm, did = lm ? '<b class="fol-did ' + (lm.r === "V" ? "v" : "d") + '">' + (lm.r === "V" ? "a battu" : "a perdu contre") + "</b> un " + esc(lm.rank) + " le " + esc(fdate(lm.date).replace(/\.$/, "")) : sn.last ? "dernier match le " + esc(fdate(sn.last).replace(/\.$/, "")) : "";
        var sub = nw && nw.t ? esc(nw.t) : [esc(f.rank), did, esc(f.club || "")].filter(Boolean).join(" · ");
        return '<button class="row" data-a="folOpen" data-id="' + esc(f.id) + '"><span class="ini">' + esc(initials(f.name)) + '</span><span class="grow"><span class="t">' + esc(f.name) + (nw ? ' <span class="fol-news ' + nw.k + (f.seen ? "" : " unseen") + '">' + esc(nw.tag) + "</span>" : "") + '</span><span class="s">' + sub + '</span></span><span class="fol-star">' + BELL_ON + "</span></button>";
      }).join("") : '<span class="small" style="padding:10px 0">Suis tes adversaires réguliers et ceux que tu vas croiser : touche la cloche à côté d\'un nom, ou « Suivre » sur sa fiche. Tu verras ici quand il joue, monte ou bat un joueur de ton niveau, et tu seras prévenu s\'il monte ou bat un joueur de ton niveau. Il ne sait pas que tu le suis.</span>') + "</div>";
    } else if (ft === "rec") {
      s += '<div class="blk">' + (rec.length ? rec.map(function (x) { var pr = x.sc.profil || {}, nm = [pr.prenom, pr.nom].filter(Boolean).join(" "); return '<button class="row" data-a="recOpen" data-id="' + esc(x.id) + '"><span class="ini">' + esc(initials(nm)) + '</span><span class="grow"><span class="t">' + esc(nm) + ' <span class="muted" style="font-weight:400">· ' + esc(pr.classement || "") + '</span></span><span class="s">' + esc(pr.club || "") + "</span></span>" + I.next + "</button>"; }).join("") : '<span class="small" style="padding:10px 0">Les fiches que tu ouvres apparaîtront ici.</span>') + "</div>";
    } else s += '<div class="blk" id="faf-known">' + knownRows(done ? "" : q.q) + "</div>";
    s += '<p class="small">Montée lit son palmarès sur Ten\'Up avec ta session, comme le site. Rien n\'est publié.</p>';
    return s + "</div>" + tabbar("faf");
  };
  // ---------- Toi contre toi : quand tu te cherches toi-même ----------
  V.moi = function () {
    var c = ctx(), me = c.cur < 0 ? 0 : c.cur, ms = playedOf(c.proj.matches), A = cmpStats(ms, me), st = scoutStats(ms);
    var meN = S.tenup.me || {}, full = [meN.prenom, meN.nom].filter(Boolean).join(" ") || S.profile.name || "Toi", first = S.profile.name || meN.prenom || "toi", ph = myPhoto();
    var av = ph ? '<span class="av-me" style="background-image:url(' + ph + ')"></span>' : '<span class="av-me">' + esc(initials(full)) + "</span>";
    // Le créateur qui se cherche lui-même : la page blague d'abord, sa vraie analyse en un tap
    var meP = { prenom: meN.prenom, nom: meN.nom, club: meN.club, licence: meN.licence || S.profile.licence };
    if (isDev(meP) && !UI.devReal) {
      var tb = UI.plTab === "stats" ? "stats" : "plan";
      return '<div class="screen">' + topbar("", "Face-à-face") + '<div class="pl-head"><span class="ini lg dv-crown">' + esc(initials(full)) + '</span><span class="grow"><span class="pl-n">' + esc(full) + '</span><span class="dv-tag">Créateur de Montée</span></span></div>' +
        '<div class="seg pl-tabs" role="tablist"><button data-a="plTab" data-v="plan" class="' + (tb === "plan" ? "on" : "") + '">Plan de jeu</button><button data-a="plTab" data-v="stats" class="' + (tb === "stats" ? "on" : "") + '">Statistiques</button></div>' +
        devPage(meP, tb, true) + '<button class="btn soft" data-a="devReal">Voir ma vraie analyse « Toi contre toi »</button></div>';
    }
    var s = '<div class="screen">' + topbar("", "Face-à-face");
    s += '<div class="moi-hero"><span class="eyebrow">Toi contre toi</span><b>Au tennis, tu as déjà deux adversaires : celui d\'en face… et toi.</b><span>Voilà ce que verrait un adversaire qui te prépare comme tu prépares les tiens.</span>' +
      '<div class="mirror">' + av + '<span class="vs">VS</span>' + av.replace('class="av-me"', 'class="av-me ghost"') + "</div></div>";
    if (ms.length < 5) return s + '<div class="card"><span style="font-size:15px">Encore quelques matchs et Montée saura ce que tes adversaires voient de toi.</span></div></div>';
    var weak = [], strong = [], pc = function (x) { return x.n ? x.v / x.n : null; };
    if (st.f1.n >= 4 && st.f1.lost / st.f1.n >= 0.5) weak.push({ k: "start", t: "« Le faire démarrer à froid »", s: "Tu perds le premier set dans " + pct(st.f1.lost, st.f1.n) + " % de tes matchs" + (st.f1l.n ? ", et tu n'en renverses que " + st.f1l.v + " sur " + st.f1l.n : "") + ".", q: "perd le premier set" });
    if (st.tb.n >= 3 && pc(st.tb) <= 0.4) weak.push({ k: "tb", t: "« L'emmener au tie-break »", s: st.tb.v + " tie-break" + (st.tb.v > 1 ? "s" : "") + " gagné" + (st.tb.v > 1 ? "s" : "") + " sur " + st.tb.n + ". Ils le savent, maintenant.", q: "se crispe au tie-break" });
    if (st.three.n >= 3 && pc(st.three) <= 0.4) weak.push({ k: "three", t: "« Le faire courir jusqu'au 3e set »", s: "Seulement " + st.three.v + " victoire" + (st.three.v > 1 ? "s" : "") + " sur " + st.three.n + " en trois sets.", q: "baisse de régime au troisième set" });
    if (st.second.n >= 3 && pc(st.second) <= 0.4) weak.push({ k: "dim", t: "« Le jouer le lendemain »", s: (st.second.n - st.second.v) + " défaites sur " + st.second.n + " lors du deuxième match du week-end.", q: "arrive fatigué le dimanche" });
    if (A.weak >= 3) weak.push({ k: "weak", t: "« Ne jamais se croire battu d'avance »", s: "Tu as perdu " + A.weak + " fois contre moins bien classé que toi.", q: "joue petit bras contre moins fort" });
    if (st.three.n >= 3 && pc(st.three) >= 0.6) strong.push({ t: "Le 3e set", s: st.three.v + " gagnés sur " + st.three.n + ". Si ça dure, c'est toi qui gagnes." });
    if (st.tb.n >= 3 && pc(st.tb) >= 0.6) strong.push({ t: "Les fins de set", s: st.tb.v + " tie-breaks gagnés sur " + st.tb.n + "." });
    if (st.f1l.n >= 3 && pc(st.f1l) >= 0.4) strong.push({ t: "Tu ne lâches jamais", s: st.f1l.v + " matchs renversés après un premier set perdu." });
    if (A.perfs >= 2) strong.push({ t: "Tes perfs", s: plural(A.perfs, "victoire") + " contre mieux classé que toi sur 12 mois." });
    var sk = streakOf(S.matches); if (sk && sk.r === "V" && sk.n >= 2) strong.push({ t: "Ta forme", s: sk.n + " victoires de suite : tu es le joueur qu'on n'a pas envie de croiser ce mois-ci." });
    if (A.n && A.v / A.n >= 0.6) strong.push({ t: "Ton bilan", s: pct(A.v, A.n) + " % de victoires sur 12 mois." });
    s += '<div class="card moi-c"><span class="eyebrow" style="color:var(--terre)">Leur plan pour te battre</span>' + (weak.length ? weak.slice(0, 3).map(function (x) { return '<div class="moi-r"><span class="dot-w"></span><span><b>' + esc(x.t) + "</b><span>" + esc(x.s) + "</span></span></div>"; }).join("") : '<div class="moi-r"><span class="dot-w"></span><span><b>« Euh… »</b><span>Ils cherchent encore : pas de point faible net sur tes 12 derniers mois.</span></span></div>') + "</div>";
    s += '<div class="card moi-c"><span class="eyebrow" style="color:var(--gazon)">Ce qu\'ils redoutent chez toi</span>' + (strong.length ? strong.slice(0, 3).map(function (x) { return '<div class="moi-r"><span class="dot-s"></span><span><b>' + esc(x.t) + "</b><span>" + esc(x.s) + "</span></span></div>"; }).join("") : '<div class="moi-r"><span class="dot-s"></span><span><b>Ta marge de progression</b><span>Pas encore d\'arme qui ressort nettement : c\'est le moment d\'en construire une.</span></span></div>') + "</div>";
    var w0 = weak[0];
    s += '<div class="moi-quote">Ton pire adversaire ce mois-ci : le ' + esc(first) + " qui " + (w0 ? esc(w0.q) + " et " : "") + "pense déjà au classement. Ne le laisse pas entrer sur le court.</div>";
    return s + "</div>";
  };

  // Analyse d'un palmarès (du point de vue du joueur) : de quoi bâtir un plan de jeu
  function scoutStats(rows) {
    var ms = rows.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); }), st = { n: ms.length, v: 0, three: { v: 0, n: 0 }, f1l: { v: 0, n: 0 }, f1: { lost: 0, n: 0 }, tb: { v: 0, n: 0 }, sun: { v: 0, n: 0 }, oth: { v: 0, n: 0 }, second: { v: 0, n: 0 }, up: { v: 0, n: 0 } };
    var byDay = {};
    ms.forEach(function (m) { (byDay[m.date] = byDay[m.date] || []).push(m); });
    ms.forEach(function (m) {
      var won = m.result === "V", sets = setsOf(m.score); if (won) st.v++;
      if (sets.length === 3) { st.three.n++; if (won) st.three.v++; }
      if (sets.length) { st.f1.n++; if (sets[0][0] < sets[0][1]) { st.f1.lost++; st.f1l.n++; if (won) st.f1l.v++; } }
      sets.forEach(function (x, i) { if (isTb(x) || isSuperTb(x, i)) { st.tb.n++; if (x[0] > x[1]) st.tb.v++; } });
      var dw = m.date ? E.parseDate(m.date).getDay() : -1, g = dw === 0 ? st.sun : st.oth; g.n++; if (won) g.v++;
      if (m.date) { var prev = E.parseDate(m.date); prev.setDate(prev.getDate() - 1); if (byDay[E.iso(prev)] && m.comp && byDay[E.iso(prev)].some(function (x) { return x.comp === m.comp; })) { st.second.n++; if (won) st.second.v++; } }
    });
    return st;
  }
  function gamePlan(st, rank) {
    var tips = [], ri = E.idx(rank);
    if (st.n < 5) return tips;
    if (st.three.n >= 3 && st.three.v / st.three.n <= 0.35) tips.push({ k: "three", ic: "phys", t: "Tu peux l'avoir au physique", s: "Il ne gagne que " + st.three.v + " de ses " + st.three.n + " matchs en trois sets. Allonge les échanges, fais durer." });
    else if (st.three.n >= 3 && st.three.v / st.three.n >= 0.65) tips.push({ k: "three", ic: "up", t: "Redoutable dans les matchs longs", s: st.three.v + " victoires sur " + st.three.n + " en trois sets : ne le laisse pas s'installer, raccourcis les échanges." });
    if (st.f1.n >= 4 && st.f1.lost / st.f1.n >= 0.5) tips.push({ ic: "clock", t: "Il met du temps à se chauffer", s: "Il perd le premier set dans " + pct(st.f1.lost, st.f1.n) + " % de ses matchs" + (st.f1l.n >= 2 ? (st.f1l.v * 2 >= st.f1l.n ? ", mais en renverse la moitié ou plus" : " et n'en renverse que " + st.f1l.v + " sur " + st.f1l.n) : "") + ". Démarre fort, pas de round d'observation." });
    if (st.tb.n >= 5 && st.tb.v / st.tb.n >= 0.65) tips.push({ k: "tb", ic: "shield", t: "Solide dans les fins de set", s: st.tb.v + " tie-breaks gagnés sur " + st.tb.n + " : évite d'arriver à 6-6, fais la différence avant." });
    else if (st.tb.n >= 5 && st.tb.v / st.tb.n <= 0.35) tips.push({ k: "tb", ic: "shield", t: "Fragile au tie-break", s: "Seulement " + plural(st.tb.v, "tie-break gagné", "tie-breaks gagnés") + " sur " + st.tb.n + " : accroche-toi, le jeu décisif est pour toi." });
    if (st.second.n >= 3 && st.second.v / st.second.n <= 0.4) tips.push({ ic: "down", t: "Moins bien le lendemain", s: "Sur ses tournois, " + (st.second.n - st.second.v) + " défaites sur " + st.second.n + " lors du deuxième match du week-end." });
    else if (st.sun.n >= 6 && st.oth.n >= 6 && pct(st.oth.v, st.oth.n) - pct(st.sun.v, st.sun.n) >= 25) tips.push({ ic: "down", t: "Moins bien le dimanche", s: (st.sun.n - st.sun.v) + " défaites sur " + st.sun.n + " le dimanche, contre " + pct(st.oth.v, st.oth.n) + " % de victoires les autres jours." });
    return tips;
  }
  // ---------- Ton jeu (profil) et celui de l'adversaire : pour adapter le plan de jeu ----------
  var GAME = {
    hand: [["D", "Droitier"], ["G", "Gaucher"]],
    backhand: [["1", "À une main"], ["2", "À deux mains"]],
    style: [["fond", "Attaquant de fond de court"], ["contre", "Contreur, je renvoie tout"], ["filet", "Je monte au filet"], ["service", "Gros service"], ["poly", "Polyvalent"]],
    arms: [["service", "Service"], ["cd", "Coup droit"], ["revers", "Revers"], ["volee", "Volée"], ["physique", "Physique"], ["mental", "Mental"], ["defense", "Défense"]]
  };
  function gameLabel(k, v) { return ((GAME[k] || []).filter(function (x) { return x[0] === v; })[0] || ["", ""])[1]; }
  // Ce que Ten'Up dit (libellés libres) → nos catégories
  function normGame(f) {
    var g = {}; if (!f) return g;
    Object.keys(f).forEach(function (k) {
      var v = String(f[k]), t = (k + " " + v).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      if (/gauch|left|\bg\b/.test(v.toLowerCase()) && /lateral|main|gauch|hand/.test(t)) g.hand = "G";
      else if (/droit|right|\bd\b/.test(v.toLowerCase()) && /lateral|main|droit|hand/.test(t) && !/revers/.test(k.toLowerCase())) g.hand = g.hand || "D";
      if (/revers/.test(t)) { if (/une|1|one|simple/.test(v.toLowerCase())) g.backhand = "1"; else if (/deux|2|two|double/.test(v.toLowerCase())) g.backhand = "2"; }
      if (/style|jeu/.test(k.toLowerCase())) {
        if (/filet|volley|vole|serve.?vol/.test(t)) g.style = "filet";
        else if (/contr|defens|regul|lift|renvo/.test(t)) g.style = "contre";
        else if (/serv/.test(t)) g.style = "service";
        else if (/attaq|offens|punch|fond/.test(t)) g.style = "fond";
        else if (/poly|complet/.test(t)) g.style = "poly";
      }
    });
    return g;
  }
  function myGame() { var a = S.profile.gameTU || {}, b = S.profile.game || {}, f = function (k) { return b[k] != null ? b[k] : a[k] || ""; }; return { hand: f("hand"), backhand: f("backhand"), style: f("style"), arms: b.arms || [] }; }
  var STY_HIS = { fond: "Attaquant de fond", contre: "Contreur", filet: "Monte au filet", service: "Gros service", poly: "Polyvalent" };
  // Carte récapitulative (une fois renseigné) : bien visible, « Modifier » au besoin
  function gameSumHtml(title, items, editKey) {
    return '<div class="card game-sum"><div class="gs-head"><span class="eyebrow">' + esc(title) + '</span><button class="linkbtn" data-a="gEdit" data-v="' + esc(editKey) + '" style="padding:0;min-height:0">Modifier</button></div>' +
      '<div class="gs-grid">' + items.map(function (x) { return '<div class="gs-i' + (x[2] ? " wide" : "") + '"><span class="k">' + esc(x[0]) + "</span><b>" + esc(x[1]) + "</b></div>"; }).join("") + "</div></div>";
  }
  function gameDone(key) { return '<button class="btn primary small" data-a="gDone" style="align-self:flex-end;margin-top:6px">Terminé</button>'; }
  function gameHtml() {
    var g = myGame(), tu = S.profile.gameTU || {};
    var filled = g.hand || g.backhand || g.style || g.arms.length;
    if (filled && UI.gEdit !== "me") {
      var items = [["Main", g.hand ? gameLabel("hand", g.hand) : "?"], ["Revers", g.backhand ? gameLabel("backhand", g.backhand) : "?"]];
      if (g.style) items.push(["Style", gameLabel("style", g.style), true]);
      if (g.arms.length) items.push(["Tes armes", g.arms.map(function (a) { return gameLabel("arms", a); }).join(", "), true]);
      return gameSumHtml("Ton jeu", items, "me");
    }
    var row = function (k, multi) {
      return '<div class="chips">' + GAME[k].map(function (x) {
        var on = multi ? g.arms.indexOf(x[0]) >= 0 : g[k] === x[0];
        return '<button class="chip' + (on ? " on" : "") + '" data-a="' + (multi ? "gameArm" : "gameSet") + '" data-k="' + k + '" data-v="' + x[0] + '" aria-pressed="' + on + '">' + esc(x[1]) + "</button>";
      }).join("") + "</div>";
    };
    var fromTU = Object.keys(tu).length;
    return '<div class="card game-card"><span class="eyebrow" style="color:var(--gazon)">Ton jeu</span><span class="small" style="margin-top:-2px">' + (fromTU ? "En partie repris de ta fiche Ten'Up. " : "") + "Montée s'en sert pour adapter tes plans de jeu face à un adversaire.</span>" +
      '<span class="lbl">Tu joues</span>' + row("hand") + '<span class="lbl">Ton revers</span>' + row("backhand") + '<span class="lbl">Ton style</span>' + row("style") +
      '<span class="lbl">Tes armes <span class="muted" style="font-weight:400">· 3 au plus</span></span>' + row("arms", true) + (filled ? gameDone() : "") + "</div>";
  }
  // Son jeu : Ten'Up ne le donne pas (vérifié le 22 oct. 2026 : rien dans profil-joueur), c'est toi qui le notes
  function oppGame(keys, fiche) {
    var g = normGame(fiche), o = S.oppGame || {}, mine = null;
    keys.forEach(function (k) { if (!mine && o[k]) mine = o[k]; });
    return Object.assign({}, g, mine || {});
  }
  function oppGameItems(g) {
    var it = [];
    if (g.hand) it.push(["Main", gameLabel("hand", g.hand)]);
    if (g.backhand) it.push(["Revers", gameLabel("backhand", g.backhand)]);
    if (g.style) it.push(["Style", STY_HIS[g.style], true]);
    return it;
  }
  function oppGameHtml(key, g, plain) {
    var it = oppGameItems(g);
    if (it.length && UI.gEdit !== key) return gameSumHtml("Son jeu", it, key);
    var STY = Object.keys(STY_HIS).map(function (k) { return [k, STY_HIS[k]]; });
    var row = function (k, opts) { return '<div class="chips">' + opts.map(function (x) { var on = g[k] === x[0]; return '<button class="chip' + (on ? " on" : "") + '" data-a="oppGame" data-id="' + esc(key) + '" data-k="' + k + '" data-v="' + x[0] + '" aria-pressed="' + on + '">' + esc(x[1]) + "</button>"; }).join("") + "</div>"; };
    return '<div class="' + (plain ? "" : "card ") + 'game-card"><span class="eyebrow" style="color:var(--gazon)">Son jeu</span><span class="small">Ce que tu sais de son jeu : le plan de jeu en tient compte.</span>' +
      '<span class="lbl">Il joue</span>' + row("hand", GAME.hand) + '<span class="lbl">Son revers</span>' + row("backhand", GAME.backhand) + '<span class="lbl">Son style</span>' + row("style", STY) + (it.length ? gameDone() : "") + "</div>";
  }
  // Dans la fiche d'un match : replié par défaut, pour ne pas alourdir la saisie
  function oppGameFold(m) {
    if (!m.opp || isAnon(m.opp) || m.wo || nameKey(m.opp).length < 3) return "";
    var key = nameKey(m.opp), g = oppGame([key], null), it = oppGameItems(g);
    if (it.length || UI.gEdit === key) return '<div class="field">' + oppGameHtml(key, g, true) + "</div>";
    return '<div class="field"><button class="og-row" data-a="gEdit" data-v="' + esc(key) + '"><span class="grow"><span class="t">Son jeu <span class="muted" style="font-weight:400">· facultatif</span></span><span class="s">Gaucher ? Revers à une main ? Pour tes plans de jeu</span></span>' + I.next + "</button></div>";
  }
  // Conseils tirés de son jeu (fiche Ten'Up) et du tien
  function gameTips(his, st) {
    var me = myGame(), tips = [], arm = function (a) { return me.arms.indexOf(a) >= 0; };
    if (his.hand === "G") tips.push({ ic: "hand", t: "Il est gaucher", s: me.hand === "G" ? "Gaucher contre gaucher : ses diagonales ressemblent aux tiennes. Cherche son revers en long de ligne." : "Ses balles tournent à l'envers. Son coup droit croisé arrive sur ton revers : joue sur son revers à lui, et attention à son service slicé côté avantage." });
    if (his.backhand === "1") tips.push({ ic: "up", t: "Revers à une main", s: "Envoie des balles hautes et liftées sur son revers : il aura du mal à prendre la balle tôt." + (arm("cd") ? " Ton coup droit est fait pour ça." : "") });
    if (his.style === "filet") tips.push({ ic: "net", t: "Il monte au filet", s: "Garde des balles basses à ses pieds, prépare passings et lobs." + (me.style === "contre" || arm("defense") ? " Ta défense va le pousser à la faute." : "") });
    else if (his.style === "contre") tips.push({ ic: "shield", t: "Il renvoie tout", s: "Sois patient, construis le point" + (arm("volee") || me.style === "filet" ? " et finis au filet sur la balle courte : c'est ton terrain." : ", et avance sur la balle courte.") });
    else if (his.style === "fond" || his.style === "service") tips.push({ ic: "phys", t: his.style === "service" ? "Gros service" : "Il frappe fort du fond", s: (his.style === "service" ? "Recule un peu en retour, bloque, mets la balle dans le court. " : "Ne lui donne pas de rythme : varie avec du slice et des balles lentes. ") + (arm("mental") ? "Reste solide, il finira par forcer." : "") });
    // Tes armes face à ses faiblesses tirées des résultats
    if (arm("physique") && st.three.n >= 3 && st.three.v / st.three.n <= 0.4) tips.push({ k: "three", ic: "phys", t: "Ton physique, son point faible", s: "Il ne gagne que " + st.three.v + " de ses " + st.three.n + " matchs en trois sets. Fais durer, c'est ta force." });
    if (arm("service") && st.tb.n >= 5 && st.tb.v / st.tb.n <= 0.4) tips.push({ k: "tb", ic: "shield", t: "Ton service dans les fins de set", s: "Il perd souvent les tie-breaks (" + st.tb.v + " sur " + st.tb.n + ") : appuie-toi sur ton service quand ça se resserre." });
    return tips;
  }

  // Le match à venir : une estimation qui motive (pas de chiffre décourageant quand il part très favori)
  // Son meilleur classement passé : un ancien mieux classé garde des coups, surtout si c'est récent
  function pastBest(pr) {
    var cur = E.idx(T.normRank(pr && pr.classement)), b = E.idx(T.normRank(pr && pr.meilleur));
    if (cur == null || b == null || b <= cur) return null;
    var t = today(), mill = t.getMonth() >= 8 ? t.getFullYear() + 1 : t.getFullYear(), y = pr.meilleurAn ? +pr.meilleurAn : null;
    return { b: b, lab: T.normRank(pr.meilleur), y: y, age: y ? Math.max(0, mill - y) : null, up: b - cur };
  }
  function matchOdds(rows, rank, mine, best) {
    var c = ctx(), me = c.cur < 0 ? 0 : c.cur, ln = levelNow(c), myL = ln.ms ? ln.mean : me, hi = E.idx(T.normRank(rank));
    if (hi == null || c.proj.status === "top") return null;
    var his = playedOf(rows), hisL = his.length >= 6 ? levelFit(his, hi).mean : hi;
    // Ancien mieux classé il y a 1 ou 2 saisons : son vrai niveau est sûrement entre les deux
    var bestPull = 0;
    if (best && best.age != null && best.age <= 2) { bestPull = Math.min(1.5, best.up * (best.age <= 1 ? 0.35 : 0.2)); if (hisL < hi + bestPull) { bestPull = hi + bestPull - hisL; hisL += bestPull; } else bestPull = 0; }
    // 1. niveaux réels  2. formes du moment (5 derniers matchs)  3. vos matchs directs, qui pèsent lourd
    // Face à face, deux joueurs de même niveau, c'est 50/50 (lvP a un léger biais, utile seulement pour estimer un niveau)
    var p0 = 1 / (1 + Math.exp(0.75 * (hisL - myL))), lg = function (x) { return Math.log(x / (1 - x)); }, ex = function (z) { return 1 / (1 + Math.exp(-z)); };
    var f5 = function (ms) { var q = ms.filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }).slice(0, 5); return q.length >= 3 ? q.filter(function (m) { return m.result === "V"; }).length / q.length : 0.5; };
    var thin = his.length < 3; // pas (ou presque pas) de match pour lui : on ne juge que son classement
    // Preuves directes : ses résultats contre ton classement exact, les tiens contre le sien (lissés vers p0)
    var myAllE = effMs(c.proj.matches), myP = playedOf(myAllE), q1 = his.filter(function (m) { return E.idx(m.oppRank) === me; }), q2 = myP.filter(function (m) { return E.idx(m.oppRank) === hi; });
    var e1 = (q1.filter(function (m) { return m.result === "D"; }).length + 3 * p0) / (q1.length + 3), e2 = (q2.filter(function (m) { return m.result === "V"; }).length + 3 * p0) / (q2.length + 3);
    var pd = (e1 * (q1.length + 3) + e2 * (q2.length + 3)) / (q1.length + q2.length + 6);
    // Tes vrais niveaux intègrent déjà tous ces matchs : les bilans croisés ne font qu'ajuster (sinon on compte deux fois)
    var pb = q1.length + q2.length >= 3 ? ex(0.65 * lg(p0) + 0.35 * lg(Math.max(0.03, Math.min(0.97, pd)))) : p0;
    // Forme pondérée : ses derniers matchs contre des joueurs de ton niveau, les tiens contre des joueurs du sien
    var f5r = function (ms, minL) { var q = playedOf(ms).filter(function (m) { return m.date && E.idx(m.oppRank) >= minL; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }).slice(0, 5); return q.length >= 2 ? q.filter(function (m) { return m.result === "V"; }).length / q.length : null; };
    var hRel = f5r(rows, me - 1), mRel = f5r(myAllE, hi - 1);
    var hN = playedOf(rows).filter(function (m) { return E.idx(m.oppRank) >= me - 1; }).length, mN = myP.filter(function (m) { return E.idx(m.oppRank) >= hi - 1; }).length;
    var pf = thin || hRel == null || mRel == null || hN < 3 || mN < 3 ? pb : ex(lg(pb) + 0.35 * (mRel - hRel));
    // Vos matchs directs : un seul match ne doit pas tout renverser (poids 1 contre 4 pour le reste)
    var v = mine.filter(function (m) { return m.result === "V"; }).length, p = (v + 4 * pf) / (mine.length + 4);
    p = Math.max(0.03, Math.min(0.97, p));
    // Ce qui fait le pourcentage, en points : affiché sous l'anneau pour qu'on comprenne d'où il vient
    var pts = function (x) { return Math.round(x * 100); };
    var parts = [{ l: "Vos vrais niveaux", d: pts(p0) - 50, best: bestPull > 0 }, { l: "Bilans face au classement de l'autre", d: pts(pb) - pts(p0) }, { l: "Formes contre ce niveau", d: pts(pf) - pts(pb) }, { l: mine.length > 1 ? "Vos " + mine.length + " matchs" : "Votre match", d: pts(p) - pts(pf), skip: !mine.length }].filter(function (x) { return !x.skip; });
    var gap = Math.round(myL - hisL); // échelons d'écart réels (positif = tu es au-dessus)
    var gain = 0; try { gain = E.simulateWin(allMatches(), c.cur, c.sex, hi, c.opts).gain; } catch (e) {}
    // « Perf » seulement s'il est mieux classé que toi ; à classement égal ou inférieur, on dit pourquoi il part devant
    var above = hi > me, k = gap >= 6 && p >= 0.85 ? "monde" : p >= 0.85 ? "large" : p >= 0.6 ? "fav" : p >= 0.4 ? "open" : !above ? "adv" : p >= 0.25 ? "coup" : "perf";
    var head = { monde: "Un monde d'écart", large: "Large favori", fav: "À ta portée", open: "Match ouvert", coup: "Un coup à jouer", perf: "Une belle perf à aller chercher", adv: "Il part devant en ce moment" }[k];
    var why = [];
    if (hisL - myL >= 0.4) why.push("ses résultats le placent au-dessus de son classement");
    if (hRel != null && hRel >= 0.6) why.push("il gagne en ce moment contre des joueurs de ton niveau");
    if (mine.length && v * 2 < mine.length) why.push(mine.length === 1 ? "il a gagné votre dernier match" : "il mène " + (mine.length - v) + " – " + v + " dans vos matchs");
    var same = hi === me ? "Vous êtes tous les deux " + lab(me) + " sur le papier" : "Sur le papier, tu es mieux classé que lui";
    var txt = { monde: "Il y a un monde entre vous : il n'y a pas match sur le papier. Sers-toi de ce match pour travailler un point de ton jeu, sans te mettre en danger.",
      large: "Impose ton jeu dès le début. Le seul danger, c'est de te mettre à jouer à son rythme.",
      fav: q1.length >= 2 ? (function () { var w1 = q1.filter(function (m) { return m.result === "V"; }).length; return "Contre les " + lab(me) + ", il est " + w1 + " V – " + (q1.length - w1) + " D cette saison" + (w1 / q1.length <= 0.4 ? " : tu as les armes, joue ton tennis." : " : il sait battre ton classement, ne le prends pas de haut."); })() : me > hi ? "L'avantage du classement est pour toi : impose ton rythme dès les premiers jeux." : "Tu pars avec l'avantage dans vos résultats récents : garde ton plan de jeu.",
      open: "Ça se jouera sur quelques points. Ton plan de jeu peut faire la différence.",
      coup: "Il part favori, mais à ce niveau les écarts sont faibles : environ " + frac(p).replace(" sur ", " match sur ") + " de ce genre bascule de ton côté.",
      perf: "Tu n'as rien à perdre : joue libéré, c'est là qu'on signe ses plus belles victoires.",
      adv: same + (why.length ? ", mais " + why.join(", et ") + "." : ", mais ses résultats récents penchent pour lui.") + " Rien d'insurmontable : à toi d'inverser la tendance." }[k];
    if (thin && k !== "monde") txt += his.length ? " Il n'a que " + plural(his.length, "match", "matchs") + " cette saison : on le juge surtout sur son classement." : " Il n'a joué aucun match cette saison : on le juge seulement sur son classement.";
    return { p: p, k: k, head: head, txt: txt, gain: gain, parts: parts, q1: { v: q1.filter(function (m) { return m.result === "V"; }).length, n: q1.length }, q2: { v: q2.filter(function (m) { return m.result === "V"; }).length, n: q2.length }, hRel: hRel, mRel: mRel, basis: (thin ? "vos classements" + (playedOf(S.matches).length >= 3 ? " et ton niveau" : "") : "vos niveaux, vos formes du moment") + (mine.length ? " et " + (mine.length > 1 ? "vos " + mine.length + " matchs" : "votre match") + " (" + v + " – " + (mine.length - v) + ")" : "") };
  }
  // Sa simulation Ten'Up pour la prochaine sortie : le plus haut échelon dont il atteint la norme
  function simProj(sim, rank) {
    var cur = E.idx(T.normRank(rank)); if (!sim || cur == null) return null;
    var lines = (sim.res || []).map(function (x) { return { i: E.idx(T.normRank(x.c)), pts: x.pts, quota: x.quota }; }).filter(function (x) { return x.i != null; });
    if (!lines.length) return null;
    var known = lines.filter(function (x) { return x.pts != null && x.quota != null; });
    var proj;
    if (known.length) {
      var ok = known.filter(function (x) { return +x.pts >= +x.quota; }).map(function (x) { return x.i; });
      proj = ok.length ? Math.max.apply(null, ok) : Math.min.apply(null, known.map(function (x) { return x.i; })) - 1;
      if (proj < cur && ok.length && ok.indexOf(cur) >= 0) proj = cur;
    } else proj = lines[0].i;
    var atCur = known.filter(function (x) { return x.i === cur; })[0];
    return { cur: cur, proj: proj, dir: proj > cur ? "up" : proj < cur ? "down" : "same", rel: E.nextRelease(today()), margin: atCur ? atCur.pts - atCur.quota : null };
  }
  function simTip(sp, first) {
    if (!sp) return null;
    var c = ctx(), when = "le " + fdate(sp.rel).replace(/\.$/, ""), n = first || "Il";
    if (sp.dir === "down") return { ic: "down", t: "La pression est sur lui", s: "Sa simulation Ten'Up le voit descendre à " + lab(sp.proj) + " " + when + ". C'est lui qui joue son classement : toi, joue libéré." };
    if (sp.dir === "up") {
      var g1 = 0, g2 = 0; try { g1 = E.simulateWin(allMatches(), c.cur, c.sex, sp.cur, c.opts).gain; g2 = E.simulateWin(allMatches(), c.cur, c.sex, sp.proj, c.opts).gain; } catch (e) {}
      return { ic: "up", t: n + " est en forme", s: "Sa simulation Ten'Up le voit monter à " + lab(sp.proj) + " " + when + "." + (g2 > g1 ? " Le battre après la sortie te rapportera encore plus : +" + g2 + " pts au lieu de +" + g1 + "." : " Le battre vaudra une perf.") };
    }
    if (sp.margin != null && sp.margin < 0) return null;
    if (sp.margin != null && sp.margin <= 30) return { ic: "shield", t: "Il est juste pour se maintenir", s: "Il n'a que " + sp.margin + " pts d'avance pour rester " + lab(sp.cur) + ". Une défaite contre toi pourrait le faire basculer : il va jouer crispé, mets-lui de la pression d'entrée." };
    return null;
  }
  // Coaching mental : ce qui compte pendant le match, pas le classement
  function mentalCoach(od, st, mine, sp) {
    var out = [], me = scoutStats(playedOf(ctx().proj.matches)), lastM = mine[0];
    if (od && od.k === "monde") out.push({ t: "Un objectif de jeu, pas de score", s: "Choisis une chose à travailler : 70 % de premières balles, monter au filet sur chaque balle courte, ou tes retours de 2e balle. C'est ça, ton match du jour." });
    else if (od && od.k === "large") out.push({ t: "Impose ton rythme", s: "Joue tes coups à ton tempo dès le premier jeu. Si tu commences à jouer comme lui, le match se resserre." });
    else if (od && od.k === "fav") out.push({ t: "Le piège du favori", s: "Ne pense pas « je dois gagner ». Joue chaque point pour lui-même : le score suivra." });
    else if (od && od.k === "open") out.push({ t: "Les points qui comptent", s: "À 30-30 et sur les balles de break, ralentis : une respiration, un objectif simple, premier service dans le court." });
    else if (od) out.push({ t: "Rien à perdre", s: "Oublie le résultat. Fixe-toi trois intentions de jeu et juge ton match là-dessus, pas sur le score." });
    if (sp && sp.dir === "down") out.push({ t: "Sa pression, pas la tienne", s: "S'il s'énerve ou doute, ne change rien : reste régulier, laisse-le se battre avec son classement." });
    if (lastM) out.push(lastM.result === "V" ? { t: "Tu l'as déjà battu", s: "Rappelle-toi ce qui avait marché le " + fdate(lastM.date).replace(/\.$/, "") + (lastM.score ? " (" + lastM.score + ")" : "") + ". Mais attends-toi à ce qu'il ait changé quelque chose." } :
      { t: "Une revanche, pas une vengeance", s: (tightSets(lastM) ? "La dernière fois c'était serré (" + lastM.score + ") : tu sais que c'est jouable. " : "") + "Ne rejoue pas l'ancien match : joue celui d'aujourd'hui." });
    if (me.f1l.n >= 3 && me.f1l.v / me.f1l.n < 0.3) out.push({ t: "Si tu perds le premier set", s: "Tu n'en as renversé que " + me.f1l.v + " sur " + me.f1l.n + " cette saison. Remets les compteurs à zéro : un set, c'est six jeux, rien de plus." });
    else if (st.f1l.n >= 2 && st.f1l.v * 2 >= st.f1l.n) out.push({ t: "Ne relâche pas", s: "Il revient souvent après un premier set perdu. Si tu le mènes, garde la même intensité jusqu'à la balle de match." });
    if (me.tb.n >= 3 && me.tb.v / me.tb.n < 0.4) out.push({ t: "Au tie-break", s: "Tu en perds plus que tu n'en gagnes (" + me.tb.v + " sur " + me.tb.n + "). Joue grand, au centre, sans chercher le point parfait." });
    out.push({ t: "Entre les points", s: "Raquette dans l'autre main, une grande respiration, une seule intention pour le point suivant." });
    return out.slice(0, 4);
  }
  // ---------- Toi contre lui en chiffres : 8 cartes comparatives ----------
  function cmpStats(ms, own) {
    var p = ms.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D") && E.idx(m.oppRank) != null; });
    var st = scoutStats(p), r = { n: p.length, v: st.v, three: st.three, tb: st.tb, f1l: st.f1l, perfs: 0, weak: 0, mins: 0, nm: 0, lost: 0, sets: 0 };
    p.forEach(function (m) {
      var o = E.idx(m.oppRank);
      if (m.result === "V" && o > own) r.perfs++;
      if (m.result === "D" && o < own) r.weak++;
      var sets = setsOf(m.score); if (sets.length) { r.mins += m.minutes ? +m.minutes : estMinutes(m); r.nm++; }
      sets.forEach(function (x, i) { if (!isSuperTb(x, i)) { r.lost += x[1]; r.sets++; } });
    });
    r.threeP = st.n ? st.three.n / st.n : 0; r.dur = r.nm ? r.mins / r.nm : 0; r.gps = r.sets ? r.lost / r.sets : 0;
    // Profil seulement avec au moins 3 scores connus (sinon 0 set = faux « Bulldozer »)
    r.prof = r.nm < 3 ? "" : r.threeP >= 0.33 || r.dur >= 110 ? "Marathonien" : r.gps <= 3 && r.threeP < 0.25 ? "Bulldozer" : "Régulier";
    return r;
  }
  function formSeries(ms) {
    var t = today(), pts = [], p = ms.filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    for (var k = 5; k >= 0; k--) {
      var d = k ? new Date(t.getFullYear(), t.getMonth() - k + 1, 0) : t, di = E.iso(d);
      var last = p.filter(function (m) { return m.date <= di; }).slice(0, 5);
      pts.push({ d: d, v: last.length >= 3 ? last.filter(function (m) { return m.result === "V"; }).length / last.length : null });
    }
    return pts;
  }
  function weekCounts(ms) {
    var t = today(), out = [0, 0, 0, 0, 0, 0, 0, 0];
    ms.forEach(function (m) { if (!m.date || m.wo || !(m.result === "V" || m.result === "D")) return; var w = Math.floor((t - E.parseDate(m.date)) / (7 * 864e5)); if (w >= 0 && w < 8) out[7 - w]++; });
    return out;
  }
  function streakOf(ms) {
    var p = ms.filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }), n = 0;
    for (var i = 0; i < p.length && p[i].result === p[0].result; i++) n++;
    return p.length ? { r: p[0].result, n: n } : null;
  }
  function compareHtml(o) {
    var c = ctx(), me = c.cur < 0 ? 0 : c.cur, hi = E.idx(T.normRank(o.rank)); if (hi == null || c.proj.status === "top") return "";
    var first = o.first || "Lui", mineAll = S.matches.filter(function (m) { return !m.dbl; }), myMs = playedOf(c.proj.matches);
    var A = cmpStats(myMs, me), B = cmpStats(o.rows, hi), s = '<h2>Toi contre lui en chiffres</h2>';
    var who = function (l, r) { return '<div class="cmp-who"><span class="me">' + l + '</span><span class="him">' + r + "</span></div>"; };
    // 1. vrais niveaux
    var ln = levelNow(c), myL = ln.ms ? ln.mean : me, hp = playedOf(o.rows), hisL = hp.length >= 6 ? levelFit(hp, hi).mean : hi, few = hp.length < 3;
    var lo = Math.max(-1, Math.floor(Math.min(me, hi, myL, hisL)) - 1), up = Math.ceil(Math.max(me, hi, myL, hisL)) + 1, X = function (v) { return Math.max(0, Math.min(100, (v - lo) / (up - lo) * 100)); };
    var dOff = hi - me, dLv = hisL - myL, head = Math.abs(dLv) < 0.5 && Math.abs(dOff) >= 1 ? "Sur le papier, " + plural(Math.abs(dOff), "échelon") + " d'écart. En vrai, presque rien." :
      dLv > dOff + 0.5 ? "Il est plus fort que son classement : méfiance." : dLv < dOff - 0.5 ? "L'écart réel est plus petit que vos classements." : dOff === 0 ? "Même classement, même niveau : match ouvert." : "Vos niveaux collent à vos classements.";
    if (few) head = hp.length ? "Seulement " + plural(hp.length, "match", "matchs") + " pour lui cette saison : trop peu pour juger son niveau." : "Aucun match pour lui cette saison : on ne connaît que son classement.";
    var xa = X(myL), xb = X(hisL), la = xa, lb = xb; if (Math.abs(la - lb) < 26) { var mid = (la + lb) / 2, dir = la <= lb ? -1 : 1; la = mid + dir * 13; lb = mid - dir * 13; }
    var step = up - lo > 8 ? 2 : 1, ticks = ""; for (var L = lo; L <= up; L++) if ((L - lo) % step === 0 || L === me || L === hi) ticks += '<span class="tk" style="left:' + X(L) + '%">' + (L < 0 ? "NC" : lab(L)) + "</span>";
    s += '<div class="card cmp" style="gap:10px"><span class="eyebrow">Vos vrais niveaux</span><span class="cmp-big">' + esc(head) + "</span>" +
      '<div class="lv2"><div class="tr"></div>' + ticks + '<span class="off" style="left:' + X(me) + '%;background:var(--gazon)"></span><span class="off" style="left:' + X(hi) + '%;background:var(--terre)"></span>' +
      '<span class="dot" style="left:' + xa + '%;background:var(--gazon)"></span><span class="dot" style="left:' + xb + '%;background:var(--terre)"></span>' +
      '<span class="lab" style="left:' + Math.max(12, Math.min(88, la)) + '%;color:var(--gazon)">Toi · ' + lab(Math.round(myL)) + '</span><span class="lab" style="left:' + Math.max(12, Math.min(88, lb)) + '%;color:var(--terre)">Lui · ' + (Math.round(hisL) < 0 ? "NC" : lab(Math.round(hisL))) + "</span></div>" +
      '<div class="cmp-legend"><span><i class="bar1"></i>classement officiel</span><span><i class="dot1"></i>niveau d\'après les résultats</span></div>' +
      '<span class="small">Toi : ' + plural(myMs.length, "match", "matchs") + " sur 12 mois. Lui : " + plural(hp.length, "match", "matchs") + " cette saison.</span></div>";
    if (few) s += '<div class="card cmp" style="gap:6px"><span class="eyebrow">Le duel en miroir</span><span style="font-size:15px;line-height:1.45">Pas assez de matchs pour le comparer à toi. Dès qu\'il en aura joué 3 cette saison, tu verras ici vos victoires, perfs, tie-breaks, vos formes, vos profils de match et votre rythme.</span></div>';
    // 2. miroir
    if (!few) {
    var rows = [
      ["Victoires", A.n ? A.v / A.n : 0, B.n ? B.v / B.n : 0, function (x) { return Math.round(x * 100) + " %"; }, "victoires", true],
      ["Perfs", A.perfs, B.perfs, String, "perfs", true],
      ["3es sets gagnés", A.three.n ? A.three.v / A.three.n : -1, B.three.n ? B.three.v / B.three.n : -1, null, "endurance", true, A.three, B.three],
      ["Tie-breaks", A.tb.n ? A.tb.v / A.tb.n : -1, B.tb.n ? B.tb.v / B.tb.n : -1, null, "tie-breaks", true, A.tb, B.tb],
      ["Remontées après 1er set perdu", A.f1l.n ? A.f1l.v / A.f1l.n : -1, B.f1l.n ? B.f1l.v / B.f1l.n : -1, null, "remontées", true, A.f1l, B.f1l],
      ["Défaites contre moins bien classé", A.weak, B.weak, String, "régularité", false]
    ], mine2 = [], his2 = [];
    var mir = rows.map(function (r) {
      var a = r[1], b = r[2], mx = Math.max(a, b, r[3] === String ? 1 : 0.01), better = a < 0 || b < 0 ? 0 : r[5] ? (a > b ? 1 : a < b ? -1 : 0) : (a < b ? 1 : a > b ? -1 : 0);
      if (better > 0) mine2.push(r[4]); else if (better < 0) his2.push(r[4]);
      var fmt = function (v, f) { return f ? (f.n ? f.v + "/" + f.n : "–") : r[3](v); };
      var wa = a < 0 ? 0 : r[5] ? a / mx : (mx ? 1 - a / (mx + 1) * 0.8 : 1), wb = b < 0 ? 0 : r[5] ? b / mx : (mx ? 1 - b / (mx + 1) * 0.8 : 1);
      return '<div class="l"><span class="n">' + fmt(a, r[6]) + '</span><span class="b' + (better > 0 ? " on" : "") + '" style="width:' + Math.max(6, wa * 100) + '%"></span></div><span class="c">' + r[0] + '</span><div class="r"><span class="b' + (better < 0 ? " on" : "") + '" style="width:' + Math.max(6, wb * 100) + '%"></span><span class="n">' + fmt(b, r[7]) + "</span></div>";
    }).join("");
    s += '<div class="card cmp" style="gap:12px"><span class="eyebrow">Le duel en miroir</span>' + who("Toi", esc(first)) + '<div class="mir">' + mir + "</div>" +
      '<div class="cmp-verdict">' + (mine2.length ? '<span class="pill">Toi : ' + mine2.slice(0, 3).join(", ") + "</span>" : "") + (his2.length ? '<span class="pill h">Lui : ' + his2.slice(0, 3).join(", ") + "</span>" : "") + "</div></div>";
    // 3. formes
    var fa = formSeries(myMs), fb = formSeries(o.rows), W = 340, H = 130, xs = function (i) { return 12 + i * (W - 30) / 5; }, ys = function (v) { return 100 - v * 85; };
    var line = function (f, col) { var pts = f.map(function (x, i) { return x.v == null ? null : xs(i).toFixed(1) + "," + ys(x.v).toFixed(1); }).filter(Boolean); if (!pts.length) return ""; var lp = pts[pts.length - 1].split(","); return '<polyline points="' + pts.join(" ") + '" fill="none" stroke="' + col + '" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="' + lp[0] + '" cy="' + lp[1] + '" r="5" fill="' + col + '"/>'; };
    var trend = function (f) { var v = f.filter(function (x) { return x.v != null; }); if (v.length < 2) return ""; var d = v[v.length - 1].v - v[Math.max(0, v.length - 3)].v; return d >= 0.15 ? "en hausse" : d <= -0.15 ? "en baisse" : "stable"; };
    var cross = null; for (var i = 1; i < 6; i++) { if (fa[i].v == null || fb[i].v == null || fa[i - 1].v == null || fb[i - 1].v == null) continue; var d0 = fa[i - 1].v - fb[i - 1].v, d1 = fa[i].v - fb[i].v; if (d0 * d1 < 0) cross = fa[i].d; }
    var l5 = function (ms) { var p = ms.filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }).slice(0, 5); return { v: p.filter(function (m) { return m.result === "V"; }).length, n: p.length }; };
    var a5 = l5(myMs), b5 = l5(o.rows);
    if (fa.some(function (x) { return x.v != null; }) || fb.some(function (x) { return x.v != null; })) {
      s += '<div class="card cmp chart" style="gap:10px"><span class="eyebrow">Vos formes</span>' + who("Toi" + (trend(fa) ? " · " + trend(fa) : ""), esc(first) + (trend(fb) ? " · " + trend(fb) : "")) +
        '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Vos formes sur six mois"><line x1="10" x2="' + (W - 10) + '" y1="' + ys(0.5) + '" y2="' + ys(0.5) + '" stroke="var(--line)" stroke-dasharray="4 4"/><text x="10" y="' + (ys(0.5) + 13) + '" font-size="10" fill="var(--muted)">50 %</text>' +
        line(fb, "var(--terre)") + line(fa, "var(--gazon)") + fa.map(function (x, i) { return i % 1 === 0 ? '<text x="' + xs(i).toFixed(1) + '" y="' + (H - 4) + '" text-anchor="middle" font-size="10" fill="var(--muted)">' + (i === 5 ? "auj." : MOIS[x.d.getMonth()]) + "</text>" : ""; }).join("") + "</svg>" +
        '<span style="font-size:15px;line-height:1.45">' + (cross ? "<b>Les courbes se croisent en " + MOIS_L[cross.getMonth()] + ".</b> " : "") + plural(a5.v, "victoire") + " sur tes " + a5.n + " derniers matchs, lui " + b5.v + " sur " + b5.n + ".</span>" +
        '<span class="small">Victoires sur les 5 derniers matchs, mois par mois. Pour lui, seulement sa saison en cours.</span></div>';
    }
    } // fin des comparaisons (assez de matchs pour lui)
    // 4. l'enjeu
    var sw = null; try { sw = E.simulateWin(allMatches(), c.cur, c.sex, hi, c.opts); } catch (e) {}
    var up1 = sw && sw.after.projected > sw.before.projected && sw.after.status === "montee", g = sw ? sw.gain : 0, sp = o.sp;
    var myTxt = up1 ? "Tu passes la norme " + lab(sw.after.projected) + " : montée le " + fdate(c.proj.release).replace(/\.$/, "") + "." : g > 0 ? "À ton bilan " + lab(Math.min(me + 1, E.MAX_CALC)) + "." : "Pas de points de plus (victoire hors quota), mais une victoire qui compte pour la tête.";
    var hisBig, hisTxt, pressure = 0;
    if (sp && sp.dir === "down") { hisBig = "Descente"; hisTxt = "Sa simulation le voit déjà descendre à " + lab(sp.proj) + ". Une défaite de plus l'enfonce."; pressure = 2; }
    else if (sp && sp.margin != null && sp.margin <= 40) { hisBig = sp.margin + " pts"; hisTxt = "C'est tout ce qu'il a d'avance pour rester " + lab(sp.cur) + ". Une défaite contre toi peut le faire basculer."; pressure = 1; }
    else if (sp && sp.dir === "up") { hisBig = "Montée"; hisTxt = "Il est en route pour " + lab(sp.proj) + ". Une défaite contre toi peut la lui coûter."; pressure = 1; }
    else if (hi != null && me - hi >= 2) { hisBig = "+" + E.BAREME.win(me - hi - 1) + " pts"; hisTxt = "Te battre, ce serait une grosse perf pour lui (" + (me - hi) + " échelons au-dessus). Il n'a rien à perdre : attends-toi à ce qu'il joue libéré."; pressure = -1; }
    else if (hi != null && me - hi === 1) { hisBig = "+" + E.BAREME.win(0) + " pts"; hisTxt = "Te battre, ce serait une perf pour lui : il jouera sans pression."; pressure = -1; }
    else { hisBig = "Tranquille"; hisTxt = "Son classement ne se joue pas sur ce match."; }
    var call = pressure < 0 ? "Il n'a rien à perdre, toi si : ne joue pas le classement, joue chaque point." : pressure >= 1 && !up1 ? "Il a plus à perdre que toi. Joue libéré." : up1 && pressure >= 1 ? "Gros enjeu des deux côtés : celui qui reste calme sur les points importants gagne." : up1 ? "Une victoire te fait monter : joue point par point, pas le score." : "Pas de pression au classement : joue ton jeu.";
    s += '<div class="card cmp" style="gap:10px"><span class="eyebrow">L\'enjeu</span><div class="stk"><div class="a"><span class="k">Si tu gagnes</span><b>+' + g + " pts</b><span>" + esc(myTxt) + '</span></div><div class="z"><span class="k">Pour lui</span><b>' + esc(hisBig) + "</b><span>" + esc(hisTxt) + '</span></div></div><div class="callout">' + esc(call) + "</div></div>";
    // 5. profils
    if (!few) {
    var pm = function (r, cls, nm) { return '<div class="' + cls + '"><span class="tag2">' + nm + (r.prof ? " · " + r.prof : "") + '</span><div class="kv2"><span>En 3 sets</span><b>' + (r.nm ? Math.round(r.threeP * 100) + " %" : "–") + '</b></div><div class="kv2"><span>Durée moy.</span><b>' + (r.dur ? fmtDur(Math.round(r.dur / 5) * 5) : "–") + '</b></div><div class="kv2"><span>Jeux perdus / set</span><b>' + (r.sets ? r.gps.toFixed(1).replace(".", ",") : "–") + "</b></div></div>"; };
    var pt = !A.prof || !B.prof ? "Pas assez de scores connus pour comparer vos profils." : A.prof === "Marathonien" && B.prof === "Bulldozer" ? "Il tue vite les matchs. Si tu tiens le premier set, tu l'emmènes sur ton terrain." : A.prof === "Bulldozer" && B.prof === "Marathonien" ? "Il aime les matchs longs : fais la différence tôt, ne le laisse pas s'installer." :
      A.prof === "Marathonien" && B.prof === "Marathonien" ? "Ça risque d'être long : garde du jus pour le troisième set." : A.prof === "Bulldozer" && B.prof === "Bulldozer" ? "Celui qui frappe le premier prendra l'avantage : démarre fort." : "Profils proches : c'est ton plan de jeu qui fera la différence.";
    s += '<div class="card cmp" style="gap:10px"><span class="eyebrow">Vos profils de match</span><div class="prof">' + pm(A, "me", "Toi") + pm(B, "him", "Lui") + '</div><span style="font-size:14.5px;line-height:1.45">' + esc(pt) + '</span><span class="small">Durées estimées d\'après les scores.</span></div>';
    }
    // 6. matchs croisés
    if (o.common.length) {
      s += '<div class="card cmp cross"><span class="eyebrow">Vos matchs croisés</span>' + o.common.slice(0, 4).map(function (x) {
        var a = x.mine.result === "V", b = x.his.result === "V", ini = initials(x.name);
        var cap = a && b ? "Tous les deux vainqueurs de " + x.name + " (" + (x.rank || "?") + ")" : a && !b ? "Tu as battu " + x.name + " (" + (x.rank || "?") + "), qui l'a battu : avantage toi" : !a && b ? x.name + " (" + (x.rank || "?") + ") : il l'a battu, pas toi" : "Tous les deux battus par " + x.name + " (" + (x.rank || "?") + ")";
        return '<button class="chain-b" data-a="scoutOpp" data-id="' + esc(x.his.oid || "") + '" data-v="' + esc(x.name) + '"><span class="chain"><span class="node me">Toi</span><span class="edge ' + (a ? "v" : "d") + '">' + (a ? "V " : "D ") + esc(x.mine.score || "") + '<i></i></span><span class="node">' + esc(ini) + '</span><span class="edge ' + (b ? "v" : "d") + '"><i></i>' + (b ? "V " : "D ") + esc(x.his.score || "") + '</span><span class="node him">' + esc(initials(o.name)) + '</span></span><span class="chain-n">' + esc(cap) + "</span></button>";
      }).join("") + "</div>";
    }
    if (few) return s;
    // 7. rythme
    var wa = weekCounts(mineAll), wb = weekCounts(o.rows), mxw = Math.max.apply(null, wa.concat(wb).concat([1]));
    var cell = function (n, col) { return '<span class="wc" style="height:' + (n ? 14 + n / mxw * 18 : 8) + 'px' + (n ? ";background:" + col : "") + '">' + (n || "") + "</span>"; };
    var a4 = wa.slice(4).reduce(function (x, y) { return x + y; }, 0), b4 = wb.slice(4).reduce(function (x, y) { return x + y; }, 0);
    var ta = wa.reduce(function (x, y) { return x + y; }, 0), tb = wb.reduce(function (x, y) { return x + y; }, 0);
    var lastB = (function () { for (var k = 7; k >= 0; k--) if (wb[k]) return 7 - k; return 8; })();
    var rt = b4 >= a4 + 3 ? "<b>" + plural(b4, "match", "matchs") + " en 4 semaines pour lui.</b> Il enchaîne : la fraîcheur peut être de ton côté." : lastB >= 4 ? "<b>Pas de match depuis " + (lastB >= 8 ? "plus de 2 mois" : lastB + " semaines") + " pour lui.</b> Il manquera peut-être de rythme : mets de l'intensité d'entrée." : a4 === 0 ? "<b>Tu n'as pas joué depuis un moment.</b> Fais un entraînement en match avant." : a4 >= b4 + 3 ? "<b>Tu joues plus que lui en ce moment.</b> Le rythme est de ton côté." :
      tb >= ta + 3 && tb >= ta * 1.5 ? "<b>" + plural(tb, "match", "matchs") + " pour lui sur 8 semaines, " + ta + " pour toi.</b> Il a plus de rythme de match : sois dedans dès le premier jeu." :
      ta >= tb + 3 && ta >= tb * 1.5 ? "<b>" + plural(ta, "match", "matchs") + " pour toi sur 8 semaines, " + tb + " pour lui.</b> Le rythme est de ton côté." : "Vous jouez à peu près au même rythme.";
    s += '<div class="card cmp" style="gap:10px"><span class="eyebrow">Le rythme · 8 dernières semaines</span><div class="wk"><span class="lb" style="color:var(--gazon)">Toi</span>' + wa.map(function (n) { return cell(n, "var(--gazon)"); }).join("") + '<span class="lb" style="color:var(--terre)">Lui</span>' + wb.map(function (n) { return cell(n, "var(--terre)"); }).join("") + '</div><span style="font-size:14.5px;line-height:1.45">' + rt + "</span></div>";
    // 8. séries
    var sa = streakOf(myMs.length ? mineAll : []), sb = streakOf(o.rows);
    var ser = function (x, nm, cls) { return '<div><span class="eyebrow ' + cls + '">' + nm + '</span>' + (x ? '<span class="form-dots">' + new Array(Math.min(x.n, 6) + 1).join('<span class="vd ' + x.r + '">' + x.r + "</span>") + "</span><b>" + (x.n > 1 ? x.n + " " + (x.r === "V" ? "victoires" : "défaites") + " de suite" : x.r === "V" ? "Vient de gagner" : "Vient de perdre") + "</b>" : '<span class="small">Pas encore de match</span>') + "</div>"; };
    s += '<div class="ser">' + ser(sa, "Toi", "me") + ser(sb, esc(first), "him") + "</div>";
    return s;
  }
  var GP_IC = { hand: '<path d="M8 13V5a1.5 1.5 0 0 1 3 0v6M11 10V4a1.5 1.5 0 0 1 3 0v6M14 10V5.5a1.5 1.5 0 0 1 3 0V14c0 4-3 7-7 7-3 0-5-2-6.5-5l-1.8-3.2a1.5 1.5 0 0 1 2.6-1.5L8 13"/>', net: '<path d="M3 20V8M21 20V8M3 8h18M3 12h18M3 16h18M8 8v12M13 8v12M18 8v12"/>', phys: '<path d="M3 12h4l3-8 4 16 3-8h4"/>', up: '<path d="M12 19V5M5 12l7-7 7 7"/>', down: '<path d="M12 5v14M5 12l7 7 7-7"/>', clock: '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M10 2h4"/>', shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>' };
  // ================= Face-à-face (refonte 3.17) : statistiques miroir et plan de jeu « coach » =================
  // Toutes les phrases viennent d'un chiffre ; rien ne s'affiche sans assez de matchs.
  function ffStats(rows, own) {
    var p = playedOf(rows).slice().sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; });
    var r = { n: p.length, v: 0, gw: 0, gl: 0, sets: 0, close: { v: 0, n: 0 }, three: { v: 0, n: 0 }, tb: { v: 0, n: 0 }, two: { v: 0, n: 0 }, bag: 0, scored: 0,
      up: { v: 0, n: 0 }, eq: { v: 0, n: 0 }, dn: { v: 0, n: 0 }, f1: { w: 0, n: 0 }, f1l: { v: 0, n: 0 }, f1w: { l: 0, n: 0 }, team: { v: 0, n: 0 }, tour: { v: 0, n: 0 },
      best: null, worst: null, weakAfterSet: 0, last: p, own: own };
    p.forEach(function (m) {
      var won = m.result === "V", o = E.idx(m.oppRank), sets = setsOf(m.score);
      if (won) r.v++;
      var g = o > own ? r.up : o === own ? r.eq : r.dn; g.n++; if (won) g.v++;
      var t = m.kind === "equipes" ? r.team : r.tour; t.n++; if (won) t.v++;
      if (won && (!r.best || o > E.idx(r.best.oppRank))) r.best = m;
      if (!won && (!r.worst || o < E.idx(r.worst.oppRank))) r.worst = m;
      if (!sets.length) return;
      r.scored++;
      sets.forEach(function (x, i) {
        if (isSuperTb(x, i)) { r.tb.n++; if (x[0] > x[1]) r.tb.v++; return; }
        r.gw += x[0]; r.gl += x[1]; r.sets++;
        if (isTb(x)) { r.tb.n++; if (x[0] > x[1]) r.tb.v++; }
        if ((x[0] === 7 || x[1] === 7) && Math.abs(x[0] - x[1]) <= 2) { r.close.n++; if (x[0] > x[1]) r.close.v++; }
        if (x[0] >= 6 && x[1] <= 2) r.bag++;
      });
      if (sets.length === 3) { r.three.n++; if (won) r.three.v++; }
      if (won) { r.two.n++; if (sets.length === 2) r.two.v++; }
      r.f1.n++;
      if (sets[0][0] > sets[0][1]) { r.f1.w++; r.f1w.n++; if (!won) { r.f1w.l++; if (o < own) r.weakAfterSet++; } }
      else { r.f1l.n++; if (won) r.f1l.v++; }
    });
    r.weak = r.dn.n - r.dn.v;
    var l5 = p.slice(0, 5); r.form = { v: l5.filter(function (m) { return m.result === "V"; }).length, n: l5.length };
    return r;
  }
  function ffRate(x) { return x && x.n ? x.v / x.n : null; }
  function ffPct(x) { return Math.round(x * 100) + " %"; }
  function ffFirst(pr) { return pr.prenom ? String(pr.prenom).split(/[\s-]/)[0].charAt(0).toUpperCase() + String(pr.prenom).split(/[\s-]/)[0].slice(1).toLowerCase() : "Lui"; }
  function ffMyIni() { var me = S.tenup.me || {}; return initials([me.prenom || S.profile.name || "", me.nom || ""].join(" ").trim() || "Moi"); }
  function ffMonth(d) { return d ? MOIS[E.parseDate(d).getMonth()] : ""; }
  function ffNum(x) { return (Math.round(x * 10) / 10).toString().replace(".", ","); }
  // Duel : deux barres Toi / Lui, la meilleure en couleur
  function ffDuel(a, b, fa, fb, win, wa, wb) {
    var bar = function (w, cls) { return '<div class="ff-bar"><i class="' + cls + '" style="width:' + Math.max(3, Math.min(100, Math.round(w * 100))) + '%"></i></div>'; };
    return '<div class="ff-duel"><span class="who">Toi</span>' + bar(wa != null ? wa : a, win > 0 ? "g" : "q") + '<span class="v">' + fa + '</span><span class="who">Lui</span>' + bar(wb != null ? wb : b, win < 0 ? "t" : "q") + '<span class="v">' + fb + "</span></div>";
  }
  function ffBadge(k, txt) { return '<span class="ff-badge ' + k + '">' + esc(txt) + "</span>"; }

  // Critères comparés (rapport de force + cartes de duels)
  function ffCriteria(A, B, D) {
    var Ab = D.Ab, Bb = D.Bb, bn = D.band ? "contre des " + lab(Math.max(0, D.band.lo)) + " à " + lab(Math.min(E.MAX_CALC, D.band.hi)) : "";
    var out = [], add = function (k, label, a, b, okA, okB, thr, lowerBetter, fa, fb, group, note, wa, wb) {
      if (!okA || !okB || a == null || b == null) return;
      var d = lowerBetter ? b - a : a - b, win = Math.abs(d) < thr ? 0 : d > 0 ? 1 : -1;
      out.push({ k: k, label: label, a: a, b: b, win: win, margin: Math.abs(d), fa: fa, fb: fb, group: group, note: note || "", wa: wa, wb: wb });
    };
    var frac2 = function (x) { return x.v + "/" + x.n; };
    // Le plus parlant d'abord : chacun face au classement de l'autre
    var xm = D.xMe, xh = D.xHim;
    if (xm.n >= 2 && xh.n >= 2) add("cross", "Face au classement de l'autre", xm.v / xm.n, xh.v / xh.n, true, true, 0.15, false, xm.v + "-" + (xm.n - xm.v), xh.v + "-" + (xh.n - xh.v), "gagne", "toi contre des " + lab(D.hi) + ", lui contre des " + lab(D.me));
    var oA = A, oB = B; A = Ab; B = Bb;
    add("wins", "Matchs gagnés", ffRate(A), ffRate(B), A.n >= 5, B.n >= 5, 0.08, false, ffPct(A.v / (A.n || 1)), ffPct(B.v / (B.n || 1)), "gagne", bn || "sur 12 mois · cette saison pour lui");
    var gA = A.gw + A.gl ? A.gw / (A.gw + A.gl) : null, gB = B.gw + B.gl ? B.gw / (B.gw + B.gl) : null;
    add("games", "Jeux gagnés", gA, gB, A.sets >= 10, B.sets >= 10, 0.02, false, gA != null ? ffPct(gA) : "", gB != null ? ffPct(gB) : "", "gagne", "le vrai rapport de force");
    add("close", "Sets serrés (7-5, 7-6)", ffRate(A.close), ffRate(B.close), A.close.n >= 4, B.close.n >= 4, 0.1, false, frac2(A.close), frac2(B.close), "press", A.close.n + " et " + B.close.n + " sets");
    add("three", "3es sets", ffRate(A.three), ffRate(B.three), A.three.n >= 3, B.three.n >= 3, 0.15, false, frac2(A.three), frac2(B.three), "press", A.three.n + " et " + B.three.n + " matchs");
    add("tb", "Tie-breaks", ffRate(A.tb), ffRate(B.tb), A.tb.n >= 5, B.tb.n >= 5, 0.15, false, frac2(A.tb), frac2(B.tb), "press");
    add("f1l", "Remontées après un 1er set perdu", ffRate(A.f1l), ffRate(B.f1l), A.f1l.n >= 3, B.f1l.n >= 3, 0.15, false, frac2(A.f1l), frac2(B.f1l), "press");
    add("two", "Victoires en 2 sets", ffRate(A.two), ffRate(B.two), A.two.n >= 4, B.two.n >= 4, 0.1, false, A.two.n ? ffPct(A.two.v / A.two.n) : "", B.two.n ? ffPct(B.two.v / B.two.n) : "", "ecrase");
    var mb = Math.max(A.bag / (A.scored || 1), B.bag / (B.scored || 1)) || 1;
    add("bag", "Sets secs (6-0, 6-1, 6-2)", A.scored ? A.bag / A.scored : null, B.scored ? B.bag / B.scored : null, A.scored >= 5, B.scored >= 5, 0.15, false, String(A.bag), String(B.bag), "ecrase", "", A.scored ? A.bag / A.scored / mb : 0, B.scored ? B.bag / B.scored / mb : 0);
    A = oA; B = oB;
    add("up", "Contre mieux classé", ffRate(A.up), ffRate(B.up), A.up.n >= 2, B.up.n >= 2, 0.1, false, A.up.v + "-" + (A.up.n - A.up.v), B.up.v + "-" + (B.up.n - B.up.v), "fiable", "les perfs");
    add("dn", "Contre moins bien classé", ffRate(A.dn), ffRate(B.dn), A.dn.n >= 3, B.dn.n >= 3, 0.08, false, A.dn.v + "-" + (A.dn.n - A.dn.v), B.dn.v + "-" + (B.dn.n - B.dn.v), "fiable", "les pièges");
    add("form", "Forme · 5 derniers matchs", ffRate(A.form), ffRate(B.form), A.form.n >= 3, B.form.n >= 3, 0.2, false, A.form.v + "/" + A.form.n, B.form.v + "/" + B.form.n, "");
    return out;
  }
  var FF_STRONG = { cross: "il bat les joueurs de ton classement", wins: "il gagne plus souvent", games: "il prend beaucoup de jeux", close: "il gagne les sets serrés", three: "il tient la distance en trois sets", tb: "il gagne les tie-breaks",
    f1l: "il revient souvent au score", two: "il gagne vite quand il gagne", bag: "il écrase ses matchs faciles", up: "il sait battre mieux classé", dn: "il ne fait pas de cadeau aux joueurs moins bien classés", form: "il est en forme" };

  // Vrais niveaux : pourquoi (victoires réelles contre attendues, par classement d'adversaire)
  function ffWhy(ms, cur, me) {
    var g = {}, lines = [];
    ms.forEach(function (m) { var o = E.idx(m.oppRank); if (o == null) return; (g[o] = g[o] || { o: o, v: 0, n: 0, e: 0 }); g[o].n++; g[o].e += lvP(o - cur); if (m.result === "V") g[o].v++; });
    var list = Object.keys(g).map(function (k) { return g[k]; }).filter(function (x) { return x.n >= 2; }).sort(function (a, b) { return Math.abs(b.v - b.e) * Math.sqrt(b.n) - Math.abs(a.v - a.e) * Math.sqrt(a.n); }).slice(0, 3).sort(function (a, b) { return a.o - b.o; });
    // Taux réel contre le taux habituel d'un joueur de ce classement face aux mêmes adversaires
    list.forEach(function (x) {
      var real = x.v / x.n, exp = x.e / x.n, d = real - exp;
      lines.push({ l: "Contre les " + (x.o < 0 ? "NC" : lab(x.o)), r: x.v + " V sur " + x.n + " (" + Math.round(real * 100) + " %)",
        ex: "Un " + lab(cur) + " en gagne d'habitude " + Math.round(exp * 100) + " %" + (Math.abs(d) < 0.12 ? " : c'est normal" : d > 0 ? (me ? " : tu fais mieux" : " : il fait mieux") : (me ? " : tu fais moins bien" : " : il fait moins bien")) });
    });
    var above = ms.filter(function (m) { return E.idx(m.oppRank) > cur; });
    if (above.length && !above.some(function (m) { return m.result === "V"; })) lines.push({ l: "Contre mieux classé", r: "0 perf", ex: me ? "aucune victoire au-dessus de ton classement : tu restes à ton niveau" : "aucune victoire au-dessus de son classement : rien ne le place plus haut" });
    return lines;
  }
  function ffLevelsCard(D) {
    var me = D.me, hi = D.hi, myL = D.myL, hisL = D.hisL;
    var desc = function (d, t) { return d >= 0.5 ? "au-dessus de " + t + " classement" : d <= -0.5 ? "en dessous de " + t + " classement" : "à " + t + " niveau"; };
    var real = myL - hisL, paper = me - hi;
    var head = D.few ? (D.hp.length ? "Seulement " + plural(D.hp.length, "match", "matchs") + " pour lui cette saison : trop peu pour juger son niveau." : "Aucun match pour lui cette saison : on ne connaît que son classement.") :
      "<b>Tu joues " + desc(myL - me, "ton") + ", lui " + desc(hisL - hi, "son") + ".</b> " + (Math.abs(real) < 0.3 && Math.round(myL) !== Math.round(hisL) ? "Mais en vrai, vous êtes tout proches : " + (Math.abs(real) < 0.05 ? "même niveau" : (Math.round(Math.abs(real) * 10) / 10).toString().replace(".", ",") + " échelon d'avance pour " + (real > 0 ? "toi" : "lui")) + "." : real > paper + 0.5 ? "L'écart réel est plus grand que sur le papier." : real < paper - 0.5 ? "L'écart réel est plus petit que sur le papier." : "L'écart réel colle aux classements.");
    var lo = Math.max(-1, Math.floor(Math.min(me, hi, myL, hisL)) - 1), up = Math.ceil(Math.max(me, hi, myL, hisL)) + 1, X = function (v) { return Math.max(2, Math.min(98, (v - lo) / (up - lo) * 100)); };
    var step = up - lo > 8 ? 2 : 1, ticks = "";
    for (var L = lo; L <= up; L++) if ((L - lo) % step === 0 || L === me || L === hi) ticks += '<span class="tk" style="left:' + X(L) + '%">' + (L < 0 ? "NC" : lab(L)) + "</span>";
    var mk = function (off, lv, col, name) {
      var a = X(off), b = X(lv), arr = Math.abs(b - a) > 3 ? '<span class="arr" style="left:' + Math.min(a, b) + "%;width:" + Math.abs(b - a) + "%;background:" + col + '"></span>' : "";
      var r = Math.round(lv), t = name + " · " + (r < 0 ? "NC" : lab(r)) + (r !== off ? " en vrai" : "");
      return '<span class="off" style="left:' + a + "%;background:" + col + '"></span>' + arr + '<span class="dt" style="left:' + b + "%;background:" + col + '"></span>' + '<span class="lb" style="left:' + Math.max(14, Math.min(86, b)) + "%;color:" + col + '">' + esc(t) + "</span>";
    };
    // Étiquettes trop proches : on décale
    var s = '<div class="card ff-lv"><span class="eyebrow">Vos vrais niveaux</span><span class="p">' + head + "</span>" +
      '<div class="ff-track' + (Math.abs(X(myL) - X(hisL)) < 30 ? " near" : "") + '"><div class="tr"></div>' + ticks + mk(hi, hisL, "var(--terre)", D.first) + mk(me, myL, "var(--gazon)", "Toi") + "</div>" +
      '<div class="ff-leg"><span><i class="b1"></i>classement officiel</span><span><i class="d1"></i>niveau d\'après les résultats</span></div>';
    var block = function (ini, cls, title, lines) {
      if (!lines.length) return "";
      return '<div class="ff-why"><div class="wh"><span class="ff-av sm ' + cls + '">' + esc(ini) + "</span><b>" + esc(title) + "</b></div>" + lines.map(function (x) { return '<div class="wl"><span>' + esc(x.l) + "</span><b>" + esc(x.r) + '</b><span class="ex">' + esc(x.ex) + "</span></div>"; }).join("") + "</div>";
    };
    var rr = function (v, off) { var r = Math.round(v); return Math.abs(v - off) < 0.5 ? "bien " + lab(off) : "plutôt " + (r < 0 ? "NC" : lab(r)); };
    s += '<span class="small">Tes résultats et les siens contre les mêmes adversaires sont dans le tableau « À adversité égale » ci-dessous.</span>';
    s += '<span class="small">Comment c\'est calculé : pour chaque niveau, Montée compare les victoires réelles à celles qu\'on attend d\'un joueur de ce niveau face aux mêmes adversaires, sur 12 mois. Sans perf, on ne place jamais un joueur au-dessus de son classement.</span></div>';
    return s;
  }

  // Données communes aux deux onglets
  // ---------- « Faux classements » : ses adversaires qui sont montés depuis (sans aucune requête) ----------
  // On ne relit rien sur Ten'Up : on croise ce que Montée connaît déjà (fiches consultées, joueurs suivis,
  // palmarès déjà analysés, tes propres matchs) pour connaître le classement le plus récent de ses adversaires.
  function knownRanks() {
    var K = {}, put = function (key, rank, date) {
      var x = E.idx(T.normRank(rank)); if (!key || x == null || !date) return;
      if (!K[key] || K[key].d < date) K[key] = { x: x, d: date };
    };
    var fromRows = function (rows) { (rows || []).forEach(function (r) { if (!r.oppRank || !r.date) return; if (r.oid) put("i:" + r.oid, r.oppRank, r.date); if (r.opp) put("n:" + nameKey(r.opp), r.oppRank, r.date); }); };
    var day = function (t, at) { return at || (t ? new Date(t).toISOString().slice(0, 10) : ""); };
    Object.keys(S.scout || {}).forEach(function (k) { var sc = S.scout[k], pr = sc.profil || {}, d = day(sc.ts, sc.at); put("i:" + k, pr.classement, d); put("n:" + nameKey([pr.prenom, pr.nom].join(" ")), pr.classement, d); put("n:" + nameKey([pr.nom, pr.prenom].join(" ")), pr.classement, d); fromRows(sc.rows); });
    Object.keys(S.anPal || {}).forEach(function (k) { var a = S.anPal[k]; if (a.id) put("i:" + a.id, a.rank, day(a.ts, a.at)); fromRows(a.rows); });
    Object.keys(S.follow || {}).forEach(function (k) { var f = S.follow[k]; if (f.at) { put("i:" + k, f.rank, day(f.at)); put("n:" + nameKey(f.name), f.rank, day(f.at)); } });
    fromRows(S.matches);
    return K;
  }
  // Ses matchs, avec le classement ACTUEL connu de l'adversaire s'il est monté depuis (comme pour tes défaites)
  function hisEffRows(rows, selfId, selfName) {
    var K = knownRanks(), selfKey = selfName ? nameKey(selfName) : "";
    return (rows || []).map(function (m) {
      var o = E.idx(T.normRank(m.oppRank)); if (o == null) return m;
      if (selfKey && m.opp && nameKey(m.opp) === selfKey) return m;
      var k1 = m.oid && m.oid !== String(selfId) ? K["i:" + m.oid] : null, k2 = m.opp ? K["n:" + nameKey(m.opp)] : null, k = k1 && k2 ? (k1.d >= k2.d ? k1 : k2) : k1 || k2;
      if (!k || k.d <= (m.date || "") || k.x <= o) return m;
      return Object.assign({}, m, { oppRank: lab(k.x), oppRank0: m.oppRank, risen: k.x - o });
    });
  }
  function ffRisenCard(D) {
    var r = (D.rows || []).filter(function (m) { return m.risen && !m.wo && (m.result === "V" || m.result === "D"); });
    if (!r.length) return "";
    var w = r.filter(function (m) { return m.result === "V"; }), l = r.length - w.length;
    var head = w.length ? "<b>" + plural(w.length, "de ses victoires vaut", "de ses victoires valent") + " plus que prévu.</b> " + (w.length > 1 ? "Ces adversaires sont" : "Cet adversaire est") + " monté" + (w.length > 1 ? "s" : "") + " depuis : c'étaient de faux classements." : "<b>" + plural(l, "de ses défaites pèse", "de ses défaites pèsent") + " moins lourd.</b> Ces adversaires sont montés depuis.";
    return '<div class="card ff-risen"><span class="eyebrow">Faux classements</span><span class="p">' + head + "</span>" +
      r.slice(0, 4).map(function (m) {
        return '<div class="rz"><span class="res ' + (m.result === "V" ? "v" : "d") + '">' + m.result + '</span><span class="grow"><b>' + esc(m.opp || "Adversaire") + '</b><span class="small">' + esc(fdate(m.date).replace(/\.$/, "")) + "</span></span>" +
          '<span class="rk"><s>' + esc(m.oppRank0) + "</s> → <b>" + esc(m.oppRank) + "</b></span></div>";
      }).join("") +
      '<span class="small">Comptés à leur classement actuel dans tout le face-à-face. Montée ne connaît que les joueurs déjà vus dans l\'app (fiches, suivis, tes matchs) : d\'autres ont pu monter aussi.</span></div>';
  }
  function ffData(o) {
    var c = ctx(), me = c.cur < 0 ? 0 : c.cur, hi = E.idx(T.normRank(o.rank));
    if (hi == null || c.proj.status === "top") return null;
    var myAll = effMs(c.proj.matches), myMs = playedOf(myAll), hp = playedOf(o.rows), ln = levelNow(c);
    var D = { c: c, me: me, hi: hi, myMs: myMs, hp: hp, few: hp.length < 3, first: o.first || "Lui", name: o.name || "", rows: o.rows, sp: o.sp, common: o.common || [], mine: o.mine || [], hisG: o.hisG || {}, od: o.od };
    D.myL = ln.ms ? ln.mean : me; D.hisL = hp.length >= 6 ? levelFit(hp, hi).mean : hi;
    D.A = ffStats(myAll, me); D.B = ffStats(o.rows, hi);
    // Même adversité : on compare vos jeux sur les matchs contre des adversaires du même niveau
    // (de l'échelon sous le plus faible de vous deux à l'échelon au-dessus du plus fort). Sinon un joueur
    // qui affronte surtout plus faible a l'air de tout écraser.
    var blo = Math.min(me, hi) - 1, bhi = Math.max(me, hi) + 1, inB = function (m) { var x = E.idx(m.oppRank); return x != null && x >= blo && x <= bhi; };
    var Ab = ffStats(myAll.filter(inB), me), Bb = ffStats(o.rows.filter(inB), hi);
    D.band = Ab.n >= 5 && Bb.n >= 5 ? { lo: blo, hi: bhi } : null;
    D.Ab = D.band ? Ab : D.A; D.Bb = D.band ? Bb : D.B;
    // Le test le plus direct : lui contre ton classement, toi contre le sien
    var cr = function (ms, r) { var q = playedOf(ms).filter(function (m) { return E.idx(m.oppRank) === r; }); return { v: q.filter(function (m) { return m.result === "V"; }).length, n: q.length }; };
    D.xMe = cr(myAll, hi); D.xHim = cr(o.rows, me);
    D.crit = D.few ? [] : ffCriteria(D.A, D.B, D);
    // Son jeu face à ton niveau ou au-dessus : c'est ce qui compte pour le plan, pas ses victoires sur plus faible
    var relM = (o.rows || []).filter(function (m) { var x = E.idx(m.oppRank); return x != null && x >= me - 1; }), Bh = ffStats(relM, hi);
    D.Bh = Bh.n >= 4 ? Bh : null; D.relLab = D.Bh ? "Contre les " + lab(Math.max(0, me - 1)) + " et plus" : "Contre des adversaires de votre niveau";
    D.notes = o.notes || []; D.noteDer = ffNoteDeriv(D.notes); D.best = o.best || null;
    return D;
  }

  // La phrase qui compte : chacun face au classement de l'autre
  function ffCrossLine(D) {
    var xm = D.xMe, xh = D.xHim, t = [];
    if (xh.n >= 3) t.push("Contre les " + lab(D.me) + " (ton classement), il est <b>" + xh.v + " V – " + (xh.n - xh.v) + " D</b>");
    if (xm.n >= 3) t.push("toi contre les " + (D.hi < 0 ? "NC" : lab(D.hi)) + ", <b>" + xm.v + " V – " + (xm.n - xm.v) + " D</b>");
    if (!t.length) return "";
    var s = t.join(" ; "); s = s.charAt(0).toUpperCase() + s.slice(1) + ".";
    return '<div class="ff-cross">' + s + "</div>";
  }
  // ---------- Onglet Statistiques (3.17.1) : on compare ce qui est comparable ----------
  function ffRk(i) { return i == null ? "?" : i < 0 ? "NC" : lab(i); }
  function ffVD(x) { return x.v + " V · " + (x.n - x.v) + " D"; }
  function ffRec(ms, test) { var q = ms.filter(test); return { v: q.filter(function (m) { return m.result === "V"; }).length, n: q.length }; }
  function ffRange(a, b) { return a === b ? "les " + ffRk(a) : "les " + ffRk(a) + " à " + ffRk(b); }
  function ffPaperCard(D) {
    var me = D.me, hi = D.hi, gap = me - hi, lo = Math.min(me, hi), up = Math.max(me, hi), n = Math.min(8, Math.abs(gap));
    var head = gap > 0 ? "Tu es favori : " + plural(gap, "échelon") + " d'avance." : gap < 0 ? "Il est favori : " + plural(-gap, "échelon") + " au-dessus de toi." : "Même classement : rien n'est écrit.";
    var real = D.few ? "" : D.hisL - hi >= 0.5 ? " Mais ses résultats le placent plus haut que son classement." : hi - D.hisL >= 0.5 ? " Et ses résultats le placent même plus bas que son classement." : " Et ses résultats ne le placent pas plus haut que son classement.";
    var lad = "";
    if (n) {
      var col = gap > 0 ? "g" : "t", labs = [];
      for (var k = 0; k <= n; k++) labs.push(ffRk(lo + k));
      lad = '<div class="ff-lad">' + new Array(n + 1).join('<i class="' + col + '"></i>') + '</div><div class="ff-ladl">' + labs.map(function (x) { return "<span>" + esc(x) + "</span>"; }).join("") + "</div>";
    }
    return '<div class="card key ff-rf"><span class="eyebrow">Sur le papier</span><div class="ff-vs"><div><span class="ff-av me">' + esc(ffMyIni()) + '</span><span class="nm me">Toi</span><span class="rk big">' + esc(ffRk(me)) + '</span></div><span class="x">VS</span><div><span class="ff-av him">' + esc(initials(D.name)) + '</span><span class="nm him">' + esc(D.first) + '</span><span class="rk big">' + esc(ffRk(hi)) + "</span></div></div>" + lad +
      '<span class="p"><b>' + head + "</b>" + real + "</span></div>";
  }
  // Tableau : vos bilans contre les mêmes classements d'adversaires
  function ffSameTable(D) {
    var me = D.me, hi = D.hi, lo = Math.max(-1, Math.min(me, hi) - 2), up = Math.min(E.MAX_CALC, Math.max(me, hi) + 1), rows = [], wsum = 0, dsum = 0;
    for (var L = up; L >= lo; L--) {
      var a = ffRec(D.myMs, function (m) { return E.idx(m.oppRank) === L; }), b = ffRec(D.hp, function (m) { return E.idx(m.oppRank) === L; });
      if (!a.n && !b.n && L !== me && L !== hi) continue;
      if (a.n && b.n) { var w = Math.min(a.n, b.n); wsum += w; dsum += w * (a.v / a.n - b.v / b.n); }
      rows.push({ L: L, a: a, b: b });
    }
    if (rows.length < 2) return "";
    var cell = function (x, who) { return x.n ? ffVD(x) : '<span class="na">' + (who === "him" ? "jamais joué" : "aucun") + "</span>"; };
    var d = wsum ? dsum / wsum : null, xh = D.xHim, xm = D.xMe, txt = "";
    if (d != null && wsum >= 3) txt = d >= 0.15 ? "<b>Contre les mêmes adversaires, tu gagnes plus.</b>" : d <= -0.15 ? "<b>Contre les mêmes adversaires, il gagne plus.</b>" : "<b>Contre les mêmes adversaires, vous faites jeu égal.</b>";
    if (me > hi && !xh.n) txt += " Il n'a jamais affronté de " + ffRk(me) + " cette saison.";
    else if (xh.n >= 2) txt += " Contre ton classement, il est " + ffVD(xh) + ".";
    return '<div class="card ff-same"><span class="eyebrow">À adversité égale</span><span class="small">Vos résultats contre les mêmes classements d\'adversaires, sur 12 mois pour toi et sa saison pour lui. C\'est la seule comparaison juste.</span>' +
      '<div class="tbl"><span class="h">Contre les…</span><span class="h c">Toi</span><span class="h c">' + esc(D.first) + "</span>" +
      rows.map(function (r) { var hl = r.L === me || r.L === hi ? " hl" : ""; return '<span class="lv' + hl + '">' + esc(ffRk(r.L)) + (r.L === me ? " · ton classement" : r.L === hi ? " · son classement" : "") + '</span><span class="c' + hl + '">' + cell(r.a, "me") + '</span><span class="c' + hl + '">' + cell(r.b, "him") + "</span>"; }).join("") + "</div>" +
      (txt ? '<span class="p">' + txt.trim() + "</span>" : "") + "</div>";
  }
  // Ce qui joue pour qui : chaque ligne dit sur quoi elle se base
  function ffForWho(D, data) {
    var me = D.me, hi = D.hi, pro = [], con = [], nc = [], A = D.Ab, B = D.Bb, first = D.first;
    if (me > hi) pro.push({ t: plural(me - hi, "échelon") + " d'avance", s: D.hisL - hi >= 0.5 ? "Sur le papier · ses résultats réduisent un peu l'écart" : "Sur le papier et dans vos résultats", w: Math.min(12, 3 + 2 * (me - hi)) });
    else if (hi > me) con.push({ t: plural(hi - me, "échelon") + " au-dessus de toi", s: "Sur le papier", w: Math.min(12, 3 + 2 * (hi - me)) });
    // Vrais niveaux : ce que disent vos résultats, au-delà des classements
    if (!D.few) {
      var dl = D.myL - D.hisL, rl = function (x) { var r = Math.round(x); return ffRk(r); };
      if (hi >= me && dl >= -0.3) pro.push({ t: dl >= 0.3 ? "Ton vrai niveau dépasse le sien" : "Ton vrai niveau vaut déjà le sien", s: "D'après vos résultats : toi " + rl(D.myL) + ", lui " + rl(D.hisL), w: 6 });
      else if (me >= hi && dl <= 0.3) con.push({ t: dl <= -0.3 ? "Son vrai niveau dépasse le tien" : "Son vrai niveau vaut déjà le tien", s: "D'après vos résultats : lui " + rl(D.hisL) + ", toi " + rl(D.myL), w: 6 });
    }
    var xh = D.xHim, eh = lvP(me - hi);
    if (xh.n >= 2) { var rh = xh.v / xh.n; if (rh <= eh - 0.15) pro.push({ t: "Contre les " + ffRk(me) + ", il est " + ffVD(xh), s: "Ton classement exact", w: Math.min(8, 2 + xh.n) }); else if (rh >= eh + 0.2) con.push({ t: "Contre les " + ffRk(me) + ", il est " + ffVD(xh), s: "Ton classement exact : il sait les battre", w: Math.min(8, 2 + xh.n) }); }
    else if (!xh.n && me > hi) pro.push({ t: "Il n'a jamais affronté de " + ffRk(me), s: "Cette saison", w: 5 });
    var xm = D.xMe;
    if (xm.n >= 2) { var rm = xm.v / xm.n; if (rm >= 0.6) pro.push({ t: "Contre les " + ffRk(hi) + ", tu es " + ffVD(xm), s: "Son classement exact", w: Math.min(7, 2 + xm.n) }); else if (rm <= 0.4) con.push({ t: "Contre les " + ffRk(hi) + ", tu es " + ffVD(xm), s: "Son classement exact : ton point à surveiller", w: Math.min(7, 2 + xm.n) }); }
    // Les marches entre vous deux
    if (me !== hi) {
      var a0 = Math.min(me, hi) + 1, a1 = Math.max(me, hi) - 1;
      if (a1 >= a0) {
        if (me > hi) { var st = ffRec(D.hp, function (m) { var o = E.idx(m.oppRank); return o >= a0 && o <= a1; }); if (st.n >= 3 && st.v / st.n <= 0.4) pro.push({ t: "Il perd contre " + ffRange(a0, a1) + " : " + ffVD(st), s: "Les niveaux juste en dessous de toi", w: 7 }); else if (st.n >= 3 && st.v / st.n >= 0.6) con.push({ t: "Il bat déjà " + ffRange(a0, a1) + " : " + ffVD(st), s: "Les niveaux juste en dessous de toi", w: 7 }); }
        else { var sm = ffRec(D.myMs, function (m) { var o = E.idx(m.oppRank); return o >= a0 && o <= a1; }); if (sm.n >= 3 && sm.v / sm.n >= 0.6) pro.push({ t: "Tu bats " + ffRange(a0, a1) + " : " + ffVD(sm), s: "Les niveaux juste en dessous de lui", w: 7 }); else if (sm.n >= 3 && sm.v / sm.n <= 0.35) con.push({ t: "Tu perds contre " + ffRange(a0, a1) + " : " + ffVD(sm), s: "Les niveaux juste en dessous de lui", w: 7 }); }
      }
    }
    // Son caractère au score (sur tous ses matchs, pas comparatif)
    var F = D.B.f1l;
    if (F.n >= 5) { if (F.v / F.n <= 0.2) pro.push({ t: "Mené d'un set, il ne revient presque jamais : " + F.v + " sur " + F.n, s: "Sur tous ses matchs", w: 4 }); else if (F.v / F.n >= 0.5) con.push({ t: "Mené d'un set, il revient souvent : " + F.v + " sur " + F.n, s: "Sur tous ses matchs", w: 4 }); }
    // Style : seulement à adversité égale
    var bn = D.band ? "À adversité égale (" + ffRange(Math.max(-1, D.band.lo), Math.min(E.MAX_CALC, D.band.hi)) + ")" : "";
    var cmpS = function (lab0, a, b, minN, thr) {
      if (a.n < minN || b.n < minN) return;
      var d = a.v / a.n - b.v / b.n, t = lab0 + " : toi " + a.v + "/" + a.n + ", lui " + b.v + "/" + b.n;
      if (d >= thr) pro.push({ t: t, s: bn, w: 3 }); else if (d <= -thr) con.push({ t: t, s: bn, w: 3 });
    };
    if (D.band) {
      cmpS("Sets serrés", A.close, B.close, 4, 0.15); cmpS("3es sets", A.three, B.three, 3, 0.2); cmpS("Tie-breaks", A.tb, B.tb, 5, 0.2);
    } else if (D.A.scored >= 5 && D.B.scored >= 5) {
      var med = function (ms) { var o = ms.map(function (m) { return E.idx(m.oppRank); }).filter(function (x) { return x != null; }).sort(function (x, y) { return x - y; }); return o.length ? o[Math.floor(o.length / 2)] : null; };
      nc.push({ t: "Sets secs, victoires en 2 sets, sets serrés", s: "Ses matchs sont surtout contre des " + ffRk(med(D.hp)) + ", les tiens contre des " + ffRk(med(D.myMs)) + " : on ne compare pas" });
    }
    var dn = D.B.dn;
    if (hi >= me - 1 && dn.n >= 5 && dn.v / dn.n >= 0.85) con.push({ t: "Il ne fait pas de cadeau aux plus faibles : " + ffVD(dn), s: "Contre moins bien classé que lui : ça ne dit rien de son niveau face à toi", w: 2 });
    var srt = function (x, y) { return y.w - x.w; };
    pro.sort(srt); con.sort(srt);
    if (data) return { pro: pro, con: con, nc: nc };
    if (!pro.length && !con.length && !nc.length) return "";
    var li = function (cls, ic, x) { return '<div class="li ' + cls + '"><span class="ic">' + ic + "</span><div>" + esc(x.t) + (x.s ? "<small>" + esc(x.s) + "</small>" : "") + "</div></div>"; };
    return '<div class="card ff-who"><span class="eyebrow">Ce qui joue pour qui</span>' +
      (pro.length ? '<span class="gh me">Pour toi</span>' + pro.slice(0, 4).map(function (x) { return li("ok", I.check, x); }).join("") : "") +
      (con.length ? '<span class="gh him">Pour ' + esc(first === "Lui" ? "lui" : first) + "</span>" + con.slice(0, 3).map(function (x) { return li("ko", "!", x); }).join("") : "") +
      (nc.length ? '<span class="gh nc">Pas comparable</span>' + nc.map(function (x) { return li("nu", "–", x); }).join("") : "") + "</div>";
  }
  // Sa forme, pondérée par le niveau de ses adversaires
  function ffFormCard(D) {
    var p = D.B.last.slice(0, 5); if (p.length < 3) return "";
    var me = D.me, rel = function (m) { return E.idx(m.oppRank) >= me - 1; };
    var r0 = p[0].result, n = 0; for (var i = 0; i < D.B.last.length && D.B.last[i].result === r0; i++) n++;
    var seq = D.B.last.slice(0, n), ranks = seq.map(function (m) { return E.idx(m.oppRank); }).filter(function (x) { return x != null; });
    var rng = ranks.length ? ffRange(Math.min.apply(null, ranks), Math.max.apply(null, ranks)).replace(/^les /, "des ") : "";
    var relAll = D.B.last.filter(rel).slice(0, 5), rv = relAll.filter(function (m) { return m.result === "V"; }).length;
    var head, tag;
    if (r0 === "V" && n >= 3) {
      var relW = seq.filter(rel).length;
      head = "<b>" + n + " victoires de suite</b>, " + (relW ? "dont " + plural(relW, "contre un joueur", "contre des joueurs") + " de ton niveau." : "mais contre " + rng + ".");
      tag = relW ? ["him", "Attention"] : ["eq", "Rien d'inquiétant pour toi"];
    } else if (r0 === "D" && n >= 2) { head = "<b>" + n + " défaites de suite</b>, contre " + rng + "."; tag = ["me", "Bon pour toi"]; }
    else { var v5 = p.filter(function (m) { return m.result === "V"; }).length; head = "<b>" + v5 + " victoire" + (v5 > 1 ? "s" : "") + " sur ses " + p.length + " derniers matchs.</b>"; tag = null; }
    if (relAll.length >= 2) head += " Contre des " + ffRk(Math.max(-1, me - 1)) + " et plus : " + rv + " sur ses " + relAll.length + " derniers.";
    if (!tag && relAll.length >= 2) tag = rv / relAll.length >= 0.6 ? ["him", "Attention"] : rv / relAll.length <= 0.35 ? ["me", "Bon pour toi"] : ["eq", "Rien de particulier"];
    return '<div class="card ff-form"><span class="eyebrow">Sa forme, remise à sa place</span><span class="p">' + head + "</span>" + (tag ? ffBadge(tag[0], tag[1]) : "") + "</div>";
  }
  // Ton enjeu : centré sur toi
  function ffMyStake(D) {
    var c = D.c, hi = D.hi; if (c.proj.status === "top" || !c.proj.next) return "";
    var b, w, l; try {
      var all = allMatches(), t = E.iso(today());
      b = E.project(all, c.cur, c.sex, c.opts);
      w = E.project(all.concat([{ id: "_simW", date: t, result: "V", oppRank: lab(hi), kind: "tournoi" }]), c.cur, c.sex, c.opts);
      l = E.project(all.concat([{ id: "_simL", date: t, result: "D", oppRank: lab(hi), kind: "tournoi" }]), c.cur, c.sex, c.opts);
    } catch (e) { return ""; }
    var g = w.next.total - b.next.total, lo = l.next.total - b.next.total, nx = b.next, after = w.next.total, gap = nx.norme - after;
    var up1 = w.status === "montee" && b.status !== "montee", down = b.status === "montee" && l.status !== "montee";
    var pct = function (x) { return Math.max(2, Math.min(100, Math.round(x / nx.norme * 100))); };
    var winTxt = up1 ? "Tu passes la norme " + nx.label + " : montée à la prochaine sortie" : g > 0 ? "Ton bilan " + nx.label + " passe à " + after + " / " + nx.norme : "Victoire hors quota : pas de points de plus";
    var lossTxt = lo < 0 ? (down ? "Tu perdrais ta montée : défaite" : "Défaite") + " contre moins bien classé, une victoire de moins comptée" : hi >= D.me ? "Défaite contre un joueur de ton échelon ou au-dessus : rien n'est retiré" : "Elle ne change pas ton bilan";
    var tail = up1 ? "<b>Une victoire te fait monter " + nx.label + ".</b>" : gap > 0 && g > 0 ? "Après une victoire, <b>il te manquera " + gap + " pts pour monter " + nx.label + "</b>." : gap > 0 ? "Il te manque " + gap + " pts pour monter " + nx.label + "." : "";
    var him = hi < D.me ? "Pour lui : te battre vaudrait une perf (+" + E.BAREME.win(D.me - hi - 1) + " pts). Il jouera libéré." : hi === D.me ? "Pour lui aussi, c'est un match à son échelon." : "Pour lui : il a plus à perdre que toi.";
    return '<div class="card key ff-stake"><span class="eyebrow">Ton enjeu</span><div class="stk2"><div class="sb g"><span class="k">Si tu gagnes</span><b>' + (g > 0 ? "+" + g : "0") + " pt" + (Math.abs(g) > 1 ? "s" : "") + "</b><span>" + esc(winTxt) + '</span></div><div class="sb t"><span class="k">Si tu perds</span><b>' + (lo < 0 ? lo : "0") + " pt" + (Math.abs(lo) > 1 ? "s" : "") + "</b><span>" + esc(lossTxt) + "</span></div></div>" +
      '<div class="prog"><i style="width:' + pct(nx.total) + '%;background:var(--gazon)"></i>' + (g > 0 ? '<i style="left:' + pct(nx.total) + "%;width:" + Math.max(0, pct(after) - pct(nx.total)) + '%;background:color-mix(in srgb,var(--gazon) 45%,transparent)"></i>' : "") + '</div><div class="pl"><span>' + nx.total + " pts aujourd'hui</span><span>norme " + esc(nx.label) + " : " + nx.norme + "</span></div>" +
      (tail ? '<span class="p">' + tail + "</span>" : "") + '<span class="small">' + esc(him) + "</span></div>";
  }
  // Rapport de force : les points qui comptent vraiment, pondérés (classement, bilans face au classement de l'autre…)
  function ffForceCard(D) {
    var f = D.few ? { pro: [], con: [], nc: [] } : ffForWho(D, true), me = D.me, hi = D.hi;
    if (D.few) { if (me > hi) f.pro.push({ t: plural(me - hi, "échelon") + " d'avance", w: 10 }); else if (hi > me) f.con.push({ t: plural(hi - me, "échelon") + " au-dessus de toi", w: 10 }); }
    var wp = f.pro.reduce(function (a, x) { return a + x.w; }, 0), wc = f.con.reduce(function (a, x) { return a + x.w; }, 0), tot = wp + wc;
    var s = '<div class="card key ff-rf"><span class="eyebrow">Le rapport de force</span><div class="ff-vs"><div><span class="ff-av me">' + esc(ffMyIni()) + '</span><span class="nm me">Toi</span><span class="rk">' + esc(ffRk(me)) + '</span></div><span class="x">VS</span><div><span class="ff-av him">' + esc(initials(D.name)) + '</span><span class="nm him">' + esc(D.first) + '</span><span class="rk">' + esc(ffRk(hi)) + "</span></div></div>";
    if (!tot) return s + '<span class="p">' + (D.few ? "Pas assez de matchs pour lui cette saison : on compare vos classements." : "<b>Très équilibré entre vous.</b> Aucun point ne fait pencher la balance.") + "</span></div>";
    var sh = wp / tot, pc = Math.round(sh * 100);
    var head = sh >= 0.8 ? "Tu as l'avantage sur presque tous les points qui comptent." : sh >= 0.58 ? "Avantage toi." : sh <= 0.2 ? "Il a l'avantage sur presque tous les points qui comptent." : sh <= 0.42 ? "Avantage lui." : "Très équilibré entre vous.";
    var best = f.pro[0], worst = f.con[0];
    var sub = (best ? "Ton meilleur atout : " + best.t.charAt(0).toLowerCase() + best.t.slice(1) + "." : "") + (worst ? " Son point fort : " + worst.t.charAt(0).toLowerCase() + worst.t.slice(1) + "." : "");
    return s + '<div class="ff-tug">' + (pc ? '<i class="g" style="width:' + pc + '%"></i>' : "") + (100 - pc ? '<i class="t" style="width:' + (100 - pc) + '%"></i>' : "") + '</div><div class="ff-tugl"><span class="me">' + plural(f.pro.length, "point") + " pour toi</span><span class=\"him\">" + plural(f.con.length, "point") + " pour lui</span></div>" +
      '<span class="p"><b>' + head + "</b> " + esc(sub.trim()) + '</span><span class="small">Chaque point est pesé selon son importance (l\'écart de classement, vos bilans face au classement de l\'autre…). Le détail est plus bas.</span></div>';
  }
  function ffStatsTab(D) {
    var s = ffForceCard(D) + ffLevelsCard(D) + ffRisenCard(D);
    if (D.few) {
      s += '<div class="card"><span class="eyebrow">À adversité égale</span><span class="p">Dès qu\'il aura joué 3 matchs cette saison, tu verras ici vos bilans contre les mêmes adversaires et ce qui joue pour qui.</span></div>';
    } else {
      s += ffSameTable(D) + ffForWho(D) + ffFormCard(D);
      var A = D.A, B = D.B, first = D.first;
      // 4. Repères
      var rp = function (k, m, isV) { return '<div class="rp"><span class="k">' + k + "</span>" + (m ? '<div class="m"><span class="vd ' + (isV ? "V" : "D") + '">' + (isV ? "V" : "D") + '</span><span class="rk2">' + esc(m.oppRank) + '</span></div><span class="sc">' + esc([m.score, ffMonth(m.date)].filter(Boolean).join(" · ")) + "</span>" : '<span class="sc">—</span>') + "</div>"; };
      var tm = function (x, y) { return '<div class="rp"><span class="k">Par équipes</span><div class="m"><span class="rk2">' + (x.n ? x.v + "-" + (x.n - x.v) : "—") + '</span></div><span class="sc">' + (y.n ? "en tournoi " + y.v + "-" + (y.n - y.v) : "") + "</span></div>"; };
      var tnote = B.team.n >= 3 && B.tour.n >= 3 ? (ffRate(B.tour) - ffRate(B.team) >= 0.25 ? "Par équipes, il perd plus souvent : la pression du résultat d'équipe lui pèse." : ffRate(B.team) - ffRate(B.tour) >= 0.25 ? "Par équipes, il se transcende : méfie-toi en championnat." : "") : "";
      s += '<h2>Repères</h2><div class="card ff-rep"><div class="colh"><span><span class="ff-av sm me">' + esc(ffMyIni()) + '</span>Toi</span><span><span class="ff-av sm him">' + esc(initials(D.name)) + "</span>" + esc(first) + '</span></div><div class="grid">' +
        rp("Meilleure victoire", A.best, true) + rp("Meilleure victoire", B.best, true) + rp("Pire défaite", A.worst, false) + rp("Pire défaite", B.worst, false) +
        ((A.team.n || B.team.n) ? tm(A.team, A.tour) + tm(B.team, B.tour) : "") + "</div>" + (tnote ? '<span class="small">' + tnote + "</span>" : "") + "</div>";
    }
    if (D.common.length) s += ffCrossCard(D);
    s += ffMyStake(D);
    return s;
  }
  function ffFormsCard(D) {
    var fa = formSeries(D.myMs), fb = formSeries(D.rows), W = 340, H = 130, xs = function (i) { return 12 + i * (W - 30) / 5; }, ys = function (v) { return 100 - v * 85; };
    if (!fa.some(function (x) { return x.v != null; }) && !fb.some(function (x) { return x.v != null; })) return "";
    var line = function (f, col) { var pts = f.map(function (x, i) { return x.v == null ? null : xs(i).toFixed(1) + "," + ys(x.v).toFixed(1); }).filter(Boolean); if (!pts.length) return ""; var lp = pts[pts.length - 1].split(","); return '<polyline points="' + pts.join(" ") + '" fill="none" stroke="' + col + '" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/><circle cx="' + lp[0] + '" cy="' + lp[1] + '" r="5" fill="' + col + '"/>'; };
    var trend = function (f) { var v = f.filter(function (x) { return x.v != null; }); if (v.length < 2) return ""; var d = v[v.length - 1].v - v[Math.max(0, v.length - 3)].v; return d >= 0.15 ? "en hausse" : d <= -0.15 ? "en baisse" : "stable"; };
    var ta = trend(fa), tb = trend(fb), A = D.A.form, B = D.B.form;
    var head = ta && tb ? (ta === "en hausse" && tb !== "en hausse" ? "Toi en hausse, lui " + tb + "." : tb === "en hausse" && ta !== "en hausse" ? "Lui en hausse, toi " + ta + "." : "Toi " + ta + ", lui " + tb + ".") : "";
    return '<div class="card cmp chart" style="gap:10px"><span class="eyebrow">Vos formes</span><div class="cmp-who"><span class="me">Toi</span><span class="him">' + esc(D.first) + "</span></div>" +
      '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Vos formes sur six mois"><line x1="10" x2="' + (W - 10) + '" y1="' + ys(0.5) + '" y2="' + ys(0.5) + '" stroke="var(--line)" stroke-dasharray="4 4"/>' +
      line(fb, "var(--terre)") + line(fa, "var(--gazon)") + fa.map(function (x, i) { return '<text x="' + xs(i).toFixed(1) + '" y="' + (H - 4) + '" text-anchor="middle" font-size="10" fill="var(--muted)">' + (i === 5 ? "auj." : MOIS[x.d.getMonth()]) + "</text>"; }).join("") + "</svg>" +
      '<span class="p">' + (head ? "<b>" + head + "</b> " : "") + (A.n ? plural(A.v, "victoire") + " sur tes " + A.n + " derniers matchs" : "") + (B.n ? ", lui " + B.v + " sur " + B.n + "." : ".") + "</span>" +
      '<span class="small">Victoires sur les 5 derniers matchs, mois par mois. Pour lui, seulement sa saison en cours.</span></div>';
  }
  function ffCrossCard(D) {
    return '<div class="card cmp cross"><span class="eyebrow">Vos matchs croisés</span>' + D.common.slice(0, 4).map(function (x) {
      var a = x.mine.result === "V", b = x.his.result === "V", ini = initials(x.name);
      var cap = a && b ? "Tous les deux vainqueurs de " + x.name + " (" + (x.rank || "?") + ")" : a && !b ? "Tu as battu " + x.name + " (" + (x.rank || "?") + "), qui l'a battu : avantage toi" : !a && b ? x.name + " (" + (x.rank || "?") + ") : il l'a battu, pas toi" : "Tous les deux battus par " + x.name + " (" + (x.rank || "?") + ")";
      return '<button class="chain-b" data-a="scoutOpp" data-id="' + esc(x.his.oid || "") + '" data-v="' + esc(x.name) + '"><span class="chain"><span class="node me">Toi</span><span class="edge ' + (a ? "v" : "d") + '">' + (a ? "V " : "D ") + esc(x.mine.score || "") + '<i></i></span><span class="node">' + esc(ini) + '</span><span class="edge ' + (b ? "v" : "d") + '"><i></i>' + (b ? "V " : "D ") + esc(x.his.score || "") + '</span><span class="node him">' + esc(initials(D.name)) + '</span></span><span class="chain-n">' + esc(cap) + "</span></button>";
    }).join("") + "</div>";
  }

  // ---------- Onglet Plan de jeu ----------
  // Signaux : chacun alimente le plan en 3 points, « Fais » ou « Évite », avec sa preuve
  // ---------- Tes notes sur lui : synthèse en consignes de jeu ----------
  var NOTE_RULES = [
    { k: "rev-", re: /revers[^.;!?]{0,40}(faible|craque|fragile|faute|mauvais|nul|bof|pas terrible|limite|pourri|tremble)|(faible|fragile)[^.;!?]{0,20}revers|(fui[a-z]*|fuy[a-z]*|cache|contourn[a-z]*|tourne autour d[eu]|protege|evite) (de )?son revers/, p: { t: "Joue sur son revers", s: "Charge son revers dès que tu as le temps, et garde ton meilleur coup pour le point qui compte." } },
    { k: "cd-", re: /(coup droit|cd)[^.;!?]{0,40}(faible|craque|fragile|faute|mauvais|nul|bof|limite)|(faible|fragile)[^.;!?]{0,20}(coup droit|\bcd\b)/, p: { t: "Joue sur son coup droit", s: "C'est son côté le plus fragile : ouvre le terrain dessus, puis attaque." } },
    { k: "rev+", pos: true, re: /revers[^.;!?]{0,40}(fort|solide|arme|bon|redoutable|tres bien|propre|excellent|lourd)|(bon|tres bon|excellent|gros|solide|super|beau) revers/, p: { t: "Évite son revers", s: "C'est son point fort : joue au centre et sur son coup droit, son revers seulement pour l'ouvrir." }, e: { t: "Le jeu dans son revers", w: "C'est son point fort" } },
    { k: "cd+", pos: true, re: /(coup droit|\bcd\b)[^.;!?]{0,40}(fort|solide|arme|bon|redoutable|lourd|puissant|excellent)|(bon|tres bon|excellent|gros|solide|super|beau|enorme) (coup droit|\bcd\b)/, p: { t: "Prive-le de son coup droit", s: "C'est son arme : joue long sur son revers et au centre, pour l'empêcher de tourner autour." }, e: { t: "Lui donner son coup droit", w: "C'est son arme" } },
    { k: "ldl", re: /long de ligne/, p: { t: "Joue long de ligne", s: "Tu l'avais noté : c'est là qu'il souffre." } },
    { k: "net-", re: /(volee|filet)[^.;!?]{0,40}(faible|mauvais|nul|bof|pas a l.aise|mal a l.aise|evite|jamais)|mal a l.aise[^.;!?]{0,20}(volee|filet)|(jamais|pas|n.aime pas)[^.;!?]{0,20}(filet|monte)|monte (jamais|pas|rarement)|ne monte/, p: { t: "Fais-le monter au filet", s: "Amortis et balles courtes : il n'est pas à l'aise devant." } },
    { k: "net+", pos: true, re: /(monte|vient|attaque)[^.;!?]{0,20}(au )?filet|bon[^.;!?]{0,10}volee|volleyeur/, p: { t: "Balles basses, prépare tes passings", s: "Il vient au filet : garde la balle basse à ses pieds, et lobe s'il colle au filet." } },
    { k: "srv+", pos: true, re: /(service|sert)[^.;!?]{0,30}(fort|gros|puissant|ace|rapide|lourd|bon|solide|arme)|(gros|bon|tres bon|excellent|sacre) (service|serveur)|serveur/, p: { t: "Recule en retour et bloque", s: "Contre son service, priorité : remettre la balle dans le court. Les points se gagnent après." } },
    { k: "srv-", re: /(2e|deuxieme|seconde) balle|double faute|service[^.;!?]{0,30}(faible|mou|bof|nul|lent)|\bsert[^.;!?]{0,15}(faible|mou|doucement|lentement)/, p: { t: "Attaque sa 2e balle", s: "Avance d'un pas en retour sur ses deuxièmes balles et prends l'initiative." } },
    { k: "phy", re: /physique|cardio|fatigu|cuit|souffle|essouffl|crampe|tient pas la distance/, p: { t: "Fais-le courir, fais durer", s: "Il baisse physiquement : longs échanges, angles, une balle de plus." } },
    { k: "men", re: /s.enerv|mental|\brale|frustr|perd (ses|son) moyens|nerveux|crispe|enerve/, p: { t: "Reste collé au score", s: "Il perd ses moyens quand ça ne tourne pas : sois régulier, laisse-le s'énerver." } },
    { k: "mob", re: /(deplace|bouge|mobil|lent|lourd sur ses jambes)[^.;!?]{0,20}(mal|peu|lent|pas)|(il est|joueur|assez|un peu|tres) lent\b|lourd sur ses jambes/, p: { t: "Ouvre les angles", s: "Il se déplace mal : croisés courts, puis le côté opposé." } },
    { k: "mur", re: /renvoie tout|remet tout|ramene tout|recupere tout|\bregulier|\bmur\b|defend bien|ne fait pas de faute|rameur|\brame\b|pousseur|defenseur|couverture|couvre (bien )?(le )?terrain|court partout|se deplace (tres )?bien|rapide (sur ses jambes|en deplacement)/, p: { t: "Sois patient, construis le point", s: "Il renvoie tout : ne cherche pas le coup gagnant trop tôt. Trois balles lourdes dans le même coin, puis avance sur la balle courte et viens finir devant." } },
    { k: "all", pos: true, re: /allonge|longs? bras|envergure|grand compas/, p: { t: "Joue dans le corps", s: "Il a de l'allonge : sur les côtés, il récupère tout. Vise le corps, et passe-le bas quand il est au filet." } },
    { k: "age", re: /vieux|veteran|papy|plus age|un certain age/, p: { t: "Fais-le bouger d'avant en arrière", s: "Amortis, angles courts, lobs : chaque changement de direction lui coûte. La fin de match est pour toi." } },
    { k: "dsl", re: /diesel|demarre (lentement|doucement|mal)|lent a (se mettre|demarrer|rentrer)|met du temps a (rentrer|demarrer)/, p: { t: "Démarre fort", s: "Il met du temps à rentrer dans son match : pas de round d'observation, agresse ses premiers jeux." } },
    { k: "fst", pos: true, re: /(demarre|part|entre) (tres )?fort|tres bon debut|commence fort/, p: { t: "Encaisse son départ", s: "Il part fort : tiens au score sur les premiers jeux, sans paniquer. Le match se joue après." } },
    { k: "lob", pos: true, re: /\blobe|\blobs?\b/, p: { t: "Ne colle pas au filet", s: "Il lobe bien : monte, mais reste à un pas et demi du filet, prêt à reculer." } },
    { k: "tmp", re: /(prendre|voler|enlever|reduire|retirer)[^.;!?]{0,25}(du |le |son )?temps|(jouer|prendre la balle|frapper) (plus )?tot|avancer dans le court|rentrer dans le court|monter sur la balle/, p: { t: "Prends-lui le temps", s: "Prends la balle tôt, un pas dans le court : il n'a plus le temps de se replacer et sa couverture ne suffit plus." } },
    { k: "frp", pos: true, re: /frappe (fort|lourd|a plat)|cogne|frappeur|attaquant|joue vite/, p: { t: "Casse son rythme", s: "Il aime la vitesse : slice, balles lentes et profondes au centre, ne lui donne jamais deux fois la même balle." } },
    { k: "err", re: /fautes? (directes?|facile)|fautif|irregulier|donne (des|les) points|fait (beaucoup de|des) fautes|rate beaucoup/, p: { t: "Une balle de plus", s: "Il se met tout seul en difficulté : pas de risque inutile, fais-le jouer, c'est lui qui va se tromper." } },
    { k: "ret", pos: true, re: /(bon|tres bon|excellent|gros) retour|retourne (bien|tout)|retour (solide|agressif)/, p: { t: "Varie ton service", s: "Il retourne bien : change de zone à chaque point (corps, extérieur, T) et soigne ta 1re balle plutôt que la vitesse." } },
    { k: "moon", re: /balles? (molles?|lentes?)|moonball|chandelle|lobe? beaucoup/, p: { t: "Avance sur ses balles hautes", s: "Ses balles lentes et hautes, prends-les en montant ou en l'air : recule et tu joues son match." } },
    { k: "gch", re: /gaucher/, p: { t: "Pense gaucher", s: "Ta diagonale coup droit tombe sur son revers ; méfie-toi de son slice extérieur côté avantage." } },
    { k: "tri", re: /trich|annonces?|conteste|fair.?play|mauvaise foi/, p: { t: "Reste froid sur les annonces", s: "Ne rentre pas dans son jeu : en cas de doute, demande calmement un juge-arbitre et passe au point suivant." } },
    { k: "grd", re: /\bgrand\b|grande taille|tres grand/, p: { t: "Balles basses, dans les pieds", s: "Les grands n'aiment pas plier les jambes : slice bas et balles dans le corps." } },
    { k: "hgt", re: /balles? hautes?|lift/, p: { t: "Balles hautes et liftées", s: "Tu l'avais noté : il est gêné par la hauteur." } },
    { k: "slc", re: /slice|balles? basses?/, p: { t: "Varie avec du slice", s: "Tu l'avais noté : la balle basse le gêne." } },
    { k: "amo", re: /amorti/, p: { t: "Reste prêt à monter sur l'amorti", s: "Tu avais noté ses amortis : ne recule pas trop derrière ta ligne." } }
  ];
  function ffNoteDeriv(notes) {
    var out = [], seen = {};
    notes.forEach(function (n) {
      String(n.text || "").split(/(?<=[.!?;\n])\s+/).forEach(function (sent) {
        var t = noteNorm(sent.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[’`]/g, "'"));
        var hit = false;
        // Chaque morceau de phrase à part (« il fuit son revers | mais excellent coup droit | et bon service ») :
        // sinon « revers … excellent » se lit comme un bon revers
        sent.split(/\s*(?:[,;:]|\bmais\b|\bpar contre\b|\bcependant\b|\bpourtant\b|\bet\b)\s*/i).filter(function (c) { return c.trim().length > 2; }).forEach(function (cl) {
          var ct = noteNorm(cl.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[’`]/g, "'")), neg = /\bn(e |')|\bpas\b|jamais|\bevite\b|aucun/.test(ct);
          NOTE_RULES.forEach(function (r) {
            if (!r.re.test(ct) || (r.pos && neg)) return; hit = true; if (seen[r.k]) return;
            seen[r.k] = 1;
            var q = cl.trim().replace(/[.;!]$/, ""); q = q.charAt(0).toUpperCase() + q.slice(1);
            out.push({ k: r.k, p: r.p, e: r.e, q: q.slice(0, 110), d: n.date, fiche: n.fiche });
          });
        });
        // Une consigne que tu t'es donnée toi-même (« faut… », « je dois… ») : on la garde telle quelle
        var own = sent.trim().replace(/[.;!]$/, "");
        if (!hit && own.length > 8 && own.length < 110 && /(^|\s)(il )?faut\b|\bje dois\b|\bpenser? a\b|\ba faire\b|\bobjectif\b|\bne pas\b/.test(t) && out.filter(function (x) { return x.k === "own"; }).length < 2)
          out.push({ k: "own", own: true, p: { t: own.charAt(0).toUpperCase() + own.slice(1), s: "Ta propre consigne" + (n.date ? ", notée le " + fdate(n.date).replace(/\.$/, "") : "") + " : garde-la en tête." }, q: own, d: n.date, fiche: n.fiche });
      });
    });
    // Combinaisons : deux observations qui, ensemble, disent autre chose qu'une par une
    var has = function (k) { return out.filter(function (x) { return x.k === k; })[0]; };
    [[["mur", "tmp"], "mur", { t: "Rameur : prends-lui le temps", s: "Il renvoie tout et couvre bien le terrain : les longs échanges du fond sont pour lui. Prends la balle tôt, un pas dans le court, et finis au filet sur la balle courte." }],
     [["net+", "all"], "net+", { t: "Il monte et couvre le filet", s: "Avec son allonge, les passings sur les côtés reviennent. Balles basses dans ses pieds, et lobe lifté côté revers quand il colle." }],
     [["rev-", "cd+"], "rev-", { t: "Tout sur son revers", s: "Il fuit son revers pour jouer coup droit : joue long et croisé sur son revers pour le fixer, puis le long de ligne côté coup droit quand il tourne autour." }],
     [["mur", "phy"], "phy", { t: "Il renvoie tout… mais pas longtemps", s: "Il défend bien mais baisse physiquement : accepte les longs échanges, fais-le courir, le 3e set est pour toi." }]
    ].forEach(function (c) {
      var a = has(c[0][0]), b = has(c[0][1]); if (!a || !b) return;
      var keep = c[1] === a.k ? a : b, drop = keep === a ? b : a;
      keep.p = c[2]; keep.combo = true; keep.e = keep.e || drop.e; keep.q = a.q === b.q ? a.q : a.q + " … " + b.q; out.splice(out.indexOf(drop), 1);
    });
    return out;
  }
  // Les tournures à double négation (« n'hésite pas à monter » = il monte) et les litotes, avant de lire la note
  function noteNorm(t) {
    return t.replace(/n'?\s?hesite pas a /g, "").replace(/n'?\s?a pas peur d(e |')/g, "").replace(/ne (se )?prive pas d(e |')/g, "").replace(/ne rechigne pas a /g, "")
      .replace(/pas (si |trop )?(mal|mauvais|nul|bete)\b/g, "bon").replace(/pas (tres |trop |vraiment |super )?(bon|solide|fort|terrible)\b/g, "faible")
      .replace(/pas (tres |trop |vraiment )?a l'?\s?aise/g, "mal a l'aise").replace(/pas (tres |trop |vraiment )?regulier/g, "irregulier").replace(/pas (tres |trop |vraiment )?rapide/g, "il est lent");
  }
  var NOTE_CAT = { "rev-": ["Sa faille", "target", "g"], "cd-": ["Sa faille", "target", "g"], ldl: ["Sa faille", "target", "g"], "net-": ["Sa faille", "target", "g"], hgt: ["Sa faille", "target", "g"], slc: ["Sa faille", "target", "g"],
    "rev+": ["Son arme", "shield", "t"], "cd+": ["Son arme", "shield", "t"], "srv+": ["Son service", "ball", "t"], "srv-": ["Son service", "ball", "g"], "net+": ["Son jeu", "net", "nu"],
    phy: ["Physique", "phys", "g"], men: ["Mental", "fire", "g"], mob: ["Déplacement", "phys", "g"], mur: ["Son jeu", "wall", "nu"], amo: ["Son jeu", "racket", "nu"], tmp: ["Ta clé", "target", "g"], frp: ["Son jeu", "fire", "nu"], err: ["Sa faille", "target", "g"], ret: ["Son retour", "ball", "t"], moon: ["Son jeu", "ball", "nu"], gch: ["Gaucher", "hand", "nu"], tri: ["Mental", "shield", "nu"], grd: ["Sa faille", "target", "g"], all: ["Son jeu", "hand", "nu"], age: ["Physique", "phys", "g"], dsl: ["Sa faille", "clock", "g"], fst: ["Son jeu", "clock", "t"], lob: ["Son jeu", "ball", "nu"] };
  var NOTE_TG = { "rev-": "rev", "cd-": "cd", ldl: "ldl", "net-": "net", "net+": "net", "srv+": "srv", "srv-": "srv2", phy: "phy", men: "men", mob: "mob", mur: "mur", hgt: "rev", slc: "slc", amo: "amo", tmp: "tmp", frp: "rythme", err: "err", ret: "srvme", moon: "moon", gch: "rev", tri: "tri", grd: "grd", all: "all", age: "phy", dsl: "f1", fst: "f1", lob: "lob" };
  function ffNotesCard(D) {
    var n = D.notes || []; if (!n.length) return "";
    var der = D.noteDer || [], last = n.reduce(function (m, x) { return x.date && x.date > m ? x.date : m; }, "");
    var ic = function (k) { return k === "ball" ? '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6c3.5 3.5 3.5 9.3 0 12.8M18.4 5.6c-3.5 3.5-3.5 9.3 0 12.8"/>' : AN_IC[k] || GP_IC[k] || AN_IC.check; };
    var bub = function (q, d) { return '<span class="nb">' + esc(q) + (d ? '<i>' + esc(fdate(d).replace(/\.$/, "")) + "</i>" : "") + "</span>"; };
    var s = '<div class="card ff-notes"><div class="nh"><span class="eyebrow">Ce que tu sais de lui</span><span class="nc">' + plural(n.length, "note", "notes") + "</span></div>";
    if (der.length) s += der.slice(0, 4).map(function (x) {
      var c = x.p || { t: "Évite : " + x.e.t.toLowerCase() }, cat = NOTE_CAT[x.k] || ["Ta note", "check", "nu"];
      if (x.own) return '<div class="nt nu"><span class="ni">' + svg(ic("check"), 2) + '</span><span class="nx"><span class="nk">Ta consigne</span><b>« ' + esc(x.q) + " »</b>" + (x.d ? '<span class="small">' + esc(fdate(x.d).replace(/\.$/, "")) + "</span>" : "") + "</span></div>";
      return '<div class="nt ' + cat[2] + '"><span class="ni">' + svg(ic(cat[1]), 2) + '</span><span class="nx"><span class="nk">' + cat[0] + "</span><b>" + esc(c.t) + "</b>" + bub(x.q, x.d) + "</span></div>";
    }).join("");
    else s += '<span class="small">Rien de tactique repéré dans tes notes. Relis-les avant d\'entrer :</span>' + n.slice(0, 2).map(function (x) { return '<div class="nt nu raw">' + bub(String(x.text).trim().slice(0, 220), x.date) + "</div>"; }).join("");
    return s + "</div>";
  }
  // ---------- Bibliothèque de coach : consignes tactiques selon son jeu et le tien ----------
  function coachLib(g, my) {
    var out = [], fw = "d'après sa fiche", meL = my.hand === "G", arm = function (a) { return my.arms.indexOf(a) >= 0; };
    var add = function (sc, t, txt, fais, evite, tg) { out.push({ sc: sc, tg: tg, plan: { src: "Sa fiche", t: t, s: txt }, fais: fais ? { t: fais, w: fw } : null, evite: evite ? { t: evite[0], w: evite[1] + " · " + fw } : null }); };
    // Main
    if (g.hand === "G" && !meL) add(6.2, "Ton coup droit croisé sur son revers",
      "Gaucher : ta diagonale coup droit tombe sur son revers, c'est ta meilleure arme. Au service, côté égalité, slice extérieur : la balle fuit vers son revers ; côté avantage, vise le T." + (g.backhand === "1" ? " Bonus : son revers est à une main, lifte haut dans cette diagonale." : ""),
      "Coup droit croisé, sur son revers", ["Son slice extérieur côté avantage", "Il t'écarte sur ton revers : décale-toi d'un pas en retour"], "rev");
    else if (g.hand === "G" && meL) add(6, "Gaucher contre gaucher : change de diagonale",
      "Vos coups droits croisés se répondent : c'est son point fort comme le tien. Ouvre avec le coup droit décroisé ou le revers long de ligne pour attaquer son revers.",
      "Décroise ton coup droit vers son revers", null, "rev");
    else if (g.hand === "D" && meL) add(5.5, "Ta diagonale de gaucher",
      "Ton coup droit croisé tombe sur son revers et ton service slicé côté avantage l'écarte sur son revers : construis tes points dans cette diagonale.",
      "Slice extérieur côté avantage");
    // Revers
    if (g.backhand === "1") add(5.6, "Balles hautes sur son revers à une main",
      "Lifte haut et lourd sur son revers : à hauteur d'épaule, il ne peut que bloquer ou slicer. Évite le slice bas, il le renvoie facilement." + (arm("cd") ? " Ton coup droit est fait pour ça." : ""),
      "Lifte haut sur son revers", ["Le slice bas sur son revers", "Son revers à une main aime la balle basse"], "rev");
    else if (g.backhand === "2") add(3.5, "Écarte-le côté revers",
      "Revers à deux mains : souvent solide mais moins d'allonge. Balles larges et basses côté revers, slice court qui l'oblige à plier les jambes.",
      "Balles larges côté revers", null, "rev");
    // Style : son jeu × ton jeu (matrice de coach)
    var MX = {
      fond: { t: "Casse son rythme", s: "Il frappe fort du fond : ne lui donne jamais deux fois la même balle. Slice, balles lentes et profondes au centre pour lui fermer les angles.",
        me: { fond: "Entre frappeurs, c'est la longueur qui décide : vise 1 m derrière le carré de service, et prends la balle tôt pour lui voler le temps.", contre: "Ta régularité va le pousser à forcer : une balle de plus, il fera les fautes.", filet: "Ne joue pas son jeu : approche sur une balle slicée basse et longue, pas sur une balle qui gicle.", service: "Fais court : service + coup droit, ne t'installe pas dans l'échange du fond.", poly: "Varie tout : hauteur, vitesse, effets. C'est la balle qui ne revient jamais pareille qui le dérègle." },
        f: "Slice et balles lentes au centre", e: ["L'échange de frappe à plat", "C'est son terrain"] },
      contre: { t: "Fais-le avancer, finis devant", s: "Il renvoie tout : le point gagnant du fond ne viendra pas. Amortis et balles courtes pour le sortir de sa zone.",
        me: { fond: "Construis : trois balles lourdes dans le même coin, puis le côté opposé. Le coup gagnant vient à la 5e balle, pas à la 2e.", contre: "Match de patience : celui qui force le premier perd. Reste à 70 % et attends SA balle courte.", filet: "C'est ton match : approche sur chaque balle courte, il n'aime pas le passing sous pression.", service: "Gagne vite sur ton service : 1re balle placée, puis attaque la balle qui revient au centre.", poly: "Alterne amorti et balle profonde : à force d'avancer et reculer, il finit par craquer." },
        f: "Amortis, puis avance", e: ["Chercher le coup gagnant trop tôt", "Il renvoie tout"] },
      filet: { t: "Balles basses, passings, lobs", s: "Il vient au filet : retours bas dans ses pieds, premier passing à mi-hauteur pour le faire volleyer bas, puis le passant. Lobe lifté côté revers quand il colle.",
        me: { fond: "Garde-le derrière : profondeur d'abord, une balle courte et il est devant.", contre: "Ta défense va le punir : il lui faut deux volées par point, toi un seul passing.", filet: "Le premier au filet gagne : attaque sa 2e balle et monte derrière ton retour.", service: "Serve-volley sur tes 1res balles : prends-lui le filet avant lui.", poly: "Pas besoin de gagnant : un passing bas, il volleye au-dessus du filet, le suivant passe." },
        f: "Balles basses à ses pieds", e: ["La balle molle au milieu", "Il volleye tout ce qui flotte"] },
      service: { t: "Survis à son service, gagne sur le tien", s: "Gros service : recule d'un mètre, raccourcis ton geste, vise le centre. Avance sur sa 2e balle. Ses jeux passeront souvent : tout se joue sur TES jeux de service.",
        me: { fond: "Une fois la balle en jeu, l'échange est pour toi : remets juste la balle profonde au centre.", contre: "Chaque retour remis le met mal : il n'aime pas que ça revienne.", filet: "Bloque le retour bas et coupé dans ses pieds, il n'a pas le temps de se replacer.", service: "Duel de serveurs : le jeu décisif t'attend. 1re balle à 65 % mais placée, et ne perds pas ton service sur une double.", poly: "Retour bloqué au centre, puis prends l'échange : c'est là qu'il est le moins bon." },
        f: "Avance sur sa 2e balle", e: ["Le retour trop ambitieux", "Remettre la balle d'abord"] },
      poly: { t: "Impose ton jeu", s: "Joueur complet, pas de faille évidente : c'est toi qui dois décider du match.",
        me: { fond: "Décale-toi pour jouer un maximum de coups droits, et cherche sa diagonale la plus faible dès le début.", contre: "Mets-le dans l'inconfort : s'il doit tout faire lui-même, il finira par se tromper.", filet: "Monte sur toute balle courte : un joueur complet reste souvent moyen en passing.", service: "Ta 1re balle est ta meilleure arme : garde tes jeux et attends le jeu où il flanche.", poly: "Teste tout au premier set (slice, amorti, filet) et garde ce qui marche." },
        f: "Joue sur tes points forts" }
    };
    var mx = MX[g.style];
    if (mx) {
      var extra = (my.style && mx.me[my.style]) ? " " + mx.me[my.style] : "";
      if (!extra) extra = (arm("defense") ? " Ta défense est une arme ici." : "") + (arm("cd") ? " Joue-le avec ton coup droit." : "");
      add(g.style === "poly" ? 3.5 : 5.2, mx.t, mx.s + extra, mx.f, mx.e, { fond: "rythme", contre: "mur", filet: "net", service: "srv" }[g.style]);
    }
    // Armes précises × son style
    if (arm("physique") && (g.style === "fond" || g.style === "service")) add(4.2, "Ton physique, son point faible", "Les gros frappeurs et gros serveurs aiment les points courts. Fais durer : au 3e set, c'est lui qui devra courir.", "Une balle de plus");
    if (arm("mental") && g.style === "contre") add(4, "Ta patience contre la sienne", "Contre un contreur, c'est la tête qui gagne : accepte les échanges de 15 balles, ne t'énerve pas sur une faute.", null, ["T'agacer après un long point perdu", "C'est ce qu'il attend"]);
    if (arm("volee") && g.style !== "filet" && g.style !== "contre") add(3.8, "Termine au filet", "Ta volée est une arme qu'il ne voit pas souvent : une approche longue dans son revers et viens finir.", "Approche dans son revers");
    if (arm("service") && g.style === "contre") add(3.6, "Varie ton service", "Il retourne tout : service corps, slice large, kick. S'il ne sait pas où ça arrive, ses retours deviennent courts.", "Service au corps");
    // Ton revers à une main face à son jeu
    if (my.backhand === "1" && (g.style === "fond" || (g.hand === "G" && !meL))) add(4.6, "Protège ton revers à une main",
      (g.hand === "G" && !meL ? "Son coup droit croisé de gaucher arrive haut sur ton revers : " : "Ses balles lourdes vont viser ton revers à hauteur d'épaule : ") + "recule d'un pas pour le prendre en descente, ou coupe en slice long, et décale-toi en coup droit dès que possible.",
      null, ["Le revers à plat au-dessus de l'épaule", "La faute qu'il cherche"]);
    return out;
  }
  // ---------- Signaux du plan : seulement ses matchs contre ton niveau ou au-dessus ----------
  function ffSignals(D) {
    var A = D.Ab, B = D.Bh || D.Bb, rel = D.relLab, out = [], me = D.me, sq = function (n) { return Math.sqrt(n); };
    var r3 = function (x) { return x.v + " sur " + x.n; };
    // 0. Tes notes et ta fiche d'abord : c'est le plus précieux
    (D.noteDer || []).forEach(function (x, i) {
      if (x.p) out.push({ sc: 9 - i * 0.5 + (x.combo ? 1.5 : 0) + ({ "rev-": 1, "cd-": 1 }[x.k] || 0) - ({ "srv+": 2, ret: 2, tri: 2, lob: 1.5, fst: 1.5, men: 1, age: 1, all: 1.5, gch: 1 }[x.k] || 0), tg: NOTE_TG[x.k] || x.k, plan: { t: x.p.t, s: x.p.s, src: "Tes notes" }, fais: { t: x.p.t, w: "D'après tes notes" } });
      if (x.e) out.push({ sc: 8 - i * 0.5, evite: { t: x.e.t, w: x.e.w + " · d'après tes notes" } });
    });
    // Bibliothèque de coach : son jeu (fiche) × ton jeu
    coachLib(D.hisG || {}, myGame()).forEach(function (x) { out.push(x); });
    // Faux classements : il a battu des joueurs plus forts que leur classement du moment
    var rz = (D.rows || []).filter(function (m) { return m.risen && m.result === "V" && !m.wo && E.idx(m.oppRank) >= D.me - 1; });
    if (rz.length) { var rzUp = rz.some(function (m) { return E.idx(m.oppRank) >= D.me; });
      out.push({ sc: 2 + rz.reduce(function (a, m) { return a + m.risen; }, 0) * (rzUp ? 1.2 : 0.6), plan: { t: rzUp ? "Plus fort que son palmarès" : "Un peu mieux que son classement", s: "Il a battu " + rz.slice(0, 2).map(function (m) { return (m.opp ? m.opp + " " : "") + "(" + m.oppRank0 + " à l'époque, " + m.oppRank + " aujourd'hui)"; }).join(" et ") + (rz.length > 2 ? " et " + (rz.length - 2) + " autre" + (rz.length > 3 ? "s" : "") : "") + (rzUp ? ". Prépare un vrai match." : " : ses victoires valent un peu plus qu'il n'y paraît.") } }); }
    // Son passé : il a été mieux classé que toi
    var bp = D.best;
    if (bp && bp.b > D.me) {
      var when = bp.y ? (bp.age <= 1 ? "la saison dernière" : "en " + bp.y) : "";
      var bt = bp.age != null && bp.age <= 1 ? "Ancien " + bp.lab + ", tout récent"
        : "Ancien " + bp.lab;
      var bs = bp.age != null && bp.age <= 1 ? "Il était " + bp.lab + " " + when + " : son classement actuel le sous-estime sûrement. Joue-le comme un " + lab(D.hi + Math.max(1, Math.round(Math.min(1.5, bp.up * 0.35)))) + " ou mieux, pas comme un " + lab(D.hi) + "."
        : bp.age != null && bp.age <= 4 ? "Il a été " + bp.lab + " " + when + ". Ses résultats d'aujourd'hui disent " + lab(D.hi) + ", mais les coups ne s'oublient pas : méfie-toi de ses temps forts, et ne le laisse pas prendre confiance."
        : (when ? "Il a été " + bp.lab + " " + when + ". C'est loin et ses résultats disent " : "Il a déjà été " + bp.lab + ". Ses résultats d'aujourd'hui disent ") + lab(D.hi) + ", mais un ancien " + bp.lab + " garde du toucher et le sens du jeu : sérieux dès le premier point, sans t'affoler.";
      out.push({ sc: bp.age != null && bp.age <= 1 ? 7 : bp.age != null && bp.age <= 4 ? 4.5 : 3.2, tg: "past", plan: { t: bt, s: bs, src: "Son passé" } });
    }
    // 1. Son bilan contre ton classement exact
    var xh = D.xHim;
    if (xh.n >= 3) {
      var xr = xh.v / xh.n, exp = lvP(D.me - D.hi);
      if (xr <= exp - 0.15) out.push({ sc: (exp - xr) * sq(xh.n) * 2.5, plan: { t: "Ton classement lui résiste", s: "Contre les " + lab(D.me) + ", il est " + xh.v + " V – " + (xh.n - xh.v) + " D cette saison. Joue ton match, sans le craindre." } });
      else if (xr >= exp + 0.2) out.push({ sc: (xr - exp) * sq(xh.n) * 2.5, plan: { t: "Il bat souvent les " + lab(D.me), s: "Contre ton classement, il est " + xh.v + " V – " + (xh.n - xh.v) + " D cette saison : prépare un vrai match." } });
    }
    // 2. Contre ton niveau : ses départs, ses remontées, ses fins de set, ses 3es sets
    if (B.f1.n >= 4) {
      var fl = 1 - B.f1.w / B.f1.n;
      if (fl >= 0.55) out.push({ sc: (fl - 0.3) * sq(B.f1.n) * 1.6, plan: { t: "Mets-lui la pression d'entrée", s: rel + ", il perd le 1er set dans " + (B.f1.n - B.f1.w) + " matchs sur " + B.f1.n + " : agresse ses premiers jeux de service, pas de round d'observation." }, fais: { t: "Agresse ses premiers jeux de service", w: rel + " : 1er set perdu " + (B.f1.n - B.f1.w) + " fois sur " + B.f1.n } });
      else if (fl <= 0.3 && B.f1.n >= 5) out.push({ sc: (0.5 - fl) * sq(B.f1.n) * 1.4, plan: { t: "Encaisse son départ", s: rel + ", il gagne le 1er set dans " + B.f1.w + " matchs sur " + B.f1.n + ". Tiens au score, le match se joue après." }, fais: { t: "Tiens les premiers jeux", w: rel + " : 1er set gagné " + B.f1.w + " fois sur " + B.f1.n } });
    }
    if (B.f1l.n >= 3) {
      var cb = B.f1l.v / B.f1l.n;
      if (cb <= 0.25) out.push({ sc: (0.5 - cb) * sq(B.f1l.n) * 1.5, plan: { t: "Si tu mènes, accélère", s: rel + ", mené d'un set, il " + (B.f1l.v ? "n'a renversé que " + r3(B.f1l) : "n'est jamais revenu (0 sur " + B.f1l.n + ")") + " : le 2e set se gagne dès son premier jeu de service." }, fais: { t: "Mène d'un set ? Enfonce le clou", w: rel + ", mené d'un set, il " + (B.f1l.v ? "n'a renversé que " + B.f1l.v + " match" + (B.f1l.v > 1 ? "s" : "") + " sur " + B.f1l.n : "n'a jamais renversé le match (0 sur " + B.f1l.n + ")") } });
      else if (cb >= 0.5) out.push({ sc: (cb - 0.3) * sq(B.f1l.n) * 1.5, plan: { t: "Il ne lâche jamais", s: rel + ", même mené d'un set, il en a renversé " + r3(B.f1l) + ". Garde ton plan jusqu'à la dernière balle." }, evite: { t: "Te croire à l'abri après un set", w: rel + ", il a renversé " + r3(B.f1l) } });
    }
    if (B.three.n >= 2 && A.three.n >= 3) {
      var h3 = B.three.v / B.three.n, m3 = A.three.v / A.three.n;
      if (m3 - h3 >= 0.25) out.push({ sc: (m3 - h3) * sq(B.three.n + A.three.n) * 1.2, plan: { t: "Fais durer : le 3e set est pour toi", s: rel + ", il gagne " + r3(B.three) + " matchs en trois sets, toi " + r3(A.three) + ". Longs échanges, une balle de plus." }, fais: { t: "Allonge les échanges", w: "3es sets : toi " + r3(A.three) + ", lui " + r3(B.three) } });
      else if (h3 - m3 >= 0.25) out.push({ sc: (h3 - m3) * sq(B.three.n + A.three.n) * 1.2, plan: { t: "Fais la différence en deux sets", s: rel + ", il gagne " + r3(B.three) + " matchs en trois sets, toi " + r3(A.three) + ". Prends des risques plus tôt." }, evite: { t: "Un match qui s'éternise", w: "3es sets : lui " + r3(B.three) + ", toi " + r3(A.three) } });
    }
    if (A.close.n >= 4 && B.close.n >= 3) {
      var dc = A.close.v / A.close.n - B.close.v / B.close.n, w = "Sets serrés : toi " + r3(A.close) + ", lui " + r3(B.close);
      if (dc >= 0.2) out.push({ sc: dc * 2, plan: { t: "Reste au contact jusqu'à 5-5", s: w + " " + rel.charAt(0).toLowerCase() + rel.slice(1) + " : quand ça se resserre, c'est pour toi." }, evite: { t: "Forcer pour finir vite", w: w } });
      else if (dc <= -0.2) out.push({ sc: -dc * 2, plan: { t: "Fais le break tôt", s: w + " : il est solide dans les fins de set, prends de l'avance avant 4-4." }, fais: { t: "Fais le break tôt dans chaque set", w: w } });
    }
    // 3. Ton piège
    if (D.A.weak >= 2 && D.hi < D.me) {
      if (D.A.weakAfterSet >= 2) out.push({ sc: 1.1, evite: { t: "Relâcher après le 1er set", w: "Tes " + D.A.weakAfterSet + " défaites contre moins bien classé sont venues après un 1er set gagné" } });
      else out.push({ sc: 0.9, evite: { t: "Le prendre de haut", w: "Tes " + D.A.weak + " défaites contre moins bien classé sur 12 mois" } });
    }
    return out.sort(function (a, b) { return b.sc - a.sc; });
  }
  function ffOddsCard(D) {
    var od = D.od; if (!od) return "";
    var parts = [], paper = D.me - D.hi;
    parts.push(paper > 0 ? plural(paper, "échelon") + " d'écart en ta faveur" : paper < 0 ? "il est " + plural(-paper, "échelon") + " au-dessus" : "même classement");
    // Forme pondérée : ses résultats récents contre des joueurs de ton niveau, pas contre n'importe qui
    if (!D.few) {
      var relH = D.B.last.filter(function (m) { return E.idx(m.oppRank) >= D.me - 1; }).slice(0, 5), relV = relH.filter(function (m) { return m.result === "V"; }).length;
      if (relH.length >= 2 && relV / relH.length >= 0.6) parts.push("il gagne en ce moment contre des joueurs de ton niveau");
      else if (relH.length >= 3 && relV / relH.length <= 0.25) parts.push("il perd ses derniers matchs contre des joueurs de ton niveau");
    }
    if (D.xHim.n >= 3) parts.push("contre les " + lab(D.me) + " il est " + D.xHim.v + " V – " + (D.xHim.n - D.xHim.v) + " D");
    var lm = D.mine[0]; if (lm) parts.push((lm.result === "V" ? "tu l'as battu" : "il t'a battu") + " en " + MOIS_L[E.parseDate(lm.date).getMonth()]);
    parts = parts.slice(0, 3); var why = parts.join(", ").replace(/, ([^,]*)$/, " et $1"); why = why.charAt(0).toUpperCase() + why.slice(1) + ".";
    var p = Math.round(od.p * 100), ring = '<div class="ff-ring"><svg viewBox="0 0 36 36" width="92" height="92"><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--line)" stroke-width="4"/><circle cx="18" cy="18" r="15.5" fill="none" stroke="' + (od.p >= 0.5 ? "var(--gazon)" : "var(--terre)") + '" stroke-width="4" stroke-linecap="round" stroke-dasharray="' + (97.4 * od.p).toFixed(1) + ' 97.4"/></svg><b>' + p + " %</b></div>";
    // D'où vient le chiffre : chaque ingrédient en points, avec ses données
    var rl = function (L) { L = Math.round(L); return L < 0 ? "NC" : lab(L); };
    // Niveaux réels sans arrondi trompeur : « entre 15/4 et 15/3 » quand c'est entre les deux, puis l'écart réel
    var rl2 = function (L) { var f = Math.floor(L), r = L - f; return r < 0.25 ? rl(f) : r > 0.75 ? rl(f + 1) : "entre " + rl(f) + " et " + rl(f + 1); };
    var gapL = D.myL - D.hisL, gapT = Math.abs(gapL) < 0.2 ? " : quasi le même niveau" : " : " + (Math.round(Math.abs(gapL) * 10) / 10).toString().replace(".", ",") + " échelon" + (Math.abs(gapL) >= 1.95 ? "s" : "") + " d'avance pour " + (gapL > 0 ? "toi" : "lui");
    var det = { "Vos vrais niveaux": "Toi " + rl2(D.myL) + ", lui " + rl2(D.hisL) + gapT + (od.parts && od.parts[0] && od.parts[0].best && D.best ? " (il était " + D.best.lab + " récemment)" : ""),
      "Bilans face au classement de l'autre": [od.q1.n ? "lui contre les " + lab(D.me) + " : " + od.q1.v + " V – " + (od.q1.n - od.q1.v) + " D" : "", od.q2.n ? "toi contre les " + ffRk(D.hi) + " : " + od.q2.v + " V – " + (od.q2.n - od.q2.v) + " D" : ""].filter(Boolean).join(" · "),
      "Formes contre ce niveau": od.hRel != null && od.mRel != null ? "Derniers matchs à ce niveau : toi " + Math.round(od.mRel * 100) + " % de victoires, lui " + Math.round(od.hRel * 100) + " %" : "" };
    var bd = (od.parts || []).filter(function (x) { return x.l === "Vos vrais niveaux" || x.d !== 0; }).map(function (x) {
      var d = x.d, sg = d > 0 ? "+" + d : d < 0 ? "−" + (-d) : "0", ex = det[x.l] != null ? det[x.l] : (D.mine || []).map(function (m) { return (m.result === "V" ? "V " : "D ") + (m.score || ""); }).slice(0, 3).join(" · ");
      return '<div class="bd"><span class="grow"><b>' + esc(x.l) + "</b>" + (ex ? '<span class="small">' + esc(ex) + "</span>" : "") + '</span><span class="pt ' + (d > 0 ? "up" : d < 0 ? "dn" : "") + '">' + sg + "</span></div>";
    }).join("");
    if (bd) bd = '<div class="ff-bd"><span class="bh">D\'où vient ce ' + p + ' % <i>(on part de 50)</i></span>' + bd + "</div>";
    return '<div class="card ff-odds"><span class="eyebrow">Le match</span><div class="row1">' + ring + '<div><span class="h">' + esc(od.head) + '</span><span class="small">' + esc(why) + '</span></div></div><span class="p">' + esc(od.txt) + "</span>" + bd + "</div>";
  }
  // ---------- Dans ta tête : tes moments clés, tirés de tes chiffres (remplace le scénario du match) ----------
  function ffMind(D) {
    var A = D.A, B = D.B, first = D.first, items = [], fr = function (x) { return x.v + " sur " + x.n; };
    var card = function (o) {
      return '<div class="mm"><div class="mh"><span class="ic ' + o.c + '">' + o.ic + '</span><div><b>' + o.t + "</b><small>" + o.st + "</small></div></div>" +
        (o.n ? '<div class="stat"><span class="n">' + o.n + '</span><span class="l">' + o.l + "</span></div>" : "") +
        (o.vs ? '<div class="vs"><i>' + o.vsk + "</i> " + o.vs + "</div>" : "") + (o.body ? '<div class="vs">' + o.body + "</div>" : "") +
        '<div class="cue">« ' + o.cue + " »</div>" + (o.rt ? '<div class="rt">' + o.rt + "</div>" : "") + "</div>";
    };
    // 1. Mené d'un set
    if (A.f1l.n >= 3) {
      var r = A.f1l.v / A.f1l.n, o = { c: "r", ic: "↺", t: "Si tu perds le 1er set", st: "Le moment où on panique", n: fr(A.f1l), l: "matchs renversés après un 1er set perdu, sur 12 mois." };
      if (r >= 0.35) { o.l += " C'est une de tes forces."; o.cue = A.f1l.v > 1 ? "Je l'ai déjà fait " + A.f1l.v + " fois. Un set, c'est six jeux." : "Un set, c'est six jeux. Rien n'est joué."; o.rt = "Au changement de côté : 3 respirations lentes, puis une seule consigne pour le 2e set, pas trois."; }
      else { o.l += " Ton point à travailler : ne laisse pas le 1er set décider pour toi."; o.cue = "Je remets le compteur à zéro. Premier jeu du 2e set, premier objectif."; o.rt = "Au changement de côté : 3 respirations lentes. Change une seule chose (plus de marge, ou monter sur la balle courte), pas tout ton jeu."; }
      if (B.f1w.n >= 3) { var hl = B.f1w.l; o.vsk = "Contre lui :"; o.vs = hl / B.f1w.n >= 0.25 ? "quand il gagne le 1er set, il perd quand même " + hl + " match" + (hl > 1 ? "s" : "") + " sur " + B.f1w.n + ". Le match reste ouvert." : "quand il gagne le 1er set, il ne lâche presque jamais (" + (B.f1w.n - hl) + " victoires sur " + B.f1w.n + "). Raison de plus pour bien démarrer."; }
      items.push(o);
    }
    // 2. Quand ça se resserre
    if (A.close.n >= 4 || A.tb.n >= 4) {
      var cr = A.close.n ? A.close.v / A.close.n : A.tb.v / A.tb.n;
      var o2 = { c: "y", ic: "⚖", t: "Quand ça se resserre", st: "5-5, 6-6, tie-break", n: A.close.n >= 4 ? fr(A.close) : fr(A.tb), l: (A.close.n >= 4 ? "sets serrés gagnés (7-5, 7-6)" : "tie-breaks gagnés") + (A.close.n >= 4 && A.tb.n >= 3 ? " · " + fr(A.tb) + " tie-breaks" : "") + "." };
      o2.cue = cr >= 0.55 ? "Je joue mes points, pas les siens." : "Une balle de plus. C'est lui qui doit faire le point.";
      o2.rt = cr >= 0.55 ? "Tu es solide dans ces moments : garde ta routine entre les points (serviette, cordes), même rythme." : "Dans ces moments, tu forces souvent : premier service avec de la marge, et fais-le jouer.";
      if (B.close.n >= 4) { var dd = A.close.v / Math.max(1, A.close.n) - B.close.v / B.close.n; o2.vsk = "Lui :"; o2.vs = fr(B.close) + " sets serrés. " + (dd >= 0.15 ? "C'est toi le plus solide quand ça chauffe." : dd <= -0.15 ? "Il est solide dans ces moments : fais la différence avant 5-5." : "Vous vous valez dans ces moments."); }
      items.push(o2);
    }
    // 3. Quand tu mènes
    if (A.f1w.n >= 5) {
      var o3 = { c: "g", ic: "↗", t: "Quand tu mènes", st: "Le piège du relâchement", n: A.f1w.l + " sur " + A.f1w.n, l: "matchs perdus après avoir gagné le 1er set." + (A.weakAfterSet >= 2 ? " Dont " + A.weakAfterSet + " contre moins bien classé : c'est là que tu te relâches." : A.f1w.l / A.f1w.n <= 0.15 ? " C'est rare chez toi." : "") };
      o3.cue = "Même plan, même intensité, jusqu'à la poignée de main.";
      o3.rt = "Ne change rien qui marche. Le 1er jeu du 2e set est le plus important.";
      if (B.f1l.n >= 3) { o3.vsk = "Lui :"; o3.vs = B.f1l.v ? "mené d'un set, il a renversé " + B.f1l.v + " match" + (B.f1l.v > 1 ? "s" : "") + " sur " + B.f1l.n + " : ne le laisse pas revenir." : "mené d'un set, il n'est jamais revenu (0 sur " + B.f1l.n + ")."; }
      items.push(o3);
    }
    // 4. Avant d'entrer : ta raquette gagnante, votre dernier match
    var g = {}, best = null;
    D.myMs.forEach(function (m) { if (!m.racketId) return; var k = m.racketId + "|" + (m.tension || ""); (g[k] = g[k] || { r: m.racketId, t: m.tension, v: 0, n: 0 }); g[k].n++; if (m.result === "V") g[k].v++; });
    Object.keys(g).forEach(function (k) { var x = g[k]; if (x.n >= 4 && x.v / x.n >= 0.6 && (!best || x.v / x.n > best.v / best.n)) best = x; });
    var rk = best && racket(best.r), lm = D.mine[0], parts = [];
    if (rk) { var st0 = racketStatus(rk); parts.push("Ta meilleure version : <b>ta " + esc(rk.name) + (best.t ? " à " + best.t + " kg" : "") + "</b> (" + best.v + " victoires sur " + best.n + ")" + (st0.level === "change" || st0.level === "broken" ? ". Pense à la recorder." : ".")); }
    if (lm) parts.push("Votre dernier match : <b>" + (lm.result === "V" ? "victoire" : "défaite") + (lm.score ? " " + esc(lm.score) : "") + "</b>" + (lm.feel ? ", ressenti " + lm.feel + "/5" : "") + "." + (lm.note ? " Ta note : « " + esc(String(lm.note).trim()) + " »." : ""));
    if (parts.length) items.push({ c: "y", ic: "●", t: "Avant d'entrer", st: "Ce qui te met dans ton match", body: parts.join(" "), cue: lm && lm.result === "V" ? "J'ai déjà gagné ce match-là." : lm ? "Ce coup-ci, c'est moi qui pose le jeu." : "Je connais mon plan. Je joue mon tennis." });
    D.mindItems = items; D.bestRk = rk ? { name: rk.name, color: rk.color, v: best.v, n: best.n, t: best.t } : null;
    if (!items.length) return "";
    return '<div class="card key ff-mind"><span class="eyebrow">Dans ta tête · tes moments clés</span><span class="small">Tirés de tes ' + plural(D.myMs.length, "match", "matchs") + " et de son palmarès. Relis-les au changement de côté.</span>" + items.map(card).join("") + "</div>";
  }
  function ffTree(D) {
    var A = D.Ab, B = D.Bb, first = D.first;
    if (A.f1.n < 4 || B.f1.n < 4) return "";
    var verdict = function (d) { return Math.abs(d) < 0.08 ? ffBadge("eq", "Équilibré") : Math.abs(d) < 0.18 ? ffBadge("eq", "Léger avantage " + (d > 0 ? "toi" : "lui")) : ffBadge(d > 0 ? "me" : "him", "Avantage " + (d > 0 ? "toi" : "lui")); };
    var ma = A.f1.w / A.f1.n, hb = B.f1.w / B.f1.n;
    var start = 1 - hb >= 0.5 ? "Il démarre lentement : mets de l'intensité dès les premiers jeux." : hb >= 0.65 ? "Il démarre fort : tiens les premiers jeux, ne panique pas s'il mène." : "Départs équilibrés : joue ton jeu dès le premier point.";
    var s = '<div class="card ff-tree"><span class="eyebrow">Le scénario du match</span><div class="ff-leg2"><span class="a">Toi</span><span class="b">' + esc(first) + "</span></div><div class=\"flow\">" +
      '<div class="node"><div class="nh"><b>Le début</b>' + verdict(ma - hb) + "</div>" + ffDuel(ma, hb, ffPct(ma), ffPct(hb), ma - hb >= 0.08 ? 1 : hb - ma >= 0.08 ? -1 : 0) + '<span class="small">1er set gagné</span><span class="adv">' + start + "</span></div>";
    var hc = B.f1l.n >= 3 ? B.f1l.v / B.f1l.n : null, mc = A.f1l.n >= 3 ? A.f1l.v / A.f1l.n : null;
    if (hc != null || mc != null) {
      var g = D.hisG || {}, change = g.backhand === "1" ? "balles hautes sur son revers" : g.style === "contre" ? "avance sur la balle courte" : g.style === "fond" ? "casse son rythme avec du slice" : "plus de balles hautes, ou monte sur la balle courte";
      var left = hc == null ? '<span class="small">Pas assez de données pour lui.</span>' : '<div class="big">' + B.f1l.v + "/" + B.f1l.n + '<small>remontées pour lui</small></div>' + (hc <= 0.2 ? ffBadge("me", "Match plié") : hc <= 0.4 ? ffBadge("me", "Bien parti") : ffBadge("him", "Il revient souvent")) + '<span class="adv">' + (hc <= 0.4 ? "Ne change rien, il revient rarement." : "Ne relâche rien : il a renversé " + B.f1l.v + " matchs sur " + B.f1l.n + ".") + "</span>";
      var right = mc == null ? '<span class="small">Pas assez de données pour toi.</span>' : '<div class="big">' + A.f1l.v + "/" + A.f1l.n + '<small>remontées pour toi</small></div>' + (mc >= 0.4 ? ffBadge("eq", "Jouable") : mc >= 0.2 ? ffBadge("him", "Difficile") : ffBadge("him", "Danger")) + '<span class="adv">' + (mc >= 0.4 ? "Tu sais revenir : garde ton plan, ça tourne souvent." : "Change une seule chose : " + change + ".") + "</span>";
      s += '<div class="fork"><i class="l"></i><i class="r"></i></div><div class="split"><div class="node me"><b class="bt">Tu gagnes le 1er set</b>' + left + '</div><div class="node him"><b class="bt">Tu perds le 1er set</b>' + right + "</div></div>";
    }
    if (A.three.n >= 3 && B.three.n >= 3) {
      var m3 = A.three.v / A.three.n, h3 = B.three.v / B.three.n, d3 = m3 - h3;
      s += '<div class="join"><i class="l"></i><i class="r"></i></div><div class="node"><div class="nh"><b>Le 3e set</b>' + verdict(d3) + "</div>" + ffDuel(m3, h3, A.three.v + "/" + A.three.n, B.three.v + "/" + B.three.n, d3 >= 0.08 ? 1 : d3 <= -0.08 ? -1 : 0) +
        '<span class="adv">' + (d3 >= 0.18 ? "S'il y a un 3e set, il est pour toi : allonge les échanges, fais-le jouer une balle de plus." : d3 <= -0.18 ? "Le 3e set est son terrain : fais la différence avant." : "Au 3e set, vous vous valez : c'est le physique et la tête qui trancheront.") + "</span></div>";
    }
    s += "</div>";
    if (A.tb.n || B.tb.n) s += '<div class="foot"><span class="chipx">Tie-break</span><span>Toi ' + A.tb.v + "/" + A.tb.n + " · lui " + B.tb.v + "/" + B.tb.n + (A.tb.n >= 5 && B.tb.n >= 5 ? "" : " : trop peu pour conclure") + ".</span></div>";
    return s + "</div>";
  }
  function ffBandCard(D) {
    var me = D.me, band = D.hp.filter(function (m) { var o = E.idx(m.oppRank); return o >= me - 1 && o <= me + 1; }).sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; });
    if (band.length < 2) return "";
    var v = band.filter(function (m) { return m.result === "V"; }).length, l = band.length - v, br = v / band.length;
    var setTaken = band.filter(function (m) { return m.result === "D" && setsOf(m.score).some(function (x) { return x[0] > x[1]; }); }).length;
    var lower = D.hp.filter(function (m) { return E.idx(m.oppRank) < me - 1; }), lv = lower.filter(function (m) { return m.result === "V"; }).length;
    var txt = br <= 0.35 && setTaken >= 2 && setTaken * 2 >= l ? "Il accroche un set, puis il cède. Ne te décourage pas s'il mène." : br <= 0.35 ? "Ton niveau lui pose problème cette saison." : br >= 0.6 ? "Il est à l'aise contre ton niveau : prépare un vrai match." : "Bilan partagé contre ton niveau : rien n'est écrit.";
    return '<div class="card ff-band"><span class="eyebrow">Contre des joueurs comme toi</span><div class="hd"><span class="big">' + v + " V – " + l + ' D</span><span class="small">contre des ' + esc(lab(Math.max(0, me - 1))) + " à " + esc(lab(Math.min(E.MAX_CALC, me + 1))) + "</span></div>" +
      '<div class="res">' + band.slice(0, 8).map(function (m) { return '<span class="r"><span class="vd ' + m.result + '">' + m.result + "</span>" + esc(m.oppRank + (m.score ? " · " + m.score : "")) + "</span>"; }).join("") + "</div>" +
      '<span class="p">' + txt + "</span>" + (lower.length >= 3 ? '<span class="small">Contre les ' + esc(lab(Math.max(0, me - 2))) + " et moins bien : " + lv + " V – " + (lower.length - lv) + " D.</span>" : "") + "</div>";
  }
  function ffMoment(D) {
    var items = [], B = D.B, p = B.last;
    if (p.length >= 2) {
      var r0 = p[0].result, n = 0; for (var i = 0; i < p.length && p[i].result === r0; i++) n++;
      var dots = p.slice(0, 6).reverse().map(function (m) { return '<i class="' + m.result + '"></i>'; }).join(""), days = p[0].date ? Math.round((today() - E.parseDate(p[0].date)) / 864e5) : null;
      var lastTxt = (r0 === "V" ? "La dernière" : "La dernière") + (days != null ? " il y a " + plural(days, "jour") : "") + (p[0].score ? " : " + p[0].score : "") + " contre un " + p[0].oppRank + ".";
      if (r0 === "D" && n >= 2) items.push({ k: "good", tag: "Bon pour toi", t: plural(n, "défaite") + " de suite", s: lastTxt, viz: '<div class="dots">' + dots + '</div><span class="vlab">' + Math.min(6, p.length) + " derniers</span>" });
      else if (r0 === "V" && n >= 3) {
        var sq = p.slice(0, n), relW = sq.filter(function (m) { return E.idx(m.oppRank) >= D.me - 1; }).length, rk = sq.map(function (m) { return E.idx(m.oppRank); }).filter(function (x) { return x != null; });
        if (relW) items.push({ k: "warn", tag: "Attention", t: n + " victoires de suite", s: "Dont " + plural(relW, "contre un joueur", "contre des joueurs") + " de ton niveau. " + lastTxt.replace("La dernière", "La dernière victoire"), viz: '<div class="dots">' + dots + '</div><span class="vlab">' + Math.min(6, p.length) + " derniers</span>" });
        else items.push({ k: "good", tag: "Pas inquiétant", t: n + " victoires de suite", s: "Mais contre " + ffRange(Math.min.apply(null, rk), Math.max.apply(null, rk)).replace(/^les /, "des ") + " : rien qui dise qu'il bat ton niveau.", viz: '<div class="dots">' + dots + '</div><span class="vlab">' + Math.min(6, p.length) + " derniers</span>" });
      }
    }
    var st = scoutStats(D.rows);
    if (st.second.n >= 3) {
      var sr = st.second.v / st.second.n;
      if (sr <= 0.4) items.push({ k: "good", tag: "Bon pour toi", t: "Le lendemain, il baisse", s: "En tournoi, " + plural(st.second.v, "victoire") + " sur " + st.second.n + " dans son 2e match du week-end. S'il a joué la veille, fais-le courir tôt.", viz: '<span class="frac">' + st.second.v + "/" + st.second.n + '</span><span class="vlab">le lendemain</span>' });
      else if (sr >= 0.75) items.push({ k: "warn", tag: "Attention", t: "Il enchaîne sans baisser", s: st.second.v + " victoires sur " + st.second.n + " dans son 2e match du week-end.", viz: '<span class="frac">' + st.second.v + "/" + st.second.n + '</span><span class="vlab">le lendemain</span>' });
    }
    var wk = weekCounts(D.rows).slice(4), tot4 = wk.reduce(function (a, b) { return a + b; }, 0), mx = Math.max.apply(null, wk.concat([1]));
    var bars = '<div class="wk">' + wk.map(function (x) { return '<i style="height:' + Math.max(12, Math.round(x / mx * 100)) + '%;opacity:' + (x ? 1 : 0.3) + '"></i>'; }).join("") + '</div><span class="vlab">4 semaines</span>';
    if (tot4 >= 4) items.push({ k: "warn", tag: "Attention", t: "Il a du rythme", s: plural(tot4, "match", "matchs") + " en 4 semaines : il sera dedans tout de suite, pas de temps à lui laisser.", viz: bars });
    else if (p.length >= 3 && p[0].date && (today() - E.parseDate(p[0].date)) / 864e5 >= 42) items.push({ k: "good", tag: "Bon pour toi", t: "Il manque de rythme", s: "Pas de match depuis " + plural(Math.round((today() - E.parseDate(p[0].date)) / (7 * 864e5)), "semaine") + " : mets-lui de l'intensité d'entrée.", viz: bars });
    var sp = D.sp;
    if (sp && sp.dir === "down") items.push({ k: "good", tag: "Bon pour toi", t: "Il joue son maintien", s: "Sa simulation Ten'Up le voit descendre à " + lab(sp.proj) + ". La pression est sur lui.", viz: '<span class="frac">↓</span><span class="vlab">' + esc(lab(sp.proj)) + "</span>" });
    else if (sp && sp.dir === "up") items.push({ k: "warn", tag: "Attention", t: "Il est en route pour " + lab(sp.proj), s: "Sa simulation Ten'Up le voit monter : il est en confiance.", viz: '<span class="frac">↑</span><span class="vlab">' + esc(lab(sp.proj)) + "</span>" });
    if (!items.length) return "";
    return '<div class="card ff-mo"><span class="eyebrow">Son moment</span>' + items.slice(0, 3).map(function (x) {
      return '<div class="mi"><div class="viz ' + x.k + '">' + x.viz + '</div><div><span class="pillt ' + x.k + '">' + x.tag + "</span><b>" + esc(x.t) + '</b><span class="tx">' + esc(x.s) + "</span></div></div>";
    }).join("") + "</div>";
  }
  function ffLastCard(D) {
    var m = D.mine[0]; if (!m) return "";
    var r = m.racketId ? racket(m.racketId) : null, facts = [];
    if (m.surface) facts.push(m.surface);
    if (m.indoor === true) facts.push("Intérieur"); else if (m.indoor === false) facts.push("Extérieur");
    if (r) facts.push("Ta " + r.name + (m.tension ? " · " + m.tension + " kg" : ""));
    if (m.feel) facts.push("Ressenti " + m.feel + "/5");
    var note = String(m.note || "").trim();
    return '<a class="card ff-last" href="#/match/' + m.id + '"><span class="eyebrow">Votre dernier match</span><div class="hd"><span class="r"><span class="vd ' + m.result + '">' + m.result + "</span>" + esc(m.score || (m.result === "V" ? "Victoire" : "Défaite")) + '</span><span class="small">' + esc([fdate(m.date).replace(/\.$/, ""), m.comp].filter(Boolean).join(" · ")) + "</span></div>" +
      (facts.length ? '<div class="facts">' + facts.map(function (f) { return "<span>" + esc(f) + "</span>"; }).join("") + "</div>" : "") +
      (note ? '<div class="note">« ' + esc(note) + ' »</div><span class="small">Ta note de ce jour-là.</span>' : facts.length ? "" : '<span class="small">Annote ce match (surface, raquette, ressenti) pour t\'en servir la prochaine fois.</span>') + "</a>";
  }
  function ffBestCard(D) {
    var items = [], g = {};
    D.myMs.forEach(function (m) { if (!m.racketId) return; var k = m.racketId + "|" + (m.tension || ""); (g[k] = g[k] || { r: m.racketId, t: m.tension, v: 0, n: 0 }); g[k].n++; if (m.result === "V") g[k].v++; });
    var best = Object.keys(g).map(function (k) { return g[k]; }).filter(function (x) { return x.n >= 4 && x.v / x.n >= 0.65; }).sort(function (a, b) { return b.v / b.n - a.v / a.n || b.n - a.n; })[0];
    if (best) {
      var rk = racket(best.r);
      if (rk) {
        var st = racketStatus(rk), cord = st.level === "change" || st.level === "broken" ? " Pense à la recorder avant ce match." : st.level === "soon" ? " Son cordage a " + fmtHours(st.min) + " : ça tient encore pour ce match." : "";
        items.push({ k: "good", ic: "✓", tag: "Ton arme", t: "Ta " + rk.name + (best.t ? " à " + best.t + " kg" : ""), s: best.v + " victoires sur " + best.n + " avec elle." + cord });
      }
    }
    var A = D.A;
    if (A.weak >= 2) items.push({ k: "warn", ic: "!", tag: "Attention", t: "Ton piège à toi", s: A.weakAfterSet >= 2 ? "Tes " + A.weak + " défaites contre moins bien classé : " + A.weakAfterSet + " après un 1er set gagné. Ne relâche pas." : "Tes " + A.weak + " défaites contre moins bien classé sur 12 mois : prends ce match au sérieux dès l'échauffement." });
    if (!items.length) return "";
    return '<div class="card ff-best"><span class="eyebrow">Ta meilleure version</span>' + items.map(function (x) { return '<div class="mo"><span class="ic ' + x.k + '">' + x.ic + '</span><div><span class="pillt ' + x.k + '">' + x.tag + "</span><b>" + esc(x.t) + "</b><span>" + esc(x.s) + "</span></div></div>"; }).join("") + "</div>";
  }
  function ffPlanTab(D, extra) {
    var s = (D.od ? '<button class="btn primary mm-go" data-a="mmOpen">' + svg('<path d="M8 5v14l11-7z"/>', 2) + " Je joue contre lui</button>" : "") + ffOddsCard(D), od = D.od;
    if (od && od.k === "monde") {
      s += '<div class="card ff-fe"><span class="eyebrow">Ton objectif du jour</span><div class="ok"><div class="gh">Travaille</div>' +
        ["70 % de premières balles", "Monter au filet sur chaque balle courte", "Attaquer ses deuxièmes balles en retour"].map(function (t) { return '<div class="it ok"><span class="ic">' + I.check + "</span><div><b>" + t + '</b></div></div>'; }).join("") +
        '</div><span class="small">Choisis-en une. Avec cet écart, le score n\'est pas la question : profites-en pour progresser.</span></div>';
      return s + extra;
    }
    s += ffNotesCard(D);
    var sig = ffSignals(D);
    // Synthèse : un point par cible (une note qui confirme la fiche fusionne avec elle), 2 au plus par source
    var plan = [], byTg = {}, bySrc = {};
    sig.filter(function (x) { return x.plan; }).forEach(function (x) {
      var src = x.plan.src || "stats", hit = x.tg && byTg[x.tg];
      if (hit) {
        if (hit.plan.src === "Tes notes" && src === "Sa fiche") { var i = plan.indexOf(hit), m = Object.assign({}, x, { plan: Object.assign({}, x.plan, { src: "Tes notes + fiche" }) }); plan[i] = m; byTg[x.tg] = m; }
        else if (hit.plan.src === "Sa fiche" && src === "Tes notes") hit.plan = Object.assign({}, hit.plan, { src: "Tes notes + fiche" });
        return;
      }
      if (plan.length >= 3 || (bySrc[src] || 0) >= (src === "Tes notes" && (D.noteDer || []).length >= 4 ? 3 : 2)) return;
      plan.push(x); bySrc[src] = (bySrc[src] || 0) + 1; if (x.tg) byTg[x.tg] = x;
    });
    D.planPicked = plan;
    if (plan.length < 3) sig.forEach(function (x) { if (plan.length < 3 && x.plan && plan.indexOf(x) < 0 && !(x.tg && byTg[x.tg]) && !plan.some(function (y) { return y.plan.t === x.plan.t; })) { plan.push(x); if (x.tg) byTg[x.tg] = x; } });
    if (plan.length) s += '<div class="card key ff-plan"><span class="eyebrow">Ton plan en ' + plural(plan.length, "point") + "</span>" + plan.map(function (x, i) { return '<div class="k3"><span class="n">' + (i + 1) + "</span><div><b>" + esc(x.plan.t) + (x.plan.src ? ' <i class="src">' + esc(x.plan.src) + "</i>" : "") + "</b><span>" + esc(x.plan.s) + "</span></div></div>"; }).join("") + "</div>";
    var inPlan = {}; plan.forEach(function (x) { inPlan[x.plan.t] = 1; if (x.fais) inPlan[x.fais.t] = 1; });
    var fais = sig.filter(function (x) { return x.fais && x.fais.t && !inPlan[x.fais.t] && !(x.tg && byTg[x.tg] && x.plan && x.plan.src === "Tes notes") && !(x.plan && plan.indexOf(x) >= 0); }).slice(0, 3), evite = sig.filter(function (x) { return x.evite && x.evite.t; }).slice(0, 3);
    if (fais.length || evite.length) {
      var it = function (cls, ic, x) { return '<div class="it ' + cls + '"><span class="ic">' + ic + "</span><div><b>" + esc(x.t) + '</b><span class="why">' + esc(x.w) + "</span></div></div>"; };
      s += '<div class="card ff-fe"><span class="eyebrow">À faire, à éviter</span>' + (fais.length ? '<div class="ok"><div class="gh">Fais</div>' + fais.map(function (x) { return it("ok", I.check, x.fais); }).join("") + "</div>" : "") +
        (evite.length ? '<div class="ko"><div class="gh">Évite</div>' + evite.map(function (x) { return it("ko", I.cross, x.evite); }).join("") + "</div>" : "") + "</div>";
    }
    if (!plan.length && !fais.length && !evite.length && !D.few) s += '<div class="card soft"><span class="p">' + (D.hp.length < 5 ? "Encore quelques matchs pour lui cette saison et Montée pourra te bâtir un plan de jeu." : "Rien de marquant dans ses résultats : pas de point faible net. Joue ton jeu.") + "</span></div>";
    s += D.gamePrompt || "";
    s += strengthsHtml(myStrengths(D.hi).slice(0, 3), "Rappelle-toi · tes forces", "Ce sur quoi tu peux compter si ça se resserre.");
    s += ffMind(D);
    if (!D.few) s += ffBandCard(D) + ffMoment(D);
    s += ffLastCard(D);
    return s + extra;
  }

  function ffStake(D) {
    var c = D.c, me = D.me, hi = D.hi, sp = D.sp, s = "";
    var sw = null; try { sw = E.simulateWin(allMatches(), c.cur, c.sex, hi, c.opts); } catch (e) {}
    var up1 = sw && sw.after.projected > sw.before.projected && sw.after.status === "montee", g = sw ? sw.gain : 0;
    var myTxt = up1 ? "Tu passes la norme " + lab(sw.after.projected) + " : montée le " + fdate(c.proj.release).replace(/\.$/, "") + "." : g > 0 ? "À ton bilan " + lab(Math.min(me + 1, E.MAX_CALC)) + "." : "Pas de points de plus (victoire hors quota), mais une victoire qui compte pour la tête.";
    var hisBig, hisTxt, pressure = 0;
    if (sp && sp.dir === "down") { hisBig = "Descente"; hisTxt = "Sa simulation le voit déjà descendre à " + lab(sp.proj) + ". Une défaite de plus l'enfonce."; pressure = 2; }
    else if (sp && sp.margin != null && sp.margin <= 40) { hisBig = sp.margin + " pts"; hisTxt = "C'est tout ce qu'il a d'avance pour rester " + lab(sp.cur) + ". Une défaite contre toi peut le faire basculer."; pressure = 1; }
    else if (sp && sp.dir === "up") { hisBig = "Montée"; hisTxt = "Il est en route pour " + lab(sp.proj) + ". Une défaite contre toi peut la lui coûter."; pressure = 1; }
    else if (hi != null && me - hi >= 2) { hisBig = "+" + E.BAREME.win(me - hi - 1) + " pts"; hisTxt = "Te battre, ce serait une grosse perf pour lui (" + (me - hi) + " échelons au-dessus). Il n'a rien à perdre : attends-toi à ce qu'il joue libéré."; pressure = -1; }
    else if (hi != null && me - hi === 1) { hisBig = "+" + E.BAREME.win(0) + " pts"; hisTxt = "Te battre, ce serait une perf pour lui : il jouera sans pression."; pressure = -1; }
    else { hisBig = "Tranquille"; hisTxt = "Son classement ne se joue pas sur ce match."; }
    var call = pressure < 0 ? "Il n'a rien à perdre, toi si : ne joue pas le classement, joue chaque point." : pressure >= 1 && !up1 ? "Il a plus à perdre que toi. Joue libéré." : up1 && pressure >= 1 ? "Gros enjeu des deux côtés : celui qui reste calme sur les points importants gagne." : up1 ? "Une victoire te fait monter : joue point par point, pas le score." : "Pas de pression au classement : joue ton jeu.";
    s += '<div class="card cmp" style="gap:10px"><span class="eyebrow">L\'enjeu</span><div class="stk"><div class="a"><span class="k">Si tu gagnes</span><b>+' + g + " pts</b><span>" + esc(myTxt) + '</span></div><div class="z"><span class="k">Pour lui</span><b>' + esc(hisBig) + "</b><span>" + esc(hisTxt) + '</span></div></div><div class="callout">' + esc(call) + "</div></div>";
    return s;
  }
  // ---------- Page spéciale : le créateur de Montée (reconnu par empreinte, rien en clair) ----------
  function fnv(str) { var x = 0x811c9dc5; for (var i = 0; i < str.length; i++) { x ^= str.charCodeAt(i); x = Math.imul(x, 16777619) >>> 0; } return x.toString(36); }
  var DEV_H = { lic: ["f4ywx3", "9g3nbd"], nc: "csj6ay" };
  function isDev(pr) {
    if (!pr) return false;
    var lic = String(pr.lic || pr.licence || "").replace(/\s/g, "").toUpperCase();
    if (lic && DEV_H.lic.indexOf(fnv(lic)) >= 0) return true;
    var club = nameKey(pr.club || "");
    return /autruche/.test(club) && fnv(nameKey([pr.prenom, pr.nom].join(" ")) + "|autruche") === DEV_H.nc;
  }
  function devPage(pr, tab, self) {
    var first = ffFirst(pr), ok = '<span class="ic dv-ok">' + I.check + "</span>", ko = '<span class="ic dv-ko">' + I.cross + "</span>";
    var li = function (ic, t, w) { return '<div class="dv-li">' + ic + "<div><b>" + t + "</b><small>" + w + "</small></div></div>"; };
    var s = "";
    if (tab === "plan") {
      s += '<div class="card ff-odds"><span class="eyebrow">Le match</span><div class="row1"><div class="ff-ring"><svg viewBox="0 0 36 36" width="92" height="92"><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--line)" stroke-width="4"/><circle cx="18" cy="18" r="15.5" fill="none" stroke="var(--terre)" stroke-width="4" stroke-linecap="round" stroke-dasharray="0.3 97.4"/></svg><b>0,3 %</b></div><div><span class="h">Mission impossible</span><span class="small">D\'après un algorithme écrit par… lui.</span></div></div>' +
        '<span class="p">' + (self ? "Tu t'es cherché toi-même ? Rassure-toi : même toi, tu ne peux pas te battre." : "Tu pensais vraiment que l'app allait t'expliquer comment battre son développeur ? Bien essayé.") + "</span></div>";
      s += '<div class="card key ff-plan"><span class="eyebrow">Ton plan en 3 points</span>' + [["Déclare forfait pendant qu'il est encore temps", "C'est la seule tactique qui a fait ses preuves : 100 % de matchs non perdus."], ["Sinon, prie pour qu'il pleuve", "Et que les courts couverts soient pris."], ["Félicite-le pour l'app", "Ça ne changera pas le score, mais il sera de bonne humeur pendant qu'il te bat."]].map(function (x, i) { return '<div class="k3"><span class="n">' + (i + 1) + "</span><div><b>" + x[0] + "</b><span>" + x[1] + "</span></div></div>"; }).join("") + "</div>";
      s += '<div class="card dv-fe"><span class="eyebrow">À faire, à éviter</span>' + li(ok, "Arrive avec ton plus beau sourire", "Pour la photo de fin de match") + li(ok, "Mets 5 étoiles à Montée sur le store", "On ne sait jamais, ça peut l'attendrir") +
        li(ko, "Chercher son point faible", "Il l'a supprimé dans la version 3.16") + li(ko, "L'emmener au 3e set", "Il a codé le 3e set lui-même") + "</div>";
    } else {
      s += '<div class="card key ff-rf"><span class="eyebrow">Le rapport de force</span><div class="ff-vs"><div><span class="ff-av me">' + (self ? esc(ffMyIni()) : "TOI") + '</span><span class="nm me">Toi</span><span class="rk">simple mortel</span></div><span class="x">VS</span><div><span class="ff-av him">' + esc(initials([pr.prenom, pr.nom].join(" "))) + '</span><span class="nm him">' + esc(first) + '</span><span class="rk">dieu du tennis</span></div></div>' +
        '<div class="ff-tug"><i class="g" style="width:2%"></i><i class="t" style="width:98%"></i></div><div class="ff-tugl"><span class="me">0 point pour toi</span><span class="him">∞ pour lui</span></div><span class="p"><b>Il a l\'avantage sur absolument tout.</b> Ton meilleur atout : aucun. Son point fort : tous.</span></div>';
      var bar = function (w, c) { return '<div class="ff-bar"><i class="' + c + '" style="width:' + w + '%"></i></div>'; };
      s += '<div class="card ff-q"><div class="qh"><b>Qui tient sous pression\u00a0?</b>' + ffBadge("him", "Lui, évidemment") + "</div>" +
        '<div class="it"><div class="l"><span>Sets serrés</span></div><div class="ff-duel"><span class="who">Toi</span>' + bar(4, "q") + '<span class="v">bof</span><span class="who">Lui</span>' + bar(100, "t") + '<span class="v">∞/∞</span></div></div>' +
        '<div class="it"><div class="l"><span>Point faible</span></div><div class="ff-duel"><span class="who">Toi</span>' + bar(80, "q") + '<span class="v">plein</span><span class="who">Lui</span>' + bar(100, "t") + '<span class="v">trop fort</span></div></div>' +
        '<div class="take">Son seul point faible connu : <b>il est trop fort.</b> On y travaille dans la prochaine version.</div></div>';
      s += '<div class="card"><span class="eyebrow">Ton enjeu</span><span class="p"><b>Si tu gagnes :</b> une place dans les notes de version de Montée.<br><b>Si tu perds :</b> rien de grave, tout le monde perd.</span></div>';
    }
    return s + '<p class="small" style="text-align:center">Page spéciale : tu as cherché le créateur de Montée. 🎾<br>Pour une vraie analyse, il faudra le battre d\'abord.</p>';
  }
  V.joueur = function (id) {
    tryMark("adv");
    var p = (S.scout || {})[id], folOn = (S.follow || {})[id], isMe = S.tenup && S.tenup.id && String(S.tenup.id) === String(id);
    var star = p && !isMe ? '<button class="fol-top' + (folOn ? " on" : "") + '" data-a="follow" data-id="' + esc(id) + '" aria-label="' + (folOn ? "Ne plus suivre" : "Suivre ce joueur") + '">' + (folOn ? BELL_ON + "<span>Suivi</span>" : BELL + "<span>Suivre</span>") + "</button>" : "";
    var s = '<div class="screen">' + topbar("", "Face-à-face", star);
    if (!p) {
      if (UI.scoutBusy === id) return s + '<div class="card empty"><b>Lecture de son palmarès sur Ten\'Up…</b><span class="small">Quelques secondes.</span></div></div>';
      return s + '<div class="card empty"><b>Fiche indisponible</b><span class="small">' + esc(UI.scoutErr || "Relance la recherche.") + '</span><a class="btn soft small" href="#/faf">Revenir à la recherche</a></div></div>';
    }
    var pr = p.profil || {}, name = [pr.prenom, pr.nom].filter(Boolean).join(" "), rows = p.rows || [], played = rows.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); });
    var gkey = nameKey([pr.prenom, pr.nom].filter(Boolean).join(" ")), st = scoutStats(rows), hisG = oppGame([gkey, nameKey([pr.nom, pr.prenom].join(" "))], p.fiche), sp = simProj(p.sim, pr.classement), stip = simTip(sp, pr.prenom ? pr.prenom.charAt(0) + pr.prenom.slice(1).toLowerCase() : ""), tips = (stip ? [stip] : []).concat(gameTips(hisG, st)).concat(gamePlan(st, pr.classement)).filter(function (t, i, a) { return !t.k || a.findIndex(function (u) { return u.k === t.k; }) === i; }).slice(0, 5);
    var k1 = nameKey(name), k2 = nameKey([pr.nom, pr.prenom].join(" ")), mine = S.matches.filter(function (m) { var k = nameKey(m.opp); return m.opp && !isAnon(m.opp) && (k === k1 || k === k2) && !m.wo && (m.result === "V" || m.result === "D"); }).sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; });
    var notes = revNotes(name), n2 = revNotes([pr.nom, pr.prenom].join(" "));
    n2.forEach(function (x) { if (!notes.some(function (y) { return y.text === x.text && y.date === x.date; })) notes.push(x); });
    s += '<div class="pl-head"><span class="ini lg">' + esc(initials(name)) + '</span><span class="grow"><span class="pl-n">' + esc(name) + '</span><span class="small">' + esc([pr.classement, pr.club, plural(played.length, "match", "matchs") + " cette saison", (function () { var b = pastBest(pr); return b ? "meilleur " + b.lab + (b.y ? " (" + b.y + ")" : "") : ""; })()].filter(Boolean).join(" · ")) + "</span>" +
      ((hisG.hand || hisG.backhand || hisG.style) ? '<span class="tags" style="margin-top:6px">' + [hisG.hand && gameLabel("hand", hisG.hand), hisG.backhand && "Revers " + gameLabel("backhand", hisG.backhand).toLowerCase(), hisG.style && { fond: "Attaquant de fond", contre: "Contreur", filet: "Monte au filet", service: "Gros service", poly: "Polyvalent" }[hisG.style]].filter(Boolean).map(function (t) { return '<span class="tag">' + esc(t) + "</span>"; }).join("") + "</span>" : "") + "</span></div>";
    var tab = UI.plTab === "stats" || UI.plTab === "pal" ? UI.plTab : "plan";
    // Fil de navigation de fiche en fiche (depuis un palmarès) : un retour arrière tronque le fil
    var trail = UI.plTrail || [], ti = trail.map(function (x) { return String(x.id); }).indexOf(String(id));
    if (ti >= 0) { trail = UI.plTrail = trail.slice(0, ti); }
    var dev = pr.dev || isDev(pr), self = S.tenup && S.tenup.id && String(S.tenup.id) === String(id), fol = (S.follow || {})[id];
    if (fol && !fol.seen) { fol.seen = true; save(); }
    if (fol && !S.folHelp) s += '<div class="card fol-help"><b>Tu suis ' + esc(fol.name) + '</b><span>Après chaque synchro Ten\'Up, Montée relit son palmarès et te prévient :</span><ul><li><b>s\'il monte</b> au classement ;</li><li><b>s\'il bat un joueur de ton niveau</b>, avec le score.</li></ul><span>Ses autres nouvelles (matchs joués, séries) s\'affichent dans l\'onglet Joueurs, filtre « Suivis ». Rien n\'est partagé : il ne sait pas que tu le suis.</span><button class="btn soft small" data-a="folHelpOk">Compris</button></div>';
    if (dev) s = s.replace('<span class="ini lg">', '<span class="ini lg dv-crown">').replace('<span class="pl-n">' + esc(name) + "</span>", '<span class="pl-n">' + esc(name) + '</span><span class="dv-tag">Créateur de Montée</span>');
    s += '<div class="seg pl-tabs" role="tablist"><button data-a="plTab" data-v="plan" class="' + (tab === "plan" ? "on" : "") + '" aria-pressed="' + (tab === "plan") + '">Plan de jeu</button><button data-a="plTab" data-v="stats" class="' + (tab === "stats" ? "on" : "") + '" aria-pressed="' + (tab === "stats") + '">Statistiques</button><button data-a="plTab" data-v="pal" class="' + (tab === "pal" ? "on" : "") + '" aria-pressed="' + (tab === "pal") + '">Palmarès</button></div>';
    if (trail.length) s = s.replace('<div class="pl-head">', '<div class="pl-trail">' + trail.map(function (x, i) { return '<button data-a="plCrumb" data-i="' + i + '">' + esc(x.name) + "</button><i>›</i>"; }).join("") + '<span>' + esc(name) + "</span></div>" + '<div class="pl-head">');
    if (dev) return s + devPage(pr, tab, self) + "</div>";
    var s0 = s.length;
    rows = hisEffRows(rows, id, name);
    var best = pastBest(pr), od = matchOdds(rows, pr.classement, mine, best);
    // Widget « Prochain adversaire » : le dernier joueur consulté
    var ls = { id: id, name: name, rank: pr.classement || "", club: pr.club || "", p: od ? Math.round(od.p * 100) : null, head: od ? od.head : "", tip: tips[0] ? tips[0].t : "", tipS: tips[0] ? tips[0].s : "", h2h: mine.length ? mine.filter(function (m) { return m.result === "V"; }).length + " – " + mine.filter(function (m) { return m.result === "D"; }).length : "" };
    if (JSON.stringify(ls) !== JSON.stringify(S.lastScout || {})) { S.lastScout = ls; save(); }
    var D = ffData({ rank: pr.classement, rows: rows, first: ffFirst(pr), name: name, sp: sp, mine: mine, hisG: hisG, od: od, notes: notes, best: best });

        var lk = oppIndex().filter(function (o) { return o.key === k1 || o.key === k2; })[0], fkey = lk ? lk.key : k1, fiche = ((S.oppNotes || {})[fkey] || (S.oppNotes || {})[k1] || (S.oppNotes || {})[k2] || {}).text || "";
    var retours = notes.filter(function (x) { return x.m; });
    var notesHtml = '<div class="card rev-card"><span class="eyebrow">Tes notes sur lui</span>' +
      '<div class="field"><label for="o-note2">Sa fiche · toujours valable</label><textarea id="o-note2" data-on="' + esc(fkey) + '" placeholder="Ses habitudes, son style, ce qui marche contre lui">' + esc(fiche) + "</textarea></div>" +
      (retours.length ? '<span class="lbl">Tes retours de match</span>' + retours.slice(0, 3).map(function (x) {
        return '<a class="rv-i" href="#/match/' + x.m.id + '"><span class="rv-t">« ' + esc(x.text) + ' »</span><span class="small">' + (x.m.result === "V" ? "Victoire" : "Défaite") + (x.date ? " le " + esc(fdate(x.date).replace(/\.$/, "")) : "") + (x.m.score ? " · " + esc(x.m.score) : "") + "</span></a>";
      }).join("") : (mine.length ? '<span class="small">Pas encore de retour sur vos matchs : ajoute-en un depuis la fiche du match.</span>' : "")) + "</div>";
    var gEmpty = !(hisG.hand || hisG.backhand || hisG.style) || UI.gEdit === gkey;
    if (D) { D.gamePrompt = gEmpty && !dev ? '<div class="card ff-ask"><span class="eyebrow">Rends ce plan plus précis</span><span class="p">Tu connais un peu son jeu ? <b>3 réponses suffisent</b> : ton plan passe des chiffres à une vraie tactique (où servir, quoi attaquer, quand monter).</span>' + oppGameHtml(gkey, hisG, true) + '<span class="small">Tu pourras compléter après le match : tes notes de match nourrissent aussi le plan.</span></div>' : ""; s += ffPlanTab(D, notesHtml + (gEmpty ? "" : oppGameHtml(gkey, hisG))); }
    else {
      s += notesHtml;
      if (tips.length) {
        s += '<div class="card gplan"><span class="eyebrow">Ton plan de jeu</span>' + tips.map(function (x) { return '<div class="gp-r"><span class="gp-i">' + svg(GP_IC[x.ic] || GP_IC.up, 2) + '</span><span><b>' + esc(x.t) + "</b><span>" + esc(x.s) + "</span></span></div>"; }).join("") +
          "</div>";
      } else s += '<div class="card soft"><span style="font-size:15px">' + (played.length < 5 ? "Pas assez de matchs cette saison pour un plan de jeu (il en faut 5)." : "Rien de marquant dans ses résultats : pas de point faible net.") + "</span></div>";
      if (od) s += '<div class="card mind"><span class="eyebrow">Dans ta tête</span><span class="small" style="margin-top:-4px">Ce qui compte sur le court, pas le classement.</span>' + mentalCoach(od, st, mine, sp).map(function (x, i) { return '<div class="mind-r"><span class="n">' + (i + 1) + '</span><span><b>' + esc(x.t) + "</b><span>" + esc(x.s) + "</span></span></div>"; }).join("") + "</div>";
      s += oppGameHtml(gkey, hisG);
    }
    var planHtml = s.slice(s0); s = s.slice(0, s0);
    var mineBy0 = {}; S.matches.forEach(function (m) { if (m.opp && !isAnon(m.opp) && !m.wo && (m.result === "V" || m.result === "D")) { var k = nameKey(m.opp); if (k !== k1 && k !== k2) (mineBy0[k] = mineBy0[k] || []).push(m); } });
    var common0 = [];
    played.forEach(function (m) { var k = nameKey(m.opp); if (mineBy0[k] && !common0.some(function (c2) { return c2.k === k; })) common0.push({ k: k, name: m.opp, rank: m.oppRank, his: m, mine: mineBy0[k][0] }); });
    if (D) { D.common = common0; s += ffStatsTab(D); }
    else s += compareHtml({ rank: pr.classement, rows: rows, first: pr.prenom ? pr.prenom.charAt(0) + pr.prenom.slice(1).toLowerCase() : "", name: name, sp: sp, common: common0 });
    var forme = played.slice().sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; }).slice(0, 5).reverse();
    var myR = effRank(), vsMe = played.filter(function (m) { return m.oppRank === myR; }), vsV = vsMe.filter(function (m) { return m.result === "V"; }).length;
    var best = played.filter(function (m) { return m.result === "V"; }).sort(function (a, b) { return E.idx(b.oppRank) - E.idx(a.oppRank); })[0];
    var sim = p.sim || {}, simTxt = (sim.res && sim.res[0] && sim.res[0].c) ? sim.res[0].c : (sim.message || "").slice(0, 40);
    if (!D) s += "<h2>Sa saison</h2><div class=\"card kv\">" +
      '<div class="kv-r"><span>Bilan</span><b>' + st.v + " V · " + (st.n - st.v) + " D</b></div>" +
      (forme.length ? '<div class="kv-r"><span>Forme</span><span class="form-dots">' + forme.map(function (m) { return '<span class="vd ' + m.result + '">' + m.result + "</span>"; }).join("") + "</span></div>" : "") +
      (best ? '<div class="kv-r"><span>Meilleure victoire</span><b>' + esc(best.oppRank) + "</b></div>" : "") +
      (vsMe.length ? '<div class="kv-r"><span>Contre les ' + esc(myR) + "</span><b>" + vsV + " V · " + (vsMe.length - vsV) + " D</b></div>" : "") +
      (sp ? '<div class="kv-r"><span>Sa simulation Ten\'Up · ' + esc(fdate(sp.rel).replace(/\.$/, "")) + '</span><b class="simv ' + sp.dir + '">' + (sp.dir === "same" ? "Maintien " + lab(sp.cur) : lab(sp.cur) + " → " + lab(sp.proj) + (sp.dir === "up" ? " ↑" : " ↓")) + "</b></div>" : simTxt ? '<div class="kv-r"><span>Simulation Ten\'Up</span><b>' + esc(simTxt) + "</b></div>" : "") + "</div>";
    // toi contre lui + adversaires communs
    s += "<h2>Toi contre lui</h2>";
    if (mine.length) {
      var mv = mine.filter(function (m) { return m.result === "V"; }).length;
      s += '<div class="card"><div class="h2h-big"><span>Toi</span><b>' + mv + " – " + (mine.length - mv) + "</b><span>" + esc(pr.prenom || "Lui") + "</span></div>" + mine.map(function (m) { return '<a class="row" href="#/match/' + m.id + '"><span class="vd lg ' + m.result + '">' + m.result + '</span><span class="grow"><span class="t">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + '</span><span class="s">' + esc(m.comp || "") + "</span></span>" + I.next + "</a>"; }).join("") + "</div>";
    }
    if (!mine.length) s += '<div class="card"><span style="font-size:15px"><b>Jamais joué.</b> ' + (common0.length ? "Vos adversaires communs sont plus haut." : "Pas encore d\'adversaire commun cette saison.") + "</span></div>";
    var statsHtml = s.slice(s0); s = s.slice(0, s0) + (tab === "plan" ? planHtml : tab === "pal" ? palHtml(rows, id, name, pr) : statsHtml);
    if (D && UI.mmOpen === String(id)) s += mmHtml(D, name, pr);
    s += '<p class="small">Les conseils ne s\'affichent que s\'ils s\'appuient sur au moins 5 matchs. Ten\'Up ne donne ni la durée ni la surface de ses matchs : le plan se base sur ses scores et son calendrier. Lu le ' + esc(fdate(p.at)) + ' · <button class="linkbtn" data-a="scoutReload" data-v="' + esc(id) + '" style="padding:0;min-height:0;font-size:inherit">actualiser</button></p>';
    return s + "</div>";
  };
  // ---------- Onglet Palmarès : ses matchs, et on navigue de joueur en joueur ----------
  function palHtml(rows, id, name, pr) {
    var c = ctx(), me = c.cur < 0 ? 0 : c.cur, f = UI.palF || "all";
    var ms = (rows || []).filter(function (m) { return m.date && (m.wo || m.result === "V" || m.result === "D"); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var pl = playedOf(ms), v = pl.filter(function (m) { return m.result === "V"; }).length, hi = pl.filter(function (m) { return E.idx(m.oppRank) >= me; }), hv = hi.filter(function (m) { return m.result === "V"; }).length;
    // Résumé visuel : bilan en barre, puis par niveau d'adversaire par rapport à TOI
    var bar = function (w, n) { return '<span class="pb"><i class="g" style="width:' + (n ? w / n * 100 : 0) + '%"></i><i class="t" style="width:' + (n ? (n - w) / n * 100 : 0) + '%"></i></span>'; };
    var band = function (t, fn) { var b = pl.filter(fn), w = b.filter(function (m) { return m.result === "V"; }).length; return b.length ? '<div class="pal-b"><span class="bl">' + t + '</span>' + bar(w, b.length) + '<span class="bn"><b class="v">' + w + '</b> – <b class="d">' + (b.length - w) + "</b></span></div>" : ""; };
    var s = '<div class="card pal-sum"><div class="pal-big"><span><b class="v">' + v + '</b><i>victoires</i></span><span><b class="d">' + (pl.length - v) + '</b><i>défaites</i></span><span class="pc"><b>' + (pl.length ? Math.round(v / pl.length * 100) : 0) + ' %</b><i>de victoires</i></span></div>' + bar(v, pl.length) +
      '<span class="pal-bh">Selon le niveau de l\'adversaire</span>' +
      band("Plus fort que toi", function (m) { return E.idx(m.oppRank) > me; }) + band("Ton niveau (" + lab(me) + ")", function (m) { return E.idx(m.oppRank) === me; }) + band("En dessous de toi", function (m) { var x = E.idx(m.oppRank); return x != null && x < me; }) + "</div>";
    s += '<div class="pal-f">' + [["all", "Tout"], ["v", "Victoires"], ["d", "Défaites"], ["lvl", "Ton niveau +"]].map(function (x) { return '<button data-a="palF" data-v="' + x[0] + '" class="' + (f === x[0] ? "on" : "") + '">' + x[1] + "</button>"; }).join("") + "</div>";
    var q = ms.filter(function (m) { return f === "v" ? m.result === "V" && !m.wo : f === "d" ? m.result === "D" && !m.wo : f === "lvl" ? E.idx(m.oppRank) >= me && !m.wo : true; });
    if (!q.length) return s + '<div class="card soft"><span class="p">Aucun match pour ce filtre cette saison.</span></div>';
    var mo = "", out = "";
    q.forEach(function (m) {
      var dd = E.parseDate(m.date), mk = MOIS_L[dd.getMonth()] + " " + dd.getFullYear();
      if (mk !== mo) { out += '<span class="pal-m">' + esc(mk.charAt(0).toUpperCase() + mk.slice(1)) + "</span>"; mo = mk; }
      var rk = m.risen ? esc(m.oppRank0) + ' <b class="up">→ ' + esc(m.oppRank) + "</b>" : esc(m.oppRank || "");
      var can = !!(m.opp && !isAnon(m.opp)), sub = [m.wo ? "w.o." : m.score, fdate(m.date).replace(/\.$/, ""), m.comp].filter(Boolean).join(" · ");
      out += (can ? '<button class="pal-r" data-a="palOpen" data-id="' + esc(m.oid || "") + '" data-v="' + esc(m.opp) + '">' : '<div class="pal-r">') +
        '<span class="res ' + (m.result === "V" ? "v" : "d") + '">' + (m.wo ? "wo" : m.result) + '</span><span class="grow"><span class="t">' + esc(m.opp || "Adversaire") + ' <span class="rk">' + rk + '</span></span><span class="s">' + esc(sub) + "</span></span>" + (can ? '<span class="chev">' + svg('<path d="M9 6l6 6-6 6"/>', 2.2) + "</span></button>" : "</div>");
    });
    return s + '<div class="card pal-l">' + out + '</div><span class="small">Classement au moment du match ; en vert, son classement d\'aujourd\'hui s\'il est monté depuis. Touche un adversaire pour ouvrir sa fiche.</span>';
  }
  // ---------- Tes saisons : ton classement et ton bilan saison par saison ----------
  function saisonsHtml() {
    var ss = (S.tenupSeasons || []).slice().sort(function (a, b) { return a.y - b.y; }); if (!ss.length) return "";
    var t = today(), y0 = t.getMonth() >= 8 ? t.getFullYear() + 1 : t.getFullYear(), from = E.iso(new Date(y0 - 1, 8, 1));
    var cur = playedOf(allMatches().filter(function (m) { return m.date >= from; }));
    var bestOf = function (list) { return list.map(function (c) { return E.idx(T.normRank(c)); }).filter(function (i) { return i != null; }).sort(function (a, b) { return b - a; })[0]; };
    var rows = ss.map(function (x) { return { y: x.y, cl: T.normRank(x.cl) || "", v: x.v, d: x.n - x.v, best: bestOf(x.wl || []) }; }).filter(function (r) { return r.v + r.d > 0; });
    var cv = cur.filter(function (m) { return m.result === "V"; });
    rows.push({ y: y0, cl: effRank() || "", v: cv.length, d: cur.length - cv.length, best: cv.map(function (m) { return E.idx(m.oppRank); }).sort(function (a, b) { return b - a; })[0], now: true });
    if (rows.length < 2) return "";
    var past = rows.filter(function (r) { return !r.now && r.v + r.d >= 5; });
    var bestS = past.slice().sort(function (a, b) { return (b.v / (b.v + b.d) + b.v / 100) - (a.v / (a.v + a.d) + a.v / 100); })[0];
    var topWin = rows.slice().sort(function (a, b) { return (b.best == null ? -9 : b.best) - (a.best == null ? -9 : a.best); })[0];
    var mx = Math.max.apply(null, rows.map(function (r) { return r.v + r.d; })), lbl = function (r) { return String(r.y - 1).slice(2) + "-" + String(r.y).slice(2); };
    var head = bestS ? "Ta meilleure saison : " + (bestS.y - 1) + "-" + String(bestS.y).slice(2) : "Tes saisons";
    var sub = bestS ? bestS.v + " victoires, " + Math.round(bestS.v * 100 / (bestS.v + bestS.d)) + " % de matchs gagnés" + (topWin && topWin.best != null ? " · ta plus belle victoire : un " + lab(topWin.best) + " en " + lbl(topWin) : "") + "." : "";
    return '<div class="card ss-card"><span class="eyebrow">Tes saisons</span><b class="ss-h">' + esc(head) + "</b>" + (sub ? '<span class="small">' + esc(sub) + "</span>" : "") +
      '<div class="ss-l">' + rows.slice().reverse().map(function (r) {
        var n = r.v + r.d, pc = n ? Math.round(r.v * 100 / n) : 0;
        return '<div class="ss-r' + (r === bestS ? " best" : "") + (r.now ? " now" : "") + '"><span class="y">' + lbl(r) + (r.now ? "<small>en cours</small>" : "") + "</span>" +
          '<span class="mid"><span class="bar" style="width:' + Math.max(8, Math.round(n / mx * 100)) + '%"><i class="v" style="flex:' + r.v + '"></i><i class="d" style="flex:' + r.d + '"></i></span>' +
          "<small><b>" + r.v + " V</b> – " + r.d + " D" + (r.best != null ? " · meilleure : " + esc(lab(r.best)) : "") + "</small></span>" +
          '<span class="pc">' + pc + "<small>%</small></span></div>";
      }).join("") + "</div>" +
      '<span class="small">Saison sportive de septembre à août, d\'après tes palmarès Ten\'Up. La longueur de la barre = le nombre de matchs.</span></div>';
  }
  // ---------- Tes forces : ce sur quoi tu peux compter dans les moments clés ----------
  // oppIdx (facultatif) : le classement de ton adversaire du jour, pour mettre en avant ton bilan contre ce classement
  function myStrengths(oppIdx) {
    var c = ctx(), me = c.cur < 0 ? 0 : c.cur, all = effMs(c.proj.matches), A = ffStats(all, me), out = [];
    var add = function (x, k, min, thr, t, cue) { if (x.n >= min && x.v / x.n >= thr) out.push({ k: k, v: x.v, n: x.n, r: x.v / x.n, t: t, cue: cue, w: (x.v / x.n) * Math.sqrt(x.n) }); };
    add(A.tb, "tb", 4, 0.6, "jeux décisifs gagnés", "Rappelle-toi : tu gagnes " + A.tb.v + " tie-breaks sur " + A.tb.n + ".");
    add(A.close, "close", 4, 0.6, "sets serrés gagnés (7-5, 7-6)", "Rappelle-toi : à 5-5, c'est toi qui gagnes " + A.close.v + " fois sur " + A.close.n + ".");
    add(A.f1l, "f1l", 3, 0.4, "matchs renversés après un 1er set perdu", "Un set perdu ne veut rien dire : tu as déjà renversé " + A.f1l.v + " match" + (A.f1l.v > 1 ? "s" : "") + ".");
    add(A.three, "three", 3, 0.6, "matchs en trois sets gagnés", "Le 3e set, c'est ton terrain : " + A.three.v + " sur " + A.three.n + ".");
    if (A.f1w.n >= 5 && A.f1w.l / A.f1w.n <= 0.15) out.push({ k: "f1w", v: A.f1w.n - A.f1w.l, n: A.f1w.n, r: 1 - A.f1w.l / A.f1w.n, t: "matchs gagnés quand tu prends le 1er set", cue: "Tu as le 1er set : tu ne lâches presque jamais (" + (A.f1w.n - A.f1w.l) + " sur " + A.f1w.n + ").", w: (1 - A.f1w.l / A.f1w.n) * Math.sqrt(A.f1w.n) });
    // Ton bilan par classement d'adversaire : « tu ne perds jamais contre les 15/5 »
    var by = {}; playedOf(all).forEach(function (m) { var o = E.idx(m.oppRank); if (o == null) return; (by[o] = by[o] || { v: 0, n: 0 }); by[o].n++; if (m.result === "V") by[o].v++; });
    Object.keys(by).forEach(function (o) {
      o = +o; var x = by[o]; if (x.n < 3 || x.v / x.n < (o >= me ? 0.6 : 0.85)) return;
      var never = x.v === x.n, rel = o > me ? "mieux classés que toi" : o === me ? "ton classement" : "";
      out.push({ k: "lv" + o, lv: o, v: x.v, n: x.n, r: x.v / x.n, t: "contre les " + lab(o) + (rel ? " (" + rel + ")" : ""),
        cue: never ? "Contre les " + lab(o) + ", tu n'as jamais perdu (" + x.n + " sur " + x.n + ")." : "Contre les " + lab(o) + ", tu gagnes " + x.v + " fois sur " + x.n + ".",
        w: (x.v / x.n) * Math.sqrt(x.n) + (o >= me ? 0.6 : 0) + (oppIdx != null && o === oppIdx ? 3 : 0) });
    });
    return out.sort(function (a, b) { return b.w - a.w; });
  }
  function strengthsHtml(list, title, sub) {
    if (!list.length) return "";
    return '<div class="card forces"><span class="eyebrow">' + esc(title || "Tes forces") + "</span>" + (sub ? '<span class="small">' + esc(sub) + "</span>" : "") +
      list.slice(0, 4).map(function (x) { return '<div class="fz"><b>' + x.v + "<small> sur " + x.n + "</small></b><span><b>" + esc(x.t.charAt(0).toUpperCase() + x.t.slice(1)) + "</b><i>« " + esc(x.cue) + " »</i></span></div>"; }).join("") + "</div>";
  }
  // ---------- Mode match : au vestiaire, un seul écran (3 pages à faire glisser) ----------
  function colorHex(c) { var IL = window.MonteeIll; return IL && IL.RCOL && IL.RCOL[c || "noir"] ? IL.RCOL[c || "noir"][0] : "#9DA1AB"; }
  function mmHtml(D, name, pr) {
    var od = D.od || {}, p = Math.round((od.p || 0) * 100), col = (od.p || 0) >= 0.5 ? "var(--gazon)" : "var(--terre)";
    var short = function (t, n) { t = String(t || ""); return t.length > n ? t.slice(0, n - 1).replace(/\s+\S*$/, "") + "…" : t; };
    var plan = (D.planPicked || []).slice(0, 3), mind = D.mindItems || [];
    var cue = (mind.filter(function (x) { return x.t !== "Avant d'entrer"; })[0] || mind[0] || {}).cue || "Je connais mon plan. Je joue mon tennis.";
    var rk = D.bestRk, main = !rk && (bag().filter(function (r) { return r.main; })[0] || bag()[0]);
    var rkLine = rk ? '<div class="mm-rk"><span class="sw" style="background:' + esc(colorHex(rk.color)) + '"></span><span><b>Ta ' + esc(rk.name) + (rk.t ? " à " + rk.t + " kg" : "") + "</b><small>ta raquette qui gagne : " + rk.v + " victoires sur " + rk.n + "</small></span></div>" :
      main ? (function () { var st = racketStatus(main); return '<div class="mm-rk"><span class="sw" style="background:' + esc(colorHex(main.color)) + '"></span><span><b>Ta ' + esc(main.name) + "</b><small>" + (st.known ? "cordage ≈ " + fmtHours(st.min) : "ta raquette principale") + "</small></span></div>"; })() : "";
    var first = (pr.prenom ? pr.prenom.charAt(0) + pr.prenom.slice(1).toLowerCase() : "") + (pr.nom ? " " + pr.nom.charAt(0) + "." : "");
    var p1 = '<section class="mm-p"><div class="mm-k">MODE MATCH · ' + esc((first || name).toUpperCase()) + " " + esc(pr.classement || "") + "</div>" +
      '<div class="mm-odds"><b style="color:' + col + '">' + p + ' %</b><span>' + esc(od.head || "") + (od.gain > 0 ? "<br>+" + od.gain + " pts si tu gagnes" : "") + "</span></div>" +
      (plan.length ? '<div class="mm-plan">' + plan.map(function (x, i) { return '<div class="pt"><i>' + (i + 1) + "</i><span><b>" + esc(x.plan.t) + "</b><small>" + esc(short(x.plan.s, 90)) + "</small></span></div>"; }).join("") + "</div>" : "") +
      '<div class="mm-cue">« ' + esc(cue) + " »</div>" + rkLine + "</section>";
    var fz = myStrengths(D.hi).slice(0, 3);
    var p2 = '<section class="mm-p"><div class="mm-k">CHANGEMENT DE CÔTÉ</div>' + (fz.length ? '<div class="mm-fz"><b>Rappelle-toi</b>' + fz.map(function (x) { return '<div class="mm-cue sm">' + esc(x.cue) + "</div>"; }).join("") + "</div>" : "") + (mind.filter(function (x) { return x.t !== "Avant d'entrer"; }).map(function (x) {
      return '<div class="mm-sit"><b>' + esc(x.t) + "</b>" + '<div class="mm-cue sm">« ' + esc(x.cue) + " »</div>" + (x.rt ? "<small>" + esc(short(x.rt, 140)) + "</small>" : "") + "</div>";
    }).join("") || '<div class="mm-sit"><b>Entre deux jeux</b><div class="mm-cue sm">« Une seule consigne pour le jeu suivant. »</div><small>3 respirations lentes, serviette, puis ta consigne. Pas trois choses à la fois.</small></div>') + "</section>";
    var p3 = '<section class="mm-p"><div class="mm-k">APRÈS LE MATCH</div><b class="mm-h">Alors ?</b><span class="mm-s">Ton score et ta note en 20 secondes : ta projection est à jour avant Ten\'Up, et ta note nourrira ton prochain plan contre lui.</span>' +
      '<div class="mm-res"><button class="btn mm-v" data-a="mmResult" data-v="V">J\'ai gagné</button><button class="btn soft" data-a="mmResult" data-v="D">J\'ai perdu</button></div></section>';
    return '<div class="mm-ov" role="dialog" aria-modal="true" aria-label="Mode match"><button class="mm-x" data-a="mmClose" aria-label="Fermer">' + I.cross + '</button><div class="mm-pages" id="mm-pages">' + p1 + p2 + p3 + '</div><div class="mm-dots"><i class="on"></i><i></i><i></i></div></div>';
  }
  // ---------- Joueurs suivis : une étoile sur la fiche, des nouvelles à chaque synchro ----------
  function folSnap(sc) {
    var p = playedOf(sc.rows || []).filter(function (m) { return m.date; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var r0 = p[0] ? p[0].result : null, n = 0; for (var i = 0; i < p.length && p[i].result === r0; i++) n++;
    return { rank: (sc.profil && sc.profil.classement) || (sc.hit && sc.hit.rank) || "", n: p.length, last: p[0] ? p[0].date : "", streak: r0 ? { r: r0, n: n } : null,
      lm: p[0] ? { r: p[0].result, rank: p[0].oppRank || "", date: p[0].date } : null };
  }
  // Compare la fiche relue à la précédente : montée, nouveaux matchs (dont contre ton niveau), série
  function folUpdate(id, notify) {
    var f = (S.follow || {})[id], sc = (S.scout || {})[id]; if (!f || !sc) return null;
    var now = folSnap(sc), old = f.snap || now, news = null; if (!f.snap) { f.snap = now; f.rank = now.rank || f.rank; f.at = Date.now(); return null; }
    var _x = 0, me = curIdx() < 0 ? 0 : curIdx();
    var ri = E.idx(T.normRank(now.rank)), ro = E.idx(T.normRank(old.rank));
    var fresh = playedOf(sc.rows || []).filter(function (m) { return m.date && m.date > (old.last || ""); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    if (ri != null && ro != null && ri > ro) news = { k: "up", tag: "↑ " + now.rank, t: "Monté " + now.rank + " (il était " + old.rank + ")" };
    else if (ri != null && ro != null && ri < ro) news = { k: "dn", tag: "↓ " + now.rank, t: "Descendu " + now.rank };
    else if (fresh.length) {
      var big = fresh.filter(function (m) { return m.result === "V" && E.idx(m.oppRank) >= me; })[0], m0 = fresh[0];
      news = big ? { k: "nw", tag: "a joué", t: "Victoire " + (big.score || "") + " contre un " + big.oppRank + " : à ton niveau", lvl: true } :
        { k: "nw", tag: "a joué", t: (m0.result === "V" ? "Victoire " : "Défaite ") + (m0.score || "") + " contre un " + m0.oppRank };
    } else if (now.streak && now.streak.n >= 3) news = { k: now.streak.r === "V" ? "nw" : "dn", tag: now.streak.n + " " + now.streak.r + " de suite", t: "" };
    f.snap = now; f.rank = now.rank || f.rank; f.at = Date.now();
    if (news && (news.k === "up" || news.lvl || fresh.length)) { f.news = news; f.newsAt = Date.now(); f.seen = false; }
    if (notify && news && (news.k === "up" || news.lvl) && LN && S.notif) {
      try { LN.schedule({ notifications: [{ id: 3000 + (parseInt(id, 10) % 900 || 1), title: f.name + (news.k === "up" ? " est monté " + now.rank : " a battu un joueur de ton niveau"), body: news.t, extra: { url: "montee://open/joueur/" + id } }] }).catch(function () {}); } catch (e) {}
    }
    return news;
  }
  // Après une synchro Ten'Up : on relit en silence les joueurs suivis (au plus une fois toutes les 12 h chacun)
  function folRefresh() {
    if (!NATIVE) return;
    var ids = Object.keys(S.follow || {}).filter(function (id) { return Date.now() - (S.follow[id].at || 0) > 12 * 3600e3; }).slice(0, 10), chain = Promise.resolve(), any = false;
    ids.forEach(function (id) {
      chain = chain.then(function () {
        var f = S.follow[id]; if (!f || !f.hit) return;
        return tenupQuery("player", f.hit).then(function (r) {
          if (!r || r.error) return;
          if (r.profil) { r.profil.dev = isDev(r.profil); delete r.profil.lic; }
          var old = S.scout[id] || {};
          S.scout[id] = { at: E.iso(today()), ts: old.ts || Date.now(), hit: f.hit, profil: r.profil, sim: r.sim, fiche: r.fiche || {}, rows: T.rows({ raw: r.raw }) };
          if (folUpdate(id, true)) any = true;
        });
      });
    });
    chain.then(function () { save(); if (any && route() === "faf") render(); }, function () {});
  }
  function openScout(hit, force) {
    S.scout = S.scout || {};
    var id = String(hit.id);
    UI.plTab = "plan"; // une fiche s'ouvre toujours sur le plan de jeu
    if (!UI.plNav) UI.plTrail = []; UI.plNav = false;
    if (S.scout[id] && !force && (Date.now() - new Date(S.scout[id].at).getTime()) < 3 * 864e5) { go("joueur/" + id); return; }
    UI.scoutBusy = id; UI.scoutErr = null;
    if (force) delete S.scout[id];
    go("joueur/" + id);
    tenupQuery("player", hit).then(function (r) {
      UI.scoutBusy = null;
      if (!r || r.error) { UI.scoutErr = r && r.error === "web" ? "Disponible dans l'appli Android ou iPhone." : /connecte/.test((r && r.error) || "") ? "Ta session Ten'Up a expiré : reconnecte-toi depuis Réglages › Ten'Up." : "Ten'Up n'a pas répondu (" + ((r && r.error) || "?") + "). Réessaie dans un instant."; render(); return; }
      var rows = T.rows({ raw: r.raw });
      if (r.profil) { r.profil.dev = isDev(r.profil); delete r.profil.lic; } // on ne garde pas la licence des autres, seulement le drapeau
      S.scout[id] = { at: E.iso(today()), hit: { id: hit.id, idp: hit.idp, nom: hit.nom, prenom: hit.prenom, rank: hit.rank, club: hit.club }, profil: r.profil, sim: r.sim, fiche: r.fiche || {}, rows: rows };
      S.scout[id].ts = Date.now();
      // On garde les 10 fiches consultées le plus récemment (à l'heure près, pas seulement au jour), jamais celle qu'on vient d'ouvrir
      var tsOf = function (k) { var x = S.scout[k]; return x.ts || new Date(x.at).getTime(); };
      var fol = S.follow || {};
      var ks = Object.keys(S.scout).filter(function (k) { return k !== id && !fol[k]; }).sort(function (a, b) { return tsOf(b) - tsOf(a); }); ks.slice(9).forEach(function (k) { delete S.scout[k]; });
      if (fol[id]) folUpdate(id, false);
      save(); if (route().indexOf("joueur/") === 0) render();
    });
  }
  function fafSearch(known, alt) {
    var q = UI.faf || (UI.faf = { q: "" });
    if (!known && !alt) { var sp0 = nameSplits(q.q || ""); if (sp0.length) { q.nom = sp0[0].nom; q.prenom = sp0[0].prenom; alt = sp0.slice(1); } else { q.nom = ""; q.prenom = ""; } }
    q.searched = q.q; UI.fafAll = false;
    var nom = (q.nom || "").trim(), pre = (q.prenom || "").trim(), ql = String(q.lic || "").replace(/\D/g, "");
    if (!ql && (nom.length < 2 || pre.length < 2)) { UI.fafErr = "Tape son prénom en entier et son nom, ex. : Julien Moreau."; render(); return; }
    if (!NATIVE) { UI.fafErr = "La recherche sur Ten'Up se fait depuis l'appli Android ou iPhone."; render(); return; }
    UI.fafErr = null; UI.fafBusy = true; if (route() === "faf") render();
    var show = function () { if (route() === "faf") render(); else { go("faf"); window.scrollTo(0, 0); } };
    // Tes dates de match contre ce nom : Ten'Up dira lequel des homonymes tu as joué
    var qn = nameKey(nom), kk = known ? known.key : null;
    var dates = S.matches.filter(function (m) { var k = nameKey(m.opp); return m.date && m.opp && !m.wo && (kk ? k === kk : k.indexOf(qn) >= 0); }).map(function (m) { return m.date; });
    var check = dates.length ? { me: nameKey((S.tenup.me || {}).nom || ""), dates: dates.filter(function (d, i, a) { return a.indexOf(d) === i; }).slice(0, 12) } : null;
    var lic = ql || (known && known.olic && !known.licTried ? String(known.olic) : "");
    if (lic) known.licTried = true;
    tenupQuery("search", { nom: nom, prenom: pre, cfg: S.tenup.searchCfg || null, check: check, lic: lic }).then(function (r) {
      UI.fafBusy = false;
      if (!r || r.error) { UI.fafHits = null; UI.fafErr = /connecte/.test((r && r.error) || "") ? "Ta session Ten'Up a expiré : reconnecte-toi depuis Réglages › Ten'Up." : "La recherche Ten'Up n'a pas répondu (" + ((r && r.error) || "?") + ")."; show(); return; }
      if (r.cfg) { S.tenup.searchCfg = r.cfg; save(); }
      UI.fafHits = r.hits || [];
      // Recherche par licence vide : on repasse par le nom
      if (!UI.fafHits.length && lic && !ql && nom) { fafSearch(known, alt); return; }
      // Recherche par licence : un seul joueur possible, on ouvre sa fiche
      if (ql && UI.fafHits.length === 1) { openScout(UI.fafHits[0]); return; }
      // Rien trouvé avec ce découpage du nom : on essaie le suivant (« MOREAU Julien » au lieu de « Julien MOREAU »…)
      if (!UI.fafHits.length && alt && alt.length) { UI.faf.nom = alt[0].nom; UI.faf.prenom = alt[0].prenom; fafSearch(known, alt.slice(1)); return; }
      // Adversaire déjà joué : si le bon est évident, on ouvre directement sa fiche
      if (known) {
        var others = UI.fafHits.filter(function (h) { return !(S.tenup.id && String(S.tenup.id) === String(h.id)); });
        var played = others.filter(function (h) { return h.played === true; }), unk = others.filter(function (h) { return h.played == null; });
        var same = others.filter(function (h) { return h.played !== false && T.normRank(h.rank) === T.normRank(known.rank); });
        var club = known.oclub ? others.filter(function (h) { return h.played !== false && h.club && nameKey(h.club) === nameKey(known.oclub); }) : [];
        if (!played.length && club.length === 1) played = club;
        // Année de naissance (donnée par ton palmarès) contre l'âge des résultats
        var yr = known.oyear ? others.filter(function (h) { return h.played !== false && h.age && Math.abs(today().getFullYear() - h.age - known.oyear) <= 1; }) : [];
        if (!played.length && yr.length === 1) played = yr;
        var pick = played.length === 1 ? played[0] : others.length === 1 ? others[0] : (!played.length && unk.length === 1 && others.length - unk.length === others.filter(function (h) { return h.played === false; }).length) ? unk[0] : same.length === 1 ? same[0] : null;
        if (pick) { openScout(pick); return; }
      }
      show();
    });
  }

  // =====================================================================================
  // 3.20 : le simulateur « Et si… », ta carte du mois à partager, ta charge de jeu
  // =====================================================================================

  // ---------- Simulateur « Et si… » : plusieurs matchs imaginaires, la projection bouge en direct ----------
  function simuFakes(list) {
    var d = E.iso(today());
    return (list || []).map(function (x, i) { return { id: "_simu" + i, date: d, result: x.r, oppRank: lab(x.l), kind: "tournoi", score: x.r === "V" ? "6-4 6-4" : "4-6 4-6" }; });
  }
  V.simu = function () {
    var c = ctx(), p = c.proj; tryMark("simu");
    if (p.status === "top") return '<div class="screen">' + topbar("Et si…") + '<p class="lead">Les joueurs numérotés sont classés au concours des meilleurs bilans : pas de simulation possible.</p></div>';
    var cur = c.cur < 0 ? 0 : c.cur, lv = [];
    for (var L = Math.max(-1, cur - 4); L <= Math.min(E.MAX_CALC, cur + 4); L++) lv.push(L);
    UI.simu = UI.simu || [];
    if (UI.simuLv == null || lv.indexOf(UI.simuLv) < 0) UI.simuLv = Math.min(cur + 1, E.MAX_CALC);
    var all = allMatches(), fakes = simuFakes(UI.simu), rel = p.release;
    var after = fakes.length ? E.project(all.concat(fakes), c.cur, c.sex, c.opts) : p;
    // Le bilan qu'on suit : celui de l'échelon visé (ou du maintien si tu es menacé)
    var danger = p.status === "descente", calc = danger ? cur : p.next.calc;
    var bil = function (ms) { return E.bilanAt(E.windowMatches(ms, rel, today()), calc, c.sex, c.cur, c.opts.extra); };
    var b0 = bil(all), prev = b0, rows = [];
    fakes.forEach(function (f, i) {
      var b = bil(all.concat(fakes.slice(0, i + 1))), d = b.total - prev.total, raw = f.result === "V" ? E.BAREME.win(E.idx(f.oppRank) - calc) : 0;
      rows.push({ x: UI.simu[i], d: d, raw: raw, weak: prev.weakest, full: prev.slotsFree === 0 });
      prev = b;
    });
    var bf = prev, up = after.projected > cur && after.status === "montee", down = after.status === "descente";
    var head = up ? "Tu montes" : down ? "Descente" : danger ? "Tu te maintiens" : "Maintien";
    var s = '<div class="screen">' + topbar("Et si…", "Sortie du " + flong(rel));
    s += '<p class="small" style="margin-top:-6px">Ajoute des matchs imaginaires : ta projection bouge en direct. Rien n\'est enregistré.</p>';
    // Projection après les matchs imaginaires
    var pc = Math.max(3, Math.min(100, Math.round(bf.total / Math.max(1, bf.norme) * 100)));
    s += '<div class="card simu-top"><div class="sp-row"><span class="sp-r muted">' + esc(lab(cur)) + '</span><span class="sp-a">→</span><span class="sp-r ' + (up ? "up" : down ? "dn" : "") + '">' + esc(lab(after.projected)) + '</span><span class="badge2 ' + (up ? "b-me" : down ? "b-him" : "b-eq") + '">' + head + "</span></div>" +
      '<div class="sp-bar"><i class="' + (bf.total >= bf.norme ? "ok" : "") + '" style="width:' + pc + '%"></i></div>' +
      '<span class="small"><b>' + bf.total + " pts</b> au bilan " + esc(bf.label) + ", il en faut " + bf.norme +
      (bf.total >= bf.norme ? ' : <b class="pos">+' + (bf.total - bf.norme) + " de marge</b>" : ' : <b class="neg">il manque ' + (bf.norme - bf.total) + "</b>") +
      (!danger && bf.total >= bf.norme && !bf.winAtLevel ? ", et une victoire contre un " + esc(bf.label) + " ou mieux" : "") + "." +
      (fakes.length ? " Sans ces matchs : " + b0.total + "." : "") + "</span></div>";
    // Le conseil qui va droit au but
    if (!fakes.length) {
      var mw = minWinToRise(c);
      if (mw !== null && mw !== undefined) s += '<div class="card menthe simu-tip">' + I.spark + "<span><b>Une victoire contre un " + esc(lab(mw)) + " ou mieux suffit</b> pour monter à cette sortie.</span></div>";
    }
    // Les matchs imaginaires
    if (rows.length) {
      s += '<div class="card simu-l"><span class="eyebrow">Tes matchs imaginaires</span>' + rows.map(function (r, i) {
        var sub = r.x.r === "D" ? (r.d < 0 ? "fait baisser le nombre de victoires comptées" : "ne change rien au bilan") :
          r.d <= 0 ? (r.raw ? "ne dépasse pas tes victoires déjà comptées" : "trop loin en dessous : 0 pt à " + lab(calc)) :
            r.raw > r.d && r.full ? "vaut " + r.raw + ", remplace une victoire à " + r.weak : "vaut " + r.raw + " pts";
        return '<div class="simu-r"><span class="res ' + (r.x.r === "V" ? "v" : "d") + '">' + r.x.r + '</span><span class="grow"><b>' + (r.x.r === "V" ? "Victoire" : "Défaite") + " contre un " + esc(lab(r.x.l)) + "</b><span>" + esc(sub) + "</span></span>" +
          '<span class="pts ' + (r.d > 0 ? "up" : r.d < 0 ? "dn" : "") + '">' + (r.d > 0 ? "+" : r.d < 0 ? "−" : "") + Math.abs(r.d) + '</span><button class="iconbtn sm" data-a="simuDel" data-i="' + i + '" aria-label="Retirer ce match">' + I.cross + "</button></div>";
      }).join("") + '<button class="linkbtn" data-a="simuClear" style="align-self:flex-start;padding:6px 0 0;min-height:0">Tout effacer</button></div>';
    }
    // Ajouter un match
    s += '<div class="card simu-add"><span class="eyebrow">Ajouter un match</span><div class="simu-lv" role="group" aria-label="Classement de l\'adversaire">' +
      lv.map(function (i) { return '<button class="' + (UI.simuLv === i ? "on" : "") + '" data-a="simuLv" data-v="' + i + '" aria-pressed="' + (UI.simuLv === i) + '">' + esc(lab(i)) + "</button>"; }).join("") + "</div>" +
      '<div class="simu-btns"><button class="btn small simu-v" data-a="simuAdd" data-v="V"' + (UI.simu.length >= 10 ? " disabled" : "") + '>+ Victoire</button><button class="btn soft small" data-a="simuAdd" data-v="D"' + (UI.simu.length >= 10 ? " disabled" : "") + '>+ Défaite</button></div></div>';
    s += '<p class="small">Les matchs imaginaires sont datés d\'aujourd\'hui et comptent comme des matchs de tournoi. Une défaite contre un joueur moins bien classé peut réduire le nombre de victoires qui comptent (V − E − 2I − 5G).</p>';
    return s + "</div>";
  };

  // ---------- Ta carte du mois : une image à partager en story ----------
  function lastReleases() {
    var t = today(), r1 = firstTue(t.getFullYear(), t.getMonth());
    if (t < r1) r1 = firstTue(t.getFullYear(), t.getMonth() - 1);
    var r0 = firstTue(r1.getFullYear(), r1.getMonth() - 1);
    return { r0: r0, r1: r1 };
  }
  // Deux périodes : le mois terminé (entre les deux dernières sorties) et le mois en cours (depuis la dernière sortie)
  function cardPeriod(which) {
    var R = lastReleases(), t = today(), done = which === "done";
    var from = done ? R.r0 : R.r1, to = done ? R.r1 : new Date(t.getTime() + 864e5);
    var ms = allMatches().filter(function (m) { var d = m.date && E.parseDate(m.date); return d && !m.dbl && d >= from && d < to && !m.wo && (m.result === "V" || m.result === "D") && E.idx(m.oppRank) != null; })
      .sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    var v = ms.filter(function (m) { return m.result === "V"; }), cur = curIdx() < 0 ? 0 : curIdx();
    var best = v.reduce(function (b, m) { var x = E.idx(m.oppRank); return b == null || x > b ? x : b; }, null);
    var run = 0, streak = 0; ms.forEach(function (m) { run = m.result === "V" ? run + 1 : 0; streak = Math.max(streak, run); });
    var perfs = v.filter(function (m) { return E.idx(m.oppRank) > cur; }).length;
    // Le classement : changement à la sortie (relevé à la synchro) pour le mois terminé, projection pour le mois en cours
    var from_ = null, to_ = null, projected = false;
    if (done) {
      var lg = (S.rankLog || []).filter(function (x) { var d = E.parseDate(x.d); return d >= R.r1 && d < new Date(R.r1.getTime() + 25 * 864e5); }).pop();
      if (lg) { from_ = lg.from; to_ = lg.to; }
    } else {
      var p = ctx().proj;
      if (p.status === "montee" || p.status === "descente") { from_ = lab(cur); to_ = lab(p.projected); projected = true; }
    }
    var mo = done ? R.r0 : R.r1;
    return { done: done, from: from, to: to, month: MOIS_L[mo.getMonth()].replace(/^./, function (x) { return x.toUpperCase(); }) + " " + mo.getFullYear(),
      span: done ? "Du " + fdate(R.r0).replace(/\.$/, "") + " au " + fdate(R.r1).replace(/\.$/, "") : "Depuis le " + fdate(R.r1).replace(/\.$/, ""),
      ms: ms, v: v.length, d: ms.length - v.length, best: best, streak: streak, perfs: perfs, rankFrom: from_, rankTo: to_, projected: projected, rank: effRank() || "" };
  }
  // Polices de la carte (embarquées : pas de réseau)
  var cardFonts = null;
  function loadCardFonts() {
    if (cardFonts) return cardFonts;
    if (!window.FontFace || !document.fonts) return (cardFonts = Promise.resolve());
    cardFonts = Promise.all([500, 700, 800].map(function (w) {
      var f = new FontFace("MonteeCard", "url(vendor/fonts/figtree-latin-" + (w === 500 ? 400 : w) + "-normal.woff2)", { weight: String(w) });
      return f.load().then(function (x) { document.fonts.add(x); }).catch(function () {});
    }));
    return cardFonts;
  }
  function drawCard(P, style) {
    var W = 1080, H = 1920, cv = document.createElement("canvas"); cv.width = W; cv.height = H;
    var g = cv.getContext("2d"), light = style === "sobre";
    var C = light ? { bg: "#F6F2EC", ink: "#121212", mut: "#625B55", acc: "#1F5C3F", tile: "#FFFFFF", v: "#1F5C3F", d: "#B04A22", kbg: "#1F5C3F", kink: "#FFFFFF" } :
      { bg: "#121212", ink: "#F2F3F5", mut: "#B5B9C2", acc: "#D4E64A", tile: "rgba(255,255,255,.07)", v: "#6FC28F", d: "#E88A5E", kbg: "#D4E64A", kink: "#121212" };
    var F = function (w, sz) { g.font = w + " " + sz + "px MonteeCard, Figtree, system-ui, sans-serif"; };
    g.fillStyle = C.bg; g.fillRect(0, 0, W, H);
    if (!light) {
      var gr = g.createRadialGradient(200, 0, 0, 200, 0, 900); gr.addColorStop(0, "rgba(111,194,143,.38)"); gr.addColorStop(1, "rgba(111,194,143,0)"); g.fillStyle = gr; g.fillRect(0, 0, W, H);
      var g2 = g.createRadialGradient(W, 180, 0, W, 180, 760); g2.addColorStop(0, "rgba(212,230,74,.26)"); g2.addColorStop(1, "rgba(212,230,74,0)"); g.fillStyle = g2; g.fillRect(0, 0, W, H);
    }
    var rr = function (x, y, w, h, r, fill) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); g.fillStyle = fill; g.fill(); };
    var X = 90, y = 170;
    // Étiquette
    F(800, 36); var kt = (P.done ? "MON MOIS DE TENNIS" : "MON MOIS (EN COURS)"), kw = g.measureText(kt).width + 64;
    rr(X, y, kw, 70, 35, C.kbg); g.fillStyle = C.kink; g.textBaseline = "middle"; g.fillText(kt, X + 32, y + 37);
    y += 140; g.textBaseline = "alphabetic"; F(500, 46); g.fillStyle = C.mut; g.fillText(P.month, X, y);
    // Le grand chiffre
    y += 60;
    if (style !== "bilan" && P.rankFrom && P.rankTo && P.rankFrom !== P.rankTo) {
      F(800, 200); g.fillStyle = C.mut; g.fillText(P.rankFrom, X, y + 190);
      var w1 = g.measureText(P.rankFrom + " ").width; g.fillStyle = C.acc; g.fillText("→", X + w1, y + 190);
      g.fillStyle = E.idx(P.rankTo) > E.idx(P.rankFrom) ? C.v : C.d; g.fillText(P.rankTo, X, y + 400);
      y += 440;
      if (P.projected) { F(500, 36); g.fillStyle = C.mut; g.fillText("projeté pour la sortie du classement", X, y); y += 30; }
    } else {
      F(800, 210); g.fillStyle = C.v; var vt = P.v + " V"; g.fillText(vt, X, y + 200); var wv = g.measureText(vt + "  ").width;
      g.fillStyle = C.d; g.fillText(P.d + " D", X + wv, y + 200);
      y += 250; F(700, 52); g.fillStyle = C.ink; g.fillText("en " + (P.v + P.d) + (P.v + P.d > 1 ? " matchs" : " match"), X, y + 30); y += 70;
    }
    // Les 4 tuiles
    y += 50; var tw = (W - 2 * X - 30) / 2, th = 190;
    var tiles = [[P.v + " V – " + P.d + " D", P.v + P.d > 1 ? (P.v + P.d) + " matchs" : (P.v + P.d) + " match"], [P.best != null ? lab(P.best) : "–", "meilleure victoire"],
      [String(P.perfs), P.perfs > 1 ? "perfs" : "perf"], [String(P.streak), P.streak > 1 ? "victoires de suite" : "victoire de suite"]];
    if (style === "bilan") tiles[0] = [P.rank || "–", "ton classement"];
    tiles.forEach(function (t, i) {
      var tx = X + (i % 2) * (tw + 30), ty = y + Math.floor(i / 2) * (th + 30);
      rr(tx, ty, tw, th, 36, C.tile); F(800, 72); g.fillStyle = C.ink; g.fillText(t[0], tx + 40, ty + 105); F(500, 34); g.fillStyle = C.mut; g.fillText(t[1], tx + 40, ty + 155);
    });
    y += 2 * th + 30 + 70;
    // Les résultats, dans l'ordre
    var sz = 64, gap = 14, per = Math.floor((W - 2 * X + gap) / (sz + gap)), seq = P.ms.slice(-per * 2);
    seq.forEach(function (m, i) {
      var tx = X + (i % per) * (sz + gap), ty = y + Math.floor(i / per) * (sz + gap);
      rr(tx, ty, sz, sz, 16, m.result === "V" ? C.v : C.d); F(800, 34); g.fillStyle = light ? "#FFFFFF" : "#121212"; g.textAlign = "center"; g.fillText(m.result, tx + sz / 2, ty + 46); g.textAlign = "left";
    });
    // Pied
    F(500, 34); g.fillStyle = C.mut; g.fillText(P.projected ? "Calculé avant la sortie" : "Mon bilan", X, H - 150); g.fillText("avec Montée", X, H - 105);
    F(800, 44); g.fillStyle = C.acc; g.textAlign = "right"; g.fillText("@montee.tennis", W - X, H - 118); g.textAlign = "left";
    return cv;
  }
  V.carte = function () {
    var R = lastReleases(), recent = (today() - R.r1) / 864e5 <= 10;
    var which = UI.cardWhich || (recent ? "done" : "cur");
    var P = cardPeriod(which), hasRank = P.rankFrom && P.rankTo && P.rankFrom !== P.rankTo;
    var style = UI.cardStyle || (hasRank ? "montee" : "bilan");
    var s = '<div class="screen">' + topbar("Ta carte du mois", P.span);
    s += '<div class="seg card-seg">' + [["done", "Mois dernier"], ["cur", "Mois en cours"]].map(function (x) { return '<button class="' + (which === x[0] ? "on" : "") + '" data-a="cardWhich" data-v="' + x[0] + '">' + x[1] + "</button>"; }).join("") + "</div>";
    if (!P.ms.length) return s + '<div class="card soft"><span class="p">Pas de match en simple sur cette période : rien à partager pour l\'instant.</span></div></div>';
    s += '<div class="card-prev"><img id="card-img" alt="Ta carte du mois : ' + esc(P.v + " victoires, " + P.d + " défaites") + '"></div>';
    s += '<div class="seg card-seg">' + [["montee", "Montée"], ["bilan", "Bilan"], ["sobre", "Sobre"]].map(function (x) { return '<button class="' + (style === x[0] ? "on" : "") + '" data-a="cardStyle" data-v="' + x[0] + '">' + x[1] + "</button>"; }).join("") + "</div>";
    s += '<button class="btn primary" data-a="cardShare">' + I.share + " Partager en story</button>";
    s += '<p class="small">Aucun nom d\'adversaire sur l\'image.' + (style === "montee" && !hasRank ? " Pas de changement de classement sur cette période : la carte montre ton bilan." : "") + "</p>";
    UI.cardP = P; UI.cardS = style;
    setTimeout(function () { loadCardFonts().then(function () { var im = document.getElementById("card-img"); if (im && UI.cardP === P) { var cv = drawCard(P, style); im.src = cv.toDataURL("image/png"); UI.cardUrl = im.src; } }); }, 0);
    return s + "</div>";
  }
  function cardHomeHtml() {
    var R = lastReleases(), days = (today() - R.r1) / 864e5, key = E.iso(R.r1);
    if (days > 10 || (S.cardSeen || {})[key]) return "";
    var P = cardPeriod("done"); if (!P.ms.length) return "";
    var up = P.rankFrom && P.rankTo && P.rankFrom !== P.rankTo;
    return '<div class="card key card-home"><span class="eyebrow">Le classement est sorti</span><b style="font-size:20px;letter-spacing:-.02em">' + (up ? "Tu es " + esc(P.rankTo) + ". Bravo !" : P.month.split(" ")[0] + " : " + P.v + " V – " + P.d + " D") + "</b>" +
      '<span class="small">Ta carte du mois est prête : partage-la en story.</span><div class="btn-pair"><button class="btn soft small" data-a="cardHide" data-v="' + key + '">Plus tard</button><button class="btn primary small" data-a="goCarte">Voir ma carte</button></div></div>';
  }

  // ---------- Ta charge de jeu : trop, ou pas assez, avant ton prochain match ----------
  function loadDays() {
    var by = {};
    S.matches.concat(S.trainings || []).forEach(function (x) { if (x.date && !x.wo) by[x.date] = (by[x.date] || 0) + playMinutes(x); });
    return by;
  }
  function loadBefore(by, d, n) { var t = 0; for (var i = 1; i <= n; i++) { var x = new Date(d.getTime() - i * 864e5); t += by[E.iso(x)] || 0; } return t; }
  function chargeInfo() {
    var by = loadDays(), t = today(), keys = Object.keys(by).sort();
    if (keys.length < 8) return null;
    var first = E.parseDate(keys[0]), weeks = Math.min(12, Math.floor((t - first) / (7 * 864e5)));
    if (weeks < 6) return null;
    var last7 = 0, days = []; for (var i = 6; i >= 0; i--) { var d = new Date(t.getTime() - i * 864e5), k = E.iso(d); last7 += by[k] || 0; days.push({ d: d, m: by[k] || 0 }); }
    var avg = 0; for (var j = 7; j < 7 + weeks * 7; j++) avg += by[E.iso(new Date(t.getTime() - j * 864e5))] || 0; avg = avg / weeks;
    var lastK = keys.filter(function (k) { return E.parseDate(k) <= t; }).pop(), since = lastK ? Math.round((t - E.parseDate(lastK)) / 864e5) : 99;
    // Ta zone : les heures jouées la semaine avant tes meilleurs résultats (12 mois)
    var cut = new Date(t.getTime() - 365 * 864e5), Bk = [[0, 2], [2, 4], [4, 6], [6, 8], [8, 99]].map(function (b) { return { lo: b[0], hi: b[1], v: 0, n: 0 }; });
    var comeback = { v: 0, n: 0 };
    playedOf(S.matches).forEach(function (m) {
      var md = E.parseDate(m.date); if (md < cut) return;
      var h = loadBefore(by, md, 7) / 60, b = Bk.filter(function (x) { return h >= x.lo && h < x.hi; })[0];
      b.n++; if (m.result === "V") b.v++;
      if (loadBefore(by, md, 10) === 0) { comeback.n++; if (m.result === "V") comeback.v++; }
    });
    var zone = null; Bk.forEach(function (b) { if (b.n >= 4 && (!zone || b.v / b.n > zone.v / zone.n)) zone = b; });
    var allR = Bk.reduce(function (a, b) { return a + b.v; }, 0) / Math.max(1, Bk.reduce(function (a, b) { return a + b.n; }, 0));
    if (zone && zone.v / zone.n - allR < 0.08) zone = null; // pas de vraie différence : on ne l'affiche pas
    var hiLim = Math.max(zone ? zone.hi * 60 : 0, avg * 1.6, 360);
    var kind = last7 >= hiLim && last7 >= avg + 120 ? "high" : since >= 10 && avg >= 120 ? "low" : null;
    return { kind: kind, last7: last7, avg: avg, since: since, zone: zone, days: days, comeback: comeback, allR: allR };
  }
  function chargeHtml() {
    var ci = chargeInfo(); if (!ci || !ci.kind) return "";
    var key = ci.kind + ":" + E.iso(today()).slice(0, 8) + Math.floor(today().getDate() / 7);
    if (S.chargeSeen === key) return "";
    var J = ["D", "L", "M", "M", "J", "V", "S"], mx = Math.max(150, Math.max.apply(null, ci.days.map(function (x) { return x.m; })));
    var bars = '<div class="ch-week">' + ci.days.map(function (x) { return '<div><i class="' + (x.m >= 120 ? "h" : x.m ? "" : "z") + '" style="height:' + (x.m ? Math.max(8, Math.round(x.m / mx * 100)) : 4) + '%"></i><span>' + J[x.d.getDay()] + "</span></div>"; }).join("") + "</div>";
    var zt = ci.zone ? (ci.zone.hi >= 99 ? "plus de " + ci.zone.lo + " h" : ci.zone.lo + " à " + ci.zone.hi + " h") : "";
    var s = '<div class="card insight ch-card"><span class="eyebrow">Ta charge de jeu</span>';
    if (ci.kind === "high") {
      s += '<b class="ch-h">' + esc(fmtHours(ci.last7)) + " de tennis en 7 jours : lève le pied</b>" + bars +
        '<span class="small">Ta moyenne : ' + esc(fmtHours(ci.avg)) + " par semaine." + (zt ? " Tes meilleurs résultats arrivent après <b>" + zt + "</b> de tennis la semaine d'avant." : "") + " Avant ton prochain match : une séance courte, sans match, et du repos la veille.</span>";
    } else {
      s += '<b class="ch-h">Pas de tennis depuis ' + ci.since + " jours</b>" +
        '<span class="small">' + (ci.comeback.n >= 3 ? "Tes " + plural(ci.comeback.n, "match", "matchs") + " après une coupure de 10 jours ou plus : " + ci.comeback.v + " V sur " + ci.comeback.n + ". " : "") + "Avant ton prochain match, une séance d'une heure avec ta raquette de match pour retrouver tes repères.</span>";
    }
    return s + '<button class="linkbtn" data-a="chargeHide" data-v="' + key + '" style="align-self:flex-start;padding:4px 0 0;min-height:0">Compris</button></div>';
  }

  // ---------- Cartes à la carte (accueil, courbes) ----------
  var BLOCKS = {
    home: [["essayer", "3 choses à essayer"], ["carte", "Ta carte du mois (après la sortie)"], ["charge", "Ta charge de jeu"], ["insight", "Le truc à savoir"], ["goal", "Ton objectif"], ["defendAl", "Points à défendre (alerte)"], ["annoter", "Annoter tes nouveaux matchs"], ["official", "Simulation officielle Ten'Up"], ["sync", "Rappel de synchro Ten'Up"], ["rate", "Noter tes séances"], ["slot", "« T'as joué ? » (semaine type)"],
      ["cordage", "Alertes cordage"], ["conditions", "Victoire et maintien"], ["drops", "Victoires qui sortent"], ["tiles", "Forme et raquette"], ["week", "Ta semaine"], ["todo", "Matchs à annoter"]],
    courbes: [["forces", "Tes forces"], ["saisons", "Tes saisons"], ["bilan", "Ton bilan"], ["niveau", "Ton niveau de jeu"], ["defend", "Points à défendre"], ["mental", "Mental"], ["plafond", "Ton plafond"], ["records", "Tes records"],
      ["forme", "Forme du moment"], ["gagner", "Ce qui te fait gagner"], ["h2h", "Face-à-face"], ["where", "Où tu gagnes"], ["raquette", "Avec quoi tu gagnes"], ["temps", "Temps de jeu"]]
  };
  function prefsOf(page) {
    S.prefs = S.prefs || {};
    var pr = S.prefs[page] || { order: [], hidden: [] }, ids = BLOCKS[page].map(function (x) { return x[0]; });
    var order = pr.order.filter(function (k) { return ids.indexOf(k) >= 0; });
    ids.forEach(function (k, i) { if (order.indexOf(k) < 0) order.splice(Math.min(i, order.length), 0, k); });
    return { order: order, hidden: pr.hidden || [] };
  }
  // Courbes : les cartes secondaires en lignes compactes, dépliées à la demande (rien n'est caché)
  var CB_COMPACT = ["forme", "gagner", "h2h", "where", "raquette", "temps"];
  function cbRow(k, html, name) {
    var m = html.match(/<div class="ct"><b>([^<]*)<\/b>(?:<span class="small">([^<]*)<\/span>)?/), title = m ? m[1] : name;
    var txt = html.replace(/<[^>]+>/g, " ").replace(/&nbsp;|&#\d+;/g, " ").replace(/\s+/g, " ").trim(), sub = m && m[2] ? m[2] : txt.replace(title, "").trim();
    sub = sub.length > 70 ? sub.slice(0, 68).replace(/\s+\S*$/, "") + "…" : sub;
    return '<button class="cb-row" data-a="cbOpen" data-v="' + k + '"><span class="grow"><b>' + title + "</b><small>" + sub + '</small></span><span class="chev">' + svg('<path d="M6 9l6 6 6-6"/>', 2.2) + "</span></button>";
  }
  function layout(page, B, anchors) {
    var pr = prefsOf(page), ks = pr.order.filter(function (k) { return pr.hidden.indexOf(k) < 0 && B[k]; });
    if (page === "courbes") {
      var names = {}; BLOCKS.courbes.forEach(function (x) { names[x[0]] = x[1]; });
      var open = UI.cbOpen || {}, main = ks.filter(function (k) { return CB_COMPACT.indexOf(k) < 0 || open[k]; }), more = ks.filter(function (k) { return CB_COMPACT.indexOf(k) >= 0 && !open[k]; });
      return main.map(function (k) { return '<div class="cb-a" id="cb-' + k + '">' + B[k] + (CB_COMPACT.indexOf(k) >= 0 ? '<button class="linkbtn cb-less" data-a="cbClose" data-v="' + k + '">Réduire</button>' : "") + "</div>"; }).join("") +
        (more.length ? '<div class="card cb-more" id="cb-more"><span class="eyebrow">Plus de courbes</span>' + more.map(function (k) { return '<div class="cb-a" id="cb-' + k + '">' + cbRow(k, B[k], names[k]) + "</div>"; }).join("") + "</div>" : "") +
        '<a class="btn soft small perso-btn" href="#/perso/courbes">' + I.edit + " Personnaliser les courbes</a>";
    }
    return ks.map(function (k) { return anchors ? '<div class="cb-a" id="cb-' + k + '">' + B[k] + "</div>" : B[k]; }).join("") +
      '<a class="btn soft small perso-btn" href="#/perso/' + page + '">' + I.edit + " Personnaliser " + (page === "home" ? "l'accueil" : "les courbes") + "</a>";
  }
  V.perso = function (page) {
    if (!BLOCKS[page]) { go(""); return ""; }
    var pr = prefsOf(page), names = {}; BLOCKS[page].forEach(function (x) { names[x[0]] = x[1]; });
    var s = '<div class="screen">' + topbar(page === "home" ? "Ton accueil" : "Tes courbes", "Choisis les cartes et leur ordre");
    if (page === "home") s += '<p class="small">La carte principale (montée, maintien) reste toujours en haut. Les alertes n\'apparaissent que quand il y a quelque chose à te dire.</p>';
    s += '<div class="list">' + pr.order.map(function (k, i) {
      var on = pr.hidden.indexOf(k) < 0;
      return '<div class="row perso-row' + (on ? "" : " off") + '"><span class="grow"><span class="t">' + esc(names[k]) + "</span></span>" +
        '<button class="iconbtn sm" data-a="persoMove" data-p="' + page + '" data-k="' + k + '" data-v="-1"' + (i ? "" : " disabled") + ' aria-label="Monter">↑</button>' +
        '<button class="iconbtn sm" data-a="persoMove" data-p="' + page + '" data-k="' + k + '" data-v="1"' + (i < pr.order.length - 1 ? "" : " disabled") + ' aria-label="Descendre">↓</button>' +
        '<input type="checkbox" role="switch" data-a="persoToggle" data-p="' + page + '" data-k="' + k + '"' + (on ? " checked" : "") + ' aria-label="Afficher ' + esc(names[k]) + '"></div>';
    }).join("") + "</div>";
    s += '<button class="linkbtn" data-a="persoReset" data-p="' + page + '">Revenir à l\'affichage d\'origine</button>';
    return s + "</div>";
  };

  // ---------- Ta semaine : temps de jeu et régularité ----------
  function mondayOf(d) { var x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - (x.getDay() + 6) % 7); return x; }
  function activity() {
    var by = {};
    S.matches.forEach(function (m) { if (m.date && !m.wo) { by[m.date] = by[m.date] || { m: 0, t: 0, min: 0 }; by[m.date].m++; by[m.date].min += playMinutes(m); } });
    (S.trainings || []).forEach(function (t) { if (t.date) { by[t.date] = by[t.date] || { m: 0, t: 0, min: 0 }; by[t.date].t++; by[t.date].min += playMinutes(t); } });
    return by;
  }
  function weekHtml() {
    var by = activity(), mon = mondayOf(today()), min = 0, dots = "", L = ["L", "M", "M", "J", "V", "S", "D"], td = E.iso(today());
    for (var i = 0; i < 7; i++) {
      var d = new Date(mon); d.setDate(d.getDate() + i); var k = E.iso(d), a = by[k];
      if (a) min += a.min;
      dots += '<span class="wd' + (k === td ? " today" : "") + '"><i class="' + (a ? (a.m ? "m" : "t") : "") + '"></i>' + L[i] + "</span>";
    }
    // semaines actives d'affilée (la semaine en cours ne casse pas la série si elle est encore vide)
    var streak = 0, w = new Date(mon), first = true;
    for (var n = 0; n < 104; n++) {
      var any = false;
      for (var j = 0; j < 7; j++) { var dd = new Date(w); dd.setDate(dd.getDate() + j); if (by[E.iso(dd)]) { any = true; break; } }
      if (any) streak++; else if (!first) break;
      first = false; w.setDate(w.getDate() - 7);
    }
    if (!min && !streak && !(S.slots || []).length) return "";
    return '<div class="card week"><div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px"><span><span class="eyebrow" style="color:var(--muted)">Cette semaine</span><span style="display:block;font-size:24px;font-weight:700;letter-spacing:-.02em">' + (min ? fmtDur(min) + ' <span style="font-size:15px;font-weight:500;color:var(--muted)">de jeu</span>' : "Pas encore joué") + "</span></span>" +
      (streak ? '<span class="streak">' + plural(streak, "semaine active", "semaines actives") + "</span>" : "") + "</div>" +
      '<div class="wdays">' + dots + "</div>" +
      '<span class="small"><span class="dot" style="background:var(--gazon)"></span> match · <span class="dot" style="background:var(--balle)"></span> entraînement' + ((S.slots || []).length ? "" : ' · <button class="linkbtn" data-a="newSlot" style="padding:0;min-height:0;font-size:inherit">Ajoute ta semaine type</button>') + "</span></div>";
  }
  // ---------- Semaine type : créneaux fixes à confirmer d'un tap ----------
  var DAYS_L = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"];
  var TLABELS = ["Collectif", "Cours", "Partenaire", "Autre"];
  function pendingSlots() {
    var out = [], now = new Date(), hhmm = ("0" + now.getHours()).slice(-2) + ":" + ("0" + now.getMinutes()).slice(-2), log = S.slotLog || {};
    (S.slots || []).forEach(function (sl) {
      for (var b = 0; b < 7; b++) {
        var d = today(); d.setDate(d.getDate() - b);
        if ((d.getDay() + 6) % 7 !== sl.dow) continue;
        var k = E.iso(d);
        if (k < sl.since || (b === 0 && (sl.time || "00:00") > hhmm) || log[sl.id + "|" + k]) continue;
        out.push({ sl: sl, date: k, back: b });
      }
    });
    return out.sort(function (a, b) { return a.back - b.back; });
  }
  function slotCardHtml() {
    var list = pendingSlots(); if (!list.length) return "";
    var x = list[0], d = E.parseDate(x.date);
    var when = x.back === 0 ? "Aujourd'hui" : x.back === 1 ? "Hier" : DAYS_L[x.sl.dow].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + d.getDate();
    return '<div class="card" style="gap:10px"><span class="eyebrow" style="color:var(--gazon)">Ta semaine type</span><span style="font-size:20px;font-weight:600;letter-spacing:-.02em">' + esc(when) + " " + esc(x.sl.time || "") + " : t'as joué ?</span>" +
      '<span class="small">' + esc(x.sl.label || "Entraînement") + " · " + fmtDur(x.sl.minutes) + ". Ça s'ajoute aux heures de ton cordage.</span>" +
      '<div class="grid2"><button class="btn primary small" data-a="slotYes" data-id="' + x.sl.id + '" data-d="' + x.date + '">Oui, j\'ai joué</button><button class="btn soft small" style="background:var(--chip)" data-a="slotNo" data-id="' + x.sl.id + '" data-d="' + x.date + '">Non</button></div>' +
      (list.length > 1 ? '<span class="small">encore ' + (list.length - 1) + " à confirmer</span>" : "") + "</div>";
  }
  V.creneau = function (id) {
    var isNew = !id || id === "new";
    if (!UI.slotDraft || UI.slotDraft._for !== (id || "new")) {
      var base = isNew ? { id: uid(), dow: 1, time: "18:30", minutes: 90, label: "Collectif", since: E.iso(today()) } : JSON.parse(JSON.stringify((S.slots || []).filter(function (x) { return x.id === id; })[0] || {}));
      if (!base.id) { go("materiel"); return ""; }
      base._for = id || "new"; UI.slotDraft = base;
    }
    var sl = UI.slotDraft;
    var s = '<div class="screen">' + topbar(isNew ? "Nouveau créneau" : "Créneau", "Ta semaine type", isNew ? "" : '<button class="iconbtn" data-a="delSlot" aria-label="Supprimer ce créneau">' + I.trash + "</button>");
    s += '<div class="form">' +
      '<div class="field"><span class="lbl">Jour</span><div class="chips">' + DAYS_L.map(function (d, i) { return '<button class="chip' + (sl.dow === i ? " on" : "") + '" data-a="slset" data-k="dow" data-v="' + i + '">' + d.slice(0, 3) + ".</button>"; }).join("") + "</div></div>" +
      '<div class="field inline"><label for="sl-time">Heure</label><input id="sl-time" type="time" data-sl="time" value="' + esc(sl.time) + '"></div>' +
      '<div class="field"><span class="lbl">Durée</span><div class="chips">' + [60, 90, 120].map(function (n) { return '<button class="chip' + (sl.minutes === n ? " on" : "") + '" data-a="slset" data-k="minutes" data-v="' + n + '">' + fmtDur(n) + "</button>"; }).join("") + "</div></div>" +
      '<div class="field"><span class="lbl">Type</span><div class="chips">' + TLABELS.map(function (l) { return '<button class="chip' + (sl.label === l ? " on" : "") + '" data-a="slset" data-k="label" data-v="' + l + '">' + l + "</button>"; }).join("") + "</div></div>" +
      "</div>";
    s += '<p class="small">Chaque semaine, après le créneau, Montée te demande sur l\'accueil si tu as joué. Un tap, et l\'entraînement est noté avec ta raquette principale.</p>';
    s += '<div class="spacer"></div><button class="btn primary" data-a="saveSlot">Enregistrer</button></div>';
    return s;
  };

  // ---------- Notation dans le flow : une carte sur l'accueil ----------
  var FEEL = ["Galère", "Bof", "Correct", "Bien", "Au top"];
  // ---------- Annoter en 10 secondes ----------
  // Les matchs récents sans raquette : raquette, surface, intérieur/ext. et ressenti en quelques taps.
  function qaPending(m) {
    var d = today(); d.setDate(d.getDate() - 30);
    return !!(m.date && !m.wo && !m.racketId && !m.qaSkip && m.date >= E.iso(d) && (m.result === "V" || m.result === "D"));
  }
  function qaList() { return S.matches.filter(qaPending).sort(function (a, b) { return a.date < b.date ? 1 : -1; }); }
  // Surfaces proposées d'emblée : les tiennes d'abord, puis les plus courantes ; le reste derrière « Autre… »
  function qaSurfaces(cur) {
    var n = {};
    S.matches.forEach(function (m) { if (m.surface) n[m.surface] = (n[m.surface] || 0) + 1; });
    var base = SURFACES.slice(0, 4), top = Object.keys(n).sort(function (a, b) { return n[b] - n[a]; });
    var out = [];
    top.concat(base).forEach(function (x) { if (out.length < 4 && out.indexOf(x) < 0 && x !== "Autre") out.push(x); });
    if (cur && out.indexOf(cur) < 0) out.push(cur);
    return out;
  }
  function qaHtml() {
    var list = qaList(), done = UI.qaDone && Date.now() - UI.qaDone.at < 6000 ? UI.qaDone : null;
    if (!list.length) {
      if (!done) return "";
      return '<div class="card qa qa-end">' + I.check + '<span><b>Tes matchs récents sont annotés.</b><span class="small" style="color:inherit;opacity:.75;display:block">Montée s\'en sert pour tes stats.</span></span></div>';
    }
    var m = list[0], last = S.lastQA || {};
    if (!UI.qa || UI.qa.id !== m.id) {
      var main = racketFor("match");
      UI.qa = { id: m.id, racketId: main ? main.id : "", surface: m.surface || last.surface || "", indoor: m.indoor != null ? m.indoor : (last.indoor != null ? last.indoor : null), feel: m.feel || 0, more: false };
    }
    var q = UI.qa, total = list.length + (UI.qaRun || 0), pos = (UI.qaRun || 0) + 1;
    var chip = function (a, v, on, label) { return '<button class="chip' + (on ? " on" : "") + '" data-a="' + a + '" data-v="' + esc(String(v)) + '" aria-pressed="' + on + '">' + esc(label) + "</button>"; };
    var s = '<div class="card qa">';
    if (done) s += '<span class="qa-done" role="status">' + I.check + " " + esc(done.label) + " : annoté</span>";
    s += '<span class="qa-top"><span class="eyebrow">Annote ton match' + (total > 1 ? " · " + pos + " sur " + total : "") + "</span></span>" +
      '<span style="font-size:20px;font-weight:600;letter-spacing:-.02em;line-height:1.2">' + (m.result === "V" ? "Victoire" : "Défaite") + " contre " + esc(m.opp && !isAnon(m.opp) ? m.opp : "un " + m.oppRank) + ' <span style="opacity:.6;font-weight:500">' + esc(m.oppRank) + "</span></span>" +
      '<span class="small" style="color:inherit;opacity:.75;margin-top:-4px">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + (m.comp ? " · " + esc(m.comp) : "") + "</span>" + revHint(m.opp, m.id, true);
    s += '<span class="qa-l">Raquette</span><div class="chips">' + (bag().length ? bag().map(function (r) { return chip("qaRacket", r.id, q.racketId === r.id, r.name); }).join("") : '<a class="chip" href="#/raquette/new">+ Ajoute ta raquette</a>') + "</div>";
    var surfs = q.more ? SURFACES : qaSurfaces(q.surface);
    s += '<span class="qa-l">Surface</span><div class="chips">' + surfs.map(function (x) { return chip("qaSurface", x, q.surface === x, SURF_LAB[x] || x); }).join("") +
      (q.more ? "" : '<button class="chip ghost" data-a="qaMore">Autre…</button>') + "</div>";
    s += '<span class="qa-l">Où</span><div class="chips">' + chip("qaIndoor", "1", q.indoor === true, "Intérieur") + chip("qaIndoor", "0", q.indoor === false, "Extérieur") + "</div>";
    s += '<span class="qa-l">Ton ressenti</span><div class="rate-row" role="group" aria-label="Ressenti de 1 à 5">' +
      FEEL.map(function (l, i) { return '<button data-a="qaFeel" data-v="' + (i + 1) + '" class="' + (q.feel === i + 1 ? "on" : "") + '" aria-pressed="' + (q.feel === i + 1) + '"><b>' + (i + 1) + "</b><span>" + l + "</span></button>"; }).join("") + "</div>";
    s += '<div class="btn-pair" style="margin-top:8px"><button class="btn balle" data-a="qaSave">' + (list.length > 1 ? "Enregistrer · suivant" : "Enregistrer") + '</button><button class="btn qa-later" data-a="qaSkip">Plus tard</button></div></div>';
    return s;
  }

  // ---------- Le truc à savoir ----------
  // Parmi toutes les stats, celle qui ressort le plus en ce moment, en une phrase.
  function insights(c) {
    var win = (c.proj.matches || []).filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); }), out = [];
    var phr = {
      surface: function (x) { return "sur " + x.label.toLowerCase(); },
      lieu: function (x) { return x.label === "Intérieur" ? "en intérieur" : "en extérieur"; },
      kind: function (x) { return x.label === "Tournoi" ? "en tournoi" : x.label === "Par équipes" ? "par équipes" : x.label === "Championnat individuel" ? "en championnat individuel" : x.label === "Match d'entraînement" ? "en match d'entraînement" : "en match libre"; }
    };
    [["surface", surfKey], ["lieu", function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; }],
      ["kind", function (m) { return (KINDS.filter(function (k) { return k[0] === (m.kind || "tournoi"); })[0] || ["", "Tournoi"])[1]; }]].forEach(function (d) {
      var g = groupStats(win, d[1]).filter(function (x) { return x.n >= 3; });
      if (g.length < 2) return;
      var hi = g[0], lo = g[g.length - 1], diff = hi.pct - lo.pct;
      if (diff < 25) return;
      out.push({ id: "split-" + d[0] + "-" + hi.label + "-" + lo.label, score: diff, go: "courbes", tab: d[0],
        text: "Tu gagnes " + hi.v + " matchs sur " + hi.n + " " + phr[d[0]](hi) + ", " + lo.v + " sur " + lo.n + " " + phr[d[0]](lo) + "." });
    });
    var ann = S.matches.filter(function (m) { return m.racketId && !m.wo && (m.result === "V" || m.result === "D"); });
    var gs = groupStats(ann, setupLabel).filter(function (x) { return x.n >= 3; });
    if (gs.length >= 2 && gs[0].pct - gs[gs.length - 1].pct >= 25) out.push({ id: "setup-" + gs[0].label, score: gs[0].pct - gs[gs.length - 1].pct - 5, go: "courbes",
      text: (function () {
        // Deux réglages qui ne diffèrent que par la fin (souvent la tension) : on ne répète que ce qui change
        var a = gs[0].label.split(" · "), b = gs[gs.length - 1].label.split(" · "), k = 0;
        while (k < a.length - 1 && k < b.length - 1 && a[k] === b[k]) k++;
        if (k > 0) return "Avec ta " + a.slice(0, k).join(" · ") + " : à " + a.slice(k).join(" · ") + ", tu gagnes " + gs[0].v + " matchs sur " + gs[0].n + " ; à " + b.slice(k).join(" · ") + ", " + gs[gs.length - 1].v + " sur " + gs[gs.length - 1].n + ".";
        return "Avec " + gs[0].label + ", tu gagnes " + gs[0].v + " matchs sur " + gs[0].n + ". Avec " + gs[gs.length - 1].label + ", " + gs[gs.length - 1].v + " sur " + gs[gs.length - 1].n + ".";
      })() });
    // points qui sortent bientôt
    var b0 = c.proj.status === "descente" ? c.proj.here : c.proj.next;
    if (b0 && b0.counted) {
      var lim = today(); lim.setDate(lim.getDate() + 92);
      var soon = b0.counted.filter(function (w) { if (!w.m.date) return false; var l = E.plus12Months(E.parseDate(w.m.date)); return l > today() && l <= lim; }).sort(function (a, b) { return b.pts - a.pts; });
      if (soon.length && soon[0].pts >= 30) {
        var w = soon[0], lv = E.plus12Months(E.parseDate(w.m.date));
        out.push({ id: "defend-" + w.m.id, score: 20 + w.pts / 3, go: "courbes",
          text: "En " + MOIS_L[lv.getMonth()] + ", ta victoire contre " + (w.m.opp || "un " + w.m.oppRank) + " (" + w.m.oppRank + ", +" + w.pts + " pts) sort de tes 12 mois." + (soon.length > 1 ? " Et " + plural(soon.length - 1, "autre") + " d'ici 3 mois." : "") });
      }
    }
    // revanche : tu viens de rejouer quelqu'un sur qui tu avais pris des notes
    var lim14 = E.iso(new Date(today().getTime() - 14 * 864e5));
    sortedMatches().filter(function (m) { return m.date >= lim14 && m.opp && !m.wo; }).slice(0, 5).forEach(function (m) {
      var prev = revNotes(m.opp, m.id).filter(function (n) { return !n.date || n.date <= m.date; })[0];
      if (!prev) return;
      out.push({ id: "rev-" + m.id, score: 45, go: "adversaire/" + encodeURIComponent(nameKey(m.opp)), ill: "revanche",
        text: (m.result === "V" ? "Revanche prise contre " : "Encore raté contre ") + m.opp + ". Ta note disait : « " + prev.text + " ». " + (m.result === "V" ? "Garde-la pour la prochaine." : "Ajoute ce que tu as appris.") });
    });
    // séries
    var sm = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }), st = 0;
    for (var i = 0; i < sm.length && sm[i].result === sm[0].result; i++) st++;
    if (st >= 3) out.push({ id: "streak-" + sm[0].result + st, score: 18 + st * 4, go: "palmares",
      text: sm[0].result === "V" ? st + " victoires d'affilée : c'est le moment de jouer des tournois." : st + " défaites d'affilée. Ça arrive : regarde contre qui, souvent mieux classés." });
    // tie-breaks d'affilée
    var tbs = []; sm.forEach(function (m) { setsOf(m.score).forEach(function (x, j) { if (isTb(x) || isSuperTb(x, j)) tbs.push(x[0] > x[1]); }); });
    var tr = 0; for (var j = 0; j < tbs.length && tbs[j] === tbs[0]; j++) tr++;
    if (tr >= 3) out.push({ id: "tb-" + tbs[0] + tr, score: 15 + tr * 4, go: "courbes", text: tbs[0] ? tr + " jeux décisifs gagnés d'affilée : dans les fins serrées, tu es là." : tr + " jeux décisifs perdus d'affilée : les fins de set se jouent aussi à la tête." });
    // forme
    var lim30 = E.iso(new Date(today().getTime() - 30 * 864e5)), rec = win.filter(function (m) { return m.date >= lim30; });
    if (rec.length >= 3 && win.length >= 8) {
      var pc = function (ms) { return Math.round(ms.filter(function (m) { return m.result === "V"; }).length * 100 / ms.length); }, dd = pc(rec) - pc(win);
      if (Math.abs(dd) >= 20) out.push({ id: "forme-" + (dd > 0 ? "up" : "down"), score: Math.abs(dd), go: "courbes",
        text: dd > 0 ? "En forme : " + pc(rec) + " % de victoires ce mois-ci, contre " + pc(win) + " % sur l'année." : "Petit creux : " + pc(rec) + " % de victoires ce mois-ci, contre " + pc(win) + " % sur l'année." });
    }
    // 1er set perdu
    var f1 = { v: 0, n: 0 }; win.forEach(function (m) { var x = setsOf(m.score); if (x.length && x[0][0] < x[0][1]) { f1.n++; if (m.result === "V") f1.v++; } });
    if (f1.n >= 4 && f1.v * 2 >= f1.n) out.push({ id: "comeback", score: 22, go: "courbes", text: "Après un premier set perdu, tu as gagné " + f1.v + " matchs sur " + f1.n + " : tu ne lâches rien." });
    // plafond
    var cap = plafondIdx(c);
    if (cap != null) {
      var nx = cap + 1, rs = win.filter(function (m) { return E.idx(m.oppRank) === nx; }), rv = rs.filter(function (m) { return m.result === "V"; }).length;
      out.push({ id: "cap-" + cap, score: 14, go: "courbes", text: "Tu bats régulièrement les " + lab(cap) + "." + (rs.length ? " La marche suivante, les " + lab(nx) + " : " + rv + " sur " + rs.length + " pour l'instant." : "") });
    }
    return out;
  }
  function insightHtml(c) {
    if (c.proj.status === "top") return "";
    var list = insights(c); if (!list.length) return "";
    var cur = S.insight || {}, td = E.iso(today());
    list.forEach(function (x) { if (x.id === cur.id && cur.since) x.score -= Math.max(0, (E.parseDate(td) - E.parseDate(cur.since)) / 864e5) * 4; });
    list.sort(function (a, b) { return b.score - a.score; });
    var x = list[0];
    if (x.id !== cur.id) { S.insight = { id: x.id, since: td }; try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
    var IL = window.MonteeIll;
    return '<button class="card insight" data-a="insightGo" data-go="' + x.go + '" data-tab="' + (x.tab || "") + '"><span class="ins-row"><span class="grow"><span class="eyebrow">Le truc à savoir</span><span class="ins-t">' + esc(x.text) + '</span></span></span><span class="go">Voir le détail ' + I.arrow + "</span></button>";
  }

  function toRate() {
    var d = today(); d.setDate(d.getDate() - 30); var lim = E.iso(d);
    return S.matches.filter(function (m) { return m.date && !m.wo && m.feel == null && !m.feelSkip && m.date >= lim && (m.result === "V" || m.result === "D") && !qaPending(m); }).map(function (m) { return { t: "m", o: m }; })
      .concat((S.trainings || []).filter(function (t) { return t.date && t.feel == null && !t.feelSkip && t.date >= lim; }).map(function (t) { return { t: "t", o: t }; }))
      .sort(function (a, b) { return a.o.date < b.o.date ? 1 : a.o.date > b.o.date ? -1 : 0; });
  }
  function rateCardHtml() {
    var list = toRate(); if (!list.length) return "";
    var x = list[0], o = x.o;
    var what = x.t === "m" ? (o.result === "V" ? "Victoire" : "Défaite") + " contre " + esc(o.opp || "un " + o.oppRank) + " (" + esc(o.oppRank) + ")" + (o.score ? " · " + esc(o.score) : "") : "Entraînement · " + fmtDur(playMinutes(o));
    var gear = o.racketId ? setupLabel(o) : "";
    return '<div class="card rate"><span class="eyebrow">À noter · un geste</span><span style="font-size:20px;font-weight:600;letter-spacing:-.02em">Comment tu t\'es senti ?</span>' +
      '<span class="small" style="color:inherit;opacity:.8">' + what + " · " + esc(fdate(o.date)) + (gear ? "<br>" + esc(gear) : "") + "</span>" +
      '<div class="rate-row" role="group" aria-label="Ta note de 1 à 5">' + FEEL.map(function (l, i) { return '<button data-a="rate" data-t="' + x.t + '" data-id="' + o.id + '" data-v="' + (i + 1) + '"><b>' + (i + 1) + "</b><span>" + l + "</span></button>"; }).join("") + "</div>" +
      '<div style="display:flex;justify-content:space-between;align-items:center"><button class="linkbtn" data-a="rateSkip" data-t="' + x.t + '" data-id="' + o.id + '" style="padding:0">Pas cette fois</button>' + (list.length > 1 ? '<span class="small">encore ' + (list.length - 1) + " à noter</span>" : "") + "</div></div>";
  }
  function party() {
    if (document.querySelector(".confetti")) return;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var box = document.createElement("div"); box.className = "confetti"; box.setAttribute("aria-hidden", "true");
    var cols = ["#D4E64A", "#1F5C3F", "#B04A22", "#121212", "#F6F2EC", "#3B8C5A"], h = "";
    for (var i = 0; i < (reduce ? 0 : 90); i++) {
      var ball = i % 9 === 0, sz = ball ? 18 : 6 + Math.random() * 7;
      h += '<i class="' + (ball ? "ball" : "") + '" style="left:' + (Math.random() * 100).toFixed(1) + "%;width:" + sz.toFixed(0) + "px;height:" + (ball ? sz : sz * 1.6).toFixed(0) + "px;background:" + (ball ? "#D4E64A" : cols[i % cols.length]) +
        ";animation-duration:" + (2.2 + Math.random() * 1.8).toFixed(2) + "s;animation-delay:" + (Math.random() * 0.6).toFixed(2) + "s;--dx:" + ((Math.random() - 0.5) * 140).toFixed(0) + "px;--r:" + (Math.random() * 900 - 450).toFixed(0) + 'deg"></i>';
    }
    box.innerHTML = h + '<div class="confetti-msg">Montée !</div>';
    document.body.appendChild(box);
    if (IOS) haptic("success"); else if (navigator.vibrate) try { navigator.vibrate([30, 60, 30]); } catch (e) {}
    setTimeout(function () { box.remove(); }, 4300);
  }

  // Cotillons décoratifs de la carte de fête (couleurs du thème, léger mouvement)
  function feteConfetti() {
    // [x, y, couleur, rotation, forme] : regroupés à droite, autour du nouveau classement
    var P = [[188,34,"hl",25,"r"],[222,18,"terre",-30,"r"],[252,40,"on",60,"c"],[282,20,"gazon",-15,"r"],[314,38,"hl",40,"r"],
      [206,70,"on",-50,"r"],[240,62,"gazon",20,"c"],[270,78,"hl",10,"r"],[300,64,"terre",75,"r"],[318,92,"hl",-35,"c"],
      [226,104,"terre",35,"r"],[256,118,"hl",-70,"r"],[288,108,"on",30,"c"],[316,140,"gazon",20,"r"],[276,150,"hl",-40,"r"],
      [176,72,"hl",-60,"c"],[238,146,"on",50,"r"],[198,132,"gazon",-20,"r"]];
    var col = { hl: "var(--hl)", terre: "var(--terre)", gazon: "var(--chart-v)", on: "var(--on-panel)" };
    return '<svg class="fete-conf" viewBox="0 0 330 170" aria-hidden="true">' +
      '<path d="M300 150c-6-14 10-18 4-32s8-18 4-30" fill="none" stroke-width="2.6" stroke-linecap="round" style="stroke:var(--hl)"/>' +
      '<path d="M206 136c12 2 14-12 26-10s14-10 24-8" fill="none" stroke-width="2.4" stroke-linecap="round" style="stroke:var(--chart-v)"/>' +
      P.map(function (q, i) {
        var st = 'style="fill:' + col[q[2]] + ";animation-delay:" + (i * 0.21).toFixed(2) + 's"';
        return q[4] === "c" ? '<circle cx="' + q[0] + '" cy="' + q[1] + '" r="5.5" ' + st + "/>" :
          '<rect x="' + (q[0] - 9) + '" y="' + (q[1] - 3.5) + '" width="18" height="7" rx="2.5" transform="rotate(' + q[3] + " " + q[0] + " " + q[1] + ')" ' + st + "/>";
      }).join("") + "</svg>";
  }
  function feteHtml() {
    var A = S.ahead, rel = E.parseDate(A.release);
    return '<div class="card hero fete" role="status">' + feteConfetti() + '<span class="eyebrow">Sortie du ' + esc(flong(rel)) + '</span><span class="big"><span class="fete-rank">' + esc(A.rank) + "</span>Tu montes !<br>C'est dans la poche.</span>" +
      '<span style="font-size:15px;line-height:1.4">Tu passes de ' + esc(A.from) + " à " + esc(A.rank) + ". Montée t'a déjà mis à jour et calcule la suite depuis " + esc(A.rank) + ".</span></div>";
  }
  // ---------- Accueil qui hiérarchise : la carte la plus urgente, le reste replié ----------
  var HOME_URG = ["verify", "hc", "cordage", "carte", "defendAl", "charge", "an", "annoter", "slot", "rate", "sync", "essayer"];
  var HOME_XN = { verify: "À vérifier", hc: "Nouvelle séance", an: "Analyse de ton match" };
  function homeLayout(B, X) {
    var pr = prefsOf("home"), names = {}; BLOCKS.home.forEach(function (x) { names[x[0]] = x[1]; });
    var all = {}; Object.keys(X).forEach(function (k) { if (X[k]) all[k] = X[k]; });
    pr.order.forEach(function (k) { if (pr.hidden.indexOf(k) < 0 && B[k]) all[k] = B[k]; });
    var hot = B.cordage && /strc hot/.test(B.cordage);
    var top = HOME_URG.filter(function (k) { return all[k] && (k !== "cordage" || hot); })[0];
    var keep = ["official", "tiles"], order = Object.keys(X).concat(pr.order);
    var rest = order.filter(function (k, i) { return all[k] && k !== top && keep.indexOf(k) < 0 && order.indexOf(k) === i; });
    var s = top ? '<div class="home-top">' + all[top] + "</div>" : "";
    if (rest.length <= 1) s += rest.map(function (k) { return all[k]; }).join("");
    else if (UI.homeMore) s += '<div class="home-grp"><button class="home-grp-h" data-a="homeLess"><b>Autres choses à voir · ' + rest.length + '</b><span>Replier ' + svg('<path d="M6 15l6-6 6 6"/>', 2.2) + "</span></button>" + rest.map(function (k) { return all[k]; }).join("") +
      '<button class="btn soft small home-less" data-a="homeLess">' + svg('<path d="M6 15l6-6 6 6"/>', 2.2) + " Replier</button></div>";
    else {
      var nm = rest.map(function (k) { return (HOME_XN[k] || names[k] || "").replace(/ \\(.*\\)$/, ""); }).filter(Boolean);
      s += '<button class="home-fold" data-a="homeMore"><span class="n">' + rest.length + '</span><span class="grow"><b>' + (rest.length > 1 ? "Autres choses à voir" : "Autre chose à voir") + "</b><small>" + esc(nm.slice(0, 3).join(" · ") + (nm.length > 3 ? "…" : "")) + '</small></span><span class="chev">' + svg('<path d="M6 9l6 6 6-6"/>', 2.2) + "</span></button>";
    }
    s += keep.map(function (k) { return all[k] || ""; }).join("");
    return s + '<a class="btn soft small perso-btn" href="#/perso/home">' + I.edit + " Personnaliser l'accueil</a>";
  }
  // « 3 choses à essayer » : se cochent toutes seules, disparaissent une fois faites
  function tryMark(k) { S.tried = S.tried || {}; if (!S.tried[k]) { S.tried[k] = 1; save(); } }
  function tryHtml() {
    var t = S.tried || {}; if (t.hide || !S.onboarded || S.matches.length < 3) return "";
    var L = [["an", "Ouvre l'analyse de ton dernier match", "tryAn"], ["adv", "Cherche ton prochain adversaire", "goFaf"], ["simu", "Essaie « Et si… » : simule ton tournoi", "goSimu"]];
    if (L.every(function (x) { return t[x[0]]; })) return "";
    return '<div class="card try-card"><span class="eyebrow">3 choses à essayer</span>' + L.map(function (x) { var d = !!t[x[0]]; return '<button class="try-r' + (d ? " done" : "") + '" data-a="' + x[2] + '"><span class="ck">' + (d ? I.check : "") + "</span><span>" + x[1] + "</span></button>"; }).join("") +
      '<button class="linkbtn" data-a="tryHide" style="align-self:flex-start;padding:2px 0 0;min-height:0">Masquer</button></div>';
  }
  function cbSpy() {
    var nav = document.getElementById("cb-nav"); if (!nav) return;
    nav.classList.toggle("stuck", nav.getBoundingClientRect().top <= (parseFloat(getComputedStyle(nav).top) || 0) + 1 && window.scrollY > 20);
    var top = nav.getBoundingClientRect().bottom + 12, cur = null;
    Array.prototype.forEach.call(document.querySelectorAll(".cb-a, #cb-more"), function (el) { if (el.getBoundingClientRect().top <= top + 40) cur = el.closest("#cb-more") ? "more" : el.id.slice(3); });
    var bs = nav.querySelectorAll("button"); if (!cur && bs[0]) cur = bs[0].dataset.v;
    if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 4 && bs.length) cur = bs[bs.length - 1].dataset.v; // en bas de page : la dernière
    Array.prototype.forEach.call(bs, function (b) { var on = b.dataset.v === cur; if (on && !b.classList.contains("on")) { b.classList.add("on"); var l = b.offsetLeft - 16; nav.scrollTo({ left: Math.max(0, l), behavior: "smooth" }); } else if (!on) b.classList.remove("on"); });
  }
  function heroHtml(c) {
    var p = c.proj, rel = "Sortie du " + flong(p.release), cur = c.cur < 0 ? 0 : c.cur;
    var nx = p.next, pct = nx.norme ? Math.min(100, Math.round(nx.total * 100 / nx.norme)) : 100;
    var gauge = '<div class="gauge" role="img" aria-label="' + nx.total + " points sur " + nx.norme + '"><span style="width:' + pct + '%"></span></div><div class="gauge-legend"><span><b>' + nx.total + "</b> pts au bilan " + nx.label + "</span><span>il en faut " + nx.norme + "</span></div>";
    var cls = "balle", title, sub = "", pre = S.ahead ? feteHtml() : "";
    if (p.status === "montee") {
      var b = p.steps.filter(function (x) { return x.calc === p.projected; })[0];
      title = "Et ensuite " + lab(p.projected) + " :<br>tu as déjà les points.";
      sub = S.ahead ? "Si rien ne change, tu monterais " + lab(p.projected) + " à la sortie d'après." : "";
      gauge = '<div class="gauge"><span style="width:100%"></span></div><div class="gauge-legend"><span><b>' + b.total + "</b> pts au bilan " + lab(p.projected) + "</span><span>norme " + b.norme + "</span></div>";
    } else if (p.status === "descente") {
      cls = "terre";
      title = "Attention : risque de descente à " + lab(p.projected) + ".";
      sub = "Bilan à " + lab(cur) + " : " + p.here.total + " / " + p.here.norme + ". Il te manque " + plural(p.here.norme - p.here.total, "point") + " pour te maintenir.";
      gauge = "";
    } else {
      var pl = pistes(c), ez = easiest(pl), one = pl.one, head = S.ahead ? "Prochaine étape, " : "Montée à ";
      if (p.gap === 0 && p.needWin) {
        title = head + nx.label + " :<br>tu as les points, il manque la victoire qui valide.";
        sub = "Pour monter, il faut au moins une victoire contre un " + nx.label + " ou mieux. Bats-en un et c'est fait.";
      } else if (ez) {
        title = head + nx.label + " :<br>" + (ez.k === 1 ? "une victoire peut suffire." : "il te manque " + plural(p.gap, "point") + ".");
        sub = ez.k === 1 ? "Contre un " + lab(Math.min(ez.top, one ? one.top : ez.top)) + " ou mieux." :
          "Ton chemin le plus accessible : " + pisteLabel(ez) + "." + (one && one.top <= (pl.maxBeaten == null ? -9 : pl.maxBeaten) ? " Ou une seule, contre un " + lab(one.top) + "." : "");
      } else {
        title = head + nx.label + " :<br>il te manque " + plural(p.gap, "point") + ".";
        sub = "Il faudrait plus de 4 victoires d'ici la sortie : vise plutôt la suivante.";
      }
    }
    return pre + '<button class="card hero ' + cls + '" data-a="goProjection">' + (window.MonteeIll ? '<span class="hero-arc">' + window.MonteeIll.arc() + "</span>" : "") + '<span class="eyebrow">' + esc(rel) + '</span><span class="big">' + title + "</span>" +
      (sub ? '<span style="font-size:15px;line-height:1.4">' + esc(sub) + "</span>" : "") + gauge +
      '<span class="go">Voir le détail ' + I.arrow + "</span></button>";
  }


  // ---------- Projection ----------
  V.projection = function () {
    var c = ctx(), p = c.proj;
    if (p.status === "top") return '<div class="screen">' + topbar("Projection") + '<p class="lead">Les joueurs numérotés sont classés au concours des meilleurs bilans : pas de simulation possible.</p></div>';
    var cur = c.cur < 0 ? 0 : c.cur, nx = p.next;
    var head = p.status === "montee" ? "Tu montes à " + lab(p.projected) : p.status === "descente" ? "Risque de descente à " + lab(p.projected) : (p.gap ? "Il te manque " + plural(p.gap, "point") + " pour " + nx.label : "Il te manque une victoire contre un " + nx.label);
    var s = '<div class="screen">' + topbar(head, "Sortie du " + flong(p.release));
    var hb = p.status === "descente" ? p.here : nx;
    s += '<span class="muted" style="font-size:15px;margin-top:-6px">' + hb.total + " au bilan " + hb.label + " · norme " + hb.norme + " · " + plural(hb.n, "victoire") + " prises en compte</span>";

    // simulateur
    var lv = levelsAround(c.cur), danger = p.status === "descente";
    if (UI.projLevel == null || lv.indexOf(UI.projLevel) < 0) UI.projLevel = danger ? cur : Math.min(cur + 1, E.MAX_CALC);
    var sim = E.simulateWin(allMatches(), c.cur, c.sex, UI.projLevel, c.opts);
    var rose = sim.after.projected > cur && sim.after.status === "montee";
    var wasUp = p.status === "montee", verdict, detail, good = rose || wasUp;
    if (danger && !rose) {
      // Menacé de descente : on regarde d'abord le maintien
      var ah = sim.after.here, g = ah.total - p.here.total, saved = sim.after.status !== "descente";
      good = saved;
      verdict = saved ? "Tu te maintiendrais à " + lab(cur) : "Toujours menacé : il manque " + plural(Math.max(0, ah.norme - ah.total), "pt") + " pour rester " + lab(cur);
      detail = g > 0 ? "+" + g + " pts au bilan " + lab(cur) + ". Bilan : " + ah.total + " / " + ah.norme + "." :
        "Cette victoire ne change rien à ton bilan " + lab(cur) + ".";
    } else {
      verdict = wasUp ? (sim.after.projected > p.projected ? "Tu monterais " + lab(sim.after.projected) : "Tu montes toujours " + lab(p.projected)) :
        rose ? "Tu monterais " + lab(sim.after.projected) : (sim.after.next.total >= sim.after.next.norme && !sim.after.next.winAtLevel ? "Pas encore : il faut battre un " + nx.label : "Pas encore : il manque " + plural(Math.max(0, sim.after.next.norme - sim.after.next.total), "pt") + " pour monter " + nx.label);
      detail = sim.gain > 0 ? "+" + sim.gain + " pts au bilan " + nx.label + (sim.pts > sim.gain ? " (+" + sim.pts + ", qui remplacent ta plus faible victoire comptée)" : "") + ". Bilan : " + sim.after.next.total + " / " + sim.after.next.norme + "." :
        (sim.pts === 0 ? "Une victoire aussi loin en dessous ne rapporte pas de points à " + nx.label + "." : "Cette victoire ne dépasse pas tes victoires déjà comptées : elle ne change rien au bilan.");
    }
    s += '<div class="card"><b style="font-size:15px">Et si tu gagnais contre un…</b><div class="chips" role="group" aria-label="Classement de l\'adversaire">' +
      lv.map(function (i) { return '<button class="chip' + (UI.projLevel === i ? " on" : "") + '" data-a="projLevel" data-v="' + i + '" aria-pressed="' + (UI.projLevel === i) + '" style="flex:1">' + lab(i) + "</button>"; }).join("") + "</div>" +
      '<div class="card ' + (good ? "balle" : "terre") + '" style="padding:14px;gap:4px"><span style="font-size:21px;font-weight:700;letter-spacing:-.02em">' + esc(verdict) + '</span><span style="font-size:14px;line-height:1.4">' + esc(detail) + "</span></div>" +
      '<a class="linkbtn simu-link" href="#/simu">Plusieurs matchs ? Simule ton tournoi ' + I.next + "</a></div>";

    s += pistesHtml(c);
    s += calendarHtml(c);
    var mw = null;
    if (mw !== undefined && mw !== null) s += '<div class="card menthe" style="flex-direction:row;align-items:center;gap:10px;padding:12px 14px">' + I.spark + '<span style="font-size:14px;line-height:1.4"><b>À retenir :</b> une victoire contre un ' + lab(mw) + " ou mieux suffit. Joue-la tôt pour qu'elle soit homologuée à temps.</span></div>";

    s += officialHtml(true);
    // détail du bilan
    var keep = cur > 0 && p.status !== "montee" ? bilanDetail(p.here, "Pour rester " + lab(cur) + " : ton bilan à " + lab(cur)) : "";
    var up = bilanDetail(nx, "Pour monter " + nx.label + " : ton bilan à " + nx.label);
    s += danger ? keep + up : up + keep;
    s += '<a class="btn soft small" href="#/methode">Comment c\'est calculé</a>';
    return s + '<p class="small">Calcul indicatif d\'après le barème FFT. Seul le classement officiel fait foi.</p></div>';
  };

  // Ton calendrier : quand tes victoires sortent du bilan, et les prochaines sorties du classement
  function calendarHtml(c) {
    var nx = c.proj.next; if (!nx || c.proj.status === "top") return "";
    var cm = countedMap(nx), ev = [], t0 = today(), lim = new Date(t0.getTime() + 100 * 864e5);
    allMatches().forEach(function (m) { if (cm[m.id] == null || !m.date) return; var lv = E.plus12Months(E.parseDate(m.date)); if (lv >= t0 && lv <= lim) ev.push({ d: lv, k: "out", pts: cm[m.id], m: m }); });
    var r = new Date(t0); for (var i = 0; i < 3; i++) { var nr = E.nextRelease(r); if (nr > lim) break; ev.push({ d: nr, k: "rel" }); r = new Date(nr.getTime() + 864e5); }
    if (!ev.some(function (x) { return x.k === "out"; })) return "";
    ev.sort(function (a, b) { return a.d - b.d; });
    var gap = Math.max(0, nx.norme - nx.total), lost = 0, tip = "";
    var rows = ev.map(function (x) {
      var dt = fdate(E.iso(x.d)).replace(/\.$/, "");
      if (x.k === "rel") { var need = gap + lost; try { var bb = E.bilanAt(E.windowMatches(allMatches(), x.d, today()), E.idx(nx.label), c.sex, c.cur, c.opts.extra); need = Math.max(0, bb.norme - bb.total); } catch (e) {} return '<div class="evx rel"><b>' + dt + " · sortie du classement</b><small>" + (need > 0 ? "Pour monter " + nx.label + " ce jour-là, il te manquera " + need + " pts (sans nouveau match)" : "Tu as les points pour " + nx.label + (nx.winAtLevel ? "" : ", il manque la victoire qui valide")) + "</small></div>"; }
      lost += x.pts;
      if (!tip) tip = "<b>Le bon moment pour gagner, c'est avant le " + dt + ".</b> Après, ta victoire contre un " + esc(x.m.oppRank) + " ne compte plus.";
      return '<div class="evx out"><b>' + dt + " · sort de ton bilan</b><small>Ta victoire contre un " + esc(x.m.oppRank) + " (" + MOIS[E.parseDate(x.m.date).getMonth()] + " " + E.parseDate(x.m.date).getFullYear() + ") : −" + x.pts + " pts</small></div>";
    }).join("");
    return '<div class="card cal-card"><span class="eyebrow">Ton calendrier</span><div class="tml">' + rows + "</div>" + (tip ? '<span class="p">' + tip + "</span>" : "") + "</div>";
  }
  function pistesHtml(c) {
    var pl = pistes(c), p = c.proj;
    if (!pl.goal) return "";
    var goalTxt = pl.goal === "keep" ? "rester " + lab(pl.target) : "monter " + lab(pl.target);
    var s = '<div class="card" style="gap:12px">' + chead("courbe", "Tes pistes pour " + goalTxt, "Si tu gagnes ces matchs avant la sortie du " + fdate(p.release).replace(/\.$/, ""));
    if (pl.goal === "up" && p.gap === 0 && p.needWin) s += '<div class="card balle" style="padding:12px 14px"><span style="font-size:15px;line-height:1.4"><b>Tu as déjà les points.</b> Il manque la victoire qui valide : au moins une contre un ' + lab(pl.target) + " ou mieux.</span></div>";
    if (!pl.list.length) return s + '<span style="font-size:15px;line-height:1.4">Contre des adversaires à ta portée, même 4 victoires ne suffiraient pas d\'ici la sortie. Vise la suivante : chaque victoire compte 12 mois.</span></div>';
    if (pl.stretch) s += '<span class="small">Avec les adversaires que tu as déjà battus, ça ne passe pas : ces pistes demandent un cran de plus.</span>';
    var cap = plafondIdx(c), ez = easiest(pl);
    s += pl.list.map(function (x) {
      var badge = x === ez ? "Le plus accessible" : x.p < 0.45 && ez && x.top > ez.top ? "Plus ambitieux" : x.k === 1 ? "Une victoire suffit aussi" : "Sans jouer plus fort que " + lab(x.top);
      var mine = cap != null && x.top <= cap && x.top >= (c.cur < 0 ? 0 : c.cur); // inutile de le dire contre des moins bien classés
      var mineTxt = !mine ? "" : x.top === cap ? " · <strong>dans tes cordes</strong> : tu bats régulièrement les " + esc(lab(cap)) : " · <strong>dans tes cordes</strong> : tu bats régulièrement des joueurs mieux classés (jusqu'à " + esc(lab(cap)) + ")";
      return '<div class="piste' + (x === ez ? " best" : "") + '"><span class="pbadge">' + esc(badge) + "</span><b>" + esc(pisteLabel(x)) + "</b>" +
        '<span class="small">' + (x.p >= 0.45 ? "À ta portée" : x.p >= 0.2 ? "Jouable" : "Ambitieux") + " · bilan " + esc(x.after.label) + " : " + x.after.total + " / " + x.after.norme + " pts" + mineTxt + "</span></div>";
    }).join("");
    return s + '<span class="small">Calculé comme ton bilan : une nouvelle victoire remplace ta plus faible victoire comptée, elle ne rapporte donc que la différence. Pistes classées de la plus probable à la moins probable, d\'après tes résultats contre chaque classement' + (pl.maxBeaten != null ? ", sans adversaire plus fort que ton meilleur succès (" + lab(pl.maxBeaten) + ")" : "") + ".</span></div>";
  }
  function bilanDetail(b, title) {
    var s = '<h2>' + esc(title) + '</h2><div class="list">';
    if (!b.counted.length) s += '<div class="row"><span class="grow"><span class="s">Aucune victoire qui rapporte des points à cet échelon pour l\'instant.</span></span></div>';
    b.counted.forEach(function (w, i) {
      s += '<a class="row" href="#/match/' + w.m.id + '"><span class="grow"><span class="t">' + esc(w.m.opp || "Adversaire") + ' <span class="muted" style="font-weight:400">· ' + esc(w.m.oppRank) + '</span></span><span class="s">' + esc(fdate(w.m.date)) + "</span></span>" +
        '<span class="pts"' + (i === b.counted.length - 1 && b.counted.length >= b.n ? ' style="color:var(--terre)"' : "") + ">+" + w.pts + "</span></a>";
    });
    if (b.bonusSD) s += '<div class="row"><span class="grow">Bonus sans défaite significative</span><span class="pts">+' + b.bonusSD + "</span></div>";
    if (b.bonusCh) s += '<div class="row"><span class="grow">Bonus championnats individuels</span><span class="pts">+' + b.bonusCh + "</span></div>";
    if (b.bonusDbl) s += '<div class="row"><span class="grow">Bonus doubles<span class="s" style="display:block">' + plural(b.doubles.length, "victoire en double prise", "victoires en double prises") + " en compte</span></span><span class=\"pts\">+" + b.bonusDbl + "</span></div>";
    if (b.adjust) s += '<div class="row"><span class="grow">Ajustement d\'après Ten\'Up<span class="s" style="display:block">bonus et coefficients que Ten\'Up ne détaille pas</span></span><span class="pts">' + (b.adjust > 0 ? "+" : "") + b.adjust + "</span></div>";
    s += '<div class="row" style="font-weight:700"><span class="grow">Total</span><span class="pts">' + b.total + " / " + b.norme + "</span></div></div>";
    s += '<div class="card" style="gap:2px;padding:12px 16px">' +
      '<div class="kv"><span>Victoires (V)</span><b>' + b.V + "</b></div>" +
      '<div class="kv"><span>Défaites à ' + esc(b.label) + " (E)</span><b>" + b.E + "</b></div>" +
      '<div class="kv"><span>Défaites un échelon en dessous (I)</span><b>' + b.I + "</b></div>" +
      '<div class="kv"><span>Défaites deux échelons ou plus en dessous (G)</span><b>' + b.G + "</b></div>" +
      '<div class="kv"><span>V − E − 2I − 5G</span><b>' + b.ve + "</b></div>" +
      '<div class="kv"><span>Victoires prises en compte</span><b>' + b.n + "</b></div>" +
      (b.extra.length ? '<div class="kv"><span>Victoires hors quota</span><b>' + b.extra.length + "</b></div>" : "") +
      "</div>";
    return s;
  }

  // ---------- Palmarès ----------
  V.palmares = function () {
    var c = ctx(), pts = countedMap(c.proj.next), tab = UI.palTab;
    var from = E.iso(new Date(today().getFullYear() - 1, today().getMonth(), today().getDate()));
    var all = sortedMatches();
    var list = all.filter(function (m) {
      return tab === "all" || (tab === "v" && m.result === "V") || (tab === "d" && m.result === "D") || (tab === "todo" && !annotated(m)) || (tab === "manual" && isManual(m));
    });
    var s = '<div class="screen has-tabs"><div class="topbar"><div class="title"><span class="small">' + plural(c.proj.matches ? c.proj.matches.length : 0, "match", "matchs") + ' sur 12 mois</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">Palmarès</span></div>' +
      '<button class="iconbtn" data-a="newMatch" aria-label="Ajouter un match" style="background:var(--solid);color:var(--on-solid)">' + I.plus + "</button></div>";
    s += '<div class="tabs" role="group" aria-label="Filtrer">' + [["all", "Tout"], ["v", "Victoires"], ["d", "Défaites"], ["todo", "À annoter"]].concat(all.some(isManual) ? [["manual", "À la main"]] : []).concat((S.doubles || []).length ? [["dbl", "Doubles"]] : []).map(function (t) {
      return '<button data-a="palTab" data-v="' + t[0] + '" class="' + (tab === t[0] ? "on" : "") + '" aria-pressed="' + (tab === t[0]) + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    if (tab === "dbl") return s + doublesListHtml(c) + "</div>" + tabbar("palmares");
    if (tab === "all" || tab === "manual") s += verifyHtml() + staleHtml();
    if (!list.length) {
      s += '<div class="card empty"><b>' + (all.length ? "Rien ici" : "Pas encore de match") + '</b><span class="small">' + (all.length ? "Aucun match pour ce filtre." : "Récupère ton palmarès Ten'Up ou ajoute un match.") + "</span>" +
        (all.length ? "" : '<a class="btn primary small" href="#/tenup">Récupérer depuis Ten\'Up</a>') + "</div>";
    }
    var curMonth = "", old = false;
    s += '<div class="stack" style="gap:8px">';
    list.forEach(function (m) {
      if (!m.date) { if (curMonth !== "nd") { curMonth = "nd"; s += "<h2>Période en cours · importés de Ten'Up</h2>"; } }
      else {
        if (!old && m.date <= from) { old = true; s += "<h2>Plus de 12 mois · ne comptent plus</h2>"; curMonth = "x"; }
        var dd = E.parseDate(m.date), mk = MOIS_L[dd.getMonth()] + " " + dd.getFullYear();
        if (!old && mk !== curMonth) { curMonth = mk; s += "<h2>" + mk.replace(/^./, function (x) { return x.toUpperCase(); }) + "</h2>"; }
      }
      var pt = pts[m.id];
      var ptsHtml = !counts(m) ? '<span class="pts muted" style="font-weight:500;font-size:13px">ne compte pas</span>' : m.result === "V" ? (old ? "" : pt != null ? '<span class="pts pos">+' + pt + "</span>" : '<span class="pts muted" style="font-weight:500;font-size:13px">hors quota</span>') : "";
      var tag = m.wo ? '<span class="tag">Forfait · non joué</span>' : annotated(m) ? '<span class="tag">' + esc(setupLabel(m)) + "</span>" : '<span class="tag todo">À annoter</span>';
      if (isManual(m)) tag = '<span class="tags"><span class="tag manual" title="Pas encore sur Ten\'Up">' + I.edit + " Saisi à la main</span>" + tag + "</span>";
      else if (m.manualOrigin && m.confirmedAt && dayDiff(m.confirmedAt, E.iso(today())) <= 14) tag = '<span class="tags"><span class="tag ok">' + I.check + " Confirmé par Ten'Up</span>" + tag + "</span>";
      s += '<a class="row' + (isManual(m) ? " manual" : "") + '" href="#/match/' + m.id + '" style="background:var(--card);border-radius:20px' + (old ? ";opacity:.65" : "") + '"><span class="vd lg ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(m.opp || "Adversaire") + ' <span class="muted" style="font-weight:400">· ' + esc(m.oppRank) + '</span></span><span class="s">' + (m.date ? esc(fdate(m.date)) : "") + (m.score ? (m.date ? " · " : "") + esc(m.score) : "") + (!m.date && !m.score ? "Ajoute date et score si tu veux" : "") + "</span>" + tag + "</span>" + ptsHtml + "</a>";
    });
    s += "</div>";
    return s + "</div>" + tabbar("palmares");
  };

  function doublesListHtml(c) {
    var nx = c.proj.next || {}, got = {};
    (nx.doubles || []).forEach(function (x) { got[x.m.id] = x; });
    var kinds = { perf: "en perf", egal: "à poids égal", contre: "en contre" };
    var list = (S.doubles || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var s = '<div class="card" style="gap:6px"><b style="font-size:15px">Tes doubles comptent en bonus</b><span style="font-size:14px;line-height:1.45">Une victoire en double ne compte pas comme une victoire en simple : elle rapporte un petit bonus selon la force des deux paires (en perf, à poids égal ou en contre). Seules tes meilleures victoires comptent' + (nx.calc != null ? " : " + E.BAREME.double(nx.calc).max + " au maximum à " + nx.label : "") + ".</span>" +
      (nx.bonusDbl ? '<span class="pos" style="font-size:15px">+' + nx.bonusDbl + " pts au bilan " + esc(nx.label) + "</span>" : "") + "</div>";
    s += '<div class="stack" style="gap:8px">' + list.map(function (m) {
      var g = got[m.id];
      return '<div class="row" style="background:var(--card);border-radius:20px"><span class="vd lg ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(m.opp || "Adversaires") + ' <span class="muted" style="font-weight:400">· ' + esc((m.oppRanks || [m.oppRank]).join(" et ")) + '</span></span><span class="s">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + (m.partner ? " · avec " + esc(m.partner) + (m.partnerRank ? " (" + esc(m.partnerRank) + ")" : "") : "") + "</span>" +
        (g ? '<span class="tag">' + kinds[g.kind] + "</span>" : "") + "</span>" + (g ? '<span class="pts pos">+' + g.pts + "</span>" : m.result === "V" && !m.wo ? '<span class="pts muted" style="font-weight:500;font-size:13px">hors quota</span>' : "") + "</div>";
    }).join("") + "</div>";
    return s;
  }

  // ---------- Fiche match ----------
  var SURFACES = ["Terre battue", "Terre artificielle", "Résine", "Béton poreux", "Gazon synthétique", "Moquette", "Gazon naturel", "Autre"];
  var SURF_LAB = { "Autre": "Autre (gymnase, parquet…)" };
  // « Autre » est gardé sur la fiche mais exclu des comparaisons par surface (trop disparate)
  function surfKey(m) { return m.surface && m.surface !== "Autre" ? m.surface : null; }
  var SURF_OLD = { "Dur": "Résine", "Synthétique": "Gazon synthétique", "Gazon": "Gazon naturel" };
  var KINDS = [["tournoi", "Tournoi"], ["champ", "Championnat individuel"], ["equipes", "Par équipes"], ["libre", "Match libre"], ["amical", "Match d'entraînement"]];
  // Libellés dans le formulaire de saisie : on distingue le match libre homologué de l'amical
  var KIND_ORDER = [["tournoi", "Tournoi"], ["champ", "Championnat individuel"], ["equipes", "Par équipes"], ["libre", ""], ["amical", ""]];
  var KIND_FORM = { libre: "Match libre (homologué)", amical: "Match d'entraînement" };
  var WIN_SETS = ["6-0", "6-1", "6-2", "6-3", "6-4", "7-5", "7-6"], LOSE_SETS = ["0-6", "1-6", "2-6", "3-6", "4-6", "5-7", "6-7"];
  var WIN_STB = ["10-0", "10-1", "10-2", "10-3", "10-4", "10-5", "10-6", "10-7", "10-8"];
  // Deux colonnes : à gauche ce que tu as gagné (vert), à droite ce que tu as perdu (orange), lignes en miroir
  function pickCols(i, st, stb) {
    var cur = st ? st.join("-") : "", ext = UI.stbExt || 11;
    var col = function (side, list, title) {
      var h = '<div class="sc-col ' + side + '"><span class="sc-head">' + (side === "w" ? I.check : I.cross) + title + "</span>";
      list.forEach(function (v) { h += '<button class="sc-chip' + (cur === v ? " on" : "") + '" data-a="scorePick" data-i="' + i + '" data-v="' + v + '" aria-label="' + (side === "w" ? "Gagné " : "Perdu ") + v + '">' + v + "</button>"; });
      if (stb) {
        var v = side === "w" ? ext + "-" + (ext - 2) : (ext - 2) + "-" + ext;
        h += '<div class="sc-ext"><button data-a="stbExt" data-v="-1" aria-label="Moins">−</button><button class="sc-chip' + (cur === v ? " on" : "") + '" data-a="scorePick" data-i="' + i + '" data-v="' + v + '">' + v + '</button><button data-a="stbExt" data-v="1" aria-label="Plus">+</button></div>';
      }
      return h + "</div>";
    };
    var win = stb ? WIN_STB : WIN_SETS, lose = stb ? WIN_STB.map(function (v) { return v.split("-").reverse().join("-"); }) : LOSE_SETS;
    return '<div class="sc-cols">' + col("w", win, stb ? "Tu gagnes le super TB" : "Tu gagnes le set") + col("l", lose, stb ? "Tu perds le super TB" : "Tu perds le set") + "</div>" +
      (stb ? '<span class="small">Au-delà de 10-8, ça se gagne avec 2 points d\'écart : règle la dernière ligne avec − et +.</span>' : "");
  }
  function scoreHtml(m) {
    if (UI.scoreManual) return '<div class="field"><label for="m-score">Score</label><input id="m-score" type="text" data-d="score" value="' + esc(m.score) + '" placeholder="6-4 3-6 7-5 ab."><button class="linkbtn" data-a="scoreManual" style="align-self:flex-start;padding:0">Revenir à la saisie rapide</button></div>';
    var sets = m.sets || [], w = 0, l = 0, s = '<div class="field"><span class="lbl">Score <span class="small">· de ton point de vue</span></span><div class="sets">';
    for (var i = 0; i < 3; i++) {
      var st = sets[i];
      if (!st && (w === 2 || l === 2 || i > sets.length)) break;
      var editing = !st || UI.scoreEdit === i;
      if (!editing) {
        s += '<button class="setrow" data-a="scoreEdit" data-v="' + i + '"><span class="small">' + (isSuperTb(st, i) ? "Super tie-break" : "Set " + (i + 1)) + '</span><b class="' + (st[0] > st[1] ? "w" : "l") + '">' + st[0] + "-" + st[1] + '</b><span class="small">modifier</span></button>';
      } else {
        var stb = i === 2 && UI.stb;
        s += '<div class="setpick"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b style="font-size:15px">' + (stb ? "Super tie-break" : "Set " + (i + 1)) + "</b>" +
          (i === 2 ? '<span class="seg mini"><button data-a="scoreStb" data-v="0" class="' + (stb ? "" : "on") + '">Set</button><button data-a="scoreStb" data-v="1" class="' + (stb ? "on" : "") + '">Super TB</button></span>' : "") + "</div>" +
          pickCols(i, st, stb) + "</div>";
      }
      if (!st) break;
      if (st[0] > st[1]) w++; else l++;
    }
    s += "</div>";
    s += '<div style="display:flex;gap:16px;flex-wrap:wrap">' + (sets.length ? '<button class="linkbtn" data-a="scoreClear" style="padding:0">Effacer le score</button>' : "") + '<button class="linkbtn" data-a="scoreManual" style="padding:0">Abandon ou score spécial</button></div></div>';
    return s;
  }
  function applySets(m, sets) {
    var out = [], w = 0, l = 0;
    sets.forEach(function (st) { if (!st || w === 2 || l === 2) return; out.push(st); if (st[0] > st[1]) w++; else l++; });
    m.sets = out; m.score = out.map(function (st) { return st[0] + "-" + st[1]; }).join(" ");
    if (w === 2) m.result = "V"; else if (l === 2) m.result = "D";
    UI.stb = out[2] ? isSuperTb(out[2], 2) : UI.stb;
  }
  function durationHtml(m, isMatch) {
    var est = isMatch ? estMinutes(m) : 60, v = m.minutes || est;
    return '<div class="field inline"><span class="lbl">' + (isMatch ? "Durée" : "Ajuster") + (isMatch ? '<span class="small" style="display:block;font-weight:400">' + (m.minutes ? "corrigée par toi · " + '<button class="linkbtn" data-a="dminReset" style="padding:0;min-height:0;font-size:inherit">estimer</button>' : "estimée d'après le score") + "</span>" : "") + '</span><span class="stepper"><button data-a="dmin" data-v="-15" aria-label="Moins 15 minutes">−</button><span>' + fmtDur(v) + '</span><button data-a="dmin" data-v="15" aria-label="Plus 15 minutes">+</button></span></div>';
  }
  function feelHtml(m, label) {
    return '<div class="field"><span class="lbl">' + esc(label) + '</span><div class="rate-row soft">' + FEEL.map(function (l, i) { return '<button data-a="dset" data-k="feel" data-v="' + (i + 1) + '" class="' + (m.feel === i + 1 ? "on" : "") + '" aria-pressed="' + (m.feel === i + 1) + '"><b>' + (i + 1) + "</b><span>" + l + "</span></button>"; }).join("") + "</div></div>";
  }
  function gearHtml(m) {
    var r = racket(m.racketId), IL = window.MonteeIll;
    if (!UI.gearOpen) {
      if (!r) return '<button class="gear-card" data-a="gearOpen"><span class="g-ill">' + (IL ? IL.racket("noir") : "") + '</span><span class="grow"><b>' + (bag().length ? "Choisir ta raquette" : "Ajoute ta raquette") + '</b><span class="small">Pour suivre tes cordages et savoir avec quoi tu gagnes</span></span><span class="g-go">' + I.next + "</span></button>";
      var st = racketStatus(r);
      return '<div class="gear-card"><span class="g-ill">' + (IL ? IL.racket(r.color || "noir", r.accent, r.pattern) : "") + '</span><span class="grow"><b>' + esc(r.name) + (r.main ? ' <span class="tag">principale</span>' : "") + "</b>" +
        '<span class="small">' + esc([m.string, fmtTension(m)].filter(Boolean).join(" · ") || "Cordage à renseigner") + (st.known ? " · " + (m.newString ? "cordage neuf" : fmtHours(st.min) + " sur ce cordage") : "") + "</span></span>" +
        '<button class="linkbtn g-change" data-a="gearOpen">Changer</button></div>';
    }
    return '<div class="form"><div class="gear-list">' + bag().map(function (r) {
        var st = racketStatus(r), on = m.racketId === r.id;
        return '<button class="gear-opt' + (on ? " on" : "") + '" data-a="dracket" data-v="' + r.id + '" aria-pressed="' + on + '"><span class="g-ill">' + (IL ? IL.racket(r.color || "noir", r.accent, r.pattern) : "") + '</span><span class="grow"><b>' + esc(r.name) + '</b><span class="small">' + esc([r.string, fmtTension(r)].filter(Boolean).join(" · ")) + (st.known ? " · " + fmtHours(st.min) + " sur son cordage" : "") + '</span></span><span class="g-check">' + (on ? I.check : "") + "</span></button>";
      }).join("") + '<button class="gear-opt add" data-a="newRacketFromMatch"><span class="g-ill">' + I.plus + '</span><span class="grow"><b>Ajouter une raquette</b></span></button></div>' +
      (m.racketId ? '<div class="field"><label for="m-str">Cordage</label><input id="m-str" type="text" data-d="string" value="' + esc(m.string) + '" placeholder="Ex. : RPM Blast 1,25"></div>' +
        tensionHtml(m, "match") +
        '<label class="field inline check" style="margin:0"><span><span style="display:block">Cordage neuf</span><span class="small">Coche si tu as recordé juste avant</span></span><input type="checkbox" role="switch" data-d="newString"' + (m.newString ? " checked" : "") + "></label>" : "") + '<button class="btn soft small" data-a="gearOpen">Terminé</button></div>';
  }

  // ---------- Entraînement ----------
  V.entrainement = function (id) {
    var isNew = !id || id === "new", key = "t:" + (id || "new");
    if (!UI.draft || UI.draft._for !== key) {
      var base = isNew ? { id: uid(), date: E.iso(today()), minutes: 60, racketId: "", string: "", tension: null, tensionCross: null, newString: false, feel: null, note: "" } :
        JSON.parse(JSON.stringify((S.trainings || []).filter(function (t) { return t.id === id; })[0] || {}));
      if (!base.id) { go("materiel"); return ""; }
      if (isNew) {
        var main = racketFor("train");
        if (main) { base.racketId = main.id; base.string = main.string || ""; base.tension = main.tension || null; base.tensionCross = main.tensionCross != null ? main.tensionCross : null; }
        // Séance venue de la santé connectée : date et durée de la montre, à corriger si besoin
        if (UI.hcPrefill) { var hx = UI.hcPrefill; UI.hcPrefill = null; base.date = hcIso(hx.start); base.minutes = hcMin(hx); base.hid = hx.id; base.src = "sante"; base._hsrc = hcSrc(hx); }
      }
      base._for = key; UI.draft = base; UI.gearOpen = false; UI.origKey = null;
    }
    var t = UI.draft;
    var s = '<div class="screen">' + topbar(isNew ? "Nouvel entraînement" : "Entraînement", isNew ? (t._hsrc ? "Séance du " + fdate(t.date).replace(/\.$/, "") + " · " + t._hsrc : "") : fdate(t.date), isNew ? "" : '<button class="iconbtn" data-a="delTraining" aria-label="Supprimer cet entraînement">' + I.trash + "</button>");
    if (t.hid && isNew) s += '<p class="small" style="margin:0">Durée reprise de ta montre : corrige-la si l\'échauffement a traîné.</p>';
    s += '<div class="form">' +
      '<div class="field inline"><label for="t-date">Date</label><input id="t-date" type="date" data-d="date" value="' + esc(t.date) + '" max="' + E.iso(today()) + '"></div>' +
      '<div class="field"><span class="lbl">Durée</span><div class="chips">' + [30, 45, 60, 90, 120].map(function (n) { return '<button class="chip' + (t.minutes === n ? " on" : "") + '" data-a="dset" data-k="minutes" data-v="' + n + '">' + fmtDur(n) + "</button>"; }).join("") + "</div></div>" +
      durationHtml(t, false) +
      '<div class="field"><span class="lbl">Type</span><div class="chips">' + TLABELS.map(function (l) { return '<button class="chip' + (t.label === l ? " on" : "") + '" data-a="dset" data-k="label" data-v="' + l + '">' + l + "</button>"; }).join("") + "</div></div>" + "</div>";
    s += '<h2>Ta raquette</h2>' + gearHtml(t);
    s += '<h2>Ton ressenti</h2><div class="form">' + feelHtml(t, "Comment tu t'es senti avec ce matériel ?") +
      '<div class="field"><label for="t-note">Ce que tu as travaillé</label><input id="t-note" type="text" data-d="note" value="' + esc(t.note) + '" placeholder="Ex. : service, retours, match à thème"></div></div>';
    s += '<p class="small">La durée compte dans les heures de jeu de ton cordage.</p>';
    s += saveBar("saveTraining", t, isNew) + "</div>";
    return s;
  };

  // ---------- Saisies à la main et Ten'Up : vérification, récapitulatif, oubliés ----------
  function mById(id) { return S.matches.filter(function (m) { return m.id === id; })[0]; }
  // Une ligne « match » compacte ; diff = champs à surligner (différents de l'autre version)
  function mLine(m, diff) {
    var hl = function (k, txt) { return diff && diff[k] ? '<mark>' + esc(txt) + "</mark>" : esc(txt); };
    return '<span class="vf-line"><span class="vd ' + m.result + '">' + m.result + "</span><span>" + hl("date", fdate(m.date).replace(/\.$/, "")) + " · " + hl("opp", m.opp || "Adversaire") + " " + hl("oppRank", m.oppRank || "?") + (m.score ? ' · <span class="nw">' + hl("score", m.score) + "</span>" : "") + "</span></span>";
  }
  function mDiff(a, b) {
    return { date: a.date !== b.date, opp: nameKey(a.opp) !== nameKey(b.opp), oppRank: a.oppRank !== b.oppRank, score: (a.score || "").replace(/\s/g, "") !== (b.score || "").replace(/\s/g, "") };
  }
  // Rapprochements douteux : on demande au joueur
  function verifyHtml() {
    return (S.verify || []).map(function (v) {
      var a = mById(v.id), b = mById(v.tid); if (!a || !b) return "";
      var d = mDiff(a, b);
      return '<div class="card vf-card"><span class="eyebrow">' + I.warn + " À vérifier · c'est le même match ?</span>" +
        '<span class="vf-k">Ta saisie</span>' + mLine(a, d) + '<span class="vf-k">Sur Ten\'Up</span>' + mLine(b, d) +
        '<span class="small">Tant que tu n\'as pas répondu, seule la version Ten\'Up compte dans ton bilan.</span>' +
        '<div class="btn-pair"><button class="btn primary small" data-a="verifySame" data-id="' + v.id + '">Oui, c\'est le même</button><button class="btn soft small" data-a="verifyDiff" data-id="' + v.id + '">Non, deux matchs</button></div></div>';
    }).join("");
  }
  // Saisies jamais retrouvées sur Ten'Up après 30 jours
  function staleManual() {
    var lim = new Date(today()); lim.setDate(lim.getDate() - 30); var l = E.iso(lim);
    // Un match de plus de 12 mois saisi à la main (historique) n'apparaîtra plus sur Ten'Up : on ne le réclame pas
    var y = new Date(today()); y.setFullYear(y.getFullYear() - 1); var ly = E.iso(y);
    return S.matches.filter(function (m) { return isManual(m) && m.date && m.date < l && m.date >= ly && m.kind !== "amical" && !(S.keepManual || {})[m.id]; });
  }
  function staleHtml() {
    return staleManual().map(function (m) {
      return '<div class="card vf-card stale"><span class="eyebrow">' + I.edit + " Toujours pas sur Ten'Up</span>" + mLine(m) +
        '<span class="small">Saisi à la main il y a plus d\'un mois. Match amical, erreur de saisie ? Gardé en match d\'entraînement, il reste dans tes stats mais ne compte pas pour le classement.</span>' +
        '<div class="btn-pair"><button class="btn primary small" data-a="staleKeep" data-id="' + m.id + '">Garder en entraînement</button><button class="btn soft small danger" data-a="staleDel" data-id="' + m.id + '">Supprimer</button></div></div>';
    }).join("");
  }
  // ---------- L'analyse du match : son palmarès au moment du match, la lecture du score, ton classement ----------
  // Ten'Up ne donne que le score des sets : on ne parle ni de breaks ni de balles sauvées, seulement de ce que les chiffres montrent.
  var AN_IC = { fire: '<path d="M12 21c-4 0-7-2.8-7-6.6 0-3.2 2.2-5.3 3.8-7 .4 1.8 1.4 3 2.7 3.6-.3-3 1.2-5.8 3.5-8 .3 3 4 5.3 4 10.8 0 4.1-3 7.2-7 7.2z"/>', star: '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>', wall: '<path d="M3 6h18v12H3zM3 12h18M9 6v6M15 12v6"/>', eq: '<path d="M5 9h14M5 15h14"/>', target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".6"/>', check: '<path d="M5 12l5 5 9-10"/>', racket: '<ellipse cx="10" cy="9" rx="6" ry="7"/><path d="M14.5 13.5L21 20"/>', rev: '<path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3M18 3v4h-4M6 21v-4h4"/>', up: GP_IC.up, down: GP_IC.down };
  function anKey(m) { return [m.date, m.result, m.score, m.oppRank, m.opp].join("|"); }
  // Palmarès de l'adversaire (gardé par match, pour ne pas relire Ten'Up à chaque ouverture)
  function anPal(m) { var p = (S.anPal || {})[m.id]; return p && p.rows ? p : null; }
  function anStore(m, r, hit) {
    S.anPal = S.anPal || {};
    var rows = T.rows({ raw: r.raw }).map(function (x) { return { date: x.date, result: x.result, score: x.score, oppRank: x.oppRank, wo: x.wo }; });
    S.anPal[m.id] = { at: E.iso(today()), id: String(hit.id), rank: (r.profil && r.profil.classement) || m.oppRank, sim: r.sim || null, rows: rows };
    S.anPal[m.id].ts = Date.now();
    var tsA = function (k) { var x = S.anPal[k]; return x.ts || new Date(x.at).getTime(); };
    var ks = Object.keys(S.anPal).filter(function (k) { return k !== m.id; }).sort(function (a, b) { return tsA(b) - tsA(a); }); ks.slice(39).forEach(function (k) { delete S.anPal[k]; });
    save();
  }
  // Va chercher son palmarès sur Ten'Up : par son identifiant (match Ten'Up), sinon par son nom (match saisi à la main)
  function anFetch(m, quiet) {
    if (!NATIVE || !m || anPal(m) || isAnon(m.opp) || m.wo || !(m.result === "V" || m.result === "D")) return Promise.resolve();
    UI.anBusy = UI.anBusy || {}; if (UI.anBusy[m.id]) return Promise.resolve(); UI.anBusy[m.id] = true;
    var done = function (msg) { UI.anBusy[m.id] = false; if (msg) { UI.anErr = UI.anErr || {}; UI.anErr[m.id] = msg; } if (!quiet && route() === "match/" + m.id) render(); };
    var player = function (hit) { return tenupQuery("player", hit).then(function (r) { if (!r || r.error) return done(r && r.error === "web" ? "" : "Ten'Up n'a pas répondu."); anStore(m, r, hit); done(); }); };
    var sc = Object.keys(S.scout || {}).filter(function (k) { var p = S.scout[k].profil || {}; return (m.oid && String(m.oid) === k) || nameKey([p.prenom, p.nom].join(" ")) === nameKey(m.opp) || nameKey([p.nom, p.prenom].join(" ")) === nameKey(m.opp); })[0];
    if (m.oid || sc) return player({ id: m.oid || sc, nom: "", prenom: "" });
    var sp = nameSplits(m.opp || "")[0];
    if (!sp || sp.nom.length < 2 || sp.prenom.length < 2) return Promise.resolve(done("Nom incomplet : Montée ne peut pas le retrouver sur Ten'Up."));
    return tenupQuery("search", { nom: sp.nom, prenom: sp.prenom, check: { me: nameKey((S.tenup.me || {}).nom || ""), dates: [m.date] } }).then(function (r) {
      var hits = (r && r.hits) || [], h = hits.filter(function (x) { return x.played === true; })[0] || (hits.length === 1 ? hits[0] : null);
      if (!h) return done(hits.length ? "Plusieurs joueurs portent ce nom : ouvre son face-à-face pour choisir le bon." : "Joueur introuvable sur Ten'Up (orthographe, ou joueur anonyme).");
      return player(h);
    });
  }
  function anGames(sets) { var a = 0, b = 0; sets.forEach(function (x, i) { if (!isSuperTb(x, i)) { a += x[0]; b += x[1]; } }); return [a, b]; }
  function anTight(x, i) { return isTb(x) || isSuperTb(x, i) || (Math.max(x[0], x[1]) === 7 && Math.abs(x[0] - x[1]) === 2); }
  function anSetLabel(x, i) { return isSuperTb(x, i) ? "super tie-break" : isTb(x) ? "tie-break" : Math.max(x[0], x[1]) === 7 ? "au finish" : Math.abs(x[0] - x[1]) <= 2 ? "serré" : Math.min(x[0], x[1]) <= 1 ? "sec" : ""; }
  function analyse(m) {
    if (m.wo) return { wo: true };
    var won = m.result === "V", sets = setsOf(m.score), me = curIdx() < 0 ? 0 : curIdx(), hi = E.idx(T.normRank(m.oppRank)), items = [], head = "";
    var pal = anPal(m), anon = isAnon(m.opp) || (!pal && m.oppTenup != null && isAnon(m.oppTenup));
    var c = ctx(), mine = playedOf(S.matches).filter(function (x) { return x.date && x.date >= E.iso(new Date(E.parseDate(m.date).getTime() - 365 * 864e5)) && x.date <= m.date; });
    var before = mine.filter(function (x) { return x.id !== m.id && x.date < m.date; }), stB = scoutStats(before), stA = scoutStats(mine);
    var g = anGames(sets), tight = sets.filter(anTight), comeback = won && sets.length === 3 && sets[0][0] < sets[0][1], first = m.opp ? m.opp.split(" ")[0] : "lui";
    // 1. Son palmarès au moment du match
    var streak = 0, lastLoss = null, hisL = null, sp = null, hisStats = null, hisLosses = [], weight = null, ctxItems = [];
    if (pal) {
      var hp = pal.rows.filter(function (x) { return !x.wo && (x.result === "V" || x.result === "D") && x.date; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
      var hb = hp.filter(function (x) { return x.date < m.date; });
      for (var i = 0; i < hb.length && hb[i].result === "V"; i++) streak++;
      lastLoss = hb.filter(function (x) { return x.result === "D"; })[0] || null;
      var hpl = playedOf(hp.map(function (x) { return { date: x.date, result: x.result, oppRank: x.oppRank, score: x.score }; }));
      if (hpl.length >= 6 && hi != null) hisL = levelFit(hpl, hi).mean;
      sp = simProj(pal.sim, pal.rank || m.oppRank);
      hisStats = hp; hisLosses = hp.filter(function (x) { return x.result === "D" && x.date !== m.date; });
      var vs = hb.slice(0, 8), vsW = vs.filter(function (x) { return x.result === "V"; }).length;
      if (won && streak >= 3) {
        var bigW = hb.slice(0, streak).filter(function (x) { var k = E.idx(T.normRank(x.oppRank)); return k != null && hi != null && k > hi; });
        items.push({ ic: "fire", t: "Il restait sur " + streak + " victoires d'affilée", s: (bigW.length ? "Dont " + plural(bigW.length, "victoire") + " contre mieux classé que lui. " : "") + (lastLoss ? "Tu es le premier à le battre depuis le " + fdate(lastLoss.date).replace(/\.$/, "") + "." : "Tu es le premier à le battre cette saison."), streak: streak });
        head = hi != null && hi > me ? "Grosse perf : tu as stoppé un joueur en pleine bourre." : "Bravo : tu as stoppé un joueur en pleine bourre.";
      } else if (!won && vs.length >= 5 && vsW >= vs.length - 1) items.push({ ic: "fire", t: "Il est en grande forme", s: vsW + " victoires sur ses " + vs.length + " derniers matchs avant le vôtre." });
      if (hisL != null && hisL - hi >= 0.6) {
        items.push({ ic: "star", t: won ? "Il jouait au-dessus de son classement" : "Il joue déjà " + lab(Math.round(hisL)), s: "D'après ses résultats, son vrai niveau est " + lab(Math.round(hisL)) + "." + (won ? " Tu as battu mieux que ce que dit son classement." : sp && sp.dir === "up" ? " Sa simulation Ten'Up le voit monter à " + lab(sp.proj) + " à la prochaine sortie." : "") });
      } else if (hisL != null && hi - hisL >= 0.6 && !won) {
        items.push({ ic: "down", t: "C'était jouable", s: "Sur le papier il est " + lab(hi) + ", mais ses résultats le placent plutôt " + lab(Math.round(hisL)) + " en ce moment." });
      } else if (sp && sp.dir === "up" && !won) items.push({ ic: "up", t: "Un joueur qui monte", s: "Sa simulation Ten'Up le voit monter à " + lab(sp.proj) + " à la prochaine sortie." });
      if (!won && hisLosses.length && hi != null) {
        var lr = hisLosses.map(function (x) { return E.idx(T.normRank(x.oppRank)); }).filter(function (k) { return k != null; });
        if (lr.length >= 1 && Math.min.apply(null, lr) > hi && hp.length >= 6) items.push({ ic: "star", t: "Il ne perd que contre mieux classé", s: "Cette saison, il n'a perdu que contre des " + lab(Math.min.apply(null, lr)) + " ou mieux." });
      }
      // Ceux qui lui ont pris un set / autant de jeux
      var hisW = hp.filter(function (x) { return x.result === "V" && x.date !== m.date; });
      if (sets.length >= 2 && hisW.length >= 5) {
        var tookSet = sets.some(function (x) { return x[0] > x[1]; });
        var gamesOpp = hisW.map(function (x) { var z = anGames(setsOf(x.score)); return z[1]; }), more = gamesOpp.filter(function (n) { return n >= g[0]; }).length;
        if (!won && tookSet) { var setTakers = hisW.filter(function (x) { return setsOf(x.score).length === 3; }).length; if (setTakers <= 2) items.push({ ic: "check", t: "Tu lui as pris un set", s: setTakers ? "Seuls " + setTakers + " de ses " + hisW.length + " adversaires battus y étaient arrivés cette saison." : "Aucun de ses " + hisW.length + " adversaires battus n'y était arrivé cette saison." }); }
        else if (!won && more <= 2 && g[0] >= 8) items.push({ ic: "check", t: "Tu l'as accroché", s: g[0] + " jeux pris : seuls " + more + " de ses " + hisW.length + " adversaires battus ont fait aussi bien cette saison." });
      }
    }
    // 1 bis. Le contexte : est-il monté depuis, son parcours dans ce tournoi, son bilan contre ton classement
    if (pal && hi != null) {
      var rNow = E.idx(T.normRank(pal.rank || "")), hpA = (hisStats || []).slice().sort(function (a, b) { return a.date < b.date ? -1 : 1; });
      if (rNow != null && rNow > hi) {
        var dUp = rNow - hi;
        ctxItems.push({ ic: "up", t: "Il est monté de " + plural(dUp, "échelon") + " depuis", s: m.oppRank + " le " + fdate(m.date).replace(/\.$/, "") + " → " + lab(rNow) + " aujourd'hui." + (won ? " Ta victoire vaut plus que ce que dit son classement." : " Ce n'était pas une contre-perf.") });
        if (!won) { weight = { from: m.oppRank, to: lab(rNow) }; head = "Défaite contre un joueur qui jouait déjà " + lab(rNow) + "."; }
        else if (!head) head = "Belle victoire : il jouait déjà " + lab(rNow) + ".";
      }
      if (m.comp) {
        var t0 = E.parseDate(m.date).getTime(), ck = nameKey(m.comp);
        var run = hpA.filter(function (x) { return x.comp && nameKey(x.comp) === ck && Math.abs(E.parseDate(x.date).getTime() - t0) <= 21 * 864e5; });
        var at = -1; run.forEach(function (x, i) { if (at < 0 && x.date === m.date && x.result !== m.result) at = i; });
        if (at >= 0 && run.length >= 2) {
          var after = run.slice(at + 1), wa = after.filter(function (x) { return x.result === "V"; }).length, endL = after.filter(function (x) { return x.result === "D"; })[0];
          var trail = run.map(function (x, i) { return { r: i === at ? "Toi" : x.oppRank, v: x.result === "V", me: i === at }; });
          if (!won && after.length) ctxItems.push({ ic: "star", t: wa ? plural(wa, "victoire") + " après toi dans ce tournoi" : "Battu juste après toi", s: (endL ? "Puis battu par un " + endL.oppRank : "Sans perdre ensuite : il est peut-être allé au bout") + " · d'après ses matchs de cette épreuve sur Ten'Up.", trail: trail });
          else if (won && at > 0) { var wb = run.slice(0, at).filter(function (x) { return x.result === "V"; }).length; if (wb) ctxItems.push({ ic: "star", t: "Il avait gagné " + plural(wb, "match", "matchs") + " avant toi dans ce tournoi", s: "Tu l'as arrêté.", trail: trail }); }
        }
      }
      var hNow = hpA.filter(function (x) { return x.date !== m.date; }), vsMe = hNow.filter(function (x) { return E.idx(T.normRank(x.oppRank)) === me; });
      if (vsMe.length >= 3) { var vm = vsMe.filter(function (x) { return x.result === "V"; }).length; ctxItems.push({ ic: vm / vsMe.length >= 0.5 ? "star" : "check", t: "Contre les " + lab(me) + ", il est " + vm + " V · " + (vsMe.length - vm) + " D", s: vm / vsMe.length >= 0.5 ? "Il sait battre ton classement." : "Ton classement lui résiste en général." }); }
      var bw = hNow.filter(function (x) { return x.result === "V"; }).sort(function (a, b) { return E.idx(T.normRank(b.oppRank)) - E.idx(T.normRank(a.oppRank)); })[0];
      if (bw && items.length + ctxItems.length < 3) ctxItems.push({ ic: "star", t: "Sa meilleure victoire : un " + bw.oppRank, s: (bw.score ? bw.score + " · " : "") + fdate(bw.date).replace(/\.$/, "") + "." });
    }
    var palItems = ctxItems.concat(items); items = [];
    // 2. La lecture du score
    if (sets.length >= 2) {
      var tw = tight.filter(function (x) { return x[0] > x[1]; }), tl = tight.filter(function (x) { return x[0] < x[1]; });
      if (won && comeback) {
        items.push({ ic: "rev", t: "Tu as renversé le match", s: "Premier set perdu, puis " + sets.slice(1).map(function (x) { return x[0] + "-" + x[1]; }).join(" et ") + ". " + (stB.f1l.n ? "C'est ta " + (stB.f1l.v + 1) + "e remontée sur 12 mois, contre " + stB.f1l.v + " sur " + stB.f1l.n + " avant." : "Ta première remontée sur 12 mois."), sets: sets });
        if (!head) head = "Belle remontée : tu ne lâches rien.";
      } else if (won && tw.length) {
        items.push({ ic: "wall", t: "Solide dans les moments chauds", s: (tw.length > 1 ? "Tu as gagné les " + tw.length + " sets serrés" : "Tu as gagné le set serré") + " (" + tw.map(function (x) { return x[0] + "-" + x[1]; }).join(", ") + ")." + (stA.tb.n >= 3 ? " Tie-breaks sur 12 mois : " + stA.tb.v + " gagnés sur " + stA.tb.n + "." : ""), sets: sets });
      } else if (won && g[1] <= 5 && sets.length === 2) {
        var same = before.filter(function (x) { return x.result === "V" && x.oppRank === m.oppRank; }).map(function (x) { return anGames(setsOf(x.score))[1]; });
        items.push({ ic: "check", t: "Victoire nette", s: g[0] + " jeux à " + g[1] + "." + (same.length && g[1] < Math.min.apply(null, same) ? " Ta victoire la plus large contre un " + m.oppRank + " sur 12 mois." : ""), sets: sets });
        if (!head) head = "Victoire nette et sans bavure.";
      } else if (!won && tl.length) {
        items.push({ ic: "eq", t: "Ça s'est joué à quelques points", s: (tl.length > 1 ? "Sets perdus " : "Set perdu ") + tl.map(function (x, i) { return x[0] + "-" + x[1] + (isTb(x) ? " au tie-break" : ""); }).join(", ") + " : " + g[0] + " jeux à " + g[1] + " au total.", sets: sets });
        if (stA.tb.n >= 3 && stA.tb.v / stA.tb.n <= 0.4 && tl.some(function (x, i) { return isTb(x) || isSuperTb(x, i); })) items.push({ ic: "target", t: "Les fins de set, ton chantier", s: "Sur 12 mois, tu gagnes " + stA.tb.v + " tie-break" + (stA.tb.v > 1 ? "s" : "") + " sur " + stA.tb.n + ". Un exercice à caler à l'entraînement : jouer des fins de set à 5-5." });
      } else if (!won && g[0] <= 4 && sets.length === 2) items.push({ ic: "eq", t: "Il a été plus fort ce jour-là", s: g[0] + " jeux à " + g[1] + ". " + (hi != null && hi > me ? "Contre mieux classé, ça arrive : retiens ce qui n'a pas marché, pas le score." : "Note dans ton retour ce qui n'a pas marché : ça servira pour la revanche.") });
    }
    var scoreItems = items; items = [];
    // 3. Revanche / face-à-face
    var prev = before.filter(function (x) { return x.opp && nameKey(x.opp) === nameKey(m.opp) && !isAnon(x.opp); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; })[0];
    if (prev && !isAnon(m.opp)) {
      if (won && prev.result === "D") items.push({ ic: "rev", t: "Revanche prise", s: first + " t'avait battu le " + fdate(prev.date).replace(/\.$/, "") + (prev.score ? " (" + prev.score + ")" : "") + "." });
      else if (!won && prev.result === "V") items.push({ ic: "rev", t: "Il prend sa revanche", s: "Tu l'avais battu le " + fdate(prev.date).replace(/\.$/, "") + ". Vous êtes à égalité : la belle se jouera." });
    }
    // 4. Ta raquette
    if (m.racketId) {
      var rk = racket(m.racketId), wr = before.concat([m]).filter(function (x) { return x.racketId === m.racketId; }).slice(-10), wv = wr.filter(function (x) { return x.result === "V"; }).length;
      if (rk && wr.length >= 5 && (wv / wr.length >= 0.7 || wv / wr.length <= 0.3)) items.push({ ic: "racket", t: "Avec ta " + rk.name + (m.tension ? " cordée à " + m.tension + " kg" : ""), s: wv + " victoire" + (wv > 1 ? "s" : "") + " sur tes " + wr.length + " derniers matchs avec elle." });
    }
    // Titre par défaut
    if (!head) head = won ? (hi != null && hi > me ? "Belle perf : victoire contre mieux classé que toi." : "Victoire maîtrisée.") :
      (hisL != null && hisL - (hi || 0) >= 0.6) || (hi != null && hi > me) ? (tight.length ? "Défaite serrée contre un joueur au-dessus." : "Défaite logique contre un joueur au-dessus.") :
        tight.length ? "Défaite serrée : ça s'est joué à quelques points." : hi != null && hi < me ? "Défaite à digérer : c'était jouable." : "Défaite : le match à retenir pour la revanche.";
    // 5. Pour ton classement
    var imp = [];
    if (!counts(m)) imp.push({ b: "0 pt", t: "Match d'entraînement : il n'est pas homologué, il ne compte pas pour le classement" });
    else if (c.proj.status !== "top" && c.proj.next) {
      try {
        var withM = E.project(allMatches(), c.cur, c.sex, c.opts), without = E.project(allMatches().filter(function (x) { return x.id !== m.id; }), c.cur, c.sex, c.opts);
        var d = (withM.next && without.next) ? withM.next.total - without.next.total : null;
        var mv = won && withM.next ? countedMap(withM.next)[m.id] : null;
        if (d != null && won && d > 0 && mv != null && mv > d) imp.push({ b: "+" + d + " pts", t: "Sur ton bilan : elle vaut " + mv + " pts, mais prend la place d'une victoire à " + (mv - d) + " pts", v: 1 });
        else if (d != null) imp.push(won ? (d > 0 ? { b: "+" + d + " pts", t: "Victoire " + (hi != null && hi > me ? "contre mieux classé" : hi === me ? "contre un joueur de ton échelon" : "comptée dans ton bilan"), v: 1 } : { b: "Hors quota", t: "Elle ne fait pas partie de tes meilleures victoires comptées" }) :
          (d < 0 ? { b: d + " pts", t: weight ? "Pour le classement FFT, c'est une défaite contre un " + m.oppRank + " : la règle ne regarde pas son niveau réel" : "Une défaite de plus réduit le nombre de victoires prises en compte dans ton bilan" } : { b: "0 pt perdu", t: hi != null && hi >= me ? "Une défaite contre un joueur de ton échelon ou au-dessus ne retire rien" : "Elle ne change pas ton bilan" }));
      } catch (e) {}
      var nx = c.proj.next;
      imp.push(c.proj.status === "montee" ? { b: lab(c.proj.projected), t: "Tu montes le " + fdate(c.proj.release).replace(/\.$/, "") + " si rien ne bouge" } : { b: nx.total + " / " + nx.norme, t: "Bilan " + nx.label + " : " + (nx.total >= nx.norme ? (nx.winAtLevel ? "c'est bon" : "il te faut une victoire contre un " + nx.label) : "il te manque " + (nx.norme - nx.total) + " pts") });
    }
    var all = palItems.slice(0, 3).concat(scoreItems.slice(0, 2)).concat(items).concat(palItems.slice(3));
    return { head: head, items: all.slice(0, 6), imp: imp, anon: anon, pal: !!pal, won: won, weight: weight };
  }
  // Après une synchro : on lit le palmarès des adversaires des nouveaux matchs, en silence
  function anAfterSync() {
    var ids = (S.anNew || []).slice(0, 3), chain = Promise.resolve();
    ids.forEach(function (id) { var m = S.matches.filter(function (x) { return x.id === id; })[0]; if (m) chain = chain.then(function () { return anFetch(m, true); }); });
    chain.then(function () { if (route() === "") render(); });
  }
  function anHomeCard() {
    var ids = (S.anNew || []).filter(function (id) { return S.matches.some(function (x) { return x.id === id; }); });
    if (!ids.length) return "";
    return ids.slice(0, 2).map(function (id) {
      var m = S.matches.filter(function (x) { return x.id === id; })[0], a = analyse(m), v = m.result === "V";
      return '<a class="card an-home" href="#/match/' + m.id + '"><span class="eyebrow">Nouveau match · l\'analyse</span><span class="an-hrow"><span class="vd lg ' + m.result + '">' + m.result + '</span><span class="grow"><b>' + esc(isAnon(m.opp) ? "Joueur anonyme" : m.opp) + " · " + esc(m.oppRank || "") + '</b><span class="small">' + esc(fdate(m.date).replace(/\.$/, "")) + (m.score ? " · " + esc(m.score) : "") + "</span></span>" + I.next + '</span><span class="an-hh">' + esc(a.anon ? "Adversaire anonyme : analyse limitée au score et à ton classement." : a.head) + "</span></a>";
    }).join("");
  }
  function analyseHtml(m) {
    if (!m || !m.date || !(m.result === "V" || m.result === "D")) return "";
    var a = analyse(m); if (a.wo) return "";
    var busy = UI.anBusy && UI.anBusy[m.id], err = UI.anErr && UI.anErr[m.id];
    if (!a.anon && !a.pal && NATIVE && !busy && !err && !(UI.anTried || {})[m.id]) { UI.anTried = UI.anTried || {}; UI.anTried[m.id] = true; setTimeout(function () { anFetch(m); }, 50); busy = true; }
    var row = function (x) {
      var vis = "";
      if (x.trail) vis = '<span class="an-trail">' + x.trail.map(function (t) { return '<span class="st' + (t.me ? " me" : "") + '">' + esc(t.r) + '<i class="' + (t.v ? "v" : "d") + '">' + (t.v ? "V" : "D") + "</i></span>"; }).join('<span class="ar">→</span>') + "</span>";
      if (x.streak) { vis = '<span class="an-streak">' + new Array(Math.min(x.streak, 8) + 1).join('<i class="v">V</i>') + '<i class="you">D</i><small>← toi</small></span>'; }
      if (x.sets) vis = '<span class="an-sets">' + x.sets.map(function (st, i) { var w = st[0] > st[1], l = anSetLabel(st, i); return '<span class="' + (w ? "w" : "l") + '">' + st[0] + "-" + st[1] + (l ? "<small>" + l + "</small>" : "") + "</span>"; }).join("") + "</span>";
      return '<div class="an-r"><span class="an-i">' + svg(AN_IC[x.ic] || AN_IC.check, 2) + '</span><span class="an-tx"><b>' + esc(x.t) + "</b><span>" + esc(x.s) + "</span>" + vis + "</span></div>";
    };
    var s = '<div class="card an' + (a.anon ? "" : " insight") + '"><span class="eyebrow"' + (a.anon ? ' style="color:var(--muted)"' : "") + ">L'analyse du match</span>";
    if (a.anon) s += '<div class="an-anon"><span class="an-q">?</span><b>Ton adversaire est anonyme sur Ten\'Up</b><span>Il a choisi de masquer son nom : Montée n\'a pas accès à son palmarès. Pas d\'analyse complète possible (sa forme, son vrai niveau, ses dernières victoires).</span></div>' + (a.items.length ? '<span class="an-k">Ce qu\'on peut dire quand même</span>' : "");
    else s += '<span class="an-h">' + esc(a.head) + "</span>";
    if (!a.anon && !a.pal) s += '<span class="an-note">' + (busy ? '<span class="spin"></span> Lecture de son palmarès sur Ten\'Up…' : err ? esc(err) : NATIVE ? "" : "Son palmarès se lit depuis l'appli Android ou iPhone : ici, l'analyse se limite au score et à ton classement.") + "</span>";
    s += a.items.map(row).join("");
    if (a.weight) s += '<div class="an-weight"><b>↓</b><span><b>Montée pèse peu cette défaite</b> : dans ton vrai niveau et tes stats, elle compte comme une défaite contre un ' + esc(a.weight.to) + ", pas contre un " + esc(a.weight.from) + ".</span></div>";
    if (!a.items.length && !a.anon && a.pal) s += '<span class="an-note">Ses résultats et le score ne montrent rien d\'inhabituel : un match conforme aux classements.</span>';
    if (a.imp.length) s += '<span class="an-k">Pour ton classement</span><div class="an-imp">' + a.imp.map(function (x) { return "<div><b" + (x.v ? ' style="color:var(--gazon)"' : "") + ">" + esc(x.b) + "</b><span>" + esc(x.t) + "</span></div>"; }).join("") + "</div>";
    return s + "</div>";
  }
  // Match officiel Ten'Up : une fiche en lecture seule (les données viennent de Ten'Up), puis les annotations
  function officialCardHtml(m, pts) {
    var kind = (KINDS.filter(function (k) { return k[0] === m.kind; })[0] || ["", "Match"])[1], v = m.result === "V";
    var sets = m.wo ? [] : setsOf(m.score);
    var setsHtml = sets.length ? '<div class="off-sets">' + sets.map(function (x) { var w = x[0] > x[1]; return '<span class="off-set ' + (w ? "w" : "l") + '"><b>' + x[0] + "</b>-" + x[1] + (x[2] != null ? "<sup>" + x[2] + "</sup>" : "") + "</span>"; }).join("") + "</div>" :
      '<span class="off-score">' + esc(m.wo ? "Forfait · non joué" : m.score || "Score non renseigné") + "</span>";
    var ptsTxt = !counts(m) ? "ne compte pas" : v ? (pts != null ? "+" + pts + " pts" : "hors quota") : "pas de points (défaite)";
    var s = '<div class="card off-card">' +
      '<div class="off-top"><span class="off-badge">' + I.check + " Match officiel · Ten'Up</span><span class=\"off-res " + (v ? "v" : "d") + '">' + (v ? "Victoire" : "Défaite") + (m.wo ? " (WO)" : "") + "</span></div>" +
      '<div class="off-opp"><span class="off-name">' + esc(isAnon(m.opp) ? "Joueur anonyme" : m.opp) + '</span><span class="off-rank">' + esc(m.oppRank || "?") + "</span></div>" +
      (m.oppTenup != null && !isAnon(m.opp) ? '<span class="small" style="margin-top:-6px">Anonyme sur Ten\'Up · nom ajouté par toi</span>' : "") +
      setsHtml +
      '<div class="off-kvs">' +
      '<div class="kv"><span>Date</span><b>' + esc(fdate(m.date)) + "</b></div>" +
      '<div class="kv"><span>Compétition</span><b>' + esc(kind) + "</b></div>" +
      (m.comp ? '<div class="kv"><span>Épreuve</span><b class="off-comp">' + esc(m.comp) + "</b></div>" : "") +
      '<div class="kv"><span>Au bilan</span>' + (v && pts != null ? '<b class="off-pts">' + ptsTxt + "</b>" : "<b>" + ptsTxt + "</b>") + "</div>" +
      "</div></div>" +
      '<p class="off-note">' + I.lock + " Données officielles, mises à jour à chaque synchro. Seules tes annotations (conditions, ressenti, retour de match, raquette) sont modifiables.</p>";
    return s;
  }
  V.match = function (id) {
    var isNew = !id || id === "new";
    if (!isNew) tryMark("an");
    if (!UI.draft || UI.draft._for !== (id || "new")) {
      var base = isNew ? { id: uid(), date: E.iso(today()), opp: "", oppRank: "", result: "V", wo: false, score: "", kind: "tournoi", surface: "", indoor: null, racketId: "", string: "", tension: null, tensionCross: null, feel: null, note: "", source: "manual" } :
        JSON.parse(JSON.stringify(S.matches.filter(function (m) { return m.id === id; })[0] || {}));
      if (!base.id) { go("palmares"); return ""; }
      // Match neuf ou pas encore annoté : on présélectionne la raquette principale
      if (isNew || (!base.racketId && !base.wo)) {
        var main = racketFor("match");
        if (main) { base.racketId = main.id; base.string = main.string || ""; base.tension = main.tension || null; base.tensionCross = main.tensionCross != null ? main.tensionCross : null; base._auto = !isNew; }
      }
      if (isNew && UI.mmPrefill) { var mp = UI.mmPrefill; UI.mmPrefill = null; base.opp = mp.opp; base.oppRank = mp.rank; base.result = mp.r; }
      if (isNew && UI.hcPrefillM) { var hm = UI.hcPrefillM; UI.hcPrefillM = null; base.date = hcIso(hm.start); base.minutes = hcMin(hm); base.hid = hm.id; base.hat = hm.start; }
      base._for = id || "new"; UI.draft = base; UI.gearOpen = false; UI.origKey = null; // nouveau brouillon : on reprend la référence « rien de modifié »
      base.sets = setsOf(base.score);
      UI.scoreEdit = null; UI.stb = base.sets[2] ? isSuperTb(base.sets[2], 2) : false;
      UI.stbExt = base.sets[2] && Math.max(base.sets[2][0], base.sets[2][1]) > 10 ? Math.max(base.sets[2][0], base.sets[2][1]) : 11;
      UI.scoreManual = !!(base.score && (!base.sets.length || /ab|abandon|disq/i.test(base.score)));
    }
    var m = UI.draft;
    var rankOpts = '<option value="">Classement…</option><option value="NC"' + (m.oppRank === "NC" ? " selected" : "") + ">NC</option>" +
      E.ECHELONS.slice(0, 22).map(function (e) { return '<option' + (m.oppRank === e ? " selected" : "") + ">" + e + "</option>"; }).join("") + '<option value="N°"' + (/^N°/.test(m.oppRank) ? " selected" : "") + ">Numéroté</option>";
    var c = ctx(), pts = countedMap(c.proj.next)[m.id];
    var s = '<div class="screen">' + topbar(isNew ? "Nouveau match" : "", isNew ? "" : (annotated(m) ? "Fiche du match" : "À annoter"),
      isNew || !isManual(m) ? "" : '<button class="iconbtn" data-a="delMatch" aria-label="Supprimer ce match">' + I.trash + "</button>");
    var official = !isNew && !isManual(m);
    if (official) s += officialCardHtml(m, pts);
    if (!isNew) s += hcMatchLine(m);
    if (!isNew && !official) {
      s += '<div class="card ink" style="flex-direction:row;justify-content:space-between;align-items:center"><span style="display:flex;flex-direction:column;gap:3px"><span style="font-size:13px;color:var(--sub)">' + esc(fdate(m.date)) + " · " + esc((KINDS.filter(function (k) { return k[0] === m.kind; })[0] || ["", "Match"])[1]) + (m.comp ? '</span><span style="font-size:12px;color:var(--sub);line-height:1.3">' + esc(m.comp) : "") + '</span><span style="font-size:20px;font-weight:600">' + esc(m.opp || "Adversaire") + " · " + esc(m.oppRank) + '</span><span style="color:#E6E0D8">' + esc(m.score || "") + "</span></span>" +
        '<span style="display:flex;flex-direction:column;align-items:flex-end;gap:4px"><span style="height:32px;padding:0 12px;border-radius:16px;background:' + (m.result === "V" ? "var(--balle)" : "var(--terre-soft)") + ";color:" + (m.result === "V" ? "var(--on-balle)" : "var(--terre-dark)") + ';font-weight:700;display:flex;align-items:center">' + (m.result === "V" ? "Victoire" : "Défaite") + (m.wo ? " (WO)" : "") + "</span>" +
        (m.result === "V" ? '<span style="color:var(--hl);font-weight:600;font-size:14px">' + (!counts(m) ? "ne compte pas" : pts != null ? "+" + pts + " pts" : "hors quota") + "</span>" : "") + "</span></div>";
    }
    if (!isNew) { s += analyseHtml(S.matches.filter(function (x) { return x.id === m.id; })[0] || m); if ((S.anNew || []).indexOf(m.id) >= 0) { S.anNew = S.anNew.filter(function (x) { return x !== m.id; }); save(); } }
    // Lien vers le face-à-face avec cet adversaire
    if (!isNew && m.opp && !isAnon(m.opp) && nameKey(m.opp).length >= 3) {
      var hk = nameKey(m.opp), hm = S.matches.filter(function (x) { return x.opp && nameKey(x.opp) === hk && !x.wo && (x.result === "V" || x.result === "D"); });
      var hv = hm.filter(function (x) { return x.result === "V"; }).length;
      s += '<a class="row h2h-link" href="#/adversaire/' + encodeURIComponent(hk) + '"><span class="ini">' + esc(initials(m.opp)) + '</span><span class="grow"><span class="t">Face-à-face avec ' + esc(m.opp.split(" ")[0]) + '</span><span class="s">' + (hm.length > 1 ? hv + " – " + (hm.length - hv) + " en " + hm.length + " matchs · " : "") + "Ta fiche, son jeu, ton plan de jeu</span></span>" + I.next + "</a>";
    }
    if (!isNew && isManual(m)) s += '<div class="card" style="flex-direction:row;gap:10px;align-items:flex-start;padding:12px 14px">' + I.edit + '<span style="font-size:14px;line-height:1.45">' + (m.kind === "amical" ? "<b>Match d\'entraînement.</b> Il reste dans tes stats et tes face-à-face, sans compter pour le classement. S\'il finit homologué sur Ten\'Up, la synchro le reconnaîtra et le fera compter." : "<b>Saisi à la main.</b> Quand Ten\'Up l\'aura homologué, la synchro le reconnaîtra : la date, l\'adversaire et le score officiels remplaceront ta saisie, tes annotations restent. Pas de doublon.") + "</span></div>";
    else if (!isNew && m.manualOrigin && m.confirmedAt) s += '<div class="card menthe" style="flex-direction:row;gap:10px;align-items:flex-start;padding:12px 14px">' + I.check + '<span style="font-size:14px;line-height:1.45"><b>Confirmé par Ten\'Up le ' + esc(fdate(m.confirmedAt).replace(/\.$/, "")) + '.</b> Tu l\'avais saisi à la main : les infos officielles ont remplacé ta saisie, tes annotations sont gardées.</span></div>';
    if (official && (isAnon(m.opp) || m.oppTenup != null)) s += '<h2>Tes annotations · l\'adversaire</h2><div class="form"><div class="field"><label for="m-opp">Son nom</label><input id="m-opp" type="text" data-d="opp" value="' + esc(isAnon(m.opp) ? "" : m.opp) + '" placeholder="Masqué sur Ten\'Up : qui était-ce ?" autocomplete="off"><span class="small">Ten\'Up affiche « Anonyme ». Le nom que tu mets ici sert à tes stats et à tes notes pour la revanche.</span></div></div>';
    if (official) s += revHint(m.opp, m.id);
    if (!official) s += '<h2>Le match</h2><div class="form">' +
      '<div class="field"><span class="lbl">Résultat</span><div class="seg"><button data-a="dset" data-k="result" data-v="V" class="' + (m.result === "V" ? "on" : "") + '">Victoire</button><button data-a="dset" data-k="result" data-v="D" class="' + (m.result === "D" ? "on" : "") + '">Défaite</button></div>' +
      '<label class="check"><input type="checkbox" data-d="wo"' + (m.wo ? " checked" : "") + "> Par forfait (WO)</label></div>" +
      '<div class="field"><label for="m-opp">Adversaire</label><input id="m-opp" type="text" data-d="opp" list="opp-list" value="' + esc(m.opp) + '" placeholder="Prénom et nom, ex. : Julien Moreau" autocomplete="off" autocapitalize="words">' + oppDatalist() +
        '<span class="small">Son prénom en entier et son nom : Montée pourra retrouver sa fiche sur Ten\'Up. Un adversaire déjà joué t\'est proposé pendant la saisie.</span>' + revHint(m.opp, m.id) + "</div>" +
      '<div class="field inline"><label for="m-rank">Son classement le jour du match</label><select id="m-rank" data-d="oppRank">' + rankOpts + "</select></div>" +
      '<div class="field inline"><label for="m-date">Date</label><input id="m-date" type="date" data-d="date" value="' + esc(m.date) + '" max="' + E.iso(today()) + '"></div>' +
      (m.wo ? "" : scoreHtml(m)) +
      '<div class="field"><span class="lbl">Type de match</span><div class="chips">' + KIND_ORDER.map(function (k) { return '<button class="chip' + (m.kind === k[0] ? " on" : "") + '" data-a="dset" data-k="kind" data-v="' + k[0] + '">' + (KIND_FORM[k[0]] || k[1]) + "</button>"; }).join("") + "</div>" +
        (m.kind === "amical" ? '<span class="small">Non homologué : il compte dans tes stats et tes face-à-face, pas pour le classement.</span>' : m.kind === "libre" ? '<span class="small">Match libre homologué (feuille de match, saisi sur Ten\'Up) : il compte pour le classement, comme un tournoi.</span>' : "") + "</div>" +
      "</div>";
    s += '<h2>' + (official ? "Tes annotations · les conditions" : "Les conditions") + '</h2><div class="form">' +
      '<div class="field"><span class="lbl">Surface</span><div class="chips">' + SURFACES.map(function (x) { return '<button class="chip' + (m.surface === x ? " on" : "") + '" data-a="dset" data-k="surface" data-v="' + x + '">' + (SURF_LAB[x] || x) + "</button>"; }).join("") + "</div></div>" +
      '<div class="field"><span class="lbl">Où</span><div class="seg"><button data-a="dset" data-k="indoor" data-v="1" class="' + (m.indoor === true ? "on" : "") + '">Intérieur</button><button data-a="dset" data-k="indoor" data-v="0" class="' + (m.indoor === false ? "on" : "") + '">Extérieur</button></div></div>' +
      (m.wo ? "" : durationHtml(m, true)) +
      feelHtml(m, "Comment tu t'es senti ?") +
      '<div class="field"><label for="m-note">Ton retour sur ce match</label><textarea id="m-note" data-d="note" rows="3" placeholder="Ex. : il a tout joué sur mon revers, j\'ai lâché au 3e set">' + esc(m.note || "") + "</textarea>" + '<span class="small">Un retour par match : il ressortira avant votre prochaine rencontre. Ce qui vaut pour toujours (gaucher, sert au T…) va dans ' +
        (m.opp && !isAnon(m.opp) && S.matches.some(function (x) { return x.opp && nameKey(x.opp) === nameKey(m.opp); }) ? '<a href="#/adversaire/' + encodeURIComponent(nameKey(m.opp)) + '">sa fiche</a>' : "sa fiche") + ".</span></div>" +
      oppGameFold(m) + "</div>";
    s += '<h2>' + (official ? "Tes annotations · ta raquette" : "Ta raquette") + '</h2>' + gearHtml(m);
    s += saveBar("saveMatch", m, isNew) + "</div>";
    return s;
  };

  // ---------- Courbes ----------
  V.courbes = function () {
    var c = ctx(), cur = c.cur < 0 ? 0 : c.cur, target = Math.min(cur + 1, E.MAX_CALC);
    var s = '<div class="screen has-tabs"><div class="topbar"><div class="title"><span class="small">12 derniers mois</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">Courbes</span></div></div>';
    if (!S.matches.length) return s + '<div class="card empty">' + (window.MonteeIll ? window.MonteeIll.vide() : "") + '<b>Pas encore de données</b><span class="small">Ajoute des matchs pour voir tes courbes.</span></div></div>' + tabbar("courbes");
    var B = {};
    if (c.proj.status !== "top") {
      var h = E.history(allMatches(), target, c.sex, cur, today(), c.opts.extra);
      B.bilan = '<div class="card chart">' + chead("courbe", "Ton bilan à " + lab(target), h[h.length - 1].total + " pts à la prochaine sortie") + lineChart(h) +
        '<span class="small">Pointillés : la norme pour être ' + lab(target) + " (" + h[0].norme + " pts). Dernier point : projection pour la prochaine sortie.</span></div>";
      UI._hist = { h: h, target: target, cur: cur };
    }
    // contre qui
    var win = c.proj.matches || [], byRank = {};
    win.forEach(function (m) {
      var o = E.idx(m.oppRank); if (o == null || m.wo) return;
      byRank[o] = byRank[o] || { o: o, v: 0, d: 0 };
      if (m.result === "V") byRank[o].v++; else if (m.result === "D") byRank[o].d++;
    });
    if (!byRank[c.cur] && c.cur >= 0) byRank[c.cur] = { o: c.cur, v: 0, d: 0 };
    var rows = Object.keys(byRank).map(function (k) { return byRank[k]; }).sort(function (a, b) { return b.o - a.o; });
    var mx = Math.max.apply(null, rows.map(function (r) { return Math.max(r.v, r.d); }).concat([1]));
    B.forme = formeHtml(win);
    B.niveau = niveauCard(c);
    B.gagner = gagnerCard();
    B.defend = defendHtml(c);
    B.plafond = '<div class="card">' + chead("plafond", "Ton plafond", "Tes victoires et défaites par classement de l'adversaire") +
      '<div class="div-row small"><span style="text-align:right">Défaites</span><span></span><span>Victoires</span></div>' +
      rows.map(function (r) {
        var me = r.o === c.cur;
        return '<button class="div-row' + (me ? " me" : "") + '" data-a="sheet" data-k="plafond" data-v="' + r.o + '" aria-label="Contre les ' + lab(r.o) + " : " + r.v + " victoires, " + r.d + ' défaites, voir les matchs"><div class="l"><span class="n">' + (r.d || "") + '</span><span class="bar d" style="width:' + (r.d / mx * 100) + '%"></span></div><span class="lab">' + lab(r.o) + (me ? '<span class="you">toi</span>' : "") + '</span><div class="r"><span class="bar v" style="width:' + (r.v / mx * 100) + '%"></span><span class="n">' + (r.v || "") + "</span></div></button>";
      }).join("") + '<span class="small">Mieux classés en haut, moins bien classés en bas. Touche un classement pour voir les matchs.</span>' + ceilingMsg(rows, c.cur) + "</div>";
    B.mental = mentalHtml(win);
    B.h2h = h2hHtml();
    B.records = recordsHtml(win, c.cur);
    B.where = whereHtml(win);
    B.raquette = S.rackets.length ? '<div class="gear-sec">' + gearAnalysisHtml() + "</div>" : "";
    B.temps = playTimeHtml();
    B.saisons = saisonsHtml();
    B.forces = strengthsHtml(myStrengths(), "Tes forces", "Ce sur quoi tu peux compter dans les moments clés, sur tes 12 derniers mois.");
    // Sommaire : une pastille par carte affichée, elle suit le défilement
    var CBN = { forces: "Tes forces", saisons: "Saisons", bilan: "Bilan", niveau: "Niveau", forme: "Forme", gagner: "Ce qui te fait gagner", defend: "À défendre", plafond: "Plafond", mental: "Mental", h2h: "Face-à-face", records: "Records", where: "Où tu gagnes", raquette: "Raquette", temps: "Temps de jeu", saisons: "Tes saisons" };
    var prC = prefsOf("courbes"), shown = prC.order.filter(function (k) { return prC.hidden.indexOf(k) < 0 && B[k]; });
    var cbOp = UI.cbOpen || {}, navK = shown.filter(function (k) { return CB_COMPACT.indexOf(k) < 0 || cbOp[k]; }), hasMore = shown.some(function (k) { return CB_COMPACT.indexOf(k) >= 0 && !cbOp[k]; });
    if (hasMore) navK.push("more");
    if (navK.length > 3) s += '<nav class="cb-nav" id="cb-nav" aria-label="Sommaire des courbes">' + navK.map(function (k, i) { return '<button class="' + (i ? "" : "on") + '" data-a="cbJump" data-v="' + k + '">' + (k === "more" ? "Plus de courbes" : esc(CBN[k] || k)) + "</button>"; }).join("") + "</nav>";
    s += layout("courbes", B, true);
    return s + "</div>" + tabbar("courbes");
  };
  // En-tête de carte : titre, sous-titre, petite illustration
  function chead(ill, title, sub) {
    var I2 = window.MonteeIll || {};
    return '<div class="chead"><div class="ct"><b>' + esc(title) + "</b>" + (sub ? '<span class="small">' + esc(sub) + "</span>" : "") + "</div>" +
      "</div>";
  }
  var WHERE_TABS = [["kind", "Compétition"], ["surface", "Surface"], ["lieu", "Intérieur / ext."]];
  function whereTabs() {
    return '<div class="chips" role="group" aria-label="Regrouper par">' + WHERE_TABS.map(function (t) {
      var on = (UI.whereTab || "kind") === t[0];
      return '<button class="chip' + (on ? " on" : "") + '" data-a="whereTab" data-v="' + t[0] + '" aria-pressed="' + on + '">' + t[1] + "</button>";
    }).join("") + "</div>";
  }
  // ---------- Détails (feuille qui monte du bas) ----------
  function playedWin() { var c = ctx(); return (c.proj.matches || []).filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); }); }
  function byDateDesc(a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; }
  function mrowHtml(m, right, note) {
    return '<a class="row dl" href="#/match/' + m.id + '"><span class="vd ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(m.opp || "Adversaire") + ' <span class="muted" style="font-weight:400">· ' + esc(m.oppRank || "") + '</span></span><span class="s">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + (note ? " · " + note : "") + "</span></span>" + (right != null ? '<span class="pts">' + right + "</span>" : "") + "</a>";
  }
  function listHtml(ms, rightFn, noteFn) {
    if (!ms.length) return '<span class="small">Aucun match.</span>';
    return '<div class="list">' + ms.map(function (m) { return mrowHtml(m, rightFn ? rightFn(m) : null, noteFn ? noteFn(m) : ""); }).join("") + "</div>";
  }
  var DET = {
    recap: function () {
      var R = S.syncRecap; if (!R || !R.length) return null;
      var body = R.map(function (x) {
        var d = mDiff(x.before, x.after);
        var changes = ["date", "opp", "oppRank", "score"].filter(function (k) { return d[k]; }).map(function (k) { return { date: "date", opp: "nom", oppRank: "classement", score: "score" }[k]; });
        return '<div class="vf-item"><span class="vf-k">Ta saisie</span>' + mLine(x.before, d) + '<span class="vf-k">Version officielle</span>' + mLine(x.after, d) +
          '<span class="small">' + (changes.length ? "Corrigé : " + changes.join(", ") + "." : "Identique à ta saisie.") + " Tes annotations sont gardées.</span></div>";
      }).join("");
      return { title: plural(R.length, "match saisi à la main reconnu", "matchs saisis à la main reconnus"), sub: "Ten'Up les a homologués : les infos officielles remplacent ta saisie.", body: body + '<button class="btn primary" data-a="sheetClose" style="margin-top:6px">Compris</button>' };
    },
    plafond: function (v) {
      var o = +v, ms = playedWin().filter(function (m) { return E.idx(m.oppRank) === o; }).sort(byDateDesc), w = ms.filter(function (m) { return m.result === "V"; }).length;
      return { title: "Contre les " + lab(o) + " · " + w + " V – " + (ms.length - w) + " D", sub: "Tes matchs des 12 derniers mois contre des joueurs classés " + lab(o) + " le jour du match.", body: listHtml(ms, null, function (m) { return m.comp ? esc(m.comp) : ""; }) };
    },
    bilan: function (v) {
      var H = UI._hist; if (!H) return null;
      var c = ctx(), p = H.h[+v]; if (!p) return null;
      var b = p.projected ? E.bilanAt(E.windowMatches(allMatches(), p.date, today()), H.target, c.sex, H.cur, c.opts.extra) : E.bilanAt(E.windowMatches(allMatches(), p.date, p.date, false), H.target, c.sex, H.cur);
      var body = '<div class="kvs"><div class="kv"><span>Victoires prises en compte</span><b>' + b.counted.length + " sur " + b.n + " possibles</b></div>" +
        (b.bonusSD ? '<div class="kv"><span>Bonus sans défaite significative</span><b>+' + b.bonusSD + "</b></div>" : "") + (b.bonusCh ? '<div class="kv"><span>Bonus championnats</span><b>+' + b.bonusCh + "</b></div>" : "") +
        (b.bonusDbl ? '<div class="kv"><span>Bonus doubles</span><b>+' + b.bonusDbl + "</b></div>" : "") + (b.adjust ? '<div class="kv"><span>Ajustement d\'après Ten\'Up</span><b>' + (b.adjust > 0 ? "+" : "") + b.adjust + "</b></div>" : "") +
        '<div class="kv" style="font-weight:700"><span>Total</span><b>' + b.total + " / " + b.norme + "</b></div></div>";
      body += "<h3>Les victoires qui comptent</h3>" + listHtml(b.counted.map(function (w) { return w.m; }), function (m) { var w = b.counted.filter(function (x) { return x.m === m; })[0]; return "+" + w.pts; });
      if (b.extra && b.extra.length) body += "<h3>Hors quota</h3><span class=\"small\">Elles ne rapportent rien à cette sortie, mais prendront le relais si une victoire comptée sort.</span>" + listHtml(b.extra.map(function (w) { return w.m; }), function () { return "0"; });
      return { title: p.projected ? "Prochaine sortie, en projection" : "Sortie du " + fdate(p.date).replace(/\.$/, ""), sub: "Ton bilan à " + lab(H.target) + " : les 12 mois avant cette date", body: body };
    },
    defend: function (v) {
      var D = UI._defend; if (!D) return null;
      var i = +v, x = D.pts[i]; if (!x) return null;
      var body = '<div class="kvs"><div class="kv"><span>Bilan à ' + esc(D.label) + '</span><b>' + x.total + " / " + x.norme + "</b></div>" + (i ? '<div class="kv"><span>Par rapport au mois d\'avant</span><b>' + (x.total - D.pts[i - 1].total >= 0 ? "+" : "") + (x.total - D.pts[i - 1].total) + " pts</b></div>" : "") + "</div>";
      if (!i) body += '<span class="small">C\'est ton bilan pour la prochaine sortie, avec tes matchs actuels.</span>';
      else {
        var prev = D.pts[i - 1].b.counted.map(function (w) { return w.m.id; }), now = x.b.counted.map(function (w) { return w.m.id; });
        var gone = D.pts[i - 1].b.counted.filter(function (w) { return now.indexOf(w.m.id) < 0; });
        var cameIn = x.b.counted.filter(function (w) { return prev.indexOf(w.m.id) < 0; });
        body += "<h3>Ce qui sort de tes 12 mois</h3>" + (gone.length ? listHtml(gone.map(function (w) { return w.m; }), function (m) { return "−" + gone.filter(function (w) { return w.m === m; })[0].pts; }) : '<span class="small">Aucune victoire comptée ne sort ce mois-ci.</span>');
        if (cameIn.length) body += "<h3>Ce qui prend le relais</h3><span class=\"small\">Des victoires hors quota remontent dans les victoires comptées.</span>" + listHtml(cameIn.map(function (w) { return w.m; }), function (m) { return "+" + cameIn.filter(function (w) { return w.m === m; })[0].pts; });
      }
      body += '<span class="small">Calcul sans aucun nouveau match : chaque victoire gagnée d\'ici là compte en plus.</span>';
      return { title: "Sortie de " + MOIS_L[x.rel.getMonth()] + " " + x.rel.getFullYear(), sub: "Si tu ne rejoues pas d'ici là", body: body };
    },
    mental: function (k) {
      var ms = playedWin().filter(function (m) { return setsOf(m.score).length; }).sort(byDateDesc);
      var first = function (m) { var t = setsOf(m.score)[0]; return t[0] > t[1] ? 1 : t[0] < t[1] ? -1 : 0; };
      var D = {
        f1w: ["1er set gagné", "Les matchs où tu as gagné le premier set. « Conclus » = tu as gagné le match derrière.", ms.filter(function (m) { return first(m) > 0; })],
        f1l: ["1er set perdu", "Les matchs où tu as perdu le premier set. « Renversés » = tu as quand même gagné le match.", ms.filter(function (m) { return first(m) < 0; })],
        three: ["Matchs en 3 sets", "Les matchs allés au troisième set (super tie-break compris).", ms.filter(function (m) { return setsOf(m.score).length === 3; })],
        tb: ["Tie-breaks (7-6)", "Les matchs avec au moins un set à 7-6 ou 6-7.", ms.filter(function (m) { return setsOf(m.score).some(isTb); })],
        stb: ["Super tie-breaks", "Les matchs décidés au super tie-break (10 points) au troisième set.", ms.filter(function (m) { var t = setsOf(m.score); return t.length === 3 && isSuperTb(t[2], 2); })],
        sets: ["Sets", "Tous les sets de tes matchs sur 12 mois, gagnés et perdus.", ms],
        games: ["Jeux", "Tous les jeux joués sur 12 mois (hors super tie-breaks). Plus de 50 % de jeux gagnés, c'est que tu domines tes matchs, même ceux que tu perds.", ms]
      }[k];
      if (!D) return null;
      var note = function (m) {
        var t = setsOf(m.score), w = 0, l = 0, gw = 0, gl = 0;
        t.forEach(function (x, i) { if (x[0] > x[1]) w++; else l++; if (!isSuperTb(x, i)) { gw += x[0]; gl += x[1]; } });
        if (k === "sets") return w + " set" + (w > 1 ? "s" : "") + " gagné" + (w > 1 ? "s" : "") + " sur " + (w + l);
        if (k === "games") return gw + " jeux sur " + (gw + gl);
        if (k === "f1l") return m.result === "V" ? "<b class=\"pos\">renversé</b>" : "";
        if (k === "f1w") return m.result === "V" ? "<b class=\"pos\">conclu</b>" : "<b class=\"neg\">laissé filer</b>";
        if (k === "tb") {
          var tw = t.filter(function (x) { return isTb(x) && x[0] > x[1]; }).length, tn = t.filter(isTb).length;
          return tn > 1 ? "<b>" + tw + " tie-break" + (tw > 1 ? "s" : "") + " gagné" + (tw > 1 ? "s" : "") + " sur " + tn + "</b>" : tw ? "<b class=\"pos\">tie-break gagné</b>" : "<b class=\"neg\">tie-break perdu</b>";
        }
        if (k === "stb") { var sx = t[2]; return sx && sx[0] > sx[1] ? "<b class=\"pos\">gagné</b>" : "<b class=\"neg\">perdu</b>"; }
        return "";
      };
      var sub = D[1];
      if (k === "tb") {
        var all = [].concat.apply([], D[2].map(function (m) { return setsOf(m.score).filter(isTb); })), won = all.filter(function (x) { return x[0] > x[1]; }).length;
        sub += " Un match peut en compter plusieurs : " + won + " gagné" + (won > 1 ? "s" : "") + " sur " + all.length + " tie-breaks, répartis sur " + plural(D[2].length, "match", "matchs") + ".";
      }
      return { title: D[0], sub: sub, body: listHtml(D[2], null, note) + '<span class="small">Scores lus de ton point de vue (ta manche d\'abord). Matchs des 12 derniers mois, forfaits exclus.</span>' };
    },
    record: function (k) {
      var c = ctx(), cur = c.cur, ms = playedWin().sort(byDateDesc), out;
      if (k === "perfs") out = ["Tes perfs", "Les victoires contre des joueurs mieux classés que toi aujourd'hui.", ms.filter(function (m) { var o = E.idx(m.oppRank); return m.result === "V" && o != null && o > cur; })];
      else if (k === "matchs") out = ["Tes matchs sur 12 mois", "Tous les matchs joués, forfaits exclus.", ms];
      else if (k === "bagel") out = ["Tes 6-0", "Les matchs où tu as gagné au moins un set 6-0.", ms.filter(function (m) { return setsOf(m.score).some(function (t) { return t[0] === 6 && t[1] === 0; }); })];
      else if (k === "streak" || k === "run") {
        var asc = ms.slice().reverse(), best = [], run = [];
        if (k === "run") { asc.forEach(function (m) { if (m.result === "V") { run.push(m); if (run.length > best.length) best = run.slice(); } else run = []; }); out = ["Ta meilleure série", "Tes victoires d'affilée les plus longues sur 12 mois.", best.reverse()]; }
        else { var all = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }), st = []; for (var i = 0; i < all.length && all[i].result === all[0].result; i++) st.push(all[i]); out = ["Ta série en cours", "Tes derniers matchs, tant que le résultat ne change pas.", st]; }
      } else if (k === "month") {
        var wm = {}; ms.forEach(function (m) { if (m.result === "V" && m.date) { var kk = m.date.slice(0, 7); wm[kk] = (wm[kk] || 0) + 1; } });
        var bm = Object.keys(wm).sort(function (a, b) { return wm[b] - wm[a] || (a < b ? 1 : -1); })[0];
        out = [bm ? "Meilleur mois : " + MOIS_L[+bm.slice(5) - 1] + " " + bm.slice(0, 4) : "Meilleur mois", "Le mois où tu as gagné le plus de matchs.", bm ? ms.filter(function (m) { return m.date && m.date.slice(0, 7) === bm; }) : []];
      }
      if (!out) return null;
      return { title: out[0], sub: out[1], body: listHtml(out[2]) };
    },
    where: function (label) {
      var tab = UI.whereTab || "kind", ms = playedWin().sort(byDateDesc);
      var key = { kind: function (m) { return (KINDS.filter(function (k) { return k[0] === (m.kind || "tournoi"); })[0] || ["", "Tournoi"])[1]; }, surface: surfKey, lieu: function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; } }[tab];
      var list = ms.filter(function (m) { return key(m) === label; }), v = list.filter(function (m) { return m.result === "V"; }).length;
      var how = tab === "kind" ? "Le type vient du nom de la compétition sur Ten\'Up (tournoi, championnat individuel, par équipes…). Si un match est mal rangé, corrige son type dans sa fiche." :
        "D\'après ce que tu as indiqué en annotant tes matchs.";
      return { title: label + " · " + v + " sur " + list.length, sub: how, body: listHtml(list, null, function (m) { return tab === "kind" && m.comp ? esc(m.comp) : ""; }) };
    },
    temps: function (mk) {
      var y = +mk.slice(0, 4), mo = +mk.slice(5) - 1;
      var ms = S.matches.filter(function (m) { return m.date && !m.wo && m.date.slice(0, 7) === mk; }).sort(byDateDesc);
      var tr = (S.trainings || []).filter(function (t) { return t.date && t.date.slice(0, 7) === mk; }).sort(byDateDesc);
      var tm = ms.reduce(function (a, m) { return a + playMinutes(m); }, 0), tt = tr.reduce(function (a, t) { return a + playMinutes(t); }, 0);
      var body = '<div class="kvs"><div class="kv"><span>Matchs</span><b>' + plural(ms.length, "match", "matchs") + " · ≈ " + fmtHours(tm) + '</b></div><div class="kv"><span>Entraînements</span><b>' + plural(tr.length, "séance") + " · " + fmtHours(tt) + "</b></div></div>";
      if (ms.length) body += "<h3>Matchs</h3>" + listHtml(ms, function (m) { return fmtDur(playMinutes(m)); });
      if (tr.length) body += "<h3>Entraînements</h3><div class=\"list\">" + tr.map(function (t) { return '<a class="row dl" href="#/entrainement/' + t.id + '"><span class="grow"><span class="t">' + esc(t.label || "Entraînement") + '</span><span class="s">' + esc(fdate(t.date)) + (t.racketId && racket(t.racketId) ? " · " + esc(racket(t.racketId).name) : "") + '</span></span><span class="pts">' + fmtDur(playMinutes(t)) + "</span></a>"; }).join("") + "</div>";
      if (!ms.length && !tr.length) body += '<span class="small">Rien de noté ce mois-ci.</span>';
      return { title: MOIS_L[mo].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + y, sub: "Durée des matchs estimée d'après le score, entraînements tels que tu les as notés", body: body };
    }
  };
  function sheetHtml() {
    var d = DET[UI.sheet.k] && DET[UI.sheet.k](UI.sheet.v);
    if (!d) { UI.sheet = null; return ""; }
    return '<div class="sheet-bg" data-a="sheetClose"></div><div class="sheet big" role="dialog" aria-modal="true" aria-label="' + esc(d.title) + '"><div class="sh-grab"></div><div class="sh-head"><b>' + esc(d.title) + '</b><button class="iconbtn sm" data-a="sheetClose" aria-label="Fermer">' + I.cross + "</button></div>" +
      (d.sub ? '<span class="small">' + esc(d.sub) + "</span>" : "") + '<div class="sh-body">' + d.body + "</div></div>";
  }
  // Plafond : jusqu'où tu bats régulièrement
  function ceilingMsg(rows, cur) {
    if (cur < 0) return "";
    var ok = rows.filter(function (r) { return r.v + r.d > 0; });
    if (ok.reduce(function (s, r) { return s + r.v + r.d; }, 0) < 5) return '<span class="small">Encore quelques matchs et Montée te dira contre qui tu gagnes, et contre qui tu perds des points.</span>';
    // On compare chaque classement à ce qu'on attend d'un joueur de ton classement face à lui (pas à 50 %)
    var n = function (r) { return r.v + r.d; }, exp = function (r) { return 1 / (1 + Math.exp(0.75 * (r.o - cur))); }, ex = function (r) { return Math.round(exp(r) * n(r)); };
    var sum = function (rs) { return rs.reduce(function (a, r) { return { v: a.v + r.v, d: a.d + r.d, e: a.e + exp(r) * n(r) }; }, { v: 0, d: 0, e: 0 }); };
    var up = sum(ok.filter(function (r) { return r.o > cur; })), eq = ok.filter(function (r) { return r.o === cur; })[0], low = ok.filter(function (r) { return r.o < cur; });
    var lines = [];
    // 1. Le classement juste sous toi (ou un peu plus bas) où tu perds plus que prévu : c'est ce qui coûte le plus cher
    var weak = low.filter(function (r) { return n(r) >= 3 && r.v < exp(r) * n(r) - 0.9; }).sort(function (a, b) { return (b.o - a.o) || ((exp(b) * n(b) - b.v) - (exp(a) * n(a) - a.v)); })[0];
    if (weak) lines.push({ w: 3, t: "Ton point faible : les <b>" + lab(weak.o) + "</b>" + (cur - weak.o === 1 ? ", juste sous toi" : "") + ". " + weak.v + " sur " + n(weak) + ", alors qu'on attend plutôt " + ex(weak) + " victoires. Chaque défaite contre un moins bien classé réduit les victoires qui comptent." });
    // 2. Les contre-performances nettes (2 échelons ou plus sous toi)
    var cp = low.filter(function (r) { return cur - r.o >= 2 && r.d > 0 && r !== weak; }), cpn = cp.reduce(function (s, r) { return s + r.d; }, 0);
    if (cpn) lines.push({ w: 2, t: (cpn > 1 ? cpn + " défaites" : "1 défaite") + " contre " + cp.map(function (r) { return "un " + lab(r.o); }).join(", ").replace(/, ([^,]*)$/, " et $1") + " : à éviter, elles pèsent lourd dans ton bilan." });
    // 3. Ton classement
    if (eq && n(eq) >= 3) { var re = eq.v - exp(eq) * n(eq); lines.push({ w: 1, t: "Contre les <b>" + lab(cur) + "</b> (ton classement) : " + eq.v + " sur " + n(eq) + ", " + (re >= 1 ? "mieux que la moyenne : tu as le niveau." : re <= -1 ? "un peu en dessous de la moyenne." : "dans la norme.") }); }
    // 4. Au-dessus : c'est là que se joue la montée
    var un = up.v + up.d;
    if (un) lines.push({ w: 1.5, t: "Contre mieux classé : <b>" + up.v + " sur " + un + "</b>" + (up.v ? (up.v >= up.e + 1 ? ", c'est au-dessus de la moyenne : ta montée est à portée." : ". Chaque perf de plus, c'est ta montée qui se rapproche.") : ". Normal à ce niveau, mais c'est là que se jouera ta montée.") });
    // 5. Point fort : là où tu gagnes plus que prévu
    var strong = ok.filter(function (r) { return n(r) >= 3 && r.o !== cur && r.v >= exp(r) * n(r) + 1; }).sort(function (a, b) { return b.o - a.o; })[0];
    if (strong) lines.push({ w: 2, t: "Ton point fort : les <b>" + lab(strong.o) + "</b>, " + strong.v + " sur " + n(strong) + " (on en attend " + ex(strong) + ")." });
    if (!lines.length) lines.push({ w: 0, t: "Tes résultats collent à ce qu'on attend d'un " + lab(cur) + ", classement par classement." });
    lines = lines.sort(function (a, b) { return b.w - a.w; }).slice(0, 3);
    return '<div class="card balle ceil-msg" style="padding:12px 14px;font-size:15px;line-height:1.4;gap:8px">' + lines.map(function (x) { return "<span>" + x.t + "</span>"; }).join("") +
      '<span class="small" style="opacity:.75">Comparé à ce qu\'on attend d\'un ' + lab(cur) + " face à chaque classement (pas à 50 %). Moins de 3 matchs contre un classement : pas de conclusion.</span></div>";
  }
  // Forme du moment : 30 derniers jours (ou 5 derniers matchs) contre la moyenne sur 12 mois
  function formeHtml(win) {
    var played = win.filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    if (played.length < 4) return "";
    var lim = E.iso(new Date(today().getTime() - 30 * 864e5)), recent = played.filter(function (m) { return m.date >= lim; }), lbl = "30 derniers jours";
    if (recent.length < 3) { recent = played.slice(0, 5); lbl = "5 derniers matchs"; }
    var pc = function (ms) { return Math.round(ms.filter(function (m) { return m.result === "V"; }).length * 100 / ms.length); };
    var a = pc(recent), b = pc(played), d = a - b;
    var arrow = d >= 10 ? "↗" : d <= -10 ? "↘" : "→", tone = d >= 10 ? "balle" : d <= -10 ? "terre" : "";
    var lvl = function (ms) { var o = ms.map(function (m) { return E.idx(m.oppRank); }).filter(function (x) { return x != null; }); return o.length ? o.reduce(function (s, x) { return s + x; }, 0) / o.length : null; };
    var lr = lvl(recent), la = lvl(played), lvMsg = "";
    if (lr != null && la != null && Math.abs(lr - la) >= 0.75) lvMsg = lr > la ? " Et tu joues des adversaires mieux classés que d'habitude." : " Mais contre des adversaires moins bien classés que d'habitude.";
    var verdict = d >= 10 ? "Tu es en forme." : d <= -10 ? "Petit creux en ce moment." : "Dans ta moyenne.";
    return '<div class="card ' + tone + '" style="gap:8px">' + chead("forme", "Forme du moment", lbl.replace(/^./, function (x) { return x.toUpperCase(); })) +
      '<div style="display:flex;align-items:baseline;gap:12px"><span style="font-size:40px;font-weight:700;letter-spacing:-.03em;line-height:1">' + a + ' %</span><span style="font-size:28px;font-weight:700">' + arrow + '</span><span class="small">de victoires<br>contre ' + b + " % sur 12 mois</span></div>" +
      '<span style="font-size:15px;line-height:1.4">' + verdict + " " + plural(recent.length, "match") + " : " + recordOf(recent) + "." + lvMsg + "</span></div>";
  }
  // Points à défendre : ton bilan aux prochaines sorties si tu ne rejoues pas
  function defendHtml(c) {
    var p = c.proj; if (p.status === "top" || c.cur < 0) return "";
    var b0 = p.status === "descente" ? p.here : p.next, calc = b0.calc, all = allMatches(), rel = p.release, pts = [];
    for (var k = 0; k < 6; k++) {
      var b = E.bilanAt(E.windowMatches(all, rel, today()), calc, c.sex, c.cur, c.opts.extra);
      pts.push({ rel: rel, total: b.total, norme: b.norme, lost: [], b: b });
      rel = E.nextRelease(rel);
    }
    // victoires comptées qui sortent à chaque sortie
    b0.counted.forEach(function (w) {
      if (!w.m.date) return;
      var leave = E.plus12Months(E.parseDate(w.m.date));
      for (var i = 1; i < pts.length; i++) if (leave <= pts[i].rel && leave > pts[i - 1].rel) { pts[i].lost.push(w); break; }
    });
    var drop = pts[0].total - pts[pts.length - 1].total;
    UI._defend = { pts: pts, label: b0.label };
    if (drop <= 0) return '<div class="card" style="gap:6px">' + chead("defend", "Points à défendre", "") + '<span style="font-size:15px">Aucune victoire comptée ne sort d\'ici 6 mois : ton bilan à ' + esc(b0.label) + " tient.</span></div>";
    var mx = Math.max.apply(null, pts.map(function (x) { return Math.max(x.total, x.norme); })) || 1, W = 320, H = 130, bw = W / pts.length, ny = H - 22 - pts[0].norme / mx * (H - 34);
    var bars = pts.map(function (x, i) {
      var h = x.total / mx * (H - 34), xx = i * bw + 6, under = x.total < x.norme;
      return '<rect x="' + xx.toFixed(1) + '" y="' + (H - 22 - h).toFixed(1) + '" width="' + (bw - 12).toFixed(1) + '" height="' + h.toFixed(1) + '" rx="4" fill="' + (under ? "var(--chart-d)" : "var(--chart-v)") + '"/>' +
        '<text x="' + (xx + (bw - 12) / 2).toFixed(1) + '" y="' + (H - 26 - h).toFixed(1) + '" text-anchor="middle" font-size="10" font-weight="700" fill="var(--ink)">' + x.total + "</text>" +
        '<text x="' + (xx + (bw - 12) / 2).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle" font-size="10" fill="var(--muted)">' + MOIS[x.rel.getMonth()] + "</text>" +
        '<rect class="hit" data-a="sheet" data-k="defend" data-v="' + i + '" x="' + (i * bw).toFixed(1) + '" y="0" width="' + bw.toFixed(1) + '" height="' + H + '" fill="transparent"/>';
    }).join("") + '<line x1="0" x2="' + W + '" y1="' + ny.toFixed(1) + '" y2="' + ny.toFixed(1) + '" stroke="var(--ink)" stroke-dasharray="4 4" stroke-width="1"/>';
    var worst = pts.slice(1).filter(function (x) { return x.lost.length; }).sort(function (a, b) { return b.lost.reduce(function (s, w) { return s + w.pts; }, 0) - a.lost.reduce(function (s, w) { return s + w.pts; }, 0); })[0];
    var msg = worst ? "En " + MOIS_L[worst.rel.getMonth()] + ", " + worst.lost.map(function (w) { return "ta victoire contre " + esc(w.m.opp || "un " + w.m.oppRank) + " (" + esc(w.m.oppRank) + ", +" + w.pts + ")"; }).join(" et ") + " sort" + (worst.lost.length > 1 ? "ent" : "") + " de tes 12 mois." : "";
    return '<div class="card chart" style="gap:8px">' + chead("defend", "Points à défendre", "Ton bilan à " + b0.label + " si tu ne rejoues pas") +
      '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Bilan aux six prochaines sorties">' + bars + "</svg>" +
      '<span style="font-size:15px;line-height:1.4">D\'ici ' + MOIS_L[pts[pts.length - 1].rel.getMonth()] + ", ton bilan perd <b>" + drop + " pts</b> sans nouvelle victoire. " + msg + "</span>" +
      '<span class="small">Pointillés : la norme ' + esc(b0.label) + " (" + pts[0].norme + " pts). Une victoire hors quota peut prendre le relais d'une victoire qui sort. Touche une barre pour le détail du mois.</span></div>";
  }
  // Mental : sets décisifs, premier set, jeux décisifs
  function mentalHtml(win) {
    var played = win.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); });
    var f1w = { v: 0, n: 0 }, f1l = { v: 0, n: 0 }, three = { v: 0, n: 0 }, tb = { v: 0, n: 0 }, stb = { v: 0, n: 0 }, setsW = { v: 0, n: 0 }, games = { v: 0, n: 0 };
    played.forEach(function (m) {
      var sets = setsOf(m.score); if (!sets.length) return;
      var won = m.result === "V";
      sets.forEach(function (st, i) { setsW.n++; if (st[0] > st[1]) setsW.v++; if (!isSuperTb(st, i)) { games.n += st[0] + st[1]; games.v += st[0]; } });
      if (sets[0][0] > sets[0][1]) { f1w.n++; if (won) f1w.v++; } else if (sets[0][0] < sets[0][1]) { f1l.n++; if (won) f1l.v++; }
      if (sets.length === 3) { three.n++; if (won) three.v++; }
      sets.forEach(function (st, i) { if (isSuperTb(st, i)) { stb.n++; if (st[0] > st[1]) stb.v++; } else if (isTb(st)) { tb.n++; if (st[0] > st[1]) tb.v++; } });
    });
    var rows = [["1er set gagné", f1w, "conclus", "f1w"], ["1er set perdu", f1l, "renversés", "f1l"], ["Matchs en 3 sets", three, "gagnés", "three"], ["Tie-breaks", tb, "gagnés", "tb"], ["Super tie-breaks", stb, "gagnés", "stb"], ["Sets", setsW, "sets gagnés", "sets"], ["Jeux", games, "jeux gagnés", "games"]].filter(function (r) { return r[1].n; });
    if (!rows.length) return "";
    var line = function (r) {
      var x = r[1], pc = Math.round(x.v * 100 / x.n);
      return '<button class="mrow" data-a="sheet" data-k="mental" data-v="' + r[3] + '"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + r[0] + ' <span class="chev">›</span></span><span class="small">' + x.v + " sur " + x.n + " " + r[2] + " · <b>" + pc + " %</b></span></div>" +
        '<div class="meter"><span class="track"><span class="fill" style="display:block;width:' + pc + "%;background:" + (pc >= 50 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span></div></button>';
    };
    var close = three.n + tb.n + stb.n, closeV = three.v + tb.v + stb.v, msg = "";
    if (close >= 4) msg = closeV * 2 >= close ? "Dans les moments serrés, tu tiens : " + closeV + " sur " + close + " gagnés (3es sets et jeux décisifs)." : "Les fins serrées t'échappent : " + closeV + " sur " + close + " gagnés (3es sets et jeux décisifs).";
    return '<div class="card" style="gap:14px">' + chead("mental", "Mental", "Sur 12 mois, d'après les scores · touche une ligne pour le détail") + rows.map(line).join("") +
      (msg ? '<div class="card balle" style="padding:12px 14px;font-size:15px;font-weight:600">' + esc(msg) + "</div>" : "") + "</div>";
  }
  // Face-à-face : adversaires rencontrés plusieurs fois
  // ---------- Notes pour la revanche ----------
  // Ce que tu as noté sur un adversaire : la note de sa fiche et celles de vos matchs, la plus récente d'abord.
  function revNotes(name, exceptId) {
    var k = nameKey(name); if (k.length < 3 || isAnon(name)) return [];
    var out = [], on = (S.oppNotes || {})[k];
    if (on && on.text) out.push({ text: on.text, date: on.at, fiche: true });
    S.matches.forEach(function (m) { if (m.id !== exceptId && m.note && m.opp && nameKey(m.opp) === k) out.push({ text: m.note, date: m.date, m: m }); });
    return out.sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; });
  }
  function revHint(name, exceptId, dark) {
    var n = revNotes(name, exceptId); if (!n.length) return "";
    var IL = window.MonteeIll, x = n[0];
    return '<a class="rev-hint' + (dark ? " dark" : "") + '" href="#/adversaire/' + encodeURIComponent(nameKey(name)) + '">' + 
      '<span class="grow"><span class="eyebrow">' + (x.fiche ? "Ta fiche sur lui" : "Ton retour du dernier match") + '</span><span class="rv-t">« ' + esc(x.text) + ' »</span><span class="small">' + (x.m ? (x.m.result === "V" ? "Victoire" : "Défaite") + (x.date ? " le " + esc(fdate(x.date)) : "") + (x.m.score ? " · " + esc(x.m.score) : "") : "Sur sa fiche") + (n.length > 1 ? " · " + plural(n.length - 1, "autre note", "autres notes") : "") + "</span></span></a>";
  }
  V.adversaire = function (key) {
    key = decodeURIComponent(key || "");
    var ms = S.matches.filter(function (m) { return m.opp && !isAnon(m.opp) && nameKey(m.opp) === key; }).sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; });
    if (!ms.length) { go("palmares"); return ""; }
    var name = ms[0].opp, v = ms.filter(function (m) { return m.result === "V" && !m.wo; }).length, d = ms.filter(function (m) { return m.result === "D" && !m.wo; }).length;
    var on = (S.oppNotes || {})[key] || {}, IL = window.MonteeIll;
    var s = '<div class="screen">' + topbar(name, ms[0].oppRank ? "Classé " + ms[0].oppRank + " au dernier match" : "");
    s += '<div class="card opp-head">' +  '<span class="grow"><span class="eyebrow">Face-à-face</span><span class="opp-score" style="color:' + (v > d ? "var(--gazon)" : v < d ? "var(--terre)" : "var(--ink)") + '">' + v + " – " + d + '</span><span class="small">' + plural(ms.length, "match", "matchs") + " contre lui</span></span></div>";
    // Le vrai plus de Montée : sa saison, tes chances, ton plan de jeu. Bien en vue, juste sous le score.
    var first = name.split(" ")[0];
    s += '<button class="card insight plan-cta" data-a="fafKnown" data-v="' + esc(key) + '"><span class="eyebrow">' + (NATIVE ? "Sa saison sur Ten\'Up" : "Face-à-face") + '</span>' +
      '<span class="pc-h">' + esc(d > v ? "Prépare ta revanche contre " + first : v > d ? "Garde l\'avantage sur " + first : "Prépare ton prochain match contre " + first) + "</span>" +
      '<span class="pc-l">' + ["Tes chances de le battre", "Son vrai niveau et sa forme", "Ton plan de jeu contre lui"].map(function (t) { return '<span>' + I.check + esc(t) + "</span>"; }).join("") + "</span>" +
      '<span class="pc-go">Voir sa fiche ' + I.next + "</span></button>";
    s += '<h2>Sa fiche · toujours valable</h2><div class="form"><div class="field"><label for="o-note">Ce qu\'il faut retenir sur lui</label><textarea id="o-note" data-on="' + esc(key) + '" placeholder="Ex. : gaucher, adore la diagonale revers, craque sur les balles hautes">' + esc(on.text || "") + '</textarea><span class="small">Ses habitudes, son style, ce qui marche contre lui. Ce qui s\'est passé lors d\'un match va dans le retour de ce match.</span></div></div>';
    s += oppGameHtml(key, oppGame([key], null));
    s += "<h2>Vos matchs et tes retours</h2><div class=\"list\">" + ms.map(function (m) {
      return '<a class="row" href="#/match/' + m.id + '"><span class="vd lg ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + '</span><span class="s">' + esc(m.oppRank || "") + (m.comp ? " · " + esc(m.comp) : "") + "</span>" + (m.note ? '<span class="s rev">« ' + esc(m.note) + " »</span>" : "") + "</span>" + I.next + "</a>";
    }).join("") + "</div>";
    return s + "</div>";
  };
  function h2hHtml() {
    var g = {};
    S.matches.forEach(function (m) {
      // Les joueurs « Anonyme » de Ten'Up sont des personnes différentes : jamais regroupés
      if (!m.opp || isAnon(m.opp) || m.wo || !(m.result === "V" || m.result === "D")) return;
      var k = nameKey(m.opp); if (k.length < 3) return;
      (g[k] = g[k] || { name: m.opp, ms: [] }).ms.push(m);
    });
    var list = Object.keys(g).map(function (k) { return g[k]; }).filter(function (x) { return x.ms.length >= 2; })
      .sort(function (a, b) { return b.ms.length - a.ms.length; }).slice(0, 6);
    var findBtn = '<a class="btn soft small faf-btn" href="#/faf">' + svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>', 2.2) + " Chercher un joueur</a>";
    if (!list.length) return '<div class="card" style="gap:8px">' + chead("h2h", "Face-à-face", "Avant un match, regarde comment joue ton adversaire") + findBtn + "</div>";
    return '<div class="card" style="gap:4px">' + chead("h2h", "Face-à-face", "Les adversaires que tu as joués plusieurs fois") +
      list.map(function (x) {
        var ms = x.ms.sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; }), v = ms.filter(function (m) { return m.result === "V"; }).length, d = ms.length - v;
        var nt = revNotes(x.name)[0];
        return '<a class="row" href="#/adversaire/' + encodeURIComponent(nameKey(x.name)) + '" style="padding:10px 0;border-bottom:1px solid var(--line)"><span class="grow"><span class="t">' + esc(x.name) + ' <span class="muted" style="font-weight:400">· ' + esc(ms[0].oppRank || "") + '</span></span><span class="s">Dernier : ' + (ms[0].result === "V" ? "victoire" : "défaite") + (ms[0].date ? " le " + esc(fdate(ms[0].date)) : "") + (ms[0].score ? " · " + esc(ms[0].score) : "") + "</span>" + (nt ? '<span class="s rev">« ' + esc(nt.text) + " »</span>" : "") + "</span>" +
          '<span class="pts" style="color:' + (v > d ? "var(--gazon)" : v < d ? "var(--terre)" : "var(--ink)") + '">' + v + " – " + d + "</span></a>";
      }).join("") + findBtn + "</div>";
  }
  // Tes records sur 12 mois
  function recordsHtml(win, cur) {
    var played = win.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); });
    if (!played.length) return "";
    var best = null, perfs = 0, tb = { v: 0, n: 0 }, three = { v: 0, n: 0 }, back = 0, bagels = 0, months = {};
    played.forEach(function (m) {
      var o = E.idx(m.oppRank), sets = setsOf(m.score);
      if (m.date) { var k = m.date.slice(0, 7); months[k] = (months[k] || 0) + 1; }
      if (m.result === "V") {
        if (o != null && (!best || o > E.idx(best.oppRank))) best = m;
        if (o != null && o > cur) perfs++;
        if (sets.length && sets[0][0] < sets[0][1]) back++;
      }
      if (sets.length === 3) { three.n++; if (m.result === "V") three.v++; }
      sets.forEach(function (st, i) {
        if (isTb(st) || isSuperTb(st, i)) { tb.n++; if (st[0] > st[1]) tb.v++; }
        if (st[0] === 6 && st[1] === 0) bagels++;
      });
    });
    var mk = Object.keys(months).sort(function (a, b) { return months[b] - months[a]; })[0];
    var bestRun = 0, run = 0;
    played.slice().sort(function (a, b) { return (a.date || "") < (b.date || "") ? -1 : 1; }).forEach(function (m) { run = m.result === "V" ? run + 1 : 0; if (run > bestRun) bestRun = run; });
    var streak = 0, sm = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); });
    for (var i = 0; i < sm.length && sm[i].result === sm[0].result; i++) streak++;
    var tile = function (k, v, sub, key) { return '<button class="rec" data-a="sheet" data-k="record" data-v="' + key + '"><span class="k">' + k + '</span><span class="v">' + v + '</span><span class="s">' + sub + "</span></button>"; };
    var wm = {}; played.forEach(function (m) { if (m.result === "V" && m.date) { var k = m.date.slice(0, 7); wm[k] = (wm[k] || 0) + 1; } });
    var bm = Object.keys(wm).sort(function (a, b) { return wm[b] - wm[a] || (a < b ? 1 : -1); })[0];
    var s = '<div class="card" style="gap:12px">' + chead("records", "Tes records sur 12 mois", "Touche une case pour voir les matchs") ;
    if (best) s += '<a class="rec-best" href="#/match/' + best.id + '"><span class="eyebrow">Plus belle victoire</span><span class="rk">' + esc(best.oppRank) + '</span><span class="who">' + esc(best.opp || "Adversaire") + (best.score ? "<br>" + esc(best.score) : "") + "</span></a>";
    s += '<div class="rec-grid">' +
      tile("Perfs", perfs, perfs > 1 ? "mieux classés battus" : "mieux classé battu", "perfs") +
      tile("Matchs", played.length, "joués sur 12 mois (WO exclus)", "matchs") +
      tile("Meilleure série", bestRun + " V", "victoires d'affilée sur 12 mois", "run") +
      tile("6-0 donnés", bagels, bagels > 1 ? "sets blancs" : "set blanc", "bagel") +
      tile("Série en cours", sm.length ? streak + " " + (sm[0].result === "V" ? "V" : "D") : "—", sm.length ? (sm[0].result === "V" ? "victoires" : "défaites") + " d'affilée (WO exclus)" : "", "streak") +
      tile("Meilleur mois", bm ? wm[bm] + " V" : "—", bm ? MOIS_L[+bm.slice(5) - 1] + " " + bm.slice(0, 4) : "pas encore de victoire", "month") +
      "</div>" +
      (mk ? '<span class="small">Mois le plus chargé : ' + MOIS_L[+mk.slice(5) - 1] + " " + mk.slice(0, 4) + ", " + plural(months[mk], "match", "matchs") + ". Scores lus de ton point de vue (ta manche d\'abord).</span>" : "") + "</div>";
    return s;
  }
  // Où tu gagnes : par type de match
  function whereHtml(win) {
    var played = win.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); });
    var tab = UI.whereTab || "kind";
    var keyFn = {
      kind: function (m) { return (KINDS.filter(function (k) { return k[0] === (m.kind || "tournoi"); })[0] || ["", "Tournoi"])[1]; },
      surface: surfKey,
      lieu: function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; }
    }[tab];
    var g = groupStats(played, keyFn);
    if (!played.length) return "";
    var ok = g.filter(function (x) { return x.n >= 3; }), msg = "";
    var low = function (x) {
      if (tab === "kind") return x.label === "Tournoi" ? "en tournoi" : x.label === "Par équipes" ? "par équipes" : x.label === "Championnat individuel" ? "en championnat individuel" : x.label === "Match d'entraînement" ? "en match d'entraînement" : "en match libre";
      if (tab === "lieu") return x.label === "Intérieur" ? "en intérieur" : "en extérieur";
      return "sur " + x.label.toLowerCase();
    };
    if (ok.length >= 2) {
      var hi = ok[0], lo = ok[ok.length - 1];
      msg = hi.pct - lo.pct >= 20 ? "Tu gagnes " + hi.v + " sur " + hi.n + " " + low(hi) + ", contre " + lo.v + " sur " + lo.n + " " + low(lo) + "." : "Pas de grosse différence pour l'instant.";
    }
    if (!g.length || (tab !== "kind" && ok.length < 2)) {
      var known = played.filter(function (m) { return keyFn(m); }).length;
      var empty = '<span class="small">' + (tab === "surface" ? "Indique la surface" : "Indique intérieur ou extérieur") + " dans la fiche de tes matchs (" + known + " sur " + played.length + " renseignés). Il en faut au moins 3 dans deux catégories pour comparer.</span>";
      if (!g.length) return '<div class="card" style="gap:14px">' + chead("where", "Où tu gagnes", "Sur 12 mois") + whereTabs() + empty + "</div>";
      msg = ""; g.push({ _note: empty });
    }
    return '<div class="card" style="gap:14px">' + chead("where", "Où tu gagnes", "Sur 12 mois · touche une ligne pour voir les matchs") + whereTabs() +
      g.map(function (x) {
        if (x._note) return x._note;
        return '<button class="mrow" data-a="sheet" data-k="where" data-v="' + esc(x.label) + '"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + esc(x.label) + ' <span class="chev">›</span> <span class="small">' + x.v + " V · " + x.d + " D</span></span><b>" + x.pct + " %</b></div>" +
          '<div class="meter" role="img" aria-label="' + x.pct + ' % de victoires"><span class="track"><span class="fill" style="display:block;width:' + x.pct + "%;background:" + (x.pct >= 50 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span></div></button>';
      }).join("") + (msg ? '<div class="card balle" style="padding:12px 14px;font-size:15px;font-weight:600">' + esc(msg) + "</div>" : "") + "</div>";
  }
  function playTimeHtml() {
    var t = today(), months = [];
    for (var k = 11; k >= 0; k--) { var d = new Date(t.getFullYear(), t.getMonth() - k, 1); months.push({ key: E.iso(d).slice(0, 7), m: d.getMonth(), match: 0, train: 0 }); }
    var by = {}; months.forEach(function (x) { by[x.key] = x; });
    S.matches.forEach(function (m) { if (m.date && !m.wo && by[m.date.slice(0, 7)]) by[m.date.slice(0, 7)].match += playMinutes(m); });
    (S.trainings || []).forEach(function (x) { if (x.date && by[x.date.slice(0, 7)]) by[x.date.slice(0, 7)].train += playMinutes(x); });
    var tot = months.reduce(function (a, x) { return a + x.match + x.train; }, 0), tr = months.reduce(function (a, x) { return a + x.train; }, 0);
    if (!tot) return "";
    var mx = Math.max.apply(null, months.map(function (x) { return x.match + x.train; })) || 1, W = 320, H = 110, bw = W / 12;
    var bars = months.map(function (x, i) {
      var hm = x.match / mx * (H - 18), ht = x.train / mx * (H - 18), xx = i * bw + 4;
      return '<rect x="' + xx.toFixed(1) + '" y="' + (H - 16 - hm).toFixed(1) + '" width="' + (bw - 8).toFixed(1) + '" height="' + hm.toFixed(1) + '" rx="3" fill="var(--ink)"/>' +
        '<rect x="' + xx.toFixed(1) + '" y="' + (H - 16 - hm - ht).toFixed(1) + '" width="' + (bw - 8).toFixed(1) + '" height="' + ht.toFixed(1) + '" rx="3" fill="var(--balle)"/>' +
        '<text x="' + (xx + (bw - 8) / 2).toFixed(1) + '" y="' + (H - 3) + '" text-anchor="middle" font-size="9" fill="var(--muted)">' + MOIS[x.m].charAt(0).toUpperCase() + "</text>" +
        '<rect class="hit" data-a="sheet" data-k="temps" data-v="' + x.key + '" x="' + (i * bw).toFixed(1) + '" y="0" width="' + bw.toFixed(1) + '" height="' + H + '" fill="transparent"/>';
    }).join("");
    return '<div class="card chart">' + chead("temps", "Temps de jeu", "≈ " + fmtHours(tot) + " sur 12 mois") +
      '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Temps de jeu par mois">' + bars + "</svg>" +
      '<span class="small"><span class="dot" style="background:var(--ink)"></span> Matchs ≈ ' + fmtHours(tot - tr) + ' · <span class="dot" style="background:var(--balle)"></span> Entraînements ' + fmtHours(tr) + ". Durée des matchs estimée d'après le score (4 min par jeu, échauffement compris). Touche un mois pour le détail.</span></div>";
  }
  function recordOf(ms) { if (!ms.length) return "—"; var v = ms.filter(function (m) { return m.result === "V"; }).length; return v + " V · " + (ms.length - v) + " D"; }

  function lineChart(h) {
    var W = 320, H = 156, pad = 10, top = 26;
    var vals = h.map(function (x) { return x.total; }).concat([h[0].norme]);
    var mx = Math.max.apply(null, vals) * 1.08 || 1, mn = 0;
    var x = function (i) { return pad + i * (W - 2 * pad) / (h.length - 1); };
    var y = function (v) { return H - 8 - (v - mn) / (mx - mn) * (H - 8 - top); };
    var sel = UI.bilanSel == null || UI.bilanSel >= h.length ? h.length - 1 : UI.bilanSel, sp = h[sel];
    var pts = h.map(function (p, i) { return x(i).toFixed(1) + "," + y(p.total).toFixed(1); });
    var solid = pts.slice(0, h.length - 1).join(" "), dash = pts.slice(h.length - 2).join(" ");
    var ny = y(h[0].norme).toFixed(1);
    var dots = h.map(function (p, i) { return i === sel ? "" : '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(p.total).toFixed(1) + '" r="3.2" style="fill:var(--card);stroke:var(--gazon)" stroke-width="1.8"/>'; }).join("");
    var hits = h.map(function (p, i) { return '<rect class="hit" data-a="bilanSel" data-v="' + i + '" x="' + (x(i) - 13).toFixed(1) + '" y="0" width="26" height="' + H + '" fill="transparent"/>'; }).join("");
    var sx = x(sel), sy = y(sp.total), bx = Math.max(24, Math.min(W - 24, sx));
    var bubble = '<line x1="' + sx.toFixed(1) + '" x2="' + sx.toFixed(1) + '" y1="' + (sy + 6).toFixed(1) + '" y2="' + (H - 8) + '" style="stroke:var(--ink)" stroke-width="1" stroke-dasharray="2 3" opacity=".5"/>' +
      '<rect x="' + (bx - 22).toFixed(1) + '" y="' + (sy - 30).toFixed(1) + '" width="44" height="20" rx="10" style="fill:var(--panel)"/><text x="' + bx.toFixed(1) + '" y="' + (sy - 16).toFixed(1) + '" text-anchor="middle" font-size="11" font-weight="700" style="fill:var(--hl)">' + sp.total + "</text>" +
      '<circle cx="' + sx.toFixed(1) + '" cy="' + sy.toFixed(1) + '" r="6.5" style="fill:var(--balle);stroke:var(--ink)" stroke-width="2.2"/>';
    var lbl = h.map(function (p, i) { return '<span class="' + (i === sel ? "on" : "") + '">' + (i % 2 === 0 || i === h.length - 1 || i === sel ? (p.projected ? "→" : MOIS[p.date.getMonth()].replace(".", "")) : "") + "</span>"; }).join("");
    var when = sp.projected ? "Prochaine sortie (" + fdate(sp.date).replace(/\.$/, "") + ", projection)" : "Sortie du " + fdate(sp.date).replace(/\.$/, "");
    return '<svg viewBox="0 0 ' + W + " " + H + '" class="tapchart" role="img" aria-label="Bilan de ' + h[0].total + " à " + h[h.length - 1].total + " points sur 12 mois, norme " + h[0].norme + '">' +
      '<line x1="0" x2="' + W + '" y1="' + (H - 8) + '" y2="' + (H - 8) + '" style="stroke:var(--line)"/>' +
      '<line x1="0" x2="' + W + '" y1="' + ny + '" y2="' + ny + '" style="stroke:var(--ink)" stroke-width="1.2" stroke-dasharray="4 4"/>' +
      '<polyline points="' + solid + '" fill="none" style="stroke:var(--gazon)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<polyline points="' + dash + '" fill="none" style="stroke:var(--gazon)" stroke-width="2.5" stroke-dasharray="3 4" stroke-linecap="round"/>' +
      dots + bubble + hits + "</svg>" + '<div class="axis">' + lbl + "</div>" +
      '<button class="sel-panel" data-a="sheet" data-k="bilan" data-v="' + sel + '"><span class="grow"><b>' + esc(when) + "</b><span class=\"small\">" + sp.total + " / " + sp.norme + " pts" + (sp.total >= sp.norme ? " · norme atteinte" : " · il manque " + (sp.norme - sp.total) + " pts") + '</span></span><span class="sel-go">Détail ' + I.next + "</span></button>" +
      '<span class="small tap-hint">Touche un point de la courbe pour voir une autre sortie.</span>';
  }

  // ---------- Matériel ----------
  function groupStats(ms, keyFn) {
    var g = {};
    ms.forEach(function (m) { var k = keyFn(m); if (!k) return; g[k] = g[k] || { label: k, v: 0, d: 0 }; if (m.result === "V") g[k].v++; else g[k].d++; });
    return Object.keys(g).map(function (k) { var x = g[k]; x.n = x.v + x.d; x.pct = Math.round(x.v * 100 / x.n); return x; })
      .sort(function (a, b) { return b.pct - a.pct || b.n - a.n; });
  }
  var USURE = ["moins de 5 h", "5 à 12 h", "12 à 20 h", "plus de 20 h"];
  function usureBucket(m) { var a = stringAge(m); if (a == null) return null; a = a / 60; return a < 5 ? USURE[0] : a < 12 ? USURE[1] : a < 20 ? USURE[2] : USURE[3]; }
  function gearAnalysisHtml() {
    var ms = S.matches.filter(function (m) { return annotated(m) && !m.wo && (m.result === "V" || m.result === "D"); });
    var tab = UI.matTab; if (["setup", "usure", "feel"].indexOf(tab) < 0) tab = UI.matTab = "setup";
    var s = '<div class="sec-head">' + chead("raquette", "Avec quoi tu gagnes", "D'après tes " + plural(ms.length, "match annoté", "matchs annotés")) + "</div>";
    s += '<div class="tabs" role="group" aria-label="Regrouper par">' + [["setup", "Raquette + cordage"], ["usure", "Usure"], ["feel", "Ressenti"]].map(function (t) {
      return '<button data-a="matTab" data-v="' + t[0] + '" class="' + (tab === t[0] ? "on" : "") + '" aria-pressed="' + (tab === t[0]) + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    var keyFn = {
      setup: setupLabel, usure: usureBucket,
      surface: surfKey,
      lieu: function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; },
      feel: function (m) { return m.feel ? (m.feel >= 4 ? "Bonnes sensations (4-5)" : m.feel === 3 ? "Moyen (3)" : "Pas dans le match (1-2)") : null; }
    }[tab];
    var src = tab === "surface" || tab === "lieu" || tab === "feel" ? S.matches.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); }) : ms;
    var g = groupStats(src, keyFn);
    var ok = g.filter(function (x) { return x.n >= 3; });
    if (tab === "usure") {
      g.sort(function (a, b) { return USURE.indexOf(a.label) - USURE.indexOf(b.label); });
      var unknown = ms.filter(function (m) { return m.racketId && stringAge(m) == null; }).length;
      var fresh = g.filter(function (x) { return x.label === USURE[0]; })[0];
      var older = g.filter(function (x) { return x.label !== USURE[0] && x.n >= 3; });
      var oldV = older.reduce(function (a, x) { return a + x.v; }, 0), oldN = older.reduce(function (a, x) { return a + x.n; }, 0);
      var oldPct = oldN ? Math.round(oldV * 100 / oldN) : null;
      if (fresh && fresh.n >= 3 && oldN >= 3) {
        var title, sub;
        if (fresh.pct - oldPct >= 15) { title = "Tu gagnes plus avec un cordage frais."; sub = fresh.pct + " % de victoires quand ton cordage a moins de 5 h de jeu, " + oldPct + " % au-delà. Recorde avant tes tournois importants."; }
        else if (oldPct - fresh.pct >= 15) { title = "Pas d'effet d'usure visible."; sub = "Tu gagnes même plus avec un cordage rodé (" + oldPct + " %) que tout neuf (" + fresh.pct + " %)."; }
        else { title = "Pas d'écart net entre cordage neuf et rodé."; sub = fresh.pct + " % sous 5 h de jeu, " + oldPct + " % au-delà."; }
        s += '<div class="card balle"><span class="eyebrow">Ce qu\'on remarque</span><span style="font-size:21px;line-height:1.2;font-weight:600;letter-spacing:-.02em">' + esc(title) + '</span><span style="font-size:14px">' + esc(sub) + "</span></div>";
      } else {
        s += '<div class="card"><b>Pas encore assez d\'infos sur tes cordages</b><span class="small">Il faut au moins 3 matchs joués avec un cordage de moins de 5 h, et 3 avec un cordage plus usé, pour comparer.</span></div>';
      }
      s += '<div class="card" style="gap:6px"><b style="font-size:15px">Comment c\'est compté</b><span style="font-size:14px;line-height:1.45">Pour chaque match, Montée regarde combien d\'heures de jeu ton cordage avait déjà : matchs (estimés d\'après le score, 4 min par jeu + échauffement) et entraînements que tu as notés. Un nouveau cordage commence quand tu coches <b>Cordage neuf</b> sur un match ou un entraînement, quand tu indiques une <b>date de cordage</b> sur la raquette, ou quand le cordage ou la tension du match changent.' +
        (unknown ? " <b>" + plural(unknown, "match est ignoré", "matchs sont ignorés") + "</b> : on ne sait pas quand leur cordage a été posé." : "") + "</span></div>";
    } else if (ok.length >= 2) {
      var best = ok[0], worst = ok[ok.length - 1];
      var ins = {
        setup: "Avec " + best.label + ", tu gagnes " + best.v + " matchs sur " + best.n + ".",

        surface: "Ton terrain, c'est " + best.label.toLowerCase() + " : " + best.v + " sur " + best.n + ".",
        lieu: "En " + best.label.toLowerCase() + ", tu gagnes " + best.v + " sur " + best.n + ".",
        feel: "Quand tu as de " + (best.label.indexOf("Bonnes") === 0 ? "bonnes sensations" : "moins bonnes sensations") + ", tu gagnes " + best.pct + " %."
      }[tab];
      var adv = best.pct - worst.pct >= 15 ? "Contre " + worst.pct + " % pour " + worst.label + "." : "Pas d'écart net pour l'instant : continue d'annoter.";
      s += '<div class="card balle"><span class="eyebrow">Ce qu\'on remarque</span><span style="font-size:21px;line-height:1.2;font-weight:600;letter-spacing:-.02em">' + esc(ins) + '</span><span style="font-size:14px">' + esc(adv) + "</span></div>";
    } else {
      s += '<div class="card"><b>Pas encore assez de matchs</b><span class="small">Il faut au moins 3 matchs dans deux groupes pour comparer. ' + (S.matches.some(function (m) { return !annotated(m); }) ? "Annote tes matchs depuis le palmarès." : "") + "</span></div>";
    }
    if (tab === "feel") {
      var gf = {}, all = S.matches.filter(function (m) { return !m.wo && m.feel; }).concat((S.trainings || []).filter(function (t) { return t.feel; }));
      all.forEach(function (x) { var k = x.racketId ? setupLabel(x) : null; if (!k) return; gf[k] = gf[k] || { k: k, sum: 0, n: 0, nt: 0 }; gf[k].sum += x.feel; gf[k].n++; if (x.opp == null) gf[k].nt++; });
      var lf = Object.keys(gf).map(function (k) { return gf[k]; }).sort(function (a, b) { return b.sum / b.n - a.sum / a.n; });
      if (lf.length) s += '<div class="card" style="gap:12px"><b style="font-size:15px">Ton ressenti par matériel</b>' + lf.map(function (x) {
        var avg = x.sum / x.n;
        return '<div style="display:flex;flex-direction:column;gap:6px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + esc(x.k) + '</span><span class="small" style="white-space:nowrap">' + plural(x.n, "séance") + (x.nt ? " dont " + x.nt + " entraîn." : "") + "</span></div>" +
          '<div class="meter" role="img" aria-label="' + avg.toFixed(1) + ' sur 5"><span class="track"><span class="fill" style="display:block;width:' + (avg * 20) + "%;background:" + (avg >= 3.5 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span><b>' + avg.toFixed(1).replace(".", ",") + "/5</b></div></div>";
      }).join("") + '<span class="small">Moyenne de tes notes, matchs et entraînements compris.</span></div>';
    }
    if (g.length) {
      s += '<div class="card" style="gap:16px">' + g.map(function (x) {
        return '<div style="display:flex;flex-direction:column;gap:6px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + esc(tab === "usure" ? "Cordage de " + x.label : x.label) + '</span><span class="small" style="white-space:nowrap">' + x.v + " V · " + x.d + " D</span></div>" +
          '<div class="meter" role="img" aria-label="' + x.pct + ' % de victoires"><span class="track"><span class="fill" style="display:block;width:' + x.pct + "%;background:" + (x.pct >= 50 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span><b>' + x.pct + " %</b></div></div>";
      }).join("") + "</div>";
    }
    s += '<p class="small">Sur ' + plural(src.length, "match", "matchs") + ", c'est une tendance, pas une certitude. Plus tu annotes, plus c'est fiable.</p>";
    return s;
  }
  V.materiel = function () {
    var s = '<div class="screen">' + topbar("Ton matériel", "Raquettes, cordages, entraînements");
    s += bagHtml();
    s += "<h2>Ta semaine type</h2><div class=\"list\">" + (S.slots || []).slice().sort(function (a, b) { return a.dow - b.dow || (a.time < b.time ? -1 : 1); }).map(function (sl) {
      return '<a class="row" href="#/creneau/' + sl.id + '"><span class="ic badge ok">' + I.clock + '</span><span class="grow"><span class="t">' + DAYS_L[sl.dow].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + esc(sl.time) + '</span><span class="s">' + esc(sl.label) + " · " + fmtDur(sl.minutes) + "</span></span>" + I.next + "</a>";
    }).join("") + '<button class="row" data-a="newSlot"><span class="badge wait">' + I.plus + '</span><span class="grow"><span class="t">Ajouter un créneau fixe</span><span class="s">Ton entraînement du mardi, ton match du dimanche…</span></span></button></div>';
    var tr = (S.trainings || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    s += "<h2>Entraînements</h2><div class=\"list\">" + tr.slice(0, 8).map(function (t) {
      return '<a class="row" href="#/entrainement/' + t.id + '"><span class="ic badge ok">' + I.clock + '</span><span class="grow"><span class="t">' + esc(fdate(t.date)) + " · " + fmtDur(playMinutes(t)) + '</span><span class="s">' + esc([t.label, t.racketId ? setupLabel(t) : "Matériel non indiqué", t.feel ? "ressenti " + t.feel + "/5" : "", t.note].filter(Boolean).join(" · ")) + "</span></span>" + I.next + "</a>";
    }).join("") + '<button class="row" data-a="newTraining"><span class="badge wait">' + I.plus + '</span><span class="grow"><span class="t">Ajouter un entraînement</span><span class="s">Ça compte dans les heures de jeu de ton cordage</span></span></button></div>';
    return s + "</div>";
  };

  // Ton sac : chaque raquette en carte, avec ses heures de jeu sur le cordage
  function wearRef(st) { return st.type === "mono" ? MONO_MAX : st.breakAvg ? st.breakAvg.avg : 30 * 60; }
  function bagHtml() {
    var list = bag(), IL = window.MonteeIll, gone = S.rackets.length - list.length;
    var s = '<div class="card bag"><div class="bag-h"><span class="eyebrow">Ton sac · ' + plural(list.length, "raquette") + "</span>" +
      '<span class="bag-t">' + (!list.length ? "Ton sac est vide." : list.some(function (r) { var l = racketStatus(r).level; return l === "change" || l === "broken"; }) ? "Un cordage à refaire." : "Ton sac est prêt.") + "</span>" +
      '<span class="small">Montée compte les heures de jeu de chaque cordage et te dit quand recorder.</span></div><div class="bag-grid">';
    s += list.map(function (r) {
      var st = racketStatus(r), ref = wearRef(st), pct = st.known ? Math.min(100, Math.round(st.min * 100 / ref)) : 0;
      var warn = st.level === "change" || st.level === "broken" || st.level === "soon";
      var lbl = st.level === "broken" ? "Cordage cassé" : !st.known ? "Date de cordage ?" : (st.min ? fmtHours(st.min) : "0 h") + " de jeu";
      return '<a class="rkt' + (r.main ? " main" : "") + '" href="#/raquette/' + r.id + '"><span class="rkt-ill">' + (IL ? IL.racket(r.color || "noir", r.accent, r.pattern) : "") + '</span><span class="rkt-b">' +
        '<b>' + esc(r.name || "Raquette") + (r.main ? ' <span class="rkt-tag">principale</span>' : "") + "</b>" + '<span class="rk-s">' + esc([r.model, r.string, fmtTension(r)].filter(Boolean).join(" · ") || "Cordage à renseigner") + "</span>" +
        '<span class="rk-bar"><span style="width:' + pct + "%;background:" + (warn ? "var(--terre)" : "var(--chart-v)") + '"></span></span>' +
        '<span class="rk-h' + (warn ? " neg" : "") + '">' + esc(lbl) + (st.level === "change" ? " · à recorder" : st.level === "soon" ? " · bientôt" : "") + "</span></span>" + I.next + "</a>";
    }).join("") + '<a class="rkt add" href="#/raquette/new"><span class="rk-plus">' + I.plus + "</span><b>Ajouter une raquette</b></a></div>" +
      (gone ? '<button class="linkbtn" data-a="showArchived" style="color:var(--sub)">' + (UI.showArchived ? "Masquer" : "Voir") + " " + plural(gone, "raquette rangée", "raquettes rangées") + "</button>" : "") +
      (UI.showArchived ? S.rackets.filter(function (r) { return r.archived; }).map(function (r) { return '<a class="row" href="#/raquette/' + r.id + '" style="color:var(--on-panel)"><span class="grow"><span class="t">' + esc(r.name) + '</span><span class="s" style="color:var(--sub)">Rangée · son historique est gardé</span></span>' + I.next + "</a>"; }).join("") : "") +
      "</div>";
    return s;
  }
  V.raquette = function (id) {
    var isNew = !id || id === "new";
    if (!UI.racketDraft || UI.racketDraft._for !== (id || "new")) {
      var r = isNew ? { id: uid(), name: "", string: "", tension: 24, tensionCross: null, restrings: [], main: !S.rackets.length } : JSON.parse(JSON.stringify(racket(id) || {}));
      if (!r.id) { go("materiel"); return ""; }
      if (r.tensionCross === undefined) r.tensionCross = null;
      r._for = id || "new"; UI.racketDraft = r; UI.origKey = null;
    }
    var r2 = UI.racketDraft;
    var rs = (r2.restrings || []).map(function (d, i) { return { d: d, i: i }; }).sort(function (a, b) { return a.d < b.d ? 1 : -1; });
    var st = isNew ? { min: 0, nm: 0, nt: 0, known: false, level: "unknown" } : racketStatus(Object.assign({}, racket(r2.id) || r2, { stringType: r2.stringType, string: r2.string }));
    var ty = r2.stringType || guessType(r2.string);
    var s = '<div class="screen has-save">' + topbar(isNew ? "Nouvelle raquette" : r2.name, "", isNew ? "" : '<button class="iconbtn" data-a="rkMenu" aria-label="Plus d\'actions" aria-expanded="' + !!UI.rkMenu + '">' + I.more + "</button>" + (UI.rkMenu ? '<div class="popmenu"><button data-a="archiveRacket">' + I.save + " " + (r2.archived ? "Remettre dans ton sac" : "Ranger cette raquette") + '</button><button class="danger" data-a="delRacket">' + I.trash + " Supprimer</button></div>" : "") + "</button>");
    var IL = window.MonteeIll;
    if (IL) s += '<div class="rk-hero"><span class="rk-ill">' + IL.racket(r2.color || "noir", r2.accent, r2.pattern) + "</span>" + (r2.model ? '<span class="rk-model">' + esc(r2.model) + "</span>" : "") + "</div>";
    s += '<div class="form">' +
      '<div class="field"><label for="r-name">Son nom dans ton sac</label><input id="r-name" type="text" data-r="name" value="' + esc(r2.name) + '" placeholder="Ex. : N°1, Pure Drive, la 24 kg"></div>' +
      '<div class="field"><label for="r-model">Modèle <span class="small">(facultatif)</span></label><input id="r-model" type="text" data-r="model" value="' + esc(r2.model || "") + '" placeholder="Ex. : Pure Aero 2023, Blade 98"></div>' +
      (IL ? '<div class="field"><span class="lbl">Couleur du cadre</span><div class="swatches">' + Object.keys(IL.RCOL).map(function (k) { var on = (r2.color || "noir") === k; return '<button class="sw' + (on ? " on" : "") + '" data-a="rset" data-k="color" data-v="' + k + '" aria-label="' + k + '" aria-pressed="' + on + '" style="background:' + IL.RCOL[k][0] + '"></button>'; }).join("") + "</div></div>" +
        '<div class="field"><span class="lbl">Deuxième couleur</span><div class="swatches"><button class="sw none' + (!r2.accent ? " on" : "") + '" data-a="rset" data-k="accent" data-v="" aria-label="Aucune">' + I.cross + "</button>" + Object.keys(IL.RCOL).map(function (k) { var on = r2.accent === k; return '<button class="sw' + (on ? " on" : "") + '" data-a="rset" data-k="accent" data-v="' + k + '" aria-label="' + k + '" aria-pressed="' + on + '" style="background:' + IL.RCOL[k][0] + '"></button>'; }).join("") + "</div></div>" +
        (r2.accent ? '<div class="field"><span class="lbl">Motif du cadre</span><div class="chips">' + IL.PATTERNS.map(function (pt) { var on = (r2.pattern || "uni") === pt[0]; return '<button class="chip' + (on ? " on" : "") + '" data-a="rset" data-k="pattern" data-v="' + pt[0] + '" aria-pressed="' + on + '">' + pt[1] + "</button>"; }).join("") + "</div></div>" : "") : "") +
      '<div class="field"><label for="r-str">Cordage</label><input id="r-str" type="text" data-r="string" value="' + esc(r2.string) + '" placeholder="Ex. : RPM Blast 1,25"></div>' +
      '<div class="field"><span class="lbl">Type de cordage' + (!r2.stringType && ty ? ' <span class="small">· deviné d\'après le nom</span>' : "") + '</span><div class="chips">' + STYPES.map(function (x) { return '<button class="chip' + (ty === x[0] ? " on" : "") + '" data-a="rtype" data-v="' + x[0] + '">' + x[1] + "</button>"; }).join("") + "</div></div>" +
      tensionHtml(r2, "racket") +
      '<label class="field inline check" style="margin:0"><span>Raquette principale</span><input type="checkbox" data-r="main"' + (r2.main ? " checked" : "") + "></label>" +
      "</div>";
    s += "<h2>Cordages</h2><div class=\"card\" style=\"gap:8px\">" +
      (st.known ? '<span style="font-size:22px;font-weight:700;letter-spacing:-.02em">' + (st.min ? "≈ " + fmtHours(st.min) + " de jeu" : "Cordage neuf") + "</span>" +
        (ty === "mono" ? '<div class="meter" role="img" aria-label="' + fmtHours(st.min) + ' sur 20 h"><span class="track"><span class="fill" style="display:block;width:' + Math.min(100, st.min / MONO_MAX * 100) + "%;background:" + (st.level === "ok" ? "var(--chart-v)" : "var(--terre)") + '"></span></span><b>20 h</b></div>' : "") +
        '<span class="small">' + esc([st.nm ? plural(st.nm, "match") : "", st.nt ? plural(st.nt, "entraînement") : ""].filter(Boolean).join(" et ")) + (st.nm || st.nt ? " · " : "") + "depuis " + (st.since ? "le " + fdate(st.since).replace(/\.$/, "") : "le dernier changement") + ".</span>" +
        (st.level === "change" ? '<span class="neg">Plus de 20 h sur un monofilament : il est temps de le changer.</span>' : st.level === "soon" ? '<span class="neg">Bientôt 20 h : prévois de le changer.</span>' : "")
      : '<span style="font-size:20px;font-weight:700">Date de cordage inconnue</span>' +
        '<span class="small">Ajoute la date du dernier cordage ci-dessous (ou coche « Cordage neuf » sur le premier match ou entraînement après). Sans ça, Montée ne sait pas si ton cordage est frais.</span>') +
      rs.map(function (x) {
        return '<div class="kv" style="align-items:center"><label for="rs-' + x.i + '">Cordée le</label><span style="display:flex;gap:6px;align-items:center"><input id="rs-' + x.i + '" type="date" data-rs="' + x.i + '" value="' + esc(x.d) + '" max="' + E.iso(today()) + '" style="border:none;background:var(--bg);border-radius:10px;min-height:40px;padding:4px 8px;font-size:15px"><button class="iconbtn" data-a="delRestring" data-v="' + x.i + '" aria-label="Retirer ce cordage" style="width:40px;height:40px;background:var(--chip)">' + I.cross + "</button></span></div>";
      }).join("") +
      '<div class="btn-pair"><button class="btn balle small" data-a="restring">Recordée aujourd\'hui</button><button class="btn soft small" data-a="addRestring" style="background:var(--chip)">Autre date</button></div>' +
      (isNew ? "" : st.level === "broken" ? '<span class="neg">Cordage cassé le ' + fdate(brokenNow(racket(r2.id) || r2).date).replace(/\.$/, "") + " : touche « Recordée aujourd\'hui » quand c\'est fait.</span>" : '<button class="btn danger small" data-a="breakString">J\'ai cassé mon cordage</button>') +
      ((r2.breaks || []).length ? '<span class="small">' + plural(r2.breaks.length, "casse notée", "casses notées") + (st.breakAvg ? " · en moyenne vers " + fmtHours(st.breakAvg.avg) + " de jeu (toutes raquettes). Montée te prévient quand tu t\'en approches." : "") + "</span>" : "") +
      "</div>";
    if (!isNew) s += adviceHtml(r2, st, ty);
    s += saveBar("saveRacket", r2, isNew) + "</div>";
    return s;
  };

  // Conseils cordage et raquette : repères courants des cordeurs, adaptés à ta raquette
  function adviceHtml(r, st, ty) {
    var tips = [];
    var regle = ["Un repère simple", "Recorde au moins autant de fois par an que tu joues de fois par semaine : 2 séances par semaine, 2 cordages par an minimum. N'attends pas la casse."];
    if (ty === "mono") {
      tips.push(["Recorde vers 15 à 20 h de jeu", "Un monofilament (polyester) perd vite sa tension, puis devient raide et « mort » bien avant de casser. Au-delà de 20 h, il ne te rend plus ce qu'il te donnait neuf."]);
      tips.push(["Ménage ton bras", "Le polyester est le cordage le plus raide. Au moindre mal au coude ou à l'épaule, passe en hybride (mono en montants, multi en travers) ou en multifilament."]);
      tips.push(["Tension : un peu plus bas", "Si tu viens d'un multifilament, baisse de 1 à 2 kg pour compenser la raideur, puis ajuste à l'essai."]);
      if (st.since && (today() - E.parseDate(st.since)) / 864e5 > 70) tips.unshift(["Plus de 10 semaines", "Même sans jouer beaucoup, un polyester posé il y a plus de 10 semaines a perdu de sa tension. Pense à le changer."]);
    } else if (ty === "multi") {
      tips.push(["Confort et puissance", "Un multifilament est souple et doux pour le bras. Pas besoin de surveiller les heures comme un polyester : change-le quand il s'effiloche ou que tu perds en contrôle."]);
      tips.push(regle);
    } else if (ty === "hybride") {
      tips.push(["Le meilleur des deux", "Le monofilament en montants apporte contrôle et durée, le multi ou le boyau en travers apporte du confort. Il vieillit plus doucement qu'un full polyester."]);
      tips.push(regle);
    } else if (ty === "boyau") {
      tips.push(["Boyau naturel", "Le plus confortable et celui qui garde le mieux sa tension. Il craint l'humidité : évite de jouer sous la pluie avec."]);
      tips.push(regle);
    } else if (ty === "synth") {
      tips.push(["Synthétique", "Économique et polyvalent, mais il perd ses sensations assez vite. Si tu casses souvent ou veux plus d'effet, essaie un hybride."]);
      tips.push(regle);
    } else {
      tips.push(["Indique le type de cordage", "Monofilament, multifilament ou hybride : c'est ce qui permet à Montée de te dire quand recorder."]);
    }
    tips.push(["La tension baisse dès la pose", "Un cordage perd 10 à 30 % de sa tension dans les 48 h après la pose, même sans jouer. Ne laisse pas ta raquette dans une voiture au soleil : la chaleur accélère la perte."]);
    var others = S.rackets.filter(function (x) { return x.id !== r.id; });
    var diff = others.filter(function (x) { return x.tension && r.tension && (Math.abs(x.tension - r.tension) >= 1 || stringType(x) !== ty); })[0];
    if (diff) tips.push(["Tes raquettes ne sont pas cordées pareil", esc(r.name) + " : " + esc([typeLabel(ty), fmtTension(r)].filter(Boolean).join(", ")) + ". " + esc(diff.name) + " : " + esc([typeLabel(stringType(diff)), fmtTension(diff)].filter(Boolean).join(", ")) + ". En match, mieux vaut deux raquettes identiques, recordées ensemble avant un tournoi."]);
    else if (!others.length) tips.push(["Une raquette de secours", "Une casse en match sans deuxième raquette, c'est un match qui bascule. Idéalement, une seconde raquette identique, cordée pareil."]);
    var ms = S.matches.filter(function (m) { return m.racketId === r.id && !m.wo && (m.result === "V" || m.result === "D") && r.string && m.string && m.string.trim().toLowerCase() === r.string.trim().toLowerCase(); });
    if (ms.length >= 3) { var v = ms.filter(function (m) { return m.result === "V"; }).length; tips.push(["Avec ce cordage, toi", "Tu as gagné " + v + " matchs sur " + ms.length + " avec " + esc(r.string) + "."]); }
    return '<details class="card advice"><summary><b>Conseils cordage</b><span class="small">' + plural(tips.length + 1, "repère") + " pour ta raquette</span></summary><div class=\"stack\" style=\"gap:8px\">" + tips.map(function (t) { return '<div class="card" style="gap:4px;padding:14px 16px"><b style="font-size:15px">' + t[0] + '</b><span style="font-size:14px;line-height:1.45">' + t[1] + "</span></div>"; }).join("") +
      '<p class="small">Repères courants des cordeurs, pas une règle : ton ressenti passe avant.</p></div></details>';
  }

  // ---------- Ten'Up ----------
  function rowsFromText(t) {
    var rows = P.parse(t);
    var have = {};
    S.matches.forEach(function (m) { have[m.date + "|" + m.oppRank + "|" + m.result] = 1; });
    return rows.map(function (r) { r.dup = !!have[r.date + "|" + r.oppRank + "|" + r.result]; r.keep = r.ok && !r.dup; r.id = uid(); return r; });
  }
  // ---------- Rapprochement Ten'Up ↔ matchs déjà dans Montée ----------
  // Chaque match Ten'Up est rapproché d'au plus un match existant (un-pour-un), même saisi à la main :
  // même résultat, date à 3 jours près (ou sans date), et même adversaire ou même classement.
  // Le match existant garde tes annotations (raquette, ressenti, notes) et prend les infos officielles.
  function nameTokens(n) { return String(n || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().split(/[^a-z]+/).filter(function (t) { return t.length >= 3; }); }
  function sameName(a, b) {
    var ta = nameTokens(a), tb = nameTokens(b);
    return ta.some(function (t) { return tb.indexOf(t) >= 0; });
  }
  function dayDiff(a, b) { return Math.abs((E.parseDate(a) - E.parseDate(b)) / 864e5); }
  // Joueur masqué par Ten'Up (« Anonyme ») : le nom saisi dans Montée le remplace pour les stats
  function isAnon(n) { return !n || /^(anonyme|joueur anonyme|anonymous|non communiqu)/i.test(String(n).trim()); }
  function scoreKey(x) { return String(x || "").replace(/\s+/g, "").replace(/\(\d+\)/g, ""); }
  function reconcile(rows) {
    var claimed = {}, removed = 0, confirmed = 0, keepM = S.keepManual || {};
    // Nom de référence côté Ten'Up (oppTenup garde « Anonyme » quand on l'a remplacé par le nom saisi)
    var tName = function (x) { return x.oppTenup != null ? x.oppTenup : x.opp; };
    var key = function (x) { return x.date + "|" + nameKey(tName(x)) + "|" + x.oppRank + "|" + x.result; };
    // 1. correspondances exactes avec ce qui vient déjà de Ten'Up
    var exact = {};
    S.matches.forEach(function (m) { if (m.source === "tenup" && m.date) (exact[key(m)] = exact[key(m)] || []).push(m); });
    rows.forEach(function (r) {
      var l = exact[key(r)]; if (!l) return;
      var m = l.filter(function (x) { return !claimed[x.id]; })[0];
      if (m) { claimed[m.id] = 1; r.match = m; }
    });
    // 2. rapprochement avec les matchs saisis à la main : sûr → fusion ; douteux → on demandera au joueur
    var pendingVerify = (S.verify || []).map(function (v) { return v.id; });
    rows.forEach(function (r) {
      if (r.match || !r.result) return;
      var best = null, bestScore = -Infinity, bestSig = 0, bestD = 99;
      S.matches.forEach(function (m) {
        if (claimed[m.id] || m.result !== r.result || (m.source === "tenup" && m.date) || keepM[m.id] || pendingVerify.indexOf(m.id) >= 0) return;
        var d = m.date && r.date ? dayDiff(m.date, r.date) : 0;
        if (d > 7) return;
        var nm = !isAnon(r.opp) && sameName(m.opp, r.opp), rk = !!(m.oppRank && m.oppRank === r.oppRank), sc = !!(m.score && r.score && scoreKey(m.score) === scoreKey(r.score));
        var sig = (nm ? 1 : 0) + (rk ? 1 : 0) + (sc ? 1 : 0);
        var pts = (nm ? 3 : 0) + (rk ? 2 : 0) + (sc ? 3 : 0) - d * 0.5;
        if (pts > bestScore) { bestScore = pts; best = m; bestSig = sig; bestD = d; }
      });
      if (!best) return;
      claimed[best.id] = 1;
      // Sûr : au moins deux indices concordants à 3 jours près (ou le score exact le jour même).
      // Deux scores connus et différents : ce ne sont sans doute pas les mêmes matchs (ex. un amical
      // 6-0 6-1 et le match de tournoi 6-4 6-1 contre le même joueur) : jamais de fusion automatique.
      var scoreClash = best.score && r.score && scoreKey(best.score) !== scoreKey(r.score);
      if (!scoreClash && ((bestSig >= 2 && bestD <= 3) || (bestSig >= 1 && bestD === 0))) r.match = best;
      else if (scoreClash && bestD > 1) { delete claimed[best.id]; return; }
      else r.verifyWith = best.id; // douteux : on garde les deux, le joueur tranchera
    });
    // 3. fusion : Ten'Up fait foi pour la date, l'adversaire, le score ; tes annotations restent
    var recap = [];
    rows.forEach(function (r) {
      var m = r.match;
      if (m) {
        var before = isManual(m) ? { date: m.date, opp: m.opp, oppRank: m.oppRank, result: m.result, score: m.score } : null;
        if (isManual(m)) { confirmed++; m.confirmedAt = E.iso(today()); m.manualOrigin = true; }
        m.date = r.date || m.date;
        if (r.opp) {
          if (isAnon(r.opp) && m.opp && !isAnon(m.opp)) m.oppTenup = r.opp; // on garde le nom connu
          else { m.opp = r.opp; delete m.oppTenup; }
        }
        if (r.oppRank) m.oppRank = r.oppRank;
        if (r.oid) m.oid = r.oid; if (r.olic) m.olic = r.olic; if (r.oclub) m.oclub = r.oclub; if (r.oyear) m.oyear = r.oyear;
        if (r.score) m.score = r.score; if (!m.kindSet || m.kind === "amical") m.kind = r.kind; m.wo = r.wo; m.source = "tenup"; if (r.comp) m.comp = r.comp;
        if (before) recap.push({ before: before, after: { date: m.date, opp: m.opp, oppRank: m.oppRank, result: m.result, score: m.score } });
      }
      r.dup = !!m; r.keep = r.ok && !m; r.id = uid(); delete r.match;
    });
    // 4. ce qui venait de Ten'Up et n'y est plus (ex. doubles importés par erreur) est retiré, mais
    // seulement dans la période que Ten'Up vient de renvoyer : un match plus ancien, sorti du
    // palmarès, reste dans ton historique (face-à-face, notes pour la revanche…).
    var from = rows.reduce(function (a, r) { return r.date && (!a || r.date < a) ? r.date : a; }, "");
    S.matches = S.matches.filter(function (m) {
      if (m.source !== "tenup" || !m.date || claimed[m.id] || !from || m.date < from) return true;
      removed++; return false;
    });
    // 5. à vérifier par le joueur, et récapitulatif des saisies reconnues
    rows.forEach(function (r) { if (r.verifyWith && r.keep) { S.verify = (S.verify || []).filter(function (v) { return v.id !== r.verifyWith; }); S.verify.push({ id: r.verifyWith, tid: r.id }); } });
    if (recap.length) S.syncRecap = (S.syncRecap || []).concat(recap);
    return { removed: removed, confirmed: confirmed };
  }
  function isManual(m) { return !m.source || m.source === "manual" || m.source === "manuel"; }
  function importPayload(pl, opts) {
    opts = opts || {};
    if (!opts.quiet) history.replaceState(null, "", location.pathname + "#/tenup");
    if (pl.error) { if (opts.quiet) return; UI.importError = pl.error; UI.importRows = null; render(); return; }
    if (!NATIVE && pl.sv !== T.VERSION) setTimeout(function () { toast("Ton favori Montée est ancien : recopie-le depuis l'écran Ten'Up."); }, 3200);
    UI.importError = null; UI.wiz = null;
    var rows = T.rows(pl), have = {};
    var rec = reconcile(rows), removed = rec.removed, confirmedN = rec.confirmed;
    var doubles = 0;
    if (pl.raw && pl.raw.length) {
      S.doubles = T.doublesRows(pl).map(function (r) { r.id = "d" + uid(); r.source = "tenup"; return r; });
      doubles = S.doubles.length;
    }
    // profil
    var pr = pl.profil || {}, msg = [];
    var rk = T.normRank(pr.classement);
    if (rk && E.idx(rk) != null && rk !== S.profile.rank) { if (S.profile.rank) { msg.push("classement mis à jour : " + rk); S.rankLog = (S.rankLog || []).concat([{ d: E.iso(today()), from: S.profile.rank, to: rk }]).slice(-24); } S.profile.rank = rk; }
    if (pr.sexe === "F" || pr.sexe === "H") S.profile.sex = pr.sexe;
    if (rk && E.idx(rk) != null) S.tenupRank = rk;
    if (!S.profile.name && pr.prenom) S.profile.name = (function (n) { return n.charAt(0).toUpperCase() + n.slice(1).toLowerCase(); })(String(pr.prenom).split(/[\s-]/)[0]);
    if (pr.licence && !S.profile.licence) S.profile.licence = String(pr.licence);
    if (pr.fiche) { S.profile.gameTU = normGame(pr.fiche); S.profile.ficheTU = pr.fiche; }
    if (pr.nom || pr.prenom) S.tenup.me = { prenom: pr.prenom || "", nom: pr.nom || "", club: pr.club || (S.tenup.me || {}).club || "", meilleur: pr.meilleur || "", licence: pr.licence || "" };
    if (pr.photo) S.profile.photoTU = pr.photo;
    if (Array.isArray(pl.seasons)) {
      // Saisons passées : on écarte celles que Ten'Up renvoie identiques à la saison en cours (paramètre ignoré)
      var seenD = {}; S.tenupSeasons = pl.seasons.filter(function (x) { if (!x || !x.n || !x.d0 || x.d0 === pl.palD0 || seenD[x.d0]) return false; seenD[x.d0] = 1; return true; });
      S.tenupSeasonsDiag = { keys: pl.palKeys || [], cl: pl.palCl || "", n: pl.seasons.length, at: E.iso(today()) };
    }
    S.tenup = Object.assign({}, S.tenup, { lastImport: E.iso(today()), official: T.official(pl), sample: pl.sample || null, id: pl.id, who: pr.nom ? { nom: String(pr.nom), prenom: String(pr.prenom || "") } : (S.tenup || {}).who });
    matchOfficialDoubles();
    S.onboarded = true;
    var todo = rows.filter(function (r) { return !r.ok && !r.dup; });
    if (opts.quiet) {
      var addq = rows.filter(function (r) { return r.keep; });
      var b4q = idSet(); addq.forEach(addImported); hcMergeToast(hcMergeNew(b4q));
      calibrateFromTenup(); setTimeout(anAfterSync, 400); setTimeout(folRefresh, 3000);
      S.tenup.lastAuto = Date.now(); save(); syncNative();
      var parts = [];
      if (addq.length) parts.push(plural(addq.length, "nouveau match", "nouveaux matchs") + " importé" + (addq.length > 1 ? "s" : ""));
      if (confirmedN) parts.push(plural(confirmedN, "match saisi à la main confirmé", "matchs saisis à la main confirmés") + " par Ten'Up");
      if (msg.length) parts.push(msg.join(", "));
      if (parts.length) toast(parts.join(" · ").replace(/^./, function (x) { return x.toUpperCase(); }) + ".");
      else if (opts.pull) toast("Tout est à jour : rien de nouveau sur Ten'Up.");
      render();
      return;
    }
    if (!todo.length) {
      var add = rows.filter(function (r) { return r.keep; });
      var b4 = idSet(); add.forEach(addImported); hcMergeToast(hcMergeNew(b4));
      calibrateFromTenup(); setTimeout(anAfterSync, 400); setTimeout(folRefresh, 3000);
      save(); syncNative();
      toast((add.length ? plural(add.length, "nouveau match", "nouveaux matchs") + " depuis Ten'Up" : "Ton palmarès est à jour") +
        (doubles ? " · " + plural(doubles, "double", "doubles") + " (bonus)" : "") + (removed ? " · " + plural(removed, "match retiré", "matchs retirés") : "") + (confirmedN ? " · " + plural(confirmedN, "match saisi à la main confirmé", "matchs saisis à la main confirmés") : "") + (msg.length ? " · " + msg.join(", ") : "") + ".");
      go(S.profile.rank ? "" : "profil");
      return;
    }
    save();
    UI.importRows = rows; render();
  }
  // Ten'Up donne son propre bilan pour la prochaine sortie : on s'aligne dessus.
  // L'écart (règles que Ten'Up ne détaille pas) devient « Ajustement d'après Ten'Up ».
  // On mémorise les bilans officiels par échelon et les matchs que Ten'Up connaissait.
  // L'écart est recalculé à chaque affichage (classement, palmarès à jour) ; les matchs
  // ajoutés ensuite à la main s'ajoutent par-dessus.
  function calibrateFromTenup() {
    var o = S.tenup && S.tenup.official; if (!o) return;
    var raw = o.pdf ? [{ c: o.atRank, pts: o.pts }] : (o.simulation || []);
    var lines = raw.map(function (x) {
      return { at: E.idx(T.normRank(x.c) || x.c), pts: x.pts === "" || x.pts == null ? NaN : Number(x.pts) };
    }).filter(function (l) { return l.at != null && l.at >= 0 && l.at <= E.MAX_CALC && isFinite(l.pts); });
    delete S.tenup.extra;
    if (!lines.length) { delete S.tenup.cal; return; }
    var day = o.at ? new Date(o.at) : today(); day = new Date(day.getFullYear(), day.getMonth(), day.getDate());
    var rel = E.nextRelease(day);
    // Seuls les matchs connus de Ten'Up servent à caler le calcul sur la simulation officielle :
    // une saisie à la main pas encore homologuée n'y figure pas, elle doit s'ajouter par-dessus
    // (sinon l'écart de calage l'annulait et le match ne comptait plus).
    var w = E.windowMatches(allMatches().filter(function (m) { return !isManual(m); }), rel, day);
    S.tenup.cal = { release: E.iso(rel), ids: w.map(function (m) { return m.id; }), lines: lines };
  }
  function tenupExtra(release, me) {
    var c = S.tenup && S.tenup.cal;
    if (!c || !c.lines || !c.lines.length || c.release !== E.iso(release)) return 0;
    var ids = {}; c.ids.forEach(function (i) { ids[i] = 1; });
    var w = E.windowMatches(allMatches().filter(function (m) { return ids[m.id]; }), release, today());
    if (me == null || me < -1) me = -1;
    var map = {}, n = 0;
    c.lines.forEach(function (l) {
      var g = l.pts - E.bilanAt(w, l.at, S.profile.sex, me).total;
      if (Math.abs(g) <= 300) { map[l.at] = g; n++; }
    });
    return n ? map : 0;
  }
  function tenupCall(cred, keep) {
    if (UI.loading) return;
    UI.loading = true; UI.importError = null; render();
    fetch("api/tenup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: cred.email, password: cred.password, licence: S.profile.licence || "" }) })
      .then(function (r) {
        if (r.status === 404) throw new Error("La connexion directe n'est pas installée sur ce site : déploie Montée avec Git ou la commande Netlify (voir README), pas par glisser-déposer.");
        return r.json();
      })
      .then(function (j) {
        UI.loading = false;
        if (!j.ok) {
          if (j.code === "credentials") delete S.tenup.cred;
          S.tenup.lastError = { at: new Date().toISOString(), code: j.code, error: j.error, trace: j.trace || [], page: j.page || null }; save();
          UI.importError = j.error || "Erreur inconnue.";
          if (route() !== "tenup") go("tenup"); else render();
          return;
        }
        if (keep) S.tenup.cred = { email: cred.email, password: cred.password };
        save();
        importPayload(j.payload);
      })
      .catch(function (e) {
        UI.loading = false;
        UI.importError = e && e.message && e.message.indexOf("Netlify") >= 0 ? e.message : "Pas de réponse. Vérifie ta connexion internet et réessaie.";
        if (route() !== "tenup") go("tenup"); else render();
      });
  }
  // Points du bonus double donnés par Ten'Up : on les rattache à nos doubles par les noms des adversaires
  function pairKey(names) { return names.map(function (n) { return nameKey(String(n).split(/\s+/).slice(-1)[0]); }).filter(Boolean).sort().join("+"); }
  function matchOfficialDoubles() {
    var od = (S.tenup && S.tenup.official && S.tenup.official.doubles) || [];
    (S.doubles || []).forEach(function (m) { delete m.officialPts; });
    if (!od.length) return;
    var pool = od.map(function (x) { return { k: pairKey(x.names), pts: x.pts, used: false }; });
    (S.doubles || []).filter(function (m) { return m.result === "V" && !m.wo; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }).forEach(function (m) {
      var k = pairKey(String(m.opp || "").split(" / "));
      var hit = pool.filter(function (p) { return !p.used && p.k === k; })[0];
      if (hit) { hit.used = true; m.officialPts = hit.pts; }
    });
  }
  function addImported(r) {
    var nid = r.id || uid();
    // Nouveau match récent (pas l'import initial) : Montée l'analyse et le met en avant sur l'accueil
    if (S.matches.length > 5 && r.date && r.date >= E.iso(new Date(Date.now() - 21 * 864e5)) && !r.wo) { S.anNew = (S.anNew || []).filter(function (x) { return x !== nid; }); S.anNew.unshift(nid); S.anNew = S.anNew.slice(0, 3); }
    S.matches.push({ id: nid, date: r.date, opp: r.opp, oppRank: r.oppRank, result: r.result, wo: r.wo, score: r.score, kind: r.kind, comp: r.comp || "", surface: "", indoor: null, racketId: "", string: "", tension: null, tensionCross: null, feel: null, note: "", source: "tenup", oid: r.oid || "", olic: r.olic || "", oclub: r.oclub || "", oyear: r.oyear || null });
  }
  function officialHtml(full) {
    var o = S.tenup && S.tenup.official;
    if (!o || !o.at) return "";
    var d = new Date(o.at), age = (today() - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5;
    if (age > 45) return "";
    var s = '<div class="card" style="gap:6px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><b style="font-size:15px">Simulation officielle Ten\'Up</b><span class="small">importée le ' + esc(fdate(E.iso(d))) + "</span></div>";
    if (o.pdf) {
      if (o.month) s += '<span class="small">Classement de ' + esc(o.month) + "</span>";
      if (o.calculated) s += '<div class="kv"><span>Classement calculé</span><b>' + esc(o.calculated) + "</b></div>";
      if (o.pts != null) s += '<div class="kv"><span>Bilan à ' + esc(o.atRank || "") + "</span><b>" + o.pts + (o.needed != null ? " / " + o.needed : "") + "</b></div>";
      if (full && o.counted != null) s += '<div class="kv"><span>Victoires comptabilisées</span><b>' + o.counted + "</b></div>";
    } else {
      var lines = (o.simulation && o.simulation.length ? o.simulation : o.bilans || []).filter(function (x) { return x.c; }).slice(0, 4);
      if (!full && lines.length) return officialSimCard(o, lines, d, age);
      if (o.message) s += '<span style="font-size:15px;line-height:1.4">' + esc(o.message) + "</span>";
      s += lines.map(function (x) { return '<div class="kv"><span>À ' + esc(x.c) + "</span><b>" + (x.pts != null ? x.pts : "?") + (x.quota != null ? " / " + x.quota : "") + "</b></div>"; }).join("");
    }
    if (age > 7) s += '<span class="small">Pense à la réimporter après tes prochains matchs.</span>';
    return s + "</div>";
  }

  // Carte d'accueil : la simulation Ten'Up mise en valeur (barres par échelon, prochain échelon en avant)
  function officialSimCard(o, lines, d, age) {
    lines = lines.map(function (x) { var n = function (v) { return v == null || v === "" || isNaN(+v) ? null : +v; }; return { c: x.c, pts: n(x.pts), quota: n(x.quota) }; });
    var ok = function (x) { return x.pts != null && x.quota != null && x.pts >= x.quota; };
    var rk = function (x) { var i = E.idx(x.c); return i == null ? -99 : i; };
    var best = null, next = null;
    lines.forEach(function (x) { if (ok(x) && (!best || rk(x) > rk(best))) best = x; });
    lines.forEach(function (x) { if (!ok(x) && x.pts != null && x.quota != null && (!best || rk(x) > rk(best)) && (!next || rk(x) < rk(next))) next = x; });
    var h = next ? 'Il te manque <b>' + (next.quota - next.pts) + " pts</b> pour " + esc(next.c)
      : best ? "Tu valides <b>" + esc(best.c) + "</b>" : esc(o.message || "Ton bilan selon Ten'Up");
    var s = '<div class="card offsim"><div class="os-top"><span class="eyebrow">Simulation officielle · Ten\'Up</span><span class="small">' + esc(fdate(E.iso(d))) + "</span></div>" +
      '<span class="os-h">' + h + "</span>";
    if (best && next) s += '<span class="small">Ton maintien à ' + esc(best.c) + " est assuré.</span>";
    s += '<div class="os-rows">' + lines.map(function (x) {
      var pc = x.pts != null && x.quota ? Math.max(4, Math.min(100, Math.round(x.pts / x.quota * 100))) : 0;
      var cl = ok(x) ? " ok" : x === next ? " next" : "";
      return '<div class="os-r' + cl + '"><span class="os-c">' + esc(x.c) + '</span><span class="os-bar"><i style="width:' + pc + '%"></i></span>' +
        '<span class="os-v">' + (ok(x) ? I.check : "") + "<b>" + (x.pts != null ? x.pts : "?") + "</b>" + (x.quota != null ? " / " + x.quota : "") + "</span></div>";
    }).join("") + "</div>";
    if (age > 7) s += '<span class="small">Pense à la réimporter après tes prochains matchs.</span>';
    return s + "</div>";
  }

  // Partage : texte + liens de téléchargement. Natif → feuille de partage du téléphone ; web → Web Share ou copie.
  var STORE_LINKS = { ios: "https://apps.apple.com/fr/app/id6826303003", android: "https://play.google.com/store/apps/details?id=fr.montennis.app" };
  function shareText(msg) {
    var links = NATIVE ? "\n\niPhone : " + STORE_LINKS.ios + "\nAndroid : " + STORE_LINKS.android : "\n\n" + location.origin + location.pathname;
    var full = msg + links;
    var copy = function () {
      if (navigator.clipboard) navigator.clipboard.writeText(full).then(function () { toast("Message copié : colle-le où tu veux."); }, function () { toast("Partage impossible sur ce téléphone."); });
      else toast("Partage impossible sur ce téléphone.");
    };
    if (Tenup && typeof Tenup.shareText === "function") return Promise.resolve().then(function () { return Tenup.shareText({ title: "Montée", text: full }); }).catch(function () { if (navigator.share) navigator.share({ title: "Montée", text: full }).catch(function () {}); else copy(); });
    if (navigator.share) return navigator.share({ title: "Montée", text: msg, url: NATIVE ? STORE_LINKS.ios : location.origin + location.pathname }).catch(function () {});
    copy();
  }

  // ---- Import d'une page Ten'Up en PDF ----
  function nameKey(n) { return String(n || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z]/g, ""); }
  function importPdfFile(file) {
    if (!file) return;
    UI.loading = true; UI.importError = null; render();
    window.MonteePdf.linesFromFile(file).then(function (lines) {
      UI.loading = false;
      var r = window.MonteePdf.parse(lines);
      if (r.kind === "simulation") return applySimulation(r);
      if (r.kind === "palmares") {
        UI.importError = "C'est la page Palmarès : elle ne dit pas qui a gagné. Ouvre plutôt l'onglet « Simu » de Ten'Up et refais le PDF.";
        return render();
      }
      UI.importError = "Ce PDF ne ressemble pas à une page Ten'Up. Ouvre l'onglet « Simu » de ta page joueur, puis refais le PDF.";
      render();
    }).catch(function () {
      UI.loading = false; UI.importError = "Impossible de lire ce fichier. Choisis le PDF de la page « Simu » de Ten'Up."; render();
    });
  }
  function applySimulation(r) {
    var msg = [];
    var pr = r.profile || {};
    if (pr.rank && E.idx(pr.rank) != null && pr.rank !== S.profile.rank) { if (S.profile.rank) msg.push("classement : " + pr.rank); S.profile.rank = pr.rank; }
    if (pr.name && !S.profile.name) S.profile.name = (function (n) { return n.charAt(0).toUpperCase() + n.slice(1).toLowerCase(); })(pr.name.split(/\s+/)[0]);
    if (pr.licence) S.profile.licence = pr.licence;
    // Les matchs Ten'Up de la période remplacent l'import précédent ; on garde les annotations.
    var old = S.matches.filter(function (m) { return m.source === "tenup-pdf"; });
    var keep = S.matches.filter(function (m) { return m.source !== "tenup-pdf"; });
    var used = {}, added = 0;
    var take = function (pool, k) {
      for (var i = 0; i < pool.length; i++) {
        var m = pool[i];
        if (!used[m.id] && nameKey(m.opp) + "|" + m.oppRank + "|" + m.result === k) { used[m.id] = 1; return m; }
      }
      return null;
    };
    var fresh = r.rows.map(function (x) {
      var k = nameKey(x.opp) + "|" + x.oppRank + "|" + x.result;
      var prev = take(old, k) || take(keep, k);
      if (!prev) added++;
      var m = prev ? Object.assign({}, prev) : { id: uid(), date: "", score: "", wo: false, kind: "tournoi", surface: "", indoor: null, racketId: "", string: "", tension: null, tensionCross: null, feel: null, note: "" };
      m.opp = prev && prev.opp ? prev.opp : x.opp; m.oppRank = x.oppRank; m.result = x.result; m.officialPts = x.pts; m.source = "tenup-pdf";
      return m;
    });
    S.matches = keep.filter(function (m) { return !used[m.id]; }).concat(fresh);
    // Écart entre notre calcul et Ten'Up (bonus, coefficients) à l'échelon calculé par Ten'Up
    var o = r.official || {};
    S.tenup.official = { pdf: true, at: new Date().toISOString(), month: r.month, period: r.period, atRank: o.at, pts: o.pts, needed: o.needed, counted: o.counted, calculated: o.calculated };
    calibrateFromTenup();
    S.tenup.snapshots = (S.tenup.snapshots || []).concat([{ at: E.iso(today()), month: r.month, rank: o.at, pts: o.pts, needed: o.needed }]).slice(-24);
    S.tenup.lastImport = E.iso(today()); S.onboarded = true; save();
    toast(plural(r.rows.length, "match", "matchs") + " importés" + (added ? " (" + added + " nouveau" + (added > 1 ? "x" : "") + ")" : "") + (msg.length ? " · " + msg.join(", ") : "") + ".");
    go("");
  }

  // ---------- App iPhone : liaison Ten'Up, actualisation, notifications ----------
  function tenupWho() { var w = S.tenup.who; return w ? { nom: w.nom, prenom: w.prenom, cfg: S.tenup.searchCfg || null } : null; }
  function nativeScript() { return T.nativeScript(S.profile.licence || "", S.tenup.id || "", tenupWho()); }
  function tenupKeys() {
    return S.matches.filter(function (m) { return m.source === "tenup" && m.date; }).map(function (m) { return m.date + "|" + m.oppRank + "|" + m.result; });
  }
  function syncNative() {
    if (!NATIVE || !S.tenup.linked) return;
    var me = E.idx(S.profile.rank);
    var st = { keys: tenupKeys(), rank: S.profile.rank, sex: S.profile.sex, extra: tenupExtra(E.nextRelease(today()), me == null ? -1 : me), status: ctx().proj.status };
    Tenup.setState({ state: JSON.stringify(st), script: nativeScript() }).catch(function () {});
    scheduleReleaseNotif();
  }
  // Notifications programmées autour de la sortie : le jour J (8 h 30), la veille (18 h) si ça bouge,
  // et un rappel une dizaine de jours avant quand une seule victoire suffit (monter ou se maintenir).
  function scheduleReleaseNotif() {
    if (!NATIVE || !S.notif || !LN) return;
    var c = ctx(), p = c.proj; if (p.status === "top") return;
    var now = new Date(), list = [], at = function (d, h, mn) { var x = new Date(d.getTime()); x.setHours(h, mn, 0, 0); return x; };
    var dayBefore = new Date(p.release.getTime()); dayBefore.setDate(dayBefore.getDate() - 1);
    var body = window.monteeStatusLine ? window.monteeStatusLine(p) : "";
    list.push({ id: 1001, title: "Sortie du classement aujourd'hui", body: body || "Ouvre Montée pour voir où tu en es.", schedule: { at: at(p.release, 8, 30) } });
    if (p.status === "montee") list.push({ id: 1002, title: "Demain, sortie du classement", body: "Tu montes à " + lab(p.projected) + " si rien ne bouge d'ici là. Résultat officiel demain matin.", schedule: { at: at(dayBefore, 18, 0) } });
    else if (p.status === "descente") list.push({ id: 1002, title: "Demain, sortie du classement", body: "Tu risques de descendre à " + lab(p.projected) + ". Il te manque " + plural(p.here.norme - p.here.total, "point") + " pour te maintenir. Résultat officiel demain matin.", schedule: { at: at(dayBefore, 18, 0) } });
    var pl = pistes(c), one = pl.one;
    if (one && (p.status === "maintien" || p.status === "descente")) {
      var rem = new Date(p.release.getTime()); rem.setDate(rem.getDate() - 10);
      var days = 10, keep = pl.goal === "keep";
      list.push({ id: 1003, title: keep ? "Une victoire peut te maintenir" : "Une victoire peut suffire",
        body: "Encore " + days + " jours avant la sortie : bats un " + lab(one.top) + " ou mieux et tu " + (keep ? "restes " + lab(pl.target) : "montes à " + lab(pl.target)) + ".", schedule: { at: at(rem, 18, 30) } });
    }
    // Points à défendre : un mois avant la sortie où une victoire qui sort fait perdre l'échelon
    var z = defendThreat(c);
    if (z) {
      var zd = new Date(z.rel.getTime()); zd.setDate(zd.getDate() - 30);
      var w0 = z.gone[0];
      list.push({ id: 1004, title: z.lost + " pts à défendre avant le " + z.rel.getDate() + " " + MOIS_L[z.rel.getMonth()],
        body: (w0 ? "Ta victoire contre " + (w0.m.opp && !isAnon(w0.m.opp) ? w0.m.opp : "un " + w0.m.oppRank) + " sort de tes 12 mois. " : "") + (z.need != null ? "Une victoire contre un " + lab(z.need) + " la remplace." : "Il te faudra de nouvelles victoires pour garder " + lab(z.calc) + "."), schedule: { at: at(zd, 18, 15) } });
    }
    list = list.filter(function (n) { return n.schedule.at > now; });
    LN.cancel({ notifications: [{ id: 1001 }, { id: 1002 }, { id: 1003 }, { id: 1004 }] }).catch(function () {}).then(function () {
      if (list.length) return LN.schedule({ notifications: list });
    }).catch(function () {});
  }
  function handleNativeResult(data, quiet, pull) {
    var pl = T.decode(data || "");
    if (pl && !pl.error) { S.tenup.linked = true; S.tenup.expired = false; importPayload(pl, { quiet: quiet || pull, pull: pull }); return true; }
    // Session Ten'Up perdue (page de connexion au lieu de Ten'Up) : on rouvre directement la connexion
    var why = String((pl && pl.error) || data || "");
    if (/connecte-toi|ouvre d'abord|tenup\.fft\.fr|auth/i.test(why)) {
      S.tenup.expired = true; save();
      if (!quiet) { UI.importError = null; toast("Ta session Ten'Up a expiré : reconnecte-toi sur la page qui s'ouvre."); render(); setTimeout(nativeConnect, 600); }
    }
    else if (pull) toast("Ten'Up n'a pas répondu. Réessaie dans un instant.");
    else if (!quiet) { UI.importError = (pl && pl.error) || "Ten'Up n'a pas répondu. Réessaie dans un instant."; render(); }
    return false;
  }
  function nativeConnect() {
    UI.importError = null;
    Tenup.connect({ script: nativeScript() }).then(function (r) {
      if (r && r.data) { S.tenup.linked = true; handleNativeResult(r.data, false); askNotif(); }
    }).catch(function (e) { UI.importError = "Connexion impossible (" + (e && e.message || e) + ")."; render(); });
  }
  function nativeRefresh(quiet, pull) {
    if (!NATIVE || UI.loading) return Promise.resolve();
    if (!S.tenup.linked || S.tenup.expired) { if (pull) { toast("Connecte-toi à Ten'Up sur la page qui s'ouvre."); nativeConnect(); } return Promise.resolve(); }
    UI.loading = true; if (!quiet && !pull) render();
    return Tenup.refresh({ script: nativeScript() }).then(function (r) {
      UI.loading = false; S.tenup.lastAuto = Date.now(); save();
      if (!handleNativeResult(r && r.data, quiet, pull) && (quiet || pull)) render();
    }).catch(function () { UI.loading = false; if (pull) toast("Ten'Up n'a pas répondu. Réessaie dans un instant."); else if (!quiet) { UI.importError = "Ten'Up n'a pas répondu."; render(); } });
  }
  function askNotif() {
    if (!NATIVE) return;
    LN.requestPermissions().then(function (p) { S.notif = p && p.display === "granted"; save(); syncNative(); render(); }).catch(function () {});
  }
  // ---------- Widgets de l'écran d'accueil (app native) ----------
  // Montée calcule ici ce que les widgets affichent ; le téléphone ne fait que le dessiner.
  function widgetData() {
    var d = { v: 1, updated: Date.now(), rank: effRank() || "", status: "none" };
    if (!S.matches.length || !S.profile.rank) { d.line = "Ajoute tes matchs pour savoir si tu montes"; d.headline = d.line; return finishWidget(d); }
    var c = ctx(), p = c.proj;
    d.releaseIso = E.iso(p.release);
    if (S.ahead) {
      d.status = "montee"; d.rank = S.ahead.rank; d.from = S.ahead.from; d.releaseIso = S.ahead.release;
      d.line = "dans la poche"; d.headline = "Tu montes à " + S.ahead.rank + " : c'est dans la poche";
      d.target = S.ahead.from + " → " + S.ahead.rank;
      if (p.status !== "top" && p.next) d.next = "Prochain objectif : " + p.next.label + (p.gap ? ", il manque " + p.gap + " pts" : p.needWin ? ", une victoire contre un " + p.next.label : "");
    } else if (p.status === "top") {
      d.status = "top"; d.line = "Joueur numéroté"; d.headline = "Classement au concours des meilleurs bilans";
    } else if (p.status === "descente") {
      d.status = "descente"; d.line = "maintien menacé : −" + (p.here.norme - p.here.total) + " pts"; d.headline = "Attention : risque de descente à " + lab(p.projected);
      d.target = effRank() + " → " + lab(p.projected);
    } else {
      d.status = "maintien";
      var nx = p.next, ezp = easiest(pistes(c)), mw = ezp && ezp.k === 1 ? ezp.top : undefined;
      d.target = effRank() + " → " + nx.label;
      d.line = "→ " + nx.label + " : " + (p.gap ? "il manque " + p.gap + " pts" : "une victoire contre un " + nx.label);
      d.headline = p.gap === 0 && p.needWin ? "Il te manque une victoire contre un " + nx.label : (mw !== undefined && mw !== null) ? "Ça se joue à une victoire contre un " + lab(mw) : "Il te manque " + plural(p.gap, "point") + " pour " + nx.label;
    }
    if (p.next && p.status !== "top") { d.total = p.next.total; d.norme = p.next.norme; d.pct = p.next.norme ? Math.min(100, Math.round(p.next.total * 100 / p.next.norme)) : 100; d.label = p.next.label; }
    // forme
    var played = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); });
    d.form = played.slice(0, 5).map(function (m) { return m.result; }).reverse();
    var st = 0; for (var i = 0; i < played.length && played[i].result === played[0].result; i++) st++;
    d.streak = played.length ? plural(st, played[0].result === "V" ? "victoire" : "défaite") + " d'affilée" : "Pas encore de match";
    var w12 = p.matches || [];
    d.record = w12.filter(function (m) { return m.result === "V" && !m.wo; }).length + " V · " + w12.filter(function (m) { return m.result === "D" && !m.wo; }).length + " D sur 12 mois";
    d.recordShort = d.record.replace(" sur 12 mois", "");
    // Textes courts pour les widgets
    d.rankNow = effRank();
    if (d.status === "maintien") {
      var nx2 = p.next, ez2 = easiest(pistes(c)), one2 = ez2 && ez2.k === 1;
      d.short = p.gap === 0 && p.needWin ? "Tu as les points" : one2 ? "Une victoire peut suffire" : "Il manque " + plural(p.gap, "pt");
      d.sub = p.gap === 0 && p.needWin ? "Il manque la victoire qui valide : bats un " + nx2.label + "." : one2 ? "Contre un " + lab(ez2.top) + " ou mieux." : ez2 ? "Piste : " + pisteLabel(ez2) + "." : "Vise plutôt la sortie suivante.";
    } else if (d.status === "descente") {
      d.short = "Il manque " + plural(p.here.norme - p.here.total, "pt") + " pour rester";
      d.sub = "Bilan à " + lab(c.cur < 0 ? 0 : c.cur) + " : " + p.here.total + " / " + p.here.norme;
    }
    try {
      var b0 = p.status === "descente" ? p.here : p.next;
      if (b0 && c.cur >= 0 && p.status !== "top") {
        var rel = p.release, ser = [], all = allMatches(), MO = ["janv", "févr", "mars", "avr", "mai", "juin", "juil", "août", "sept", "oct", "nov", "déc"];
        for (var k6 = 0; k6 < 6; k6++) { var bb = E.bilanAt(E.windowMatches(all, rel, today()), b0.calc, c.sex, c.cur, c.opts.extra); ser.push({ m: MO[rel.getMonth()], total: bb.total, norme: bb.norme }); rel = E.nextRelease(rel); }
        var worst = 0, wd = 0;
        for (var j6 = 1; j6 < ser.length; j6++) { var dd6 = ser[j6 - 1].total - ser[j6].total; if (dd6 > wd) { wd = dd6; worst = j6; } }
        if (ser[0].total - ser[5].total > 0) d.defend = { pts: ser, worst: wd ? worst : -1, caption: wd ? ser[worst].m.replace(/^./, function (x) { return x.toUpperCase(); }) + " : −" + wd + " pts" : "" };
      }
      var ins = insights(c); if (ins.length) { ins.sort(function (a, b) { return b.score - a.score; }); d.truc = ins[0].text; }
    } catch (e) {}
    var pts = countedMap(p.next);
    d.last = played.slice(0, 8).map(function (m) { var dt = E.parseDate(m.date); return { r: m.result, date: dt.getDate() + " " + MOIS[dt.getMonth()], opp: (m.opp || "Adversaire") + " · " + m.oppRank, right: m.result === "V" ? (pts[m.id] != null ? "+" + pts[m.id] : "hors quota") : (m.score || "") }; });
    return finishWidget(d);
  }
  function finishWidget(d) {
    // Objectif de saison
    try {
      if (S.goal && S.profile.rank) {
        var cg = ctx(), gp = goalPlan(cg), byD = E.parseDate(S.goal.by), curI = cg.cur < 0 ? 0 : cg.cur;
        var nx = gp.items.filter(function (x) { return x.kind === "next" || x.kind === "goal"; })[0];
        var wf = gp.state === "atteint" ? null : winsFor(cg, S.goal.rank);
        d.goal = { rank: lab(S.goal.rank), from: lab(S.goal.from), now: lab(curI), by: ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."][byD.getMonth()] + " " + byD.getFullYear(), state: gp.state,
          pct: Math.round(Math.max(0, Math.min(1, (curI - S.goal.from) / Math.max(1, S.goal.rank - S.goal.from))) * 100),
          steps: S.goal.rank - S.goal.from, done: Math.max(0, curI - S.goal.from), wins: wf ? wf.n : 0, winsAt: wf ? lab(wf.lvl) + " ou " + lab(S.goal.rank) : "",
          next: nx && gp.state !== "atteint" ? nx.rank : "" };
      }
    } catch (e) {}
    // Prochain adversaire (dernier joueur consulté)
    if (S.lastScout && S.lastScout.name) d.scout = S.lastScout;
    // Recherche : derniers adversaires (initiales)
    try { d.recent = oppIndex().slice(0, 4).map(function (o) { return { ini: initials(o.name), name: o.name.split(" ")[0] }; }); } catch (e) {}
    var rk = bag().filter(function (r) { return r.main; })[0] || bag()[0];
    if (rk) {
      var st = racketStatus(rk);
      d.racket = { id: rk.id, name: rk.name, hours: st.known ? "≈ " + fmtHours(st.min) : "?", level: st.level,
        pct: st.known && st.type === "mono" ? Math.min(100, Math.round(st.min * 100 / MONO_MAX)) : st.known ? Math.min(100, Math.round(st.min * 100 / (40 * 60))) : 0,
        msg: st.level === "broken" ? "Cordage cassé" : st.level === "change" ? "À recorder" : st.level === "soon" ? "Bientôt à recorder" : !st.known ? "Date de cordage ?" : st.type === "mono" ? "recorder vers 20 h" : "de jeu sur le cordage" };
    }
    // Détails pour les widgets dessinés (illustration, titre, sac complet)
    var wr = function (r) {
      var st2 = racketStatus(r), mono = st2.type === "mono";
      return { id: r.id, name: r.name || "Raquette", color: r.color || "noir", accent: r.accent, pattern: r.pattern, known: st2.known, level: st2.level,
        hours: st2.known ? fmtHours(st2.min) : "?", max: st2.known && mono ? "sur " + Math.round(MONO_MAX / 60) + " h" : st2.known ? "de jeu" : "",
        pct: st2.known && mono ? Math.min(100, Math.round(st2.min * 100 / MONO_MAX)) : st2.known ? Math.min(100, Math.round(st2.min * 100 / (40 * 60))) : 0,
        title: [r.name, r.string ? r.string.replace(/\s*\d+([.,]\d+)?\s*$/, "") : r.model, fmtTension(r)].filter(Boolean).join(" · "),
        short: st2.level === "broken" ? "cassé" : st2.level === "change" ? "à recorder" : st2.level === "soon" ? "bientôt" : !st2.known ? "date ?" : "OK" };
    };
    if (rk) { var full = wr(rk); for (var kk in full) if (d.racket[kk] === undefined || kk === "hours" || kk === "pct") d.racket[kk] = full[kk]; d.racket.msg = d.racket.msg; }
    d.bag = bag().map(wr);
    // semaine
    var by = activity(), mon = mondayOf(today()), min = 0, days = [];
    for (var i = 0; i < 7; i++) { var x = new Date(mon); x.setDate(x.getDate() + i); var a = by[E.iso(x)]; if (a) min += a.min; days.push(a ? (a.m ? "m" : "t") : ""); }
    var streak = 0, w = new Date(mon), first = true;
    for (var n = 0; n < 104; n++) { var any = false; for (var j = 0; j < 7; j++) { var dd = new Date(w); dd.setDate(dd.getDate() + j); if (by[E.iso(dd)]) { any = true; break; } } if (any) streak++; else if (!first) break; first = false; w.setDate(w.getDate() - 7); }
    var wmins = [], wcount = 0;
    for (var i2 = 0; i2 < 7; i2++) { var x2 = new Date(mon); x2.setDate(x2.getDate() + i2); var a2 = by[E.iso(x2)]; wmins.push(a2 && a2.min ? fmtDur(a2.min) : ""); if (a2) wcount += a2.m + a2.t; }
    d.week = { mins: wmins, count: wcount ? plural(wcount, "séance") : "", total: min ? fmtDur(min) : "0 h", days: days, todayIdx: (today().getDay() + 6) % 7, streak: streak ? plural(streak, "semaine active", "semaines actives") : "" };
    var pend = pendingSlots()[0];
    if (pend) d.week.slot = { label: DAYS_L[pend.sl.dow].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + pend.sl.time + " · " + (pend.sl.label || "Entraînement"), id: pend.sl.id, date: pend.date, ask: true };
    else if ((S.slots || []).length) {
      var nxt = S.slots.slice().map(function (sl) { var k = (sl.dow - (today().getDay() + 6) % 7 + 7) % 7; return { sl: sl, k: k }; }).sort(function (a, b) { return a.k - b.k || (a.sl.time < b.sl.time ? -1 : 1); })[0];
      d.week.slot = { label: "Prochain : " + DAYS_L[nxt.sl.dow] + " " + nxt.sl.time + " · " + (nxt.sl.label || "Entraînement"), ask: false };
    }
    return d;
  }
  var lastWidgetJson = "", widgetTimer = 0, widgetBusy = false;
  function widgetTheme() { var w = (S.prefs && S.prefs.wtheme) || "app"; return w === "app" ? themeNow() : w; }
  function syncWidgets(force) {
    if (!NATIVE || !Tenup || !S.onboarded) return;
    if (force) lastWidgetJson = "";
    clearTimeout(widgetTimer);
    widgetTimer = setTimeout(function () {
      if (widgetBusy) { syncWidgets(); return; }
      var d, json; try { d = widgetData(); delete d.updated; json = JSON.stringify(d); } catch (e) { return; }
      var Art = window.MonteeWidgetArt, theme = widgetTheme();
      // Ancienne version native (sans widgets dessinés) : on envoie juste les données
      if (!Art || !Tenup.widgetInfo) {
        if (json === lastWidgetJson) return; lastWidgetJson = json;
        try { var r = Tenup.setWidgets({ data: json }); if (r && r.catch) r.catch(function () {}); } catch (e) {}
        return;
      }
      widgetBusy = true;
      Promise.resolve(Tenup.widgetInfo()).then(function (info) {
        info = info || {};
        var kinds = info.kinds || [], sizes = info.sizes || {}, scale = Math.min(3, Math.max(2, info.density || 2.5));
        var key = json + "|" + theme + "|" + JSON.stringify(sizes) + "|" + kinds.join(",");
        if (key === lastWidgetJson) return;
        var images = {}, chain = Promise.resolve();
        kinds.forEach(function (k) {
          var sz = sizes[k] || Art.SIZES[k] || [170, 170];
          chain = chain.then(function () { return Art.render(k, d, theme, sz[0], sz[1], scale); }).then(function (b64) { images[k] = b64; }).catch(function () {});
        });
        return chain.then(function () {
          lastWidgetJson = key;
          return Tenup.setWidgetImages({ data: json, images: images });
        });
      }).catch(function () {}).then(function () { widgetBusy = false; });
    }, 700);
  }
  // Action demandée depuis un widget (ouvrir un écran, « J'ai joué »)
  function widgetAction(url) {
    var m = /^montee:\/\/(open|slot)\/?(.*)$/.exec(url || ""); if (!m) return;
    if (m[1] === "open") {
      var pth = (m[2] || "").split("?"), qs = pth[1] || "";
      if (/(^|&)focus=1/.test(qs)) { UI.faf = { q: "" }; UI.fafHits = null; UI.fafErr = null; UI.fafFocus = true; }
      if (pth[0] === "sante/nouvelle") UI.hcFromNotif = true;
      go(pth[0] || ""); return;
    }
    var q = {}; (m[2].split("?")[1] || "").split("&").forEach(function (kv) { var p = kv.split("="); if (p[0]) q[p[0]] = decodeURIComponent(p[1] || ""); });
    if (q.id && q.d) { A.slotYes({ dataset: { id: q.id, d: q.d } }); go(""); }
  }
  function nativeWake() {
    if (!NATIVE) return;
    syncWidgets(true); // un widget a pu être ajouté ou redimensionné
    hcWake();
    if (UI.hcWait) setTimeout(function () { hcStatus().then(function (st) { if (st && !st.granted && UI.hcWait) { UI.hcWait = false; UI.hcDenied = true; if (route().indexOf("sante") === 0) render(); } }); }, 1500);
    try { var ta = Tenup.takeAction(); if (ta && ta.then) ta.then(function (r) { if (r && r.action) widgetAction(r.action); }).catch(function () {}); } catch (e) {}
    Tenup.takePending().then(function (r) { if (r && r.data) handleNativeResult(r.data, true); }).catch(function () {}).then(function () {
      // Après une mise à jour de l'appli, on resynchronise tout de suite : les nouvelles règles
      // (type de compétition, sens des scores…) s'appliquent à tout le palmarès sans attendre.
      var fresh = S.syncedVersion !== CONFIG.VERSION;
      if (S.tenup.linked && (fresh || !S.tenup.lastAuto || Date.now() - S.tenup.lastAuto > 2 * 3600 * 1000)) {
        var p = nativeRefresh(true);
        if (fresh && p && p.then) p.then(function () { S.syncedVersion = CONFIG.VERSION; save(); });
      }
    });
  }
  // Moteur web Android trop ancien : la page Ten'Up s'affiche mal et ses boutons ne répondent pas
  function oldWebView() {
    if (!(CAP && CAP.getPlatform && CAP.getPlatform() === "android")) return 0;
    var m = /Chrome\/(\d+)/.exec(navigator.userAgent); var v = m ? +m[1] : 0;
    return v && v < 100 ? v : 0;
  }
  function nativeTenupHtml() {
    var s = "", ow = oldWebView();
    if (ow) s += '<div class="card terre" style="gap:8px"><b>Ton téléphone doit d\'abord mettre à jour son moteur web</b>' +
      '<span style="font-size:14px;line-height:1.45">Montée affiche Ten\'Up avec le moteur web d\'Android, et celui de ce téléphone est trop ancien (version ' + ow + ') : la page Ten\'Up s\'affiche en vrac et ses boutons ne marchent pas. Dans le Play Store, mets à jour <b>Android System WebView</b> et <b>Chrome</b>, puis rouvre Montée.</span>' +
      '<a class="btn primary small" href="https://play.google.com/store/apps/details?id=com.google.android.webview">Mettre à jour Android System WebView</a>' +
      '<a class="btn soft small" style="background:var(--chip)" href="https://play.google.com/store/apps/details?id=com.android.chrome">Mettre à jour Chrome</a></div>';
    if (UI.importError) s += '<div class="card terre"><b>Ten\'Up</b><span>' + esc(UI.importError) + "</span>" +
      (S.tenup.linked && !S.tenup.expired ? '<button class="btn soft small" data-a="nativeConnect">' + I.link + " Me reconnecter à Ten'Up</button>" : "") + "</div>";
    if (!S.tenup.linked || S.tenup.expired) {
      s += '<p class="lead" style="font-size:16px">' + (S.tenup.expired ? "Ta session Ten'Up a expiré. Reconnecte-toi : tes matchs reviendront tout seuls." :
        "Connecte ton compte Ten'Up une fois, sur la page officielle de la FFT. Ensuite, Montée récupère tes nouveaux matchs toute seule et te prévient.") + "</p>";
      s += '<button class="btn primary" data-a="nativeConnect">' + I.link + " " + (S.tenup.expired ? "Me reconnecter à Ten'Up" : "Connecter mon compte Ten'Up") + "</button>";
      s += '<p class="small">Tu te connectes directement sur tenup.fft.fr. Montée ne voit pas ton mot de passe et rien n\'est envoyé sur un serveur. Montée n\'est pas lié à la FFT.</p>';
    } else {
      s += '<div class="card"><span class="eyebrow" style="color:var(--gazon)">Compte Ten\'Up lié</span>' +
        '<span style="font-size:15px">' + (S.tenup.lastImport ? "Dernière mise à jour : " + esc(fdate(S.tenup.lastImport)).replace(/\.$/, "") + ". " : "") + "Montée vérifie tes nouveaux matchs à chaque ouverture, et de temps en temps en arrière-plan.</span>" +
        '<button class="btn primary small" data-a="nativeRefresh"' + (UI.loading ? " disabled" : "") + ">" + (UI.loading ? '<span class="spin"></span> Lecture de Ten\'Up…' : "Actualiser maintenant") + "</button></div>";
      s += '<label class="card" style="flex-direction:row;align-items:center;justify-content:space-between;gap:12px;cursor:pointer"><span><b style="display:block;font-size:15px">Notifications</b><span class="small">Nouveau match détecté, points, montée ou pas, jour de sortie</span></span>' +
        '<input type="checkbox" role="switch" data-a="notifSwitch"' + (S.notif ? " checked" : "") + "></label>";
      s += '<button class="linkbtn" data-a="nativeLogout">Délier mon compte Ten\'Up</button>';
    }
    s += '<details class="card"><summary style="font-weight:600;cursor:pointer;min-height:28px">Sans compte : importer un PDF</summary>' +
      '<span style="font-size:14px;line-height:1.45">' + (CAP && CAP.getPlatform && CAP.getPlatform() === "android" ? "Sur Ten\'Up dans Chrome, onglet « Simu » : menu ⋮ › Partager › Imprimer › Enregistrer au format PDF." : "Sur Ten\'Up, onglet « Simu », capture d\'écran › Page entière › Enregistrer le PDF dans Fichiers.") + "</span>" +
      '<label class="btn soft small" style="cursor:pointer;background:var(--chip)">' + (UI.loading ? '<span class="spin"></span> Lecture…' : "Choisir le PDF") + '<input type="file" accept="application/pdf,.pdf" data-a="pdfFile" hidden></label></details>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="skipImport">Pas de compte Ten\'Up ? Je saisis mes matchs à la main</button>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button>';
    return s;
  }

  // ---------- Assistant favori Ten'Up : une étape par écran, avec le dessin de ce qu'on voit ----------
  function wizardHtml(ios, android) {
    var plat = UI.platform || (ios ? "ios" : android ? "android" : "ios"), st = UI.wiz == null ? 0 : UI.wiz, N = 5;
    var and = plat === "android";
    var mock = function (inner, cap) { return '<div class="mock" aria-hidden="true">' + inner + "</div>" + (cap ? '<span class="small" style="text-align:center">' + cap + "</span>" : ""); };
    var bar = function (txt, sugg) { return '<div class="mk-bar"><span class="mk-url">' + txt + '<i class="mk-caret"></i></span></div>' + (sugg ? '<div class="mk-sugg"><span class="mk-star">' + "☆" + "</span><span><b>montee</b><br><span class=\"mk-dim\">javascript:(function(){…</span></span></div>" : ""); };
    var steps = [
      { t: "Relie Ten'Up à Montée", b: "Une seule fois, 2 minutes. Tu vas créer un favori nommé <b>montee</b> dans " + (and ? "Chrome" : "Safari") + ". Ensuite, pour récupérer ton palmarès, tu ouvres Ten'Up et tu touches ce favori. C'est tout.",
        m: mock('<div class="mk-flow"><span class="mk-pill">Ten\'Up</span><span class="mk-arrow">→</span><span class="mk-pill hl">☆ montee</span><span class="mk-arrow">→</span><span class="mk-pill">Montée</span></div>'),
        go: '<button class="btn primary" data-a="wizGo" data-v="1">C\'est parti</button>' },
      { t: "Copie le code du favori", b: "C'est le petit programme qui lira ton palmarès sur Ten'Up, depuis ton téléphone. Rien ne passe par un serveur.",
        m: "", go: '<button class="btn primary" data-a="wizCopy">Copier le code</button>' },
      { t: and ? "Ajoute n'importe quelle page en favori" : "Crée un signet",
        b: and ? "Dans Chrome, sur cette page par exemple : menu <b>⋮</b> en haut à droite, puis touche l'<b>étoile ☆</b>. Un bandeau « Favori ajouté » s'affiche en bas : touche <b>Modifier</b>." :
          "Dans Safari, sur cette page par exemple : touche <b>Partager</b> (le carré avec la flèche), puis <b>Ajouter un signet</b>, puis <b>Enregistrer</b>.",
        m: and ? mock('<div class="mk-menu"><span>← &nbsp; ☆ &nbsp; ⤓ &nbsp; ⓘ &nbsp; ⟳</span><span class="mk-hl">☆</span></div><div class="mk-snack">Favori ajouté <b>Modifier</b></div>', "Le menu ⋮ de Chrome, puis le bandeau en bas") :
          mock('<div class="mk-sheet"><span>Copier</span><span class="mk-hl2">Ajouter un signet</span><span>Ajouter à l\'écran d\'accueil</span></div>', "La feuille Partager de Safari"),
        go: '<button class="btn primary" data-a="wizGo" data-v="3">C\'est fait</button>' },
      { t: "Remplace son adresse par le code", b: and ? "Dans l'écran Modifier : nom <b>montee</b>, puis dans URL, efface tout et colle. Valide avec la flèche en haut." :
          "Ouvre tes signets (icône livre), touche <b>Modifier</b> en bas, puis le signet. Nom : <b>montee</b>. Adresse : efface tout et colle. Touche <b>OK</b>.",
        m: mock('<div class="mk-form"><span class="mk-dim">Nom</span><span class="mk-field">montee</span><span class="mk-dim">' + (and ? "URL" : "Adresse") + '</span><span class="mk-field hl">javascript:(function(){…<i class="mk-caret"></i></span></div>', "Efface l'ancienne adresse, colle à la place"),
        go: '<button class="btn primary" data-a="wizGo" data-v="4">C\'est fait</button><button class="btn soft small" data-a="wizCopy" data-v="stay" style="background:var(--chip)">Recopier le code</button>' },
      { t: "Utilise-le sur Ten'Up", b: "Ouvre Ten'Up dans " + (and ? "Chrome" : "Safari") + " et connecte-toi. Touche la barre d'adresse, tape <b>montee</b>, puis touche le favori proposé" + (and ? " (avec l'étoile)" : "") + ". Un bouton <b>Copier pour Montée</b> apparaît : touche-le, puis reviens ici.",
        m: mock(bar("montee", true), "Tape « montee » : le favori apparaît dans les suggestions"),
        go: '<a class="btn primary" href="https://tenup.fft.fr" target="_blank" rel="noopener" data-a="openTenup">Ouvrir Ten\'Up</a><button class="btn ' + (UI.backFromTenup ? "balle" : "soft") + '" data-a="importClipboard"' + (UI.backFromTenup ? "" : ' style="background:var(--chip)"') + ">J'ai copié : importer</button>" }
    ];
    var x = steps[st];
    var s = '<div class="seg" role="group" aria-label="Ton téléphone"><button data-a="platform" data-v="ios" class="' + (!and ? "on" : "") + '">iPhone · Safari</button><button data-a="platform" data-v="android" class="' + (and ? "on" : "") + '">Android · Chrome</button></div>';
    s += '<div class="card wiz"><div class="wiz-dots" aria-label="Étape ' + (st + 1) + " sur " + N + '">' + steps.map(function (_, i) { return '<i class="' + (i <= st ? "on" : "") + '"></i>'; }).join("") + "</div>" +
      '<span class="eyebrow" style="color:var(--muted)">Étape ' + (st + 1) + " sur " + N + '</span><span style="font-size:24px;font-weight:700;letter-spacing:-.02em;line-height:1.15">' + x.t + "</span>" +
      '<span style="font-size:16px;line-height:1.5">' + x.b + "</span>" + x.m + '<div class="stack" style="gap:8px">' + x.go + "</div>" +
      (st > 0 ? '<button class="linkbtn" data-a="wizGo" data-v="' + (st - 1) + '" style="align-self:flex-start;padding:0">← Étape précédente</button>' : "") + "</div>";
    if (UI.importError) s = '<div class="card terre"><b>Import impossible</b><span>' + esc(UI.importError) + "</span></div>" + s;
    s += '<details class="card"><summary style="font-weight:600;cursor:pointer;min-height:28px">Bloqué ? Autres solutions</summary>' +
      '<span style="font-size:15px;line-height:1.45">Sans favori, tu peux importer le PDF de la page « Simu » de Ten\'Up (sans dates ni scores), ou ajouter tes derniers matchs à la main. Si tu as déjà des matchs dans Montée, l\'import Ten\'Up ne les comptera pas en double.</span>' +
      '<div class="grid2"><button class="btn soft small" style="background:var(--chip)" data-a="tenupMethod" data-v="pdf">Importer un PDF</button><button class="btn soft small" style="background:var(--chip)" data-a="newMatch">Ajouter un match</button></div>' +
      '<span style="font-size:15px">Le favori a copié quelque chose mais l\'import ne part pas ? Colle-le ici :</span>' +
      '<div class="field" style="padding:0"><label for="imp" class="sr">Texte à importer</label><textarea id="imp" data-f="importText" placeholder="Colle ici">' + esc(UI.importText) + "</textarea></div>" +
      '<button class="btn soft small" data-a="parseImport" style="background:var(--chip)">Lire</button></details>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="skipImport">Pas de compte Ten\'Up ? Je saisis mes matchs à la main</button>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button>';
    return s;
  }
  V.tenup = function () {
    var s = '<div class="screen">' + topbar(NATIVE ? "Ton compte Ten'Up" : "Importer depuis Ten'Up", S.onboarded ? "" : "Pour commencer");
    if (UI.importRows) {
      var rows = UI.importRows, n = rows.filter(function (r) { return r.keep; }).length;
      s += '<p class="lead">' + plural(rows.length, "match trouvé", "matchs trouvés") + ". Vérifie, corrige si besoin, puis importe.</p>";
      s += '<div class="list">' + rows.map(function (r, i) {
        var ro = '<option value="">?</option><option' + (r.oppRank === "NC" ? " selected" : "") + ">NC</option>" + E.ECHELONS.slice(0, 22).map(function (e) { return "<option" + (r.oppRank === e ? " selected" : "") + ">" + e + "</option>"; }).join("") + '<option value="N°"' + (/^N°/.test(r.oppRank) ? " selected" : "") + ">N°</option>";
        return '<div class="preview-row' + (r.ok ? "" : " warnrow") + '"><input type="checkbox" aria-label="Importer ce match" data-ir="' + i + '" data-k="keep"' + (r.keep ? " checked" : "") + ' style="width:22px;height:22px;accent-color:var(--gazon);margin-top:2px">' +
          '<div><div style="font-size:15px;font-weight:600">' + esc(r.opp || "Adversaire ?") + ' <span class="muted" style="font-weight:400">· ' + esc(fdate(r.date)) + "</span></div>" +
          '<div class="small">' + esc(r.score || "score ?") + (r.dup ? " · déjà dans ton palmarès" : "") + "</div>" +
          '<div class="edit"><select aria-label="Classement de l\'adversaire" data-ir="' + i + '" data-k="oppRank">' + ro + "</select>" +
          '<select aria-label="Résultat" data-ir="' + i + '" data-k="result"><option value="">?</option><option value="V"' + (r.result === "V" ? " selected" : "") + '>Victoire</option><option value="D"' + (r.result === "D" ? " selected" : "") + ">Défaite</option></select>" +
          '<input type="date" aria-label="Date" data-ir="' + i + '" data-k="date" value="' + esc(r.date) + '"></div></div></div>';
      }).join("") + "</div>";
      s += '<div class="spacer"></div><button class="btn primary" data-a="doImport"' + (n ? "" : " disabled") + ">Importer " + plural(n, "match", "matchs") + "</button>" +
        '<button class="linkbtn" data-a="cancelImport">Recommencer</button></div>';
      return s;
    }
    if (NATIVE) return s + nativeTenupHtml() + "</div>";
    var ios = /iphone|ipad|ipod/i.test(navigator.userAgent), android = /android/i.test(navigator.userAgent);
    var step = function (n, title, body) {
      return '<div style="display:flex;gap:12px;align-items:flex-start"><span class="vd lg" style="background:var(--solid);color:var(--on-solid);flex-shrink:0">' + n + '</span><span style="display:flex;flex-direction:column;gap:6px;flex:1;min-width:0"><b style="font-size:16px">' + title + "</b>" + (body ? '<span style="font-size:14px;line-height:1.45">' + body + "</span>" : "") + "</span></div>";
    };
    if (UI.importError) s += '<div class="card terre"><b>Import impossible</b><span>' + esc(UI.importError) + "</span></div>";
    var meth = UI.tenupMethod || "fav";
    var origin = location.origin + location.pathname.replace(/index\.html$/, "").replace(/\/$/, "");
    s += '<div class="seg" role="group" aria-label="Méthode"><button data-a="tenupMethod" data-v="fav" class="' + (meth === "fav" ? "on" : "") + '">Favori · complet</button><button data-a="tenupMethod" data-v="pdf" class="' + (meth === "pdf" ? "on" : "") + '">PDF · simple</button></div>';
    if (meth === "fav") {
      var ready = !!(S.tenup.setup && S.tenup.setup.fav && S.tenup.setup.favVersion === T.VERSION);
      s += '<p class="lead" style="font-size:16px">Le favori Montée lit Ten\'Up comme le fait la page elle-même : <b>dates, scores, victoires, classements et simulation officielle</b>. Ton mot de passe ne passe jamais par Montée.</p>';
      var setup = '<div class="card balle"><span class="eyebrow">' + (S.tenup.setup && S.tenup.setup.fav && !ready ? "Mets ton favori à jour" : "Une seule fois · 1 minute") + '</span><div class="stack" style="gap:14px">' +
        step(1, "Copie le favori", '<button class="btn primary small" data-a="copyBookmark" style="margin-top:4px">Copier</button>') +
        (ios ? step(2, "Crée un signet dans Safari", "Sur n'importe quelle page : Partager › <b>Ajouter un signet</b> › Enregistrer.") +
          step(3, "Colle-le comme adresse", "Icône livre › <b>Modifier</b› › touche le signet. Nom : <b>Montée</b>. Adresse : efface tout, colle.".replace("</b›", "</b>")) :
          (android ? step(2, "Crée un favori dans Chrome", "Sur n'importe quelle page : menu ⋮ › touche l'<b>étoile</b>.") +
            step(3, "Colle-le comme adresse", "Menu ⋮ › <b>Favoris</b> › appui long sur ce favori › <b>Modifier</b>. Nom : <b>Montée</b>. URL : efface tout, colle.") :
            step(2, "Crée un favori", "Ajoute n'importe quelle page en favori, puis modifie-le. Nom : <b>Montée</b>. Adresse : efface tout, colle."))) +
        '<button class="btn soft small" data-a="setupFav">C\'est fait</button></div></div>';
      var use = '<div class="card"><span class="eyebrow" style="color:var(--gazon)">Pour actualiser</span><div class="stack" style="gap:14px">' +
        step(1, "Ouvre Ten'Up, connecté", '<a class="btn soft small" href="https://tenup.fft.fr" target="_blank" rel="noopener" data-a="openTenup" style="margin-top:4px;background:var(--chip)">Ouvrir Ten\'Up</a>N\'importe quelle page de ton compte. Si Ten\'Up s\'ouvre à l\'intérieur de Montée, touche l\'icône ' + (/android/i.test(navigator.userAgent) ? "⋮ › Ouvrir dans Chrome" : "Safari (boussole) en bas à droite") + ".") +
        step(2, "Tape « Montée » dans la barre d'adresse", (android ? "Touche le favori ☆ Montée proposé" : "Touche le signet") + ", puis <b>Copier pour Montée</b>." + (android ? " Si Montée est installée sur ton écran d'accueil, tu peux aussi toucher « Ou ouvrir Montée » : l'import est direct." : "")) +
        step(3, "Reviens ici", '<button class="btn ' + (UI.backFromTenup ? "balle" : "primary") + ' small" data-a="importClipboard" style="margin-top:4px">Importer</button>') +
        "</div></div>";
      if (!ready || UI.wiz != null) return '<div class="screen">' + topbar("Relier Ten'Up", S.onboarded ? "" : "Pour commencer") + wizardHtml(ios, android) + "</div>";
      s += use + '<button class="linkbtn" data-a="wizGo" data-v="1">Réinstaller le favori, pas à pas</button>';
    } else {
      s += '<p class="lead" style="font-size:16px">Sans rien installer : Montée lit le PDF de la page « Simu ». Mais Ten\'Up n\'y met ni les dates ni les scores.</p>';
      s += '<div class="card"><div class="stack" style="gap:16px">' +
        step(1, "Ouvre l'onglet « Simu » de Ten'Up", '<a class="btn soft small" href="https://tenup.fft.fr" target="_blank" rel="noopener" style="margin-top:4px;background:var(--chip)">Ouvrir Ten\'Up</a>') +
        step(2, "Enregistre la page en PDF", ios ? "Capture d'écran › touche l'aperçu › <b>Page entière</b> › <b>OK › Enregistrer le PDF dans Fichiers</b>." :
          android ? "Menu ⋮ › <b>Partager</b> › <b>Imprimer</b> › <b>Enregistrer au format PDF</b>." : "Menu du navigateur › <b>Imprimer</b> › <b>Enregistrer au format PDF</b>.") +
        step(3, "Donne-le à Montée", '<label class="btn primary small" style="margin-top:4px;cursor:pointer">' + (UI.loading ? '<span class="spin"></span> Lecture…' : "Choisir le PDF") + '<input type="file" accept="application/pdf,.pdf" data-a="pdfFile" hidden></label>') +
        "</div></div>";
    }
    s += '<details class="card"><summary style="font-weight:600;cursor:pointer;min-height:28px">Ça ne marche pas ?</summary>' +
      '<span style="font-size:15px">Colle ici ce que le favori a copié.</span>' +
      '<div class="field" style="padding:0"><label for="imp" class="sr">Texte à importer</label><textarea id="imp" data-f="importText" placeholder="Colle ici">' + esc(UI.importText) + "</textarea></div>" +
      '<button class="btn soft small" data-a="parseImport" style="background:var(--chip)">Lire</button></details>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="skipImport">Pas de compte Ten\'Up ? Je saisis mes matchs à la main</button>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button>';
    return s + "</div>";
  };

  // ---------- Thèmes ----------
  var THEMES = [["auto", "Auto", "Lin le jour, Nuit le soir"], ["lin", "Lin", "Clair, le classique"], ["nuit", "Nuit", "Sombre"], ["terre", "Terre battue", "Fond d'argile ocre, vert profond"], ["dur", "Dur", "Bleu court sous les projecteurs"], ["gazon", "Gazon", "Blanc et gazon tondu"]];
  var THEME_SW = { lin: ["#F6F2EC", "#FFFFFF", "#1F5C3F", "#D4E64A"], nuit: ["#17181C", "#272930", "#6FC28F", "#D4E64A"], terre: ["#B5582D", "#FFFFFF", "#0B4D35", "#FFF4E8"], dur: ["#2F5584", "#FFFFFF", "#E3F25B", "#EAF1FB"], gazon: ["#F7F7F2", "#FFFFFF", "#006633", "#0F4A28"] };
  var darkMq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
  function themeNow() { var t = (S.prefs && S.prefs.theme) || "auto"; return t === "auto" ? (darkMq && darkMq.matches ? "nuit" : "lin") : t; }
  function applyTheme() {
    var t = themeNow(), r = document.documentElement;
    if (t === "lin") r.removeAttribute("data-theme"); else r.setAttribute("data-theme", t);
    var bg = (THEME_SW[t] || THEME_SW.lin)[0];
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute("content", bg);
    // Barres système Android (notifications, navigation) à la couleur du fond, icônes claires en Nuit
    if (Tenup && Tenup.setBars) try { Tenup.setBars({ color: bg, light: ["nuit", "terre", "dur"].indexOf(t) < 0 }).catch(function () {}); } catch (e) {}
  }
  if (darkMq && darkMq.addEventListener) darkMq.addEventListener("change", function () { applyTheme(); syncWidgets(true); });
  applyTheme();

  // ---------- Réglages ----------
  // ---------- Santé connectée (Health Connect, Android 14+) : séances de tennis → entraînements ----------
  // Lecture seule. Rien n'est ajouté sans le joueur ; les séances des jours de match sont écartées (pas de doublon).
  var HC_OK = NATIVE;
  var HC_NAME = IOS ? "Apple Santé" : "Health Connect";
  function hcOn() { return !!(S.health && S.health.on); }
  function hcIso(ms) { var d = new Date(ms); return d.getFullYear() + "-" + (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? "0" : "") + d.getDate(); }
  function hcMin(x) { return Math.max(5, Math.round((x.end - x.start) / 60000 / 5) * 5); }
  // Jours de match dont la séance de montre n'est pas encore connue. Un match déjà rattaché à sa séance
  // libère la journée : une autre séance ce jour-là (entraînement du matin, match le soir) est un vrai entraînement.
  function hcMatchDays() { var o = {}; S.matches.forEach(function (m) { if (m.date && !m.hid && !m.wo) o[m.date] = m; }); return o; }
  function hcWhen(x) {
    var d = new Date(x.start), iso = hcIso(x.start), td = E.iso(today()), y = new Date(today().getTime() - 864e5);
    var day = iso === td ? "Aujourd'hui" : iso === E.iso(y) ? "Hier" : JOURS[d.getDay()].replace(/^./, function (c) { return c.toUpperCase(); }).slice(0, 3) + ". " + d.getDate() + " " + MOIS[d.getMonth()];
    return day + " · " + d.getHours() + " h" + (d.getMinutes() ? " " + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes() : "");
  }
  function hcSrc(x) {
    var o = x.origin || "";
    var n = x.device || ({ "com.google.android.apps.fitness": "Google Health", "com.google.android.apps.healthdata": "Health Connect", "com.sec.android.app.shealth": "Samsung Health", "com.fitbit.FitbitMobile": "Fitbit", "com.garmin.android.apps.connectmobile": "Garmin Connect", "com.huawei.health": "Huawei Santé", "com.mi.health": "Mi Fitness", "com.xiaomi.wearable": "Mi Fitness", "com.strava": "Strava" })[o] || (o ? o.split(".").slice(-1)[0] : "Health Connect");
    return (x.deviceType === 1 || x.deviceType === 6 || /watch|montre/i.test(n) ? "⌚ " : "♥ ") + n;
  }
  // Séances de tennis : type « tennis », titre qui contient « tennis », ou séance que le joueur a marquée comme du tennis
  function hcIsTennis(x) { return x.tennis === true || x.tennis == null || /tennis/i.test(x.title || "") || !!((S.health && S.health.extra) || {})[x.id]; }
  function hcAll() { return (UI.hc && UI.hc.sessions) || []; }
  function hcSessions() { return hcAll().filter(function (x) { return hcIsTennis(x) && !/table/i.test(x.typeName || ""); }); }
  var HC_TYPES = { RUNNING: "Course", RUNNING_TREADMILL: "Tapis de course", WALKING: "Marche", BIKING: "Vélo", BIKING_STATIONARY: "Vélo d'appartement", OTHER_WORKOUT: "Autre", BADMINTON: "Badminton", SQUASH: "Squash", RACQUETBALL: "Racquetball", TABLE_TENNIS: "Tennis de table", STRENGTH_TRAINING: "Musculation", WEIGHTLIFTING: "Haltérophilie", HIKING: "Randonnée", SWIMMING_POOL: "Natation", SWIMMING_OPEN_WATER: "Natation", YOGA: "Yoga", HIGH_INTENSITY_INTERVAL_TRAINING: "HIIT", CALISTHENICS: "Renforcement", ELLIPTICAL: "Elliptique", FOOTBALL_AMERICAN: "Football américain", SOCCER: "Football", BASKETBALL: "Basket", VOLLEYBALL: "Volley", GYMNASTICS: "Gym", STRETCHING: "Étirements", EXERCISE_CLASS: "Cours collectif", PILATES: "Pilates", ROWING_MACHINE: "Rameur", STAIR_CLIMBING: "Escaliers", UNKNOWN: "Inconnu" };
  function hcTypeLabel(x) { var n = x.typeName || ""; return HC_TYPES[n] || (n ? n.charAt(0) + n.slice(1).toLowerCase().replace(/_/g, " ") : "Séance"); }
  // Séances à proposer : pas encore traitées, pas un jour de match, au moins 10 minutes
  function hcPending(days) {
    if (!hcOn()) return [];
    var done = S.health.done || {}, md = hcMatchDays(), lim = Date.now() - (days || 14) * 864e5;
    return hcSessions().filter(function (x) { return !done[x.id] && x.start >= lim && x.end - x.start >= 10 * 60000 && !md[hcIso(x.start)]; })
      .sort(function (a, b) { return b.start - a.start; });
  }
  function hcSync() {
    if (!HC_OK || !Tenup || !Tenup.healthSync) return;
    var md = Object.keys(hcMatchDays()).filter(function (d) { return d >= E.iso(new Date(Date.now() - 60 * 864e5)); });
    try { var r = Tenup.healthSync({ on: hcOn(), notify: !S.health || S.health.notify !== false, known: JSON.stringify(Object.keys((S.health && S.health.done) || {})), matchDays: JSON.stringify(md), since: String((S.health && S.health.since) || 0) }); if (r && r.catch) r.catch(function () {}); } catch (e) {}
  }
  function hcStatus() {
    if (!HC_OK || !Tenup || !Tenup.healthStatus) return Promise.resolve(null);
    return Promise.resolve(Tenup.healthStatus()).then(function (st) { UI.hc = UI.hc || {}; UI.hc.st = st; return st; }, function () { return null; });
  }
  function hcLoad(days, quiet) {
    if (!HC_OK || !Tenup || !Tenup.healthRead) return Promise.resolve();
    var before = hcPending().map(function (x) { return x.id; });
    UI.hc = UI.hc || {}; UI.hc.busy = true;
    return Promise.resolve(Tenup.healthRead({ days: days || 30 })).then(function (r) {
      UI.hc.busy = false;
      if (r && r.sessions) { try { UI.hc.sessions = JSON.parse(r.sessions); UI.hc.err = null; UI.hc.at = Date.now(); } catch (e) {} }
      else UI.hc.err = (r && r.error) || "lecture impossible";
      var fresh = hcPending().filter(function (x) { return before.indexOf(x.id) < 0; });
      hcSync();
      if (fresh.length && !quiet && route() !== "" && route().indexOf("sante") !== 0) toast(fresh.length > 1 ? fresh.length + " nouvelles séances de tennis : retrouve-les sur l'accueil." : "Nouvelle séance de tennis détectée : retrouve-la sur l'accueil.");
      if (route() === "" || route().indexOf("sante") === 0) render();
    }, function () { UI.hc.busy = false; });
  }
  // Au réveil de l'appli : on relit les séances récentes
  function hcWake() {
    if (!HC_OK || !hcOn()) return;
    hcStatus().then(function (st) { if (st && st.granted) hcLoad(30); else { UI.hc = UI.hc || {}; UI.hc.lost = true; } });
  }
  // Séance de la montre + match le même jour = la même chose : la séance devient la durée réelle du match.
  // Cas couverts : entraînement importé de la montre puis match arrivé par la synchro Ten'Up (ou saisi à la main),
  // et séance encore en attente le jour d'un match. Renvoie le nombre de séances rattachées.
  function hcMerge(only) {
    var n = 0, ses = HC_OK ? hcSessions() : [], done = (S.health && S.health.done) || {};
    S.matches.forEach(function (m) {
      if (only && !only[m.id]) return;
      if (!m.date || m.wo || m.dbl || m.hid) return;
      var est = estMinutes(m);
      var tr = (S.trainings || []).filter(function (t) { return t.src === "sante" && t.date === m.date; })
        .sort(function (a, b) { return Math.abs(a.minutes - est) - Math.abs(b.minutes - est); })[0];
      if (tr) {
        if (!m.minutes) m.minutes = tr.minutes;
        m.hid = tr.hid; if (tr.at) m.hat = tr.at;
        ["racketId", "string", "tension", "tensionCross", "feel", "note"].forEach(function (k) { if (tr[k] != null && tr[k] !== "" && (m[k] == null || m[k] === "")) m[k] = tr[k]; });
        S.trainings = S.trainings.filter(function (t) { return t !== tr; });
        if (tr.hid) hcDone(tr.hid, "match");
        n++; return;
      }
      var x = ses.filter(function (y) { return !done[y.id] && hcIso(y.start) === m.date && y.end - y.start >= 10 * 60000; })
        .sort(function (a, b) { return Math.abs(hcMin(a) - est) - Math.abs(hcMin(b) - est); })[0];
      if (x) { if (!m.minutes) m.minutes = hcMin(x); m.hid = x.id; m.hat = x.start; hcDone(x.id, "match"); n++; }
    });
    return n;
  }
  // Seulement les matchs arrivés depuis `before` (ids avant l'import) : on ne touche jamais à l'historique
  function hcMergeNew(before) { var o = {}, k = 0; S.matches.forEach(function (m) { if (!before[m.id]) { o[m.id] = 1; k++; } }); return k ? hcMerge(o) : 0; }
  function idSet() { var o = {}; S.matches.forEach(function (m) { o[m.id] = 1; }); return o; }
  function hcMergeToast(n) { if (n) setTimeout(function () { toast(n > 1 ? n + " séances de ta montre étaient des matchs : rattachées, pas de doublon." : "La séance de ta montre était ce match : rattachée, pas de doublon."); }, 1600); }
  // Fiche de match : la séance de montre rattachée, et l'échange si c'était l'autre séance du jour
  function hcHour(ms) { var d = new Date(ms); return d.getHours() + " h" + (d.getMinutes() ? (d.getMinutes() < 10 ? " 0" : " ") + d.getMinutes() : ""); }
  function hcMatchLine(m) {
    if (!m.hid) return "";
    var others = (S.trainings || []).filter(function (t) { return t.src === "sante" && t.date === m.date; });
    var s = '<div class="card hc-ml"><span class="hc-ml-t">' + I.clock + "<span>Durée de ta montre" + (m.hat ? " · séance de " + hcHour(m.hat).replace(" ", "\u00a0") : "") + "</span></span>";
    others.forEach(function (t) {
      s += '<button class="linkbtn" data-a="hcSwap" data-id="' + esc(t.id) + '">C\'était la séance de ' + (t.at ? hcHour(t.at) : "l'autre") + " (" + esc(fmtDur(t.minutes)) + ")</button>";
    });
    return s + "</div>";
  }
  function hcTraining(x, racketId) {
    var r = racketId ? racket(racketId) : racketFor("train");
    return { id: uid(), date: hcIso(x.start), minutes: hcMin(x), racketId: r ? r.id : "", string: r ? r.string || "" : "", tension: r ? r.tension || null : null, tensionCross: r && r.tensionCross != null ? r.tensionCross : null, newString: false, feel: null, note: "", hid: x.id, at: x.start, src: "sante" };
  }
  function hcDone(id, how) { S.health.done = S.health.done || {}; S.health.done[id] = how; }
  // Carte d'accueil : la dernière séance détectée
  function hcHomeCard() {
    var pend = hcPending(); if (!pend.length) return "";
    var x = pend[0], rk = racketFor("train");
    return '<div class="card insight hc-new" style="gap:8px"><span class="eyebrow">Nouvelle séance · ' + HC_NAME + '</span>' +
      '<b style="font-size:20px;letter-spacing:-.02em;line-height:1.25">' + esc(hcWhen(x)) + " · " + esc(fmtDur(hcMin(x))) + " de tennis</b>" +
      '<span style="font-size:14px">On l\'ajoute à tes entraînements' + (rk ? ", avec ta " + esc(rk.name) : "") + " ?" + (pend.length > 1 ? ' <a href="#/sante/revue">+' + (pend.length - 1) + " autre" + (pend.length > 2 ? "s" : "") + "</a>" : "") + "</span>" +
      '<div class="hc-btns"><button class="btn soft small" data-a="hcMatch" data-id="' + esc(x.id) + '" style="background:var(--chip)">Un match</button><button class="btn soft small" data-a="hcDetail" data-id="' + esc(x.id) + '" style="background:var(--chip)">Détailler</button><button class="btn primary small" data-a="hcAdd" data-id="' + esc(x.id) + '">Ajouter</button></div><button class="linkbtn hc-ign" data-a="hcIgnore" data-id="' + esc(x.id) + '">Ignorer cette séance</button></div>';
  }
  function hcRow(x, md) {
    var m = md[hcIso(x.start)], off = !!m && !(UI.hcForce || {})[x.id], on = !off && (UI.hcSel || {})[x.id] !== false;
    if (off) return '<div class="ses off"><span class="ck">–</span><span class="grow"><span class="t">' + esc(hcWhen(x)) + '</span><span class="s">Jour de match : ' + (m.result === "V" ? "V" : "D") + " contre " + esc(m.opp || "ton adversaire") + '</span><button class="linkbtn" data-a="hcForce" data-id="' + esc(x.id) + '">L\'ajouter quand même</button></span><span class="tag">Écartée</span></div>';
    return '<div class="ses"><button class="ck' + (on ? " on" : "") + '" data-a="hcTick" data-id="' + esc(x.id) + '" aria-pressed="' + on + '" aria-label="Garder cette séance">' + (on ? I.check : "") + '</button><span class="grow" style="display:flex;flex-direction:column;align-items:flex-start;min-width:0"><button class="ses-b" data-a="hcDetail" data-id="' + esc(x.id) + '" style="align-self:stretch"><span class="t">' + esc(hcWhen(x)) + '</span><span class="src">' + esc(hcSrc(x)) + '</span></button><button class="linkbtn ses-m" data-a="hcMatch" data-id="' + esc(x.id) + '">C\'était un match ?</button></span><span class="dur">' + esc(fmtDur(hcMin(x))) + (on ? '<span class="dur-k">entraînement</span>' : "") + "</span></div>";
  }
  V.sante = function (sub) {
    var st = UI.hc && UI.hc.st;
    if (!st && HC_OK && !UI.hcAsked) { UI.hcAsked = true; hcStatus().then(function () { if (route().indexOf("sante") === 0) render(); }); }
    if (sub === "revue" || sub === "nouvelle") return V.santeRevue(sub === "nouvelle");
    var s = '<div class="screen">' + topbar("", "Réglages");
    if (!HC_OK) return s + '<h1 class="hc-h">Santé connectée</h1><div class="card"><span style="font-size:15px">La lecture de tes séances de tennis passe par Health Connect, sur l\'appli Android. Bientôt sur iPhone avec Apple Santé.</span></div></div>';
    if (st && !st.supported) return s + '<h1 class="hc-h">Santé connectée</h1><div class="card"><b>Disponible à partir d\'Android 14</b><span style="font-size:14.5px;line-height:1.45">Health Connect est intégré au téléphone à partir d\'Android 14. Ton téléphone est en Android ' + esc(String(st.sdk >= 33 ? 13 : st.sdk >= 31 ? 12 : "11 ou moins")) + ' : la lecture des séances n\'est pas possible ici pour l\'instant.</span></div></div>';
    if (!hcOn()) {
      s += '<h1 class="hc-h">Tes entraînements, sans les saisir</h1><div class="hc-ill"><i style="background:var(--menthe)">⌚</i><b>→</b><i style="background:var(--balle-soft)">♥</i><b>→</b><i style="background:var(--balle);color:var(--on-balle);font-weight:800;font-size:18px">M</i></div>' +
        '<p class="small" style="text-align:center;margin:0 0 6px">' + (IOS ? "Ton Apple Watch ou ton iPhone → Santé → Montée" : "Ta montre ou ton téléphone → Health Connect → Montée") + '</p>' +
        '<div class="card" style="gap:2px">' + [["Montée lit tes séances de tennis", IOS ? " enregistrées par ton Apple Watch ou ton iPhone dans l'app Santé : date, heure, durée." : " enregistrées dans Google Health, Samsung Health ou par ta montre : date, heure, durée."], ["Les jours de match sont écartés.", " Ton match est déjà dans ton palmarès : pas de doublon dans tes heures de jeu."], ["Rien ne s'ajoute sans toi.", " Tu valides chaque séance, et tu y notes ta raquette et ton ressenti si tu veux."]].map(function (x, i) { return '<div class="pt"><span class="n">' + (i + 1) + "</span><span><b>" + esc(x[0]) + "</b>" + esc(x[1]) + "</span></div>"; }).join("") + "</div>" +
        '<div class="alert" style="margin-top:4px"><span class="badge ok">' + I.check + '</span><span style="font-size:14px">Montée lit seulement. Elle n\'écrit rien dans tes données santé et n\'envoie rien : tout reste sur ton téléphone.</span></div>';
      if (UI.hcDenied) s += '<div class="alert"><span class="badge ko">' + I.warn + '</span><span style="font-size:14px">' + (IOS ? "L\'autorisation n\'a pas été donnée. Active-la dans Réglages → Santé → Accès aux données et appareils → Montée → Entraînements." : "L\'autorisation n\'a pas été donnée. Tu peux l\'activer dans Health Connect : « Montée » → autoriser « Exercice ».") + '</span></div><button class="btn soft" data-a="hcSettings" style="background:var(--card)">Ouvrir Health Connect</button>';
      s += '<div class="savebar-space"></div><div class="savebar" style="flex-direction:column;gap:6px"><button class="btn primary" data-a="hcConnect"' + (UI.hcWait ? " disabled" : "") + ">" + (UI.hcWait ? '<span class="spin"></span> En attente de ' + HC_NAME + '…' : "Connecter " + HC_NAME) + '</button><span class="small" style="text-align:center">Tu pourras te déconnecter quand tu veux, dans Réglages.</span></div>';
      return s + "</div>";
    }
    var lost = st && !st.granted;
    s += '<h1 class="hc-h">Santé connectée</h1>';
    if (lost) s += '<div class="alert"><span class="badge ko">' + I.warn + '</span><span style="font-size:14px">' + (IOS ? "Montée ne voit plus tes séances. Vérifie dans Réglages → Santé → Accès aux données et appareils → Montée." : "Montée n\'a plus accès à tes séances. Autorise « Exercice » pour Montée dans Health Connect.") + '</span></div><button class="btn soft" data-a="hcSettings" style="background:var(--card)">Ouvrir Health Connect</button>';
    var pend = hcPending(30).length;
    s += '<div class="card" style="padding:0"><div class="row"><span class="grow"><b style="font-size:15px">' + HC_NAME + '</b><span class="small">' + (UI.hc && UI.hc.at ? "Dernière lecture à " + new Date(UI.hc.at).getHours() + " h " + (new Date(UI.hc.at).getMinutes() < 10 ? "0" : "") + new Date(UI.hc.at).getMinutes() : "Lecture à chaque ouverture de Montée") + "</span></span>" + (lost ? '<span class="tag ko">Accès coupé</span>' : '<span class="tag ok">Connecté</span>') + "</div>" +
      '<label class="row" style="border-top:1px solid var(--line);cursor:pointer"><span class="grow"><span style="font-size:15px">Me prévenir des nouvelles séances</span><span class="small">' + (IOS ? "Notification même quand Montée est fermée : iOS décide du moment, en général dans l'heure." : st && st.bgPossible ? (st.background ? "Notification même quand Montée est fermée." : "Notification quand Montée est fermée : autorise aussi « Lecture en arrière-plan » dans Health Connect.") : "Sur l'accueil, à l'ouverture de Montée (Android 14 ne permet pas la lecture en arrière-plan).") + '</span></span><input type="checkbox" role="switch" data-a="hcNotify"' + (S.health.notify !== false ? " checked" : "") + "></label>" +
      '<a class="row" href="#/sante/revue" style="border-top:1px solid var(--line)"><span class="grow"><span style="font-size:15px">Revoir les séances</span><span class="small">' + (pend ? plural(pend, "séance") + " à trier sur 30 jours" : "Tout est à jour") + "</span></span>" + I.next + "</a>" +
      (!IOS && st && st.bgPossible && !st.background && !lost ? '<button class="row" data-a="hcSettings" style="border:0;border-top:1px solid var(--line);background:none;width:100%;text-align:left;font:inherit;color:inherit"><span class="grow" style="font-size:15px">Autoriser la lecture en arrière-plan</span>' + I.next + "</button>" : "") +
      '<button class="row" data-a="hcOff" style="border:0;border-top:1px solid var(--line);background:none;width:100%;text-align:left;font:inherit"><span class="grow" style="font-size:15px;color:var(--terre)">Se déconnecter</span></button></div>';
    s += '<p class="small">Montée lit seulement tes séances de type « tennis » : date, heure, durée, et l\'appareil qui l\'a enregistrée. Rien n\'est écrit dans tes données santé ni envoyé ailleurs.</p>';
    return s + "</div>";
  };
  V.santeRevue = function (fromNotif) {
    var s = '<div class="screen">' + topbar("", HC_NAME + " · 30 derniers jours");
    if (!hcOn()) { go("sante"); return ""; }
    if (!UI.hc || !UI.hc.sessions) {
      if (UI.hc && UI.hc.err && !UI.hc.busy) return s + '<div class="card"><b>' + HC_NAME + ' n\'a pas répondu</b><span style="font-size:14.5px;line-height:1.45">' + (UI.hc.err === "non autorisé" ? "Montée n'a pas (ou plus) l'autorisation de lire « Exercice ». Active-la dans Health Connect." : "La lecture de tes séances a échoué. Réessaie dans un instant.") + '</span><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn soft small" data-a="hcRetry" style="background:var(--chip)">Réessayer</button><button class="btn soft small" data-a="hcSettings" style="background:var(--chip)">Ouvrir Health Connect</button></div></div></div>';
      if (!UI.hc || !UI.hc.busy) hcLoad(30, true);
      return s + '<div class="card empty"><b>Lecture de tes séances…</b><span class="small">Quelques secondes.</span></div></div>';
    }
    var done = S.health.done || {}, md = hcMatchDays(), lim = Date.now() - 30 * 864e5;
    var list = hcSessions().filter(function (x) { return !done[x.id] && x.start >= lim && x.end - x.start >= 10 * 60000; }).sort(function (a, b) { return b.start - a.start; });
    // Autres séances (pas marquées tennis) : le joueur peut dire « c'est du tennis » (montre qui enregistre en « Autre »…)
    var others = hcAll().filter(function (x) { return !done[x.id] && x.start >= lim && x.end - x.start >= 10 * 60000 && hcSessions().indexOf(x) < 0; }).sort(function (a, b) { return b.start - a.start; });
    var typesSeen = {}; hcAll().forEach(function (x) { var l = hcTypeLabel(x); typesSeen[l] = (typesSeen[l] || 0) + 1; });
    var diag = '<p class="small">' + HC_NAME + ' : ' + plural(hcAll().length, "séance d'exercice", "séances d'exercice") + " sur 30 jours" + (hcAll().length ? " (" + Object.keys(typesSeen).map(function (k) { return k + " " + typesSeen[k]; }).join(", ") + ")" : "") + ".</p>";
    var othersHtml = others.length ? '<button class="row hc-oth-t" data-a="hcOthers" style="background:var(--card);border-radius:18px;border:0;width:100%;text-align:left;font:inherit;color:inherit"><span class="grow"><span class="t">Autres séances · ' + others.length + '</span><span class="s">Pas marquées « tennis » par ta montre. Si c\'en était, dis-le.</span></span>' + (UI.hcOthers ? "▴" : "▾") + "</button>" +
      (UI.hcOthers ? '<div class="ses-list">' + others.slice(0, 15).map(function (x) { return '<div class="ses"><span class="grow" style="display:flex;flex-direction:column;gap:2px"><span class="t">' + esc(hcWhen(x)) + '</span><span class="src">' + esc(hcTypeLabel(x) + " · " + hcSrc(x).replace(/^[^ ]+ /, "")) + '</span></span><span class="dur">' + esc(fmtDur(hcMin(x))) + '</span><button class="btn soft small" data-a="hcIsTennis" data-id="' + esc(x.id) + '" style="background:var(--chip);flex:none">C\'est du tennis</button></div>'; }).join("") + "</div>" : "") : "";
    if (!list.length) return s + '<h1 class="hc-h">Pas de séance de tennis</h1><div class="card"><span style="font-size:15px;line-height:1.45">Aucune séance enregistrée comme « tennis » sur les 30 derniers jours.' + (hcAll().length ? "" : IOS ? " Vérifie que Montée a accès aux entraînements : Réglages → Santé → Accès aux données et appareils → Montée." : " Vérifie que l'appli de ta montre (Samsung Health, Google Health, Mi Fitness…) partage bien ses séances avec Health Connect : Health Connect → Applis → ton appli → autoriser « Exercice ».") + "</span></div>" + othersHtml + diag + '<a class="btn soft" href="#/" style="background:var(--card)">Revenir à l\'accueil</a></div>';
    var kept = list.filter(function (x) { return (!md[hcIso(x.start)] || (UI.hcForce || {})[x.id]) && (UI.hcSel || {})[x.id] !== false; });
    s += '<h1 class="hc-h">' + plural(list.length, "séance trouvée", "séances trouvées") + '</h1><p class="small" style="margin:0 0 4px"><b>Chaque séance cochée devient un entraînement.</b> Un match ? Touche « C\'était un match ? », ou laisse faire : quand il arrivera de Ten\'Up, Montée reliera la séance au match.</p>';
    s += '<div class="ses-list">' + list.map(function (x) { return hcRow(x, md); }).join("") + "</div>";
    s += othersHtml;
    var b = bag(), sel = UI.hcRk !== undefined ? UI.hcRk : (racketFor("train") || {}).id || "";
    if (b.length && kept.length) s += '<div class="card" style="gap:8px"><span class="lbl">Raquette pour ' + (kept.length > 1 ? "ces " + kept.length + " séances" : "cette séance") + '</span><div class="chips">' + b.map(function (r) { return '<button class="chip' + (sel === r.id ? " on" : "") + '" data-a="hcRk" data-v="' + r.id + '">' + esc(r.name + (r.model ? " · " + r.model : "")) + "</button>"; }).join("") + '<button class="chip' + (sel === "" ? " on" : "") + '" data-a="hcRk" data-v="">Plus tard</button></div></div>';
    s += diag + '<div class="savebar-space"></div><div class="savebar"><button class="btn primary" data-a="hcAddAll">' + (kept.length ? "Ajouter " + plural(kept.length, "entraînement") : "Terminer") + "</button></div>";
    return s + "</div>";
  };
  V.reglages = function () {
    var cur = (S.prefs && S.prefs.theme) || "auto", pull = (S.prefs && S.prefs.pull) || "normal";
    var s = '<div class="screen">' + topbar("Réglages") + matRow().replace("margin-top:8px", "margin-top:0");
    if (HC_OK) s += '<a class="row" href="#/sante" style="background:var(--card);border-radius:20px;margin-top:8px"><span class="grow"><span class="t">Santé connectée</span><span class="s">' + (hcOn() ? HC_NAME + " · tes séances de tennis arrivent toutes seules" : "Importe tes séances de tennis depuis ta montre (" + HC_NAME + ")") + "</span></span>" + (hcOn() ? '<span class="tag ok">Connecté</span>' : "") + I.next + "</a>";
    s += "<h2>Thème de l'appli</h2><div class=\"themes\">" + THEMES.map(function (t) {
      var sw = THEME_SW[t[0] === "auto" ? "lin" : t[0]], on = cur === t[0];
      var mini = function (w, cls) { return '<span class="th-prev' + (cls || "") + '" style="background:' + w[0] + '"><i class="hh" style="background:' + w[3] + '"></i><i class="c1" style="background:' + w[1] + '"></i><i class="c2" style="background:' + w[1] + '"></i><i class="ac" style="background:' + w[2] + '"></i></span>'; };
      var prev = t[0] === "auto" ? '<span class="th-wrap">' + mini(THEME_SW.lin, " half") + mini(THEME_SW.nuit, " half r") + "</span>" : mini(sw);
      return '<button class="theme' + (on ? " on" : "") + '" data-a="setTheme" data-v="' + t[0] + '" aria-pressed="' + on + '" aria-label="' + t[1] + " : " + t[2] + '">' + prev + "<b>" + t[1] + "</b></button>";
    }).join("") + "</div>";
    // Thème des widgets de l'écran d'accueil
    var wcur = (S.prefs && S.prefs.wtheme) || "app";
    var wmini = function (bg, card, bar) { return '<span class="th-prev" style="background:' + bg + '"><i class="wt-card" style="background:' + card + '"></i><i class="wt-bar" style="background:' + bar + '"></i><i class="wt-sq" style="background:' + card + '"></i></span>'; };
    var WT = { lin: ["#E9E3D9", "#F0F5CF", "#1F5C3F"], nuit: ["#3A3D44", "#2A2E1F", "#D4E64A"] };
    if (NATIVE && !IOS) s += "<h2>Thème des widgets</h2><div class=\"themes\">" + [["app", "Appli"], ["lin", "Lin"], ["nuit", "Nuit"]].map(function (o) {
      var on = wcur === o[0], prev = o[0] === "app" ? (function () { var a = THEME_SW[themeNow()] || THEME_SW.lin, c = themeNow() === "nuit" ? WT.nuit : themeNow() === "lin" ? WT.lin : [a[0], a[3], a[2]]; return wmini(c[0], c[1], c[2]); })() : wmini(WT[o[0]][0], WT[o[0]][1], WT[o[0]][2]);
      return '<button class="theme' + (on ? " on" : "") + '" data-a="setWTheme" data-v="' + o[0] + '" aria-pressed="' + on + '">' + prev + "<b>" + o[1] + "</b></button>";
    }).join("") + '</div><p class="small" style="margin-top:-4px">« Appli » : les widgets suivent le thème de l\'appli. Ils se mettent à jour à chaque ouverture de Montée.</p>';
    s += '<h2>Synchronisation Ten\'Up</h2><div class="card" style="gap:10px"><b style="font-size:15px">Tirer l\'écran vers le bas</b><span class="small">Pour lancer la synchro depuis l\'accueil, le palmarès ou les courbes.</span><div class="seg">' +
      [["normal", "Normal"], ["ferme", "Plus ferme"], ["off", "Désactivé"]].map(function (o) { return '<button data-a="setPull" data-v="' + o[0] + '" class="' + (pull === o[0] ? "on" : "") + '">' + o[1] + "</button>"; }).join("") + "</div>" +
      '<a class="btn soft small" href="#/tenup" style="background:var(--chip)">' + I.link + " Ton compte Ten'Up</a></div>";
    s += "<h2>Affichage</h2><div class=\"list\">" +
      '<a class="row" href="#/perso/home"><span class="grow"><span class="t">Personnaliser l\'accueil</span><span class="s">Choisir les cartes et leur ordre</span></span>' + I.next + "</a>" +
      '<a class="row" href="#/perso/courbes"><span class="grow"><span class="t">Personnaliser les courbes</span></span>' + I.next + "</a></div>";
    s += "<h2>Montée</h2><div class=\"list\">" +
      '<button class="row" data-a="openNotes"><span class="grow"><span class="t">Quoi de neuf</span><span class="s">Les nouveautés de la version ' + esc(CONFIG.VERSION) + "</span></span>" + I.next + "</button>" +
      (NATIVE && (!IOS || CONFIG.APPSTORE_ID) ? '<button class="row" data-a="openStore"><span class="grow"><span class="t">Mettre à jour Montée</span><span class="s">Ouvre la fiche sur ' + (IOS ? "l\'App Store" : "le Play Store") + '</span></span>' + I.next + "</button>" : "") +
      '<a class="row" href="#/donnees"><span class="grow"><span class="t">Sauvegarder mes données</span></span>' + I.next + "</a>" +
      '<a class="row" href="#/apropos"><span class="grow"><span class="t">À propos</span><span class="s">Version ' + esc(CONFIG.VERSION) + "</span></span>" + I.next + "</a></div>";
    return s + "</div>";
  };

  // ---------- Quoi de neuf (une fois par version) ----------
  var NOTES = {
    v: "3.21",
    pages: [
      { hero: true, title: "Montée 3.21", text: "Un mode match à ouvrir au vestiaire, tes forces à te rappeler dans les moments clés, tes saisons en un coup d'œil, et un accueil qui va à l'essentiel." },
      { tag: "Nouveau", tone: "rose", title: "Mode match", text: "Sur la fiche de ton adversaire, touche « Je joue contre lui » : tes chances, ton plan en 3 points, ta phrase et ta raquette, en très grand. Glisse pour le changement de côté, puis pour noter le résultat.", vis: "mm21" },
      { tag: "Nouveau", tone: "rose", title: "Tes forces", text: "Ce sur quoi tu peux compter quand ça se resserre : tes tie-breaks, tes sets serrés, les classements contre qui tu ne perds jamais. Dans tes courbes, ton plan de jeu et le mode match." , vis: "fz21" },
      { tag: "Nouveau", tone: "rose", title: "Tes saisons", text: "Ton classement et ton bilan saison par saison, d'après tes palmarès Ten'Up. À retrouver dans tes courbes." },
      { tag: "Amélioré", tone: "bleu", title: "Plus simple à parcourir", text: "L'accueil met en avant la chose la plus utile du moment et replie le reste. Les courbes ont un sommaire en haut pour sauter directement à la bonne carte." },
      { tag: "Amélioré", tone: "bleu", title: "Des analyses plus justes", text: "« Ton plafond » compare tes résultats à ce qu'on attend d'un joueur de ton classement, et les joueurs anonymes de Ten'Up ne sont plus regroupés." }
    ]
  };
  // Sur iPhone (pas encore de widgets) et sur le web, on retire la page « widgets »
  if (!NATIVE) NOTES.pages = NOTES.pages.filter(function (x) { return x.vis !== "sante" && x.vis !== "hcnotif"; });
  if (!NATIVE || IOS) NOTES.pages = NOTES.pages.filter(function (x) { return x.vis !== "widgets"; });
  if (!NATIVE) NOTES.pages = NOTES.pages.map(function (x) { return x.title === "Match libre ou entraînement" ? Object.assign({}, x, { text: "Un match libre homologué compte pour le classement, un match d'entraînement non." }) : x; });
  function notesDue() {
    if (UI.notesOpen) return true;
    if (!S.onboarded || !S.matches.length) return false;
    if (!S.seenNotes) { S.seenNotes = NOTES.v; save(); return false; } // première installation : rien à annoncer
    if (S.seenNotes !== NOTES.v && route() === "") { UI.notesOpen = true; UI.notesPage = 0; return true; }
    return false;
  }
  function notesVis(k) {
    var nvc = function (inner) { return '<div class="nv-mock">' + inner + "</div>"; };
    if (k === "verify") return nvc('<span class="nv-k">Ta saisie</span><span class="nv-l"><i class="vd D">D</i><span><mark>3 oct</mark> · <mark>Jean Dupont</mark> 15/3 · 3-6 4-6</span></span><span class="nv-k">Sur Ten\'Up</span><span class="nv-l"><i class="vd D">D</i><span><mark>4 oct</mark> · <mark>Jean DUPOND</mark> 15/3 · 3-6 4-6</span></span><span class="nv-b"><b>Oui, c\'est le même</b></span>');
    if (k === "sim17") return nvc('<span class="nv-k" style="color:#6FC28F">SIMULATION OFFICIELLE · TEN\'UP</span><b style="font-size:18px">Il te manque 28 pts pour 15/3</b>' + [["15/4", 100, "#6FC28F", "447 / 315", ""], ["15/3", 91, "#D4E64A", "297 / 325", "background:rgba(212,230,74,.14);border-radius:10px;"], ["15/2", 53, "rgba(255,255,255,.35)", "177 / 335", ""]].map(function (x) { return '<span style="display:grid;grid-template-columns:40px 1fr 74px;gap:8px;align-items:center;font-size:13px;padding:4px 6px;' + x[4] + '"><b>' + x[0] + '</b><i style="height:7px;border-radius:7px;background:rgba(255,255,255,.12);overflow:hidden"><i style="display:block;height:100%;width:' + x[1] + '%;background:' + x[2] + '"></i></i><span style="text-align:right">' + x[3] + "</span></span>"; }).join(""));
    if (k === "libre17") return nvc('<span class="nv-k">TYPE DE MATCH</span><span style="display:flex;flex-wrap:wrap;gap:8px">' + ["Tournoi", "Par équipes", "Match libre (homologué)", "Match d\'entraînement"].map(function (t, i) { return '<span style="font-size:13.5px;font-weight:600;padding:8px 12px;border-radius:12px;' + (i === 3 ? "background:#6FC28F;color:#0d2016" : "background:rgba(255,255,255,.08);box-shadow:inset 0 0 0 1px rgba(255,255,255,.18)") + '">' + t + "</span>"; }).join("") + '</span><span style="font-size:12.5px;opacity:.75">Non homologué : il compte dans tes stats, pas pour le classement.</span>');
    var nvTag = function (t) { return ' <i style="font-style:normal;font-size:9.5px;font-weight:800;letter-spacing:.04em;background:rgba(255,255,255,.1);color:rgba(255,255,255,.7);border-radius:99px;padding:2px 7px;vertical-align:2px;white-space:nowrap">' + t + "</i>"; };
    var nvNum = function (n) { return '<i style="flex:none;width:24px;height:24px;border-radius:12px;background:#D4E64A;color:#121212;font-style:normal;font-weight:800;display:flex;align-items:center;justify-content:center;font-size:13px">' + n + "</i>"; };
    if (k === "plan18") return nvc('<span class="nv-k" style="color:#6FC28F">TON PLAN EN 3 POINTS · THÉO D. 15/4</span>' + [["1", "Ton coup droit croisé sur son revers", "TES NOTES + FICHE", "Gaucher, revers à une main : lifte haut dans cette diagonale."], ["2", "Reste collé au score", "TES NOTES", "Il s\'énerve vite : sois régulier, laisse-le craquer."], ["3", "Casse son rythme", "SA FICHE", "Slice, balles lentes au centre : ta régularité le fera forcer."]].map(function (x) { return '<span style="display:flex;gap:10px;align-items:flex-start">' + nvNum(x[0]) + '<span style="display:flex;flex-direction:column"><b style="font-size:14.5px">' + x[1] + nvTag(x[2]) + '</b><span style="font-size:12.5px;opacity:.75">' + x[3] + "</span></span></span>"; }).join(""));
    if (k === "mm21") return nvc('<span class="nv-k" style="color:#D4E64A">MODE MATCH · JULIEN M. 15/4</span><span style="display:flex;align-items:center;gap:12px"><b style="font-size:40px;color:#6FC28F;letter-spacing:-.03em">58 %</b><span style="font-size:13px;opacity:.75">Match ouvert<br>+60 pts si tu gagnes</span></span>' + ["Tout sur son revers", "Prends-lui le temps", "Si tu mènes, accélère"].map(function (t, i) { return '<span style="display:flex;gap:10px;align-items:center"><i style="flex:none;width:24px;height:24px;border-radius:12px;background:#D4E64A;color:#121212;font-style:normal;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center">' + (i + 1) + '</i><b style="font-size:15px">' + t + "</b></span>"; }).join(""));
    if (k === "fz21") return nvc('<span class="nv-k" style="color:#6FC28F">RAPPELLE-TOI · TES FORCES</span>' + [["7", "8", "Jeux décisifs gagnés"], ["5", "5", "Contre les 15/4 : jamais perdu"], ["4", "6", "Matchs renversés après un set perdu"]].map(function (x) { return '<span style="display:flex;gap:12px;align-items:center"><b style="flex:none;min-width:62px;font-size:26px;color:#6FC28F">' + x[0] + '<small style="font-size:12px;opacity:.6"> sur ' + x[1] + '</small></b><b style="font-size:14px">' + x[2] + "</b></span>"; }).join(""));
    if (k === "simu20") return nvc('<span class="nv-k" style="color:#6FC28F">ET SI… · SORTIE DU 3 NOV</span><span style="display:flex;align-items:center;gap:10px"><b style="font-size:30px;opacity:.55">15/4</b><b style="font-size:22px;color:#D4E64A">→</b><b style="font-size:30px;color:#6FC28F">15/3</b><i style="margin-left:auto;font-style:normal;font-size:11px;font-weight:800;background:#6FC28F;color:#0d2016;border-radius:99px;padding:3px 9px">TU MONTES</i></span>' + [["V", "Victoire contre un 15/3", "+30"], ["V", "Victoire contre un 15/2", "+30"], ["D", "Défaite contre un 15/1", "0"]].map(function (x) { return '<span style="display:flex;gap:10px;align-items:center"><i style="flex:none;width:24px;height:24px;border-radius:7px;background:' + (x[0] === "V" ? "#6FC28F;color:#0d2016" : "#E88A5E;color:#2a1006") + ';font-style:normal;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center">' + x[0] + '</i><b style="flex:1;font-size:14px">' + x[1] + '</b><b style="color:' + (x[2] === "0" ? "#9DA1AB" : "#6FC28F") + '">' + x[2] + "</b></span>"; }).join(""));
    if (k === "card20") return nvc('<span style="display:flex;gap:14px;align-items:center"><span style="flex:none;width:96px;height:170px;border-radius:14px;background:radial-gradient(80% 40% at 20% 0%,rgba(111,194,143,.4),transparent 70%),#121212;box-shadow:0 0 0 1px rgba(255,255,255,.08);padding:10px;display:flex;flex-direction:column;gap:5px"><i style="font-style:normal;font-size:7px;font-weight:800;background:#D4E64A;color:#121212;border-radius:9px;padding:2px 5px;align-self:flex-start">MON MOIS</i><b style="font-size:20px;line-height:1">15/4 <span style="color:#D4E64A">→</span><br><span style="color:#6FC28F">15/3</span></b><span style="display:grid;grid-template-columns:1fr 1fr;gap:3px;margin-top:4px">' + ["6V–3D", "15/2", "2", "3"].map(function (t) { return '<i style="font-style:normal;font-size:8px;font-weight:800;background:rgba(255,255,255,.08);border-radius:4px;padding:4px">' + t + "</i>"; }).join("") + '</span><i style="font-style:normal;margin-top:auto;font-size:7px;font-weight:800;color:#D4E64A;text-align:right">@montee.tennis</i></span><span style="display:flex;flex-direction:column;gap:8px"><b style="font-size:16px">Ton mois en une image</b><span style="font-size:13px;opacity:.75">Montée · Bilan · Sobre</span><i style="font-style:normal;font-size:13px;font-weight:800;background:#F2F3F5;color:#121212;border-radius:99px;padding:8px 12px;align-self:flex-start">Partager en story</i></span></span>');
    if (k === "ch20") return nvc('<span class="nv-k" style="color:#6FC28F">TA CHARGE DE JEU</span><b style="font-size:17px">9 h de tennis en 7 jours : lève le pied</b><span style="display:grid;grid-template-columns:repeat(7,1fr);gap:5px;height:70px;align-items:end">' + [40, 95, 20, 85, 55, 0, 30].map(function (h) { return '<i style="display:block;height:' + Math.max(4, h) + '%;border-radius:5px;background:' + (h >= 80 ? "#E88A5E" : h ? "#6FC28F" : "rgba(255,255,255,.12)") + '"></i>'; }).join("") + '</span><span style="font-size:12.5px;opacity:.75">Tes meilleurs résultats arrivent après 4 à 6 h la semaine d\'avant.</span>');
    if (k === "coach20") return nvc('<span class="nv-k" style="color:#6FC28F">CE QUE TU SAIS DE LUI</span><span style="font-size:13px;font-style:italic;background:rgba(255,255,255,.07);border-radius:4px 12px 12px 12px;padding:8px 10px">« Il fuyait son revers mais excellent coup droit et bon service »</span><span style="display:flex;gap:10px;align-items:center"><i style="flex:none;width:28px;height:28px;border-radius:9px;background:#6FC28F;color:#0d2016;font-style:normal;font-weight:800;display:flex;align-items:center;justify-content:center">◎</i><span style="display:flex;flex-direction:column"><span style="font-size:10px;font-weight:800;letter-spacing:.06em;color:#6FC28F">SA FAILLE</span><b style="font-size:15px">Tout sur son revers</b></span></span><span style="display:flex;gap:10px;align-items:center"><i style="flex:none;width:28px;height:28px;border-radius:9px;background:#E88A5E;color:#2a1006;font-style:normal;font-weight:800;display:flex;align-items:center;justify-content:center">●</i><span style="display:flex;flex-direction:column"><span style="font-size:10px;font-weight:800;letter-spacing:.06em;color:#E88A5E">SON SERVICE</span><b style="font-size:15px">Recule en retour et bloque</b></span></span>');
    if (k === "pal19") return nvc('<span class="nv-k" style="color:#6FC28F">PALMARÈS · SELON LE NIVEAU</span>' + [["Plus fort que toi", 1, 1], ["Ton niveau", 1, 3], ["En dessous", 5, 1]].map(function (x) { var n = x[1] + x[2]; return '<span style="display:grid;grid-template-columns:1fr 80px 40px;gap:10px;align-items:center;font-size:13.5px"><span>' + x[0] + '</span><span style="display:flex;gap:2px;height:7px;border-radius:9px;overflow:hidden"><i style="width:' + x[1] / n * 100 + '%;background:#6FC28F"></i><i style="width:' + x[2] / n * 100 + '%;background:#E88A5E"></i></span><b style="text-align:right">' + x[1] + "–" + x[2] + "</b></span>"; }).join("") + '<span style="display:flex;gap:10px;align-items:center;border-top:1px solid rgba(255,255,255,.08);padding-top:8px"><i style="flex:none;width:24px;height:24px;border-radius:7px;background:#6FC28F;color:#0d2016;font-style:normal;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center">V</i><span style="flex:1;display:flex;flex-direction:column"><b style="font-size:14px">Lucas Petit <span style="opacity:.6">15/5</span> <span style="color:#6FC28F">→ 15/2</span></b><span style="font-size:12px;opacity:.7">6-3 6-4 · 23 oct</span></span><span style="opacity:.6">›</span></span>');
    if (k === "mind18") return nvc('<span class="nv-k" style="color:#6FC28F">DANS TA TÊTE · SI TU PERDS LE 1ER SET</span><b style="font-size:34px;line-height:1;letter-spacing:-.02em">1 sur 6</b><span style="font-size:12.5px;opacity:.75">matchs renversés après un 1er set perdu, sur 12 mois.</span><span style="font-size:14.5px;font-weight:700;border-left:3px solid #D4E64A;padding-left:10px">« Je remets le compteur à zéro. Premier jeu du 2e set, premier objectif. »</span><span style="font-size:12px;opacity:.7">Au changement de côté : 3 respirations lentes.</span>');
    if (k === "fol18") return nvc('<span style="display:flex;justify-content:space-between;align-items:center"><span class="nv-k" style="color:#6FC28F">TES SUIVIS</span><i style="font-style:normal;font-size:12px;font-weight:700;background:#D4E64A;color:#121212;border-radius:99px;padding:5px 11px;display:inline-flex;gap:5px;align-items:center">' + BELL_ON.replace(/width="20" height="20"/, 'width="13" height="13"') + ' Suivi</i></span>' + [["HB", "Hugo Bernard", "15/3", "Monté de 15/4 · aujourd\'hui", "#6FC28F"], ["AR", "Antoine Roux", "15/4", "A battu un 15/4 · 6-3 7-5", "#E88A5E"], ["TM", "Thomas Mercier", "15/2", "4 victoires de suite", "rgba(255,255,255,.6)"]].map(function (x) { return '<span style="display:flex;gap:10px;align-items:center"><i style="flex:none;width:32px;height:32px;border-radius:16px;background:rgba(255,255,255,.1);font-style:normal;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center">' + x[0] + '</i><span style="display:flex;flex-direction:column;flex:1"><b style="font-size:14.5px">' + x[1] + ' <span style="opacity:.6;font-weight:600">' + x[2] + '</span></b><span style="font-size:12.5px;color:' + x[4] + '">' + x[3] + "</span></span></span>"; }).join(""));
    if (k === "risen18") return nvc('<span class="nv-k" style="color:#6FC28F">FAUX CLASSEMENTS</span><b style="font-size:15px">2 de ses victoires valent plus que prévu.</b>' + [["Lucas Petit", "15/5", "15/2"], ["Julien Moreau", "30", "15/3"]].map(function (x) { return '<span style="display:flex;gap:10px;align-items:center"><i style="flex:none;width:24px;height:24px;border-radius:7px;background:#6FC28F;color:#0d2016;font-style:normal;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center">V</i><b style="flex:1;font-size:14.5px">' + x[0] + '</b><span style="font-size:14px"><s style="opacity:.55">' + x[1] + "</s> → <b>" + x[2] + "</b></span></span>"; }).join("") + '<span style="font-size:12px;opacity:.7">Comptées à leur classement actuel dans tout le face-à-face.</span>');
    if (k === "plan17") return nvc('<span class="nv-k" style="color:#6FC28F">TON PLAN EN 3 POINTS</span>' + [["1", "Prends le premier set", "Mené d\'un set, il n\'a renversé que 1 match sur 11."], ["2", "Fais durer, le 3e set est pour toi", "Lui 1 sur 6 en trois sets, toi 4 sur 6."], ["3", "Ne panique pas s\'il démarre bien", "Il prend un set, puis il cède."]].map(function (x) { return '<span style="display:flex;gap:10px;align-items:flex-start"><i style="flex:none;width:24px;height:24px;border-radius:12px;background:#D4E64A;color:#121212;font-style:normal;font-weight:800;display:flex;align-items:center;justify-content:center;font-size:13px">' + x[0] + '</i><span style="display:flex;flex-direction:column"><b style="font-size:15px">' + x[1] + '</b><span style="font-size:12.5px;opacity:.75">' + x[2] + "</span></span></span>"; }).join(""));
    if (k === "stats17") return nvc('<span style="display:flex;justify-content:space-between;align-items:center"><b style="font-size:16px">Qui tient sous pression ?</b><i style="font-style:normal;font-size:11px;font-weight:800;background:#6FC28F;color:#0d2016;border-radius:99px;padding:3px 9px">TOI</i></span>' + [["Sets serrés", 64, 38, "7/11", "3/8"], ["3es sets", 67, 17, "4/6", "1/6"]].map(function (x) { return '<span style="font-size:13px;font-weight:600">' + x[0] + '</span><span style="display:grid;grid-template-columns:30px 1fr 34px;gap:4px 8px;align-items:center;font-size:12px"><span style="opacity:.7">Toi</span><i style="height:8px;border-radius:8px;background:rgba(255,255,255,.15);overflow:hidden"><i style="display:block;height:100%;width:' + x[1] + '%;background:#6FC28F;border-radius:8px"></i></i><b style="text-align:right">' + x[3] + '</b><span style="opacity:.7">Lui</span><i style="height:8px;border-radius:8px;background:rgba(255,255,255,.15);overflow:hidden"><i style="display:block;height:100%;width:' + x[2] + '%;background:rgba(255,255,255,.4);border-radius:8px"></i></i><b style="text-align:right">' + x[4] + "</b></span>"; }).join(""));
    if (k === "analyse") return nvc('<span class="nv-k" style="color:#6FC28F">L\'ANALYSE DU MATCH</span><b style="font-size:18px;line-height:1.25">Grosse perf : tu as stoppé un joueur en pleine bourre.</b><span style="font-size:13px;opacity:.85">Il restait sur 6 victoires d\'affilée. Tu es le premier à le battre depuis le 14 sept.</span><span style="display:flex;gap:4px;margin-top:4px">' + new Array(7).join('<i style="width:20px;height:20px;border-radius:10px;background:#6FC28F;color:#0E2318;font-style:normal;font-size:10px;font-weight:700;display:inline-flex;align-items:center;justify-content:center">V</i>') + '<i style="width:20px;height:20px;border-radius:10px;background:#E88A5E;color:#2A1208;font-style:normal;font-size:10px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;box-shadow:0 0 0 2px #D4E64A">D</i></span>');
    if (k === "sante") return nvc('<span class="nv-k" style="color:#6FC28F">NOUVELLE SÉANCE · HEALTH CONNECT</span><b style="font-size:19px">Hier, 19 h · 1 h 30 de tennis</b><span style="font-size:13px;opacity:.8">On l\'ajoute à tes entraînements, avec ta N°1 ?</span><span style="display:flex;gap:6px;align-items:center;margin-top:4px"><span style="font-size:13px;opacity:.7;flex:1">Ignorer</span><span class="nv-pill">Détailler</span><span class="nv-pill" style="background:#D4E64A;color:#121212;font-weight:700">Ajouter</span></span>');
    if (k === "hcnotif") return nvc('<span style="display:flex;gap:10px;align-items:flex-start"><i style="flex:none;width:34px;height:34px;border-radius:10px;background:#1F5C3F;color:#D4E64A;display:flex;align-items:center;justify-content:center;font-style:normal;font-weight:800">M</i><span><b style="font-size:15px">Nouvelle séance de tennis</b><br><span style="font-size:13px;opacity:.8">Hier, 19 h · 1 h 30. Touche pour l\'ajouter à tes entraînements, avec ta raquette.</span></span></span>');
    if (k === "themes") return nvc('<span class="nv-k">TES THÈMES</span><span style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px">' + [["#F6F2EC", "#D4E64A", "Lin"], ["#17181C", "#6FC28F", "Nuit"], ["#B5582D", "#0B4D35", "Terre"], ["#2F5584", "#E3F25B", "Dur"], ["repeating-linear-gradient(90deg,#E3EED8 0 8px,#EDF4E4 8px 16px)", "#54287F", "Gazon"]].map(function (t) { return '<span style="display:flex;flex-direction:column;align-items:center;gap:4px"><i style="width:100%;height:58px;border-radius:12px;background:' + t[0] + ';position:relative;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12)"><i style="position:absolute;left:6px;right:6px;top:8px;height:14px;border-radius:5px;background:#fff"></i><i style="position:absolute;right:7px;bottom:7px;width:14px;height:14px;border-radius:7px;background:' + t[1] + '"></i></i><span style="font-size:11px;opacity:.8">' + t[2] + "</span></span>"; }).join("") + "</span>");
    if (k === "moi") return nvc('<span class="nv-k" style="color:#D4E64A">TOI CONTRE TOI</span><span style="display:flex;align-items:center;gap:10px"><i style="width:40px;height:40px;border-radius:20px;background:#D4E64A;color:#121212;display:flex;align-items:center;justify-content:center;font-style:normal;font-weight:700">TM</i><b style="color:#D4E64A">VS</b><i style="width:40px;height:40px;border-radius:20px;border:2px dashed #D4E64A;color:#D4E64A;display:flex;align-items:center;justify-content:center;font-style:normal;font-weight:700">TM</i></span><span class="nv-l"><i class="vd D">!</i><span>« L\'emmener au tie-break »</span></span><span class="nv-l"><i class="vd V">✓</i><span>Le 3e set : 5 gagnés sur 6</span></span>');
    if (k === "joueurs") return nvc('<span style="display:flex;align-items:center;gap:8px;background:#fff;color:#121212;border-radius:14px;padding:8px 10px"><span style="opacity:.5">⌕</span><span style="flex:1">Julien Moreau</span><b style="background:#121212;color:#fff;border-radius:10px;padding:4px 10px;font-size:12px">Chercher</b></span><span class="nv-l"><i class="vd" style="background:#2A2E1F;color:#D4E64A">15/4</i><span>Julien MOREAU · TC Dijon · <b style="color:#6FC28F">Déjà joué</b></span></span><span class="nv-l"><i class="vd" style="background:#2A2E1F;color:#D4E64A">30/1</i><span>Julien MOREAU · AS Beaune · 19 ans</span></span>');
    if (k === "rang") return nvc('<span class="nv-k" style="text-align:center">TON CLASSEMENT</span><b style="font-size:46px;line-height:1;text-align:center;letter-spacing:-.04em">15/3</b><span style="display:flex;justify-content:center;gap:6px;margin-top:6px"><span class="nv-pill">Meilleur 15/2</span><span class="nv-pill" style="background:#6FC28F;color:#0E2318;font-weight:700">↑ Montée à 15/2</span></span>');
    if (k === "cmp") return nvc('<span class="nv-k" style="color:#D4E64A">LE DUEL EN MIROIR</span>' + [["Perfs", 80, 40], ["3es sets", 83, 33], ["Tie-breaks", 25, 71]].map(function (r) { return '<span style="display:grid;grid-template-columns:1fr 70px 1fr;align-items:center;gap:6px;font-size:12px"><i style="justify-self:end;height:9px;border-radius:5px;width:' + r[1] + '%;background:' + (r[1] > r[2] ? "#6FC28F" : "#33363E") + '"></i><span style="text-align:center;opacity:.8">' + r[0] + '</span><i style="height:9px;border-radius:5px;width:' + r[2] + '%;background:' + (r[2] > r[1] ? "#E88A5E" : "#33363E") + '"></i></span>'; }).join("") + '<span class="nv-pill" style="background:#1F3A2C;color:#6FC28F;margin-top:6px">Toi : perfs, endurance</span>');
    if (k === "notes") return nvc('<span class="nv-k" style="color:#E88A5E">TES NOTES SUR LUI</span><span style="font-size:13px;opacity:.7">Sa fiche · toujours valable</span><b style="font-size:15px">« Sert fort au T, craque sur les balles hautes »</b><span style="font-size:13px;opacity:.7;margin-top:6px">Ton retour · défaite le 25 mai</span><b style="font-size:15px">« Démarre lentement, accélère au 2e set »</b>');
    if (k === "profil") return nvc('<span style="display:flex;align-items:center;gap:12px"><i style="width:46px;height:46px;border-radius:23px;background:#121212;color:#D4E64A;display:flex;align-items:center;justify-content:center;font-style:normal;font-weight:700">JM</i><span><b style="font-size:17px">Julien MOREAU</b><br><span style="font-size:12px;opacity:.7">TC EXEMPLE</span></span></span><span class="nv-l" style="gap:6px;margin-top:6px"><span class="nv-pill">15/3</span><span class="nv-pill">Droitier</span><span class="nv-pill">Revers à deux mains</span></span>');
    if (k === "faf") return nvc('<span class="nv-k" style="color:#D4E64A">TON PLAN DE JEU · THOMAS M. 15/2</span><b style="font-size:16px">Tu peux l\'avoir au physique</b><span style="font-size:13px;opacity:.8">2 victoires sur 7 en trois sets : fais durer.</span><b style="font-size:16px;margin-top:8px">Il met du temps à se chauffer</b><span style="font-size:13px;opacity:.8">Premier set perdu dans 55 % de ses matchs.</span>');
    if (k === "objectif") return nvc('<span class="nv-k">OBJECTIF 15/2 · SEPT. 2027</span><span class="nv-l"><i class="vd V">✓</i><span>15/4 · point de départ</span></span><span class="nv-l"><i class="vd" style="background:#D4E64A;color:#121212">3</i><span><b>15/3</b> le 3 nov. · une victoire suffit</span></span><span class="nv-l"><i class="vd" style="background:#33363E;color:#D4E64A">★</i><span><b>15/2</b> en septembre</span></span><span class="nv-pill" style="background:#1F5C3F;color:#fff;margin-top:6px">DANS LES TEMPS</span>');
    if (k === "niveau") return nvc('<span class="nv-k">TON NIVEAU DE JEU</span><span style="font-size:30px;font-weight:700;letter-spacing:-.02em">15/3 <small style="font-size:14px;font-weight:600;opacity:.8">solide · classé 15/4</small></span><span style="position:relative;height:6px;border-radius:3px;background:#33363E;margin:10px 0 4px"><i style="position:absolute;left:45%;top:-6px;width:3px;height:18px;background:#fff;border-radius:2px"></i><i style="position:absolute;left:68%;top:-6px;width:18px;height:18px;border-radius:9px;background:#6FC28F"></i></span>');
    if (k === "annoter") return nvc('<span class="nv-k" style="color:#D4E64A">ANNOTE TON MATCH · 1 SUR 3</span><b style="font-size:16px">Victoire contre Julien Moreau</b><span class="nv-l" style="gap:6px"><span class="nv-pill" style="background:#D4E64A;color:#121212">N°1</span><span class="nv-pill" style="background:#D4E64A;color:#121212">Terre battue</span><span class="nv-pill">Extérieur</span></span><span class="nv-pill" style="background:#D4E64A;color:#121212;align-self:flex-end;margin-top:6px;padding:8px 14px">Enregistrer · suivant</span>');
    if (k === "fiche") return nvc('<span class="nv-k" style="color:#6FC28F">✓ MATCH OFFICIEL · TEN\'UP</span><span style="font-size:20px;font-weight:700">Julien Moreau <small style="font-size:13px;background:#33363E;padding:2px 8px;border-radius:8px">15/4</small></span><span class="nv-sets"><b class="w">6-4</b><b>3-6</b><b class="w">10-7</b></span><span class="nv-k">Au bilan <b style="color:#6FC28F;float:right">+20 pts</b></span>');
    if (k === "pistes") return nvc('<span class="nv-pill" style="background:#D4E64A;color:#121212">LE PLUS ACCESSIBLE</span><b style="font-size:17px">1 victoire contre un 15/4</b><span class="nv-pill" style="margin-top:8px">PLUS AMBITIEUX</span><b style="font-size:17px">1 victoire contre un 15/3</b>');
    if (k === "notif") return nvc('<span class="nv-k">Montée · maintenant</span><b style="font-size:16px">Tu montes à 15/3 !</b><span style="font-size:13px;opacity:.8">Victoire contre Paul (15/1) : +120 pts. C\'est dans la poche pour la sortie du 3 novembre.</span>');
    if (k === "widgets" && window.MonteeWidgetArt) {
      var A2 = window.MonteeWidgetArt, dd = { status: "maintien", rank: "15/4", releaseIso: E.iso(today()).slice(0, 8) + "28", target: "15/4 → 15/3", short: "Une victoire peut suffire", total: 310, norme: 325, pct: 95, form: ["V", "D", "V", "V", "V"], streak: "3 victoires d'affilée", recordShort: "12 V · 5 D" };
      var d3 = { recent: [{ ini: "JM" }, { ini: "TD" }, { ini: "LP" }], scout: { name: "Thomas Mercier", rank: "15/2", p: 41, head: "Match ouvert", h2h: "1 – 1", tip: "Il met du temps à se chauffer", tipS: "Démarre fort, pas de round d'observation." } };
      return '<div class="nv-widgets col"><style>' + A2.css + '</style><div class="nv-w wide s">' + A2.html("joueurs", d3, "lin", 360, 92) + '</div><div class="nv-w wide">' + A2.html("adversaire", d3, "nuit", 360, 170) + "</div></div>";
    }
    if (k === "themes") return '<div class="nv-themes">' + ["lin", "nuit", "terre", "dur", "gazon"].map(function (t) { var w = THEME_SW[t]; return '<span class="nv-ph" style="background:' + w[0] + '"><i style="background:' + w[1] + '"></i><b style="background:' + w[3] + '"></b><u style="background:' + w[2] + '"></u><u style="background:' + w[1] + ';width:70%"></u></span>'; }).join("") + "</div>";
    if (k === "courbe") return '<svg viewBox="0 0 300 130" class="nv-chart"><line x1="0" x2="300" y1="34" y2="34" stroke="#fff" stroke-opacity=".5" stroke-dasharray="4 4"/><polyline points="10,110 50,104 90,96 130,98 170,70 210,64 250,52 290,40" fill="none" stroke="#6FC28F" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/><line x1="170" x2="170" y1="76" y2="122" stroke="#fff" stroke-opacity=".4" stroke-dasharray="2 3"/><rect x="146" y="38" width="48" height="22" rx="11" fill="#D4E64A"/><text x="170" y="53" text-anchor="middle" font-size="12" font-weight="700" fill="#121212">245</text><circle cx="170" cy="70" r="7" fill="#D4E64A" stroke="#121212" stroke-width="2"/></svg>';
    if (k === "clavier") return '<div class="nv-kb"><div class="nv-field">Gaucher, slice revers très bas<i></i></div><div class="nv-keys">' + new Array(28).join("<span></span>") + "</div></div>";
    return "";
  }
  function notesHtml() {
    var p = NOTES.pages[UI.notesPage || 0], last = (UI.notesPage || 0) === NOTES.pages.length - 1, IL = window.MonteeIll;
    var dots = '<div class="nv-dots">' + NOTES.pages.map(function (x, i) { return '<i class="' + (i === (UI.notesPage || 0) ? "on" : "") + '"></i>'; }).join("") + "</div>";
    var body = p.hero ? '<div class="nv-hero">' + (IL ? IL.welcome() : "") + '<span class="nv-big">' + esc(p.title) + '</span><span class="nv-lead">' + esc(p.text) + "</span></div>" :
      '<div class="nv-vis">' + notesVis(p.vis) + '</div><span class="nv-tag ' + p.tone + '">' + esc(p.tag) + '</span><span class="nv-title">' + esc(p.title) + '</span><span class="nv-text">' + esc(p.text) + "</span>";
    return '<div class="notes" role="dialog" aria-modal="true" aria-label="Quoi de neuf"><button class="iconbtn nv-close" data-a="notesClose" aria-label="Fermer">' + I.cross + '</button><div class="nv-body">' + body + "</div>" +
      '<div class="nv-foot">' + dots + '<button class="btn nv-next" data-a="notesNext">' + (last ? "C'est parti" : "Suivant " + I.next) + "</button></div></div>";
  }

  // ---------- Données ----------
  function backup(share) {
    var copy = JSON.parse(JSON.stringify(S)); if (copy.tenup) delete copy.tenup.cred;
    var name = "montee-sauvegarde-" + E.iso(today()) + ".json", txt = JSON.stringify(copy, null, 2);
    var done = function (msg) { S.lastBackup = E.iso(today()); save(); toast(msg); render(); };
    var web = function () {
      var file = typeof File === "function" ? new File([txt], name, { type: "application/json" }) : null;
      if ((NATIVE || share) && file && navigator.canShare && navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], title: "Sauvegarde Montée" }).then(function () { done("Sauvegarde créée."); }).catch(function () {});
        return;
      }
      var blob = new Blob([txt], { type: "application/json" });
      var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
      document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
      done("Sauvegarde créée : " + name);
    };
    if (NATIVE && Tenup) {
      Promise.resolve().then(function () { return Tenup.saveFile({ name: name, content: txt, mime: "application/json", share: !!share }); })
        .then(function (r) { done(r && r.saved === "downloads" ? "Sauvegarde créée dans Téléchargements : " + name : "Choisis où ranger ta sauvegarde."); })
        .catch(web);
      return;
    }
    web();
  }
  V.donnees = function () {
    var lb = S.lastBackup, age = lb ? Math.round((today() - E.parseDate(lb)) / 864e5) : null, old = age == null || age > 30;
    var nT = (S.trainings || []).length;
    var row = function (attr, ic, t, sub, extra) { return '<' + (extra ? "label" : "button") + ' class="row dn-row" ' + attr + '><span class="dn-ic">' + ic + '</span><span class="grow"><span class="t">' + t + '</span><span class="s">' + sub + "</span></span>" + (extra || I.next) + "</" + (extra ? "label" : "button") + ">"; };
    var s = '<div class="screen">' + topbar("Tes données");
    // État
    s += '<div class="card dn-state"><div class="dn-top"><span class="badge ' + (old ? "ko" : "ok") + '">' + (old ? I.warn : I.check) + '</span><span class="grow"><b>' + (lb ? "Sauvegardé " + (age === 0 ? "aujourd'hui" : age === 1 ? "hier" : "il y a " + age + " jours") : "Jamais sauvegardé") + '</b><span class="small">' + (old ? "Pense à faire une sauvegarde : tes données ne sont que sur ce téléphone." : "Tes données sont à l'abri.") + "</span></span></div>" +
      '<div class="dn-stats"><span><b>' + S.matches.length + "</b>match" + (S.matches.length > 1 ? "s" : "") + "</span><span><b>" + S.rackets.length + "</b>raquette" + (S.rackets.length > 1 ? "s" : "") + "</span><span><b>" + nT + "</b>entraînement" + (nT > 1 ? "s" : "") + "</span></div></div>";
    // Sauvegarder
    s += "<h2>Sauvegarde</h2>";
    if (IOS) s += '<button class="btn primary" data-a="export">' + I.share + " Sauvegarder</button>";
    else if (NATIVE) s += '<button class="btn primary" data-a="exportShare">' + I.share + " Sauvegarder</button>";
    else s += '<button class="btn primary" data-a="export">' + I.save + " Télécharger une sauvegarde</button>";
    s += '<p class="small" style="margin:0">' + (IOS ? "Dans Fichiers, iCloud ou par e-mail : garde-la ailleurs que sur ce téléphone." : NATIVE ? "Sur Drive ou par e-mail : garde-la ailleurs que sur ce téléphone." : "Un fichier est téléchargé sur cet appareil.") + "</p>";
    s += '<div class="card" style="padding:0">' +
      (NATIVE && !IOS ? row('data-a="export"', I.save, "Copie sur ce téléphone", "Dans le dossier Téléchargements") + '<div class="dn-sep"></div>' : "") +
      row('style="cursor:pointer"', svg('<path d="M4 12a8 8 0 1 0 2.3-5.6M4 4v4h4"/>'), "Restaurer une sauvegarde", "Remplace les données de ce téléphone", I.next + '<input type="file"' + (NATIVE ? "" : ' accept="application/json,.json"') + ' data-a="importFile" hidden>') + "</div>";
    // Zone sensible, à part
    s += '<div class="card" style="padding:0;margin-top:8px"><button class="row dn-row dn-danger" data-a="wipe"><span class="dn-ic">' + I.trash + '</span><span class="grow"><span class="t">Tout effacer</span><span class="s">Supprime tes matchs, raquettes et réglages</span></span></button></div>';
    return s + "</div>";
  };

  // ---------- Méthode ----------
  V.methode = function () {
    var sex = S.profile.sex;
    var rows = E.ECHELONS.slice(1, 22).map(function (e, i) { return "<tr><td>" + e + "</td><td>" + E.BAREME.norme[sex][i + 1] + "</td><td>" + E.BAREME.base[sex][i + 1] + "</td></tr>"; }).join("");
    return '<div class="screen">' + topbar("Comment c'est calculé") +
      '<div class="card"><b>Le principe</b><span style="font-size:15px;line-height:1.5">Le classement sort le premier mardi de chaque mois. Il compte tes matchs des 12 derniers mois. Pour monter, il faut atteindre la norme de l\'échelon au-dessus <b>et</b> avoir battu un joueur déjà classé à cet échelon (hors WO).</span></div>' +
      '<div class="card"><b>Ce que rapporte une victoire</b><table class="simple"><tr><th>Adversaire, par rapport à l\'échelon calculé</th><th>Points</th></tr>' +
      [["2 échelons ou plus au-dessus", 120], ["1 échelon au-dessus", 90], ["Même échelon", 60], ["1 échelon en dessous", 30], ["2 échelons en dessous", 20], ["3 échelons en dessous", 15], ["4 échelons ou plus en dessous", 0]].map(function (r) { return "<tr><td>" + r[0] + "</td><td>" + r[1] + "</td></tr>"; }).join("") + "</table></div>" +
      '<div class="card"><b>Combien de victoires comptent</b><span style="font-size:15px;line-height:1.5">Seules tes meilleures victoires comptent. Leur nombre dépend de l\'échelon et de ton V − E − 2I − 5G : V tes victoires, E tes défaites à échelon égal, I à un échelon en dessous, G à deux échelons ou plus en dessous. Les deux premières défaites par WO ne comptent pas.</span></div>' +
      '<div class="card"><b>Les bonus</b><span style="font-size:15px;line-height:1.5">Sans défaite (WO compris) contre un joueur classé à l\'échelon calculé ou en dessous : +50 (30/2 et 30/1, 5 matchs minimum), +50 (3e série, 10 matchs), +100 (2e série, 10 matchs). Championnats individuels (France et phases qualificatives) : +15 par victoire en 4e série, +20 en 3e série, +25 en 2e série, 3 meilleures bonifications (5 à partir de -2/6).</span></div>' +
      '<div class="card"><b>Les doubles</b><span style="font-size:15px;line-height:1.5">Une victoire en double ne compte pas comme une victoire en simple : elle rapporte un bonus selon le poids des paires (la somme des classements des deux joueurs, le jour du match). En perf, à poids égal ou en contre : 5, 3 ou 1 point en 3e et 4e série, 7, 4 ou 2 en 2e série, 10, 6 ou 3 à partir de -2/6. Seules les meilleures comptent : 5 en 4e série, 7 au-delà. Les défaites en double ne comptent pas.</span></div>' +
      '<div class="card"><b>L\'ajustement Ten\'Up</b><span style="font-size:15px;line-height:1.5">Quand tu importes depuis Ten\'Up, Montée récupère aussi le bilan officiel de ta simulation et s\'aligne dessus. L\'écart éventuel apparaît dans le détail sous « Ajustement d\'après Ten\'Up ».</span></div>' +
      '<div class="card"><b>Normes ' + (sex === "F" ? "dames" : "messieurs") + '</b><table class="simple"><tr><th>Échelon</th><th>Points</th><th>Victoires de base</th></tr>' + rows + "</table></div>" +
      '<p class="small">Valeurs publiées par la FFT (normes mises à jour en janvier 2023). Les échelons 40/2 et 40/1, la 1re série et les cas particuliers (coefficients de format, blocages, WO à répétition au-delà du bilan) ne sont pas simulés. Calcul indicatif : seul le classement officiel fait foi.</p></div>';
  };

  V.apropos = function () {
    return '<div class="screen">' + topbar("À propos") +
      '<div class="brand">' + I.logo(30) + "montée</div>" +
      '<div class="card"><b>Tes données restent chez toi</b><span style="font-size:15px;line-height:1.5">Pas de compte, pas de serveur, pas de pub, pas de pisteur. Ton palmarès et ton matériel sont enregistrés uniquement dans ce navigateur.</span></div>' +
      '<div class="card"><b>Pas lié à la FFT</b><span style="font-size:15px;line-height:1.5">Montée est une application indépendante. Elle n\'est ni éditée ni approuvée par la Fédération Française de Tennis. Ten\'Up est un service de la FFT. Le calcul est indicatif : seul le classement officiel fait foi.</span></div>' +
      (NATIVE ? '<div class="card"><b>Gratuite et sans pub</b><span style="font-size:15px;line-height:1.5">Parle de Montée à ton club, c\'est la meilleure façon de l\'aider.</span></div>' :
      '<div class="card"><b>Gratuit grâce à toi</b><span style="font-size:15px;line-height:1.5">Si Montée t\'aide à monter, un petit don aide à la garder gratuite.</span><button class="btn balle small" data-a="don">' + I.heart + " Soutenir Montée</button></div>") +
      '<a class="row" href="#/methode" style="background:var(--card);border-radius:20px"><span class="grow"><span class="t">Comment c\'est calculé</span><span class="s">Barème, normes, V − E − 2I − 5G</span></span>' + I.next + "</a>" +
      '<a class="row" href="#/donnees" style="background:var(--card);border-radius:20px"><span class="grow"><span class="t">Sauvegarder mes données</span><span class="s">Créer ou restaurer une sauvegarde</span></span>' + I.next + "</a>" +
      '<p class="small">Version ' + CONFIG.VERSION + "</p></div>";
  };

  // ---------- Données d'exemple ----------
  function demo() {
    var t = today();
    var ago = function (days) { var d = new Date(t); d.setDate(d.getDate() - days); return E.iso(d); };
    var r1 = { id: "r1", name: "Raquette n°1", string: "Polyester 1,25", stringType: "mono", tension: 24, restrings: [ago(380), ago(40)], main: true };
    var r2 = { id: "r2", name: "Raquette n°2", string: "Multifilament 1,30", stringType: "multi", tension: 25, restrings: [ago(150)], main: false };
    r1.breaks = [{ date: ago(120), min: 1250, string: "Polyester 1,25", type: "mono" }];
    S.slots = [{ id: "s1", dow: (today().getDay() + 4) % 7, time: "18:30", minutes: 90, label: "Collectif", since: ago(20) }];
    S.slotLog = {};
    S.trainings = [[3, 120, null], [9, 90, 3], [16, 120, 4], [23, 90, 5], [30, 90, 3], [37, 120, 4]].map(function (x) {
      return { id: uid(), date: ago(x[0]), minutes: x[1], racketId: "r1", string: "Polyester 1,25", tension: 24, tensionCross: null, newString: false, feel: x[2], note: "" };
    });
    var M = function (days, opp, rank, res, score, o) {
      return Object.assign({ id: uid(), date: ago(days), opp: opp, oppRank: rank, result: res, wo: false, score: score, kind: "tournoi", surface: "Dur", indoor: true, racketId: "r1", string: "Polyester 1,25", tension: 24, feel: 4, note: "", source: "exemple" }, o || {});
    };
    S.profile = { name: S.profile.name || "Alex", sex: "H", rank: "15/2", licence: S.profile.licence || "" };
    S.rackets = [r1, r2];
    S.matches = [
      M(4, "J. Lefèvre", "15/1", "V", "6-4 3-6 7-5", { racketId: "", string: "", tension: null, feel: null }),
      M(6, "E. Blanc", "15/2", "V", "", { wo: true, racketId: "", string: "", tension: null, feel: null }),
      M(11, "A. Moreau", "15/2", "V", "6-3 6-2", { racketId: "", string: "", tension: null, feel: null, kind: "equipes" }),
      M(17, "K. Benali", "15", "D", "4-6 2-6", { feel: 2 }),
      M(25, "T. Martin", "15/1", "V", "7-6 6-4"),
      M(32, "P. Garnier", "15/3", "V", "6-1 6-3", { surface: "Terre battue", indoor: false }),
      M(46, "M. Girard", "15/1", "D", "3-6 6-7", { racketId: "r2", string: "Multifilament 1,30", tension: 25, surface: "Terre battue", indoor: false, feel: 3 }),
      M(53, "S. Roux", "15/2", "V", "6-2 4-6 6-3", { surface: "Terre battue", indoor: false }),
      M(88, "L. Faure", "15/4", "V", "6-2 6-2", { racketId: "r2", string: "Multifilament 1,30", tension: 25 }),
      M(120, "N. Petit", "15/3", "V", "6-4 6-4", { tension: 23 }),
      M(150, "B. Leroy", "15/2", "D", "6-7 4-6", { tension: 23, feel: 2 }),
      M(175, "C. Bernard", "15/3", "V", "7-5 6-3"),
      M(210, "F. Lambert", "15/4", "V", "6-0 6-1", { racketId: "r2", string: "Multifilament 1,30", tension: 25, kind: "equipes" }),
      M(245, "G. Mercier", "15/3", "D", "2-6 7-6 4-6", { tension: 23, feel: 3 }),
      M(280, "H. Simon", "15/5", "V", "6-3 6-2"),
      M(355, "R. Petit", "15/2", "V", "6-4 7-6", { kind: "equipes" }),
      M(420, "D. Fontaine", "15/3", "V", "6-2 6-4")
    ];
    var Dd = function (days, opp, r1, r2, res, partnerRank, score) { return { id: "d" + uid(), date: ago(days), opp: opp, oppRanks: [r1, r2], oppRank: r1, result: res, wo: false, dbl: true, partner: "P. Durand", partnerRank: partnerRank, score: score, source: "exemple" }; };
    S.doubles = [Dd(9, "L. Roy / M. Blanc", "15/1", "15/2", "V", "15/3", "6-4 7-5"), Dd(40, "T. Gay / B. Noël", "15/3", "15/4", "V", "15/2", "6-2 6-3"), Dd(70, "R. Diaz / S. Morel", "15/2", "15/2", "V", "15/2", "7-6 6-4"), Dd(130, "J. Faure / K. Ly", "15", "15/1", "D", "15/2", "4-6 3-6")];
    S.onboarded = true; save();
    toast("Exemple chargé : 17 matchs, 4 doubles et 6 entraînements. Tu peux tout effacer dans Sauvegarder mes données.");
    go("");
  }

  // ---------- Actions ----------
  var A = {
    // ----- Santé connectée -----
    hcConnect: function () {
      if (!Tenup || !Tenup.healthRequest) return;
      UI.hcWait = true; UI.hcDenied = false; render();
      Promise.resolve(Tenup.healthRequest()).catch(function () {});
      var n = 0, tick = function () {
        hcStatus().then(function (st) {
          if (st && st.granted) {
            UI.hcWait = false; S.health = { on: true, since: Date.now(), notify: true, done: (S.health && S.health.done) || {} }; save();
            if (LN && LN.requestPermissions) LN.requestPermissions().catch(function () {});
            hcSync(); UI.hc.sessions = null; go("sante/revue"); return;
          }
          if (++n < 90 && UI.hcWait) setTimeout(tick, 1000); else { UI.hcWait = false; UI.hcDenied = true; if (route().indexOf("sante") === 0) render(); }
        });
      };
      setTimeout(tick, 1200);
    },
    hcSettings: function () { if (Tenup && Tenup.healthSettings) Promise.resolve(Tenup.healthSettings()).catch(function () {}); UI.hcAsked = false; UI.hc = UI.hc || {}; UI.hc.st = null; },
    hcOff: function () {
      if (!confirm("Déconnecter la santé connectée ? Tes entraînements déjà ajoutés restent dans Montée.")) return;
      S.health.on = false; save(); hcSync(); UI.hc = {}; toast("Déconnecté. Tu peux aussi retirer l'accès de Montée dans " + (IOS ? "Réglages → Santé." : "Health Connect.")); render();
    },
    hcTick: function (el) { UI.hcSel = UI.hcSel || {}; UI.hcSel[el.dataset.id] = UI.hcSel[el.dataset.id] === false; render(); },
    hcForce: function (el) { UI.hcForce = UI.hcForce || {}; UI.hcForce[el.dataset.id] = true; UI.hcSel = UI.hcSel || {}; UI.hcSel[el.dataset.id] = true; render(); },
    hcRk: function (el) { UI.hcRk = el.dataset.v; render(); },
    hcOthers: function () { UI.hcOthers = !UI.hcOthers; render(); },
    hcRetry: function () { UI.hc = UI.hc || {}; UI.hc.err = null; UI.hc.sessions = null; hcLoad(30, true); render(); },
    hcIsTennis: function (el) { S.health.extra = S.health.extra || {}; S.health.extra[el.dataset.id] = true; save(); toast("Noté : cette séance compte comme du tennis."); render(); },
    hcAddAll: function () {
      var done = S.health.done || {}, md = hcMatchDays(), lim = Date.now() - 30 * 864e5, n = 0;
      var rk = UI.hcRk !== undefined ? UI.hcRk : (racketFor("train") || {}).id || "";
      S.trainings = S.trainings || [];
      hcSessions().filter(function (x) { return !done[x.id] && x.start >= lim && x.end - x.start >= 10 * 60000; }).forEach(function (x) {
        var keep = (!md[hcIso(x.start)] || (UI.hcForce || {})[x.id]) && (UI.hcSel || {})[x.id] !== false;
        if (keep) { S.trainings.push(hcTraining(x, rk)); n++; hcDone(x.id, "added"); } else hcDone(x.id, md[hcIso(x.start)] ? "match" : "ignored");
      });
      S.onboarded = true; save(); hcSync(); UI.hcSel = {}; UI.hcForce = {};
      toast(n ? plural(n, "entraînement ajouté", "entraînements ajoutés") + (rk ? "" : ". Choisis la raquette quand tu veux.") : "C'est noté."); go("");
    },
    hcAdd: function (el) {
      var x = hcSessions().filter(function (y) { return y.id === el.dataset.id; })[0]; if (!x) return;
      S.trainings = S.trainings || []; var t = hcTraining(x); S.trainings.push(t); hcDone(x.id, "added"); save(); hcSync();
      toast("Entraînement ajouté : " + fmtDur(t.minutes) + " de jeu" + (t.racketId ? "." : ". Choisis la raquette quand tu veux.")); render();
    },
    hcIgnore: function (el) { hcDone(el.dataset.id, "ignored"); save(); hcSync(); render(); },
    follow: function (el) {
      var id = el.dataset.id, sc = (S.scout || {})[id]; if (!sc) return;
      S.follow = S.follow || {};
      if (S.follow[id]) { delete S.follow[id]; save(); toast("Tu ne suis plus ce joueur."); render(); return; }
      var pr = sc.profil || {};
      S.follow[id] = { id: id, name: [pr.prenom ? pr.prenom.charAt(0).toUpperCase() + pr.prenom.slice(1).toLowerCase() : "", pr.nom || ""].join(" ").trim(), rank: pr.classement || "", club: pr.club || "", hit: sc.hit, snap: folSnap(sc), at: Date.now(), seen: true };
      save(); toast("Suivi : ses nouvelles arriveront à chaque synchro Ten'Up."); render();
      if (LN && !S.notif && LN.requestPermissions) LN.requestPermissions().then(function (p) { S.notif = p && p.display === "granted"; save(); }).catch(function () {});
    },
    followHit: function (el) { var h = (UI.fafHits || [])[+el.dataset.v]; if (h) folAdd({ id: h.id, idp: h.idp, nom: h.nom, prenom: h.prenom, rank: h.rank, club: h.club }, [h.prenom ? h.prenom.charAt(0) + h.prenom.slice(1).toLowerCase() : "", h.nom].join(" ").trim(), h.rank, h.club); },
    followKnown: function (el) { var x = oppIndex().filter(function (o) { return o.key === el.dataset.v; })[0]; if (!x || !x.oid) return; var pr = x.name.split(" "); folAdd({ id: x.oid, nom: pr.slice(1).join(" "), prenom: pr[0], rank: x.rank, club: x.oclub || "" }, x.name, x.rank, x.oclub); },
    folHelpOk: function () { S.folHelp = true; save(); render(); },
    fafTab: function (el) { UI.fafTab = el.dataset.v; render(); },
    folOpen: function (el) { var f = (S.follow || {})[el.dataset.id]; if (f && f.hit) openScout(f.hit); },
    recOpen: function (el) { var sc = (S.scout || {})[el.dataset.id]; if (sc && sc.hit) openScout(sc.hit); },
    devReal: function () { UI.devReal = true; render(); window.scrollTo(0, 0); },
    hcSwap: function (el) {
      var t = (S.trainings || []).filter(function (x) { return x.id === el.dataset.id; })[0], m = UI.draft && mById(UI.draft.id); if (!t || !m) return;
      var a = { minutes: m.minutes, hid: m.hid, at: m.hat };
      m.minutes = t.minutes; m.hid = t.hid; m.hat = t.at;
      t.minutes = a.minutes || t.minutes; t.hid = a.hid; t.at = a.at;
      UI.draft.minutes = m.minutes; UI.draft.hid = m.hid; UI.draft.hat = m.hat; UI.origKey = null;
      save(); toast("Échangé : le match prend la séance de " + (m.hat ? hcHour(m.hat) : "l'autre") + ", l'autre redevient un entraînement."); render();
    },
    hcMatch: function (el) {
      var x = hcSessions().filter(function (y) { return y.id === el.dataset.id; })[0]; if (!x) return;
      UI.hcPrefillM = x; UI.draft = null; go("match/new");
    },
    hcDetail: function (el) {
      var x = hcSessions().filter(function (y) { return y.id === el.dataset.id; })[0]; if (!x) return;
      UI.hcPrefill = x; UI.draft = null; go("entrainement/new");
    },
    back: function () {
      if (isDirty()) { UI.leaveAsk = true; render(); return; }
      UI.draft = null; UI.racketDraft = null; UI.rkMenu = false; back();
    },
    leaveStay: function () { UI.leaveAsk = false; render(); },
    leaveDiscard: function () { UI.leaveAsk = false; UI.draft = null; UI.racketDraft = null; UI.rkMenu = false; UI.origKey = null; back(); },
    leaveSave: function () { var e = editCtx(); UI.leaveAsk = false; if (e) A[e.save](); },
    rkMenu: function () { UI.rkMenu = !UI.rkMenu; render(); },
    bilanSel: function (el) { UI.bilanSel = +el.dataset.v; render(); },
    sheet: function (el) { UI.sheet = { k: el.dataset.k, v: el.dataset.v }; render(); },
    sheetClose: function () { if (UI.sheet && UI.sheet.k === "recap") { delete S.syncRecap; save(); } UI.sheet = null; render(); },
    menu: function () { UI.menu = true; render(); var b = app.querySelector(".sheet .menu-item"); if (b) b.focus(); },
    closeMenu: function () { UI.menu = false; render(); },
    newMatch: function () { UI.menu = false; UI.draft = null; go("match/new"); },
    newTraining: function () { UI.menu = false; UI.draft = null; go("entrainement/new"); },
    saveTraining: function () {
      var t = UI.draft;
      if (!t.date) return toast("Indique la date de l'entraînement.");
      var clean = Object.assign({}, t); delete clean._for; delete clean._hsrc;
      if (clean.hid && S.health) { hcDone(clean.hid, "added"); hcSync(); }
      S.trainings = S.trainings || [];
      var i = S.trainings.findIndex(function (x) { return x.id === clean.id; });
      if (i >= 0) S.trainings[i] = clean; else S.trainings.push(clean);
      S.onboarded = true; save(); UI.draft = null;
      toast(i >= 0 ? "Entraînement mis à jour." : "Entraînement ajouté : " + fmtDur(clean.minutes) + " de jeu.");
      if (i >= 0) back(); else go("materiel");
    },
    delTraining: function () {
      if (!confirm("Supprimer cet entraînement ?")) return;
      S.trainings = (S.trainings || []).filter(function (x) { return x.id !== UI.draft.id; }); save(); UI.draft = null; toast("Entraînement supprimé."); back();
    },
    dmin: function (el) { var d = UI.draft, isM = d.opp != null; d.minutes = Math.max(15, Math.min(300, (d.minutes || (isM ? estMinutes(d) : 60)) + (+el.dataset.v))); render(); },
    dminReset: function () { UI.draft.minutes = null; render(); },
    scorePick: function (el) { var d = UI.draft, sets = (d.sets || []).slice(); sets[+el.dataset.i] = el.dataset.v.split("-").map(Number); UI.scoreEdit = null; applySets(d, sets); render(); },
    scoreEdit: function (el) { UI.scoreEdit = +el.dataset.v; render(); },
    scoreClear: function () { UI.draft.sets = []; UI.draft.score = ""; UI.scoreEdit = null; UI.stb = false; render(); },
    scoreStb: function (el) { UI.stb = el.dataset.v === "1"; render(); },
    stbExt: function (el) { UI.stbExt = Math.max(11, Math.min(40, (UI.stbExt || 11) + (+el.dataset.v))); render(); },
    scoreManual: function () { UI.scoreManual = !UI.scoreManual; if (!UI.scoreManual) { UI.draft.sets = setsOf(UI.draft.score); } render(); },
    qaRacket: function (el) { UI.qa.racketId = UI.qa.racketId === el.dataset.v ? "" : el.dataset.v; render(); },
    qaSurface: function (el) { UI.qa.surface = UI.qa.surface === el.dataset.v ? "" : el.dataset.v; render(); },
    qaMore: function () { UI.qa.more = true; render(); },
    qaIndoor: function (el) { var v = el.dataset.v === "1"; UI.qa.indoor = UI.qa.indoor === v ? null : v; render(); },
    qaFeel: function (el) { var v = +el.dataset.v; UI.qa.feel = UI.qa.feel === v ? 0 : v; haptic("light"); render(); },
    qaSkip: function () { var m = S.matches.filter(function (x) { return x.id === UI.qa.id; })[0]; if (m) { m.qaSkip = true; save(); } UI.qa = null; UI.qaDone = null; toast("Tu le retrouves dans le Palmarès, onglet « À annoter »."); render(); },
    qaSave: function () {
      var q = UI.qa, m = q && S.matches.filter(function (x) { return x.id === q.id; })[0]; if (!m) return;
      if (!q.racketId && !q.surface && q.indoor == null && !q.feel) { toast("Choisis au moins une info, ou touche « Plus tard »."); return; }
      var r = racket(q.racketId);
      if (r) { m.racketId = r.id; m.string = r.string || ""; m.tension = r.tension || null; m.tensionCross = r.tensionCross != null ? r.tensionCross : null; }
      if (q.surface) m.surface = q.surface;
      if (q.indoor != null) m.indoor = q.indoor;
      if (q.feel) m.feel = q.feel;
      m.noted = true; m.qaSkip = true;
      S.lastQA = { surface: q.surface || (S.lastQA || {}).surface, indoor: q.indoor != null ? q.indoor : (S.lastQA || {}).indoor };
      UI.qaRun = qaList().length ? (UI.qaRun || 0) + 1 : 0;
      UI.qaDone = { at: Date.now(), label: (m.result === "V" ? "Victoire" : "Défaite") + " contre " + (m.opp && !isAnon(m.opp) ? m.opp : "un " + m.oppRank) };
      UI.qa = null; save(); haptic("success"); render();
      setTimeout(function () { if (UI.qaDone && Date.now() - UI.qaDone.at >= 5900) { UI.qaDone = null; if (route() === "") render(); } }, 6000);
    },
    photoMenu: function () { UI.photoMenu = true; render(); },
    photoClose: function () { UI.photoMenu = false; render(); },
    photoPick: function () {
      // Le champ fichier vit hors de l'appli : un nouveau rendu ne doit pas l'effacer pendant le choix
      var inp = document.getElementById("photo-in");
      if (!inp) {
        inp = document.createElement("input"); inp.type = "file"; inp.accept = "image/*"; inp.id = "photo-in"; inp.style.display = "none"; document.body.appendChild(inp);
        inp.addEventListener("change", function () { var el = inp;
    if (el.files && el.files[0]) {
      var fr = new FileReader();
      fr.onload = function () {
        var im = new Image();
        im.onload = function () {
          var SZ = 320, c = document.createElement("canvas"), k = Math.max(SZ / im.width, SZ / im.height); c.width = c.height = SZ;
          c.getContext("2d").drawImage(im, (SZ - im.width * k) / 2, (SZ - im.height * k) / 2, im.width * k, im.height * k);
          S.profile.photo = c.toDataURL("image/jpeg", 0.85); save(); toast("Photo mise à jour."); render();
        };
        im.onerror = function () { toast("Cette image n'a pas pu être lue."); };
        im.src = fr.result;
      };
      fr.readAsDataURL(el.files[0]); el.value = "";
    }
        });
      }
      UI.photoMenu = false; inp.click(); setTimeout(render, 0);
    },
    photoTenup: function () { S.profile.photo = null; UI.photoMenu = false; save(); render(); },
    photoDel: function () { S.profile.photo = "none"; UI.photoMenu = false; save(); render(); },
    gEdit: function (el) { UI.gEdit = el.dataset.v; render(); },
    gDone: function () { UI.gEdit = null; render(); },
    plTab: function (el) { UI.plTab = el.dataset.v; render(); window.scrollTo(0, 0); },
    oppGame: function (el) {
      S.oppGame = S.oppGame || {}; var g = S.oppGame[el.dataset.id] = S.oppGame[el.dataset.id] || {}, k = el.dataset.k; UI.gEdit = el.dataset.id;
      g[k] = g[k] === el.dataset.v ? "" : el.dataset.v; save(); render();
    },
    gameSet: function (el) { UI.gEdit = "me"; var g = S.profile.game = S.profile.game || {}, k = el.dataset.k; g[k] = myGame()[k] === el.dataset.v ? "" : el.dataset.v; save(); render(); },
    gameArm: function (el) {
      UI.gEdit = "me"; var g = S.profile.game = S.profile.game || {}, a = (g.arms || []).slice(), i = a.indexOf(el.dataset.v);
      if (i >= 0) a.splice(i, 1); else { if (a.length >= 3) { toast("3 armes au plus : retire-en une d'abord."); return; } a.push(el.dataset.v); }
      g.arms = a; save(); render();
    },
    goalLater: function () { S.goalLater = E.iso(today()); save(); toast("Tu le retrouves dans ton profil."); render(); },
    goalEdit: function () { UI.goalEdit = true; UI.goalDraft = null; render(); },
    goalDel: function () { if (!confirm("Retirer ton objectif ?")) return; S.goal = null; UI.goalDraft = null; save(); go("profil"); },
    goalRank: function (el) { UI.goalDraft.rank = +el.dataset.v; render(); },
    goalBy: function (el) { UI.goalDraft.by = el.dataset.v; render(); },
    goalSave: function () {
      var d = UI.goalDraft, c = ctx(), keep = S.goal && S.goal.rank === d.rank;
      S.goal = { rank: d.rank, by: d.by, at: keep ? S.goal.at : E.iso(today()), from: keep ? S.goal.from : (c.cur < 0 ? 0 : c.cur) };
      UI.goalEdit = false; UI.goalDraft = null; save(); haptic("success"); toast("Objectif " + lab(d.rank) + " enregistré."); render(); window.scrollTo(0, 0);
    },
    fafSearch: function () { UI.fafLocal = null; var inp = document.getElementById("ff-q"); if (inp) { UI.faf.q = inp.value; inp.blur(); } fafSearch(null); },
    fafClear: function () { UI.faf = { q: "" }; UI.fafHits = null; UI.fafErr = null; UI.fafLocal = null; render(); var inp = document.getElementById("ff-q"); if (inp) inp.focus(); },
    fafAll: function () { UI.fafAll = true; render(); },
    fafKnown: function (el) {
      var x = oppIndex().filter(function (o) { return o.key === el.dataset.v; })[0]; if (!x) return;
      var sp = nameSplits(x.name), n = sp[0] || splitName(x.name); UI.faf = { nom: n.nom, prenom: n.prenom, q: x.name, searched: x.name }; UI.fafHits = null; UI.fafErr = null; UI.fafLocal = x.key;
      // Ton palmarès Ten'Up connaît son identifiant : sa fiche directement, sans recherche
      if (x.oid && NATIVE) { openScout({ id: x.oid, nom: n.nom, prenom: n.prenom, rank: x.rank }); return; }
      // Depuis une autre page : on cherche sans quitter la page, pour que le retour y ramène
      if (route() !== "faf" && NATIVE && sp.length) { toast("Recherche de " + x.name + " sur Ten'Up…"); fafSearch(x, sp.slice(1)); return; }
      if (route() !== "faf") go("faf"); else render();
      window.scrollTo(0, 0);
      if (NATIVE && sp.length) fafSearch(x, sp.slice(1));
    },
    // Adversaire commun : sa fiche Ten'Up directement si on a son identifiant, sinon par la recherche
    goSimu: function () { UI.menu = false; go("simu"); },
    goCarte: function () { UI.menu = false; UI.cardWhich = null; UI.cardStyle = null; go("carte"); },
    simuLv: function (el) { UI.simuLv = +el.dataset.v; var y = window.scrollY; render(); window.scrollTo(0, y); },
    simuAdd: function (el) { UI.simu = (UI.simu || []).concat([{ r: el.dataset.v, l: UI.simuLv }]).slice(0, 10); var y = window.scrollY; render(); window.scrollTo(0, y); haptic("light"); },
    simuDel: function (el) { UI.simu.splice(+el.dataset.i, 1); var y = window.scrollY; render(); window.scrollTo(0, y); },
    simuClear: function () { UI.simu = []; render(); },
    cardWhich: function (el) { UI.cardWhich = el.dataset.v; UI.cardStyle = null; render(); },
    cardStyle: function (el) { UI.cardStyle = el.dataset.v; var y = window.scrollY; render(); window.scrollTo(0, y); },
    cardHide: function (el) { S.cardSeen = S.cardSeen || {}; S.cardSeen[el.dataset.v] = 1; save(); render(); },
    chargeHide: function (el) { S.chargeSeen = el.dataset.v; save(); render(); },
    cardShare: function () {
      var P = UI.cardP; if (!P) return;
      loadCardFonts().then(function () {
        var cv = drawCard(P, UI.cardS), url = cv.toDataURL("image/png"), b64 = url.split(",")[1], name = "montee-" + P.month.toLowerCase().replace(/\s+/g, "-") + ".png";
        var R = lastReleases(); S.cardSeen = S.cardSeen || {}; S.cardSeen[E.iso(R.r1)] = 1; save();
        if (NATIVE && Tenup && typeof Tenup.shareImage === "function") { Promise.resolve().then(function () { return Tenup.shareImage({ base64: b64, name: name }); }).catch(function () { toast("Partage impossible. Mets à jour Montée."); }); return; }
        cv.toBlob(function (blob) {
          var file = window.File ? new File([blob], name, { type: "image/png" }) : null;
          if (file && navigator.canShare && navigator.canShare({ files: [file] })) { navigator.share({ files: [file], title: "Mon mois de tennis" }).catch(function () {}); return; }
          var a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); toast("Image enregistrée : " + name);
        }, "image/png");
      });
    },
    wNext: function () { UI.wStep = Math.min(2, (UI.wStep || 0) + 1); render(); window.scrollTo(0, 0); },
    wSkip: function () { UI.wStep = 2; render(); },
    homeMore: function () { UI.homeMore = true; var y = window.scrollY; render(); window.scrollTo(0, y); },
    homeLess: function () { UI.homeMore = false; render(); var f = document.querySelector(".home-fold"); if (f) window.scrollTo(0, Math.max(0, f.getBoundingClientRect().top + window.scrollY - 120)); },
    tryAn: function () { var m = sortedMatches().filter(function (x) { return x.date && !x.wo && (x.result === "V" || x.result === "D"); })[0]; if (m) go("match/" + m.id); },
    tryHide: function () { S.tried = S.tried || {}; S.tried.hide = 1; save(); render(); },
    goFaf: function () { go("faf"); },
    cbOpen: function (el) { UI.cbOpen = UI.cbOpen || {}; UI.cbOpen[el.dataset.v] = 1; render(); setTimeout(function () { A.cbJump({ dataset: { v: el.dataset.v } }); }, 30); },
    cbClose: function (el) { UI.cbOpen = UI.cbOpen || {}; delete UI.cbOpen[el.dataset.v]; render(); setTimeout(function () { A.cbJump({ dataset: { v: el.dataset.v } }); }, 30); },
    cbJump: function (el) { if (el.dataset.v === "more") { var mo = document.getElementById("cb-more"), nv = document.getElementById("cb-nav"); if (mo) window.scrollTo({ top: mo.getBoundingClientRect().top + window.scrollY - (nv ? nv.offsetHeight + (parseFloat(getComputedStyle(nv).top) || 0) + 16 : 16), behavior: "smooth" }); return; }
      if (CB_COMPACT.indexOf(el.dataset.v) >= 0 && !(UI.cbOpen || {})[el.dataset.v]) { UI.cbOpen = UI.cbOpen || {}; UI.cbOpen[el.dataset.v] = 1; render(); } var t = document.getElementById("cb-" + el.dataset.v), nav = document.getElementById("cb-nav"); if (!t) return; var y = t.getBoundingClientRect().top + window.scrollY - (nav ? nav.offsetHeight + (parseFloat(getComputedStyle(nav).top) || 0) + 16 : 16); window.scrollTo({ top: y, behavior: "smooth" }); },
    mmOpen: function () { var id = route().split("/")[1]; UI.mmOpen = String(id); UI.plTab = "plan"; render(); mmWake(true); },
    mmClose: function () { UI.mmOpen = null; mmWake(false); render(); },
    mmResult: function (el) {
      var id = route().split("/")[1], sc = (S.scout || {})[id], pr = (sc && sc.profil) || {};
      UI.mmOpen = null; mmWake(false);
      UI.mmPrefill = { opp: [pr.prenom ? pr.prenom.charAt(0) + pr.prenom.slice(1).toLowerCase() : "", pr.nom || ""].join(" ").trim(), rank: T.normRank(pr.classement) || "", r: el.dataset.v };
      UI.draft = null; go("match/new");
    },
    palF: function (el) { UI.palF = el.dataset.v; var y = window.scrollY; render(); window.scrollTo(0, y); },
    palOpen: function (el) {
      var cur = route().split("/")[1], sc = (S.scout || {})[cur], pr = (sc && sc.profil) || {};
      UI.plTrail = (UI.plTrail || []).concat([{ id: cur, name: [pr.prenom, pr.nom].filter(Boolean).join(" ").replace(/\b([A-ZÀ-Ü])([A-ZÀ-Ü]+)\b/g, function (w, a, b) { return w === pr.nom ? w : a + b.toLowerCase(); }) }]);
      UI.plNav = true; A.scoutOpp(el);
    },
    plCrumb: function (el) { var i = +el.dataset.i, t = UI.plTrail || [], x = t[i]; if (!x) return; UI.plTrail = t.slice(0, i); UI.plTab = "pal"; go("joueur/" + x.id); window.scrollTo(0, 0); },
    scoutOpp: function (el) {
      var n = nameSplits(el.dataset.v)[0] || splitName(el.dataset.v);
      if (el.dataset.id) { openScout({ id: el.dataset.id, nom: n.nom, prenom: n.prenom }); return; }
      var k = nameKey(el.dataset.v), x = oppIndex().filter(function (o) { return o.key === k; })[0];
      UI.faf = { nom: n.nom, prenom: n.prenom, q: el.dataset.v, searched: el.dataset.v }; UI.fafHits = null; UI.fafErr = null; UI.fafLocal = x ? x.key : null;
      if (NATIVE) { toast("Recherche de " + el.dataset.v + " sur Ten'Up…"); fafSearch(x || { key: k, rank: "" }, nameSplits(el.dataset.v).slice(1)); return; }
      go("faf"); window.scrollTo(0, 0);
    },
    fafOpen: function (el) {
      var h0 = (UI.fafHits || [])[+el.dataset.v]; if (h0 && S.tenup.id && String(S.tenup.id) === String(h0.id)) { go("moi"); return; } var h = (UI.fafHits || [])[+el.dataset.v]; if (h) openScout(h); },
    scoutReload: function (el) { var p = (S.scout || {})[el.dataset.v]; if (p && p.hit) openScout(p.hit, true); },
    insightGo: function (el) { if (el.dataset.tab) UI.whereTab = el.dataset.tab; go(el.dataset.go || "courbes"); },
    rate: function (el) {
      var arr = el.dataset.t === "t" ? (S.trainings || []) : S.matches, o = arr.filter(function (x) { return x.id === el.dataset.id; })[0];
      if (!o) return; o.feel = +el.dataset.v; save(); toast("Noté : " + FEEL[o.feel - 1].toLowerCase() + "."); render();
    },
    rateSkip: function (el) {
      var arr = el.dataset.t === "t" ? (S.trainings || []) : S.matches, o = arr.filter(function (x) { return x.id === el.dataset.id; })[0];
      if (o) { o.feelSkip = true; save(); render(); }
    },
    party: function () { party(); },

    shareMontee: function () {
      if (!S.ahead) return;
      shareText("Je monte " + S.ahead.rank + " à la sortie du classement du " + flong(E.parseDate(S.ahead.release)) + " ! Calculé avec Montée.");
    },
    don: function () {
      UI.menu = false;
      if (CONFIG.DON_URL) { window.open(CONFIG.DON_URL, "_blank", "noopener"); render(); }
      else { render(); toast("Le lien de don n'est pas encore configuré."); }
    },
    goTenup: function () { UI.menu = false; UI.importRows = null; go("tenup"); },
    goRaquettes: function () { UI.menu = false; go("materiel"); setTimeout(function () { var h = app.querySelector("h2:last-of-type"); if (h) h.scrollIntoView({ behavior: "smooth" }); }, 50); },
    goProfil: function () { UI.menu = false; go("profil"); },
    goReglages: function () { UI.menu = false; go("reglages"); },
    setTheme: function (el) { S.prefs = S.prefs || {}; S.prefs.theme = el.dataset.v; save(); applyTheme(); render(); syncWidgets(true); },
    setWTheme: function (el) { S.prefs = S.prefs || {}; S.prefs.wtheme = el.dataset.v; save(); render(); syncWidgets(true); toast("Widgets mis à jour"); },
    setPull: function (el) { S.prefs = S.prefs || {}; S.prefs.pull = el.dataset.v; save(); render(); },
    openNotes: function () { UI.notesPage = 0; UI.notesOpen = true; render(); },
    notesNext: function () { if (UI.notesPage < NOTES.pages.length - 1) { UI.notesPage++; render(); } else A.notesClose(); },
    notesClose: function () { S.seenNotes = NOTES.v; UI.notesOpen = false; UI.notesPage = 0; save(); render(); },
    openStore: function () { var u = IOS ? "itms-apps://apps.apple.com/app/id" + CONFIG.APPSTORE_ID : NATIVE ? "market://details?id=fr.montennis.app" : "https://play.google.com/store/apps/details?id=fr.montennis.app"; window.open(u, "_system"); },
    goDonnees: function () { UI.menu = false; go("donnees"); },
    goMethode: function () { UI.menu = false; go("methode"); },
    goApropos: function () { UI.menu = false; go("apropos"); },
    goProjection: function () { go("projection"); },
    contact: function () { location.href = "mailto:" + CONFIG.CONTACT_EMAIL + "?subject=" + encodeURIComponent("Montée — mon avis"); },
    share: function () {
      UI.menu = false; render();
      shareText("Tu montes ce mois-ci ? Montée recalcule ton classement de tennis avant la sortie officielle.");
    },
    install: function () {
      UI.menu = false; render();
      if (UI.installEvt) { UI.installEvt.prompt(); UI.installEvt = null; return; }
      var ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
      toast(ios ? "Dans Safari : Partager, puis « Sur l'écran d'accueil »." : "Menu du navigateur ⋮, puis « Ajouter à l'écran d'accueil ».");
    },
    demo: demo,
    sex: function (el) { S.profile.sex = el.dataset.v; save(); render(); },
    saveProfil: function () {
      if (!S.profile.rank) return toast("Choisis ton classement.");
      UI.profEdit = false;
      save();
      if (!S.onboarded) { S.onboarded = true; save(); var nx = UI.afterProfil || ""; UI.afterProfil = null; go(nx); } else if (!S.matches.length || stack.length < 2) { toast("Profil enregistré."); go(""); } else { toast("Profil enregistré."); back(); }
    },
    skipImport: function () { UI.draft = null; if (!S.profile.rank) { UI.afterProfil = "match/new"; go("profil"); return; } S.onboarded = true; save(); go("match/new"); },
    palTab: function (el) { UI.palTab = el.dataset.v; render(); },
    palTodo: function () { UI.palTab = "todo"; go("palmares"); },
    matTab: function (el) { UI.matTab = el.dataset.v; render(); },
    projLevel: function (el) { UI.projLevel = +el.dataset.v; render(); },
    // fiche match
    dset: function (el) {
      var k = el.dataset.k, v = el.dataset.v;
      if (k === "kind" && UI.draft) UI.draft.kindSet = true; // choix à la main : la synchro ne l'écrase plus
      if (k === "indoor") v = v === "1";
      if (k === "feel" || k === "minutes") v = +v;
      UI.draft[k] = UI.draft[k] === v && (k === "surface" || k === "feel" || k === "indoor" || k === "label") ? (k === "surface" || k === "label" ? "" : null) : v;
      render();
    },
    dracket: function (el) {
      var r = racket(el.dataset.v);
      if (UI.draft.racketId === r.id) { UI.draft.racketId = ""; }
      else { UI.draft.racketId = r.id; UI.draft.string = r.string || ""; UI.draft.tension = r.tension || null; UI.draft.tensionCross = r.tensionCross != null ? r.tensionCross : null; }
      render();
    },
    tens: function (el) {
      var o = el.dataset.t === "match" ? UI.draft : UI.racketDraft, k = el.dataset.k;
      o[k] = Math.max(15, Math.min(32, (o[k] || 24) + (+el.dataset.v))); render();
    },
    newRacketFromMatch: function () { UI.racketDraft = null; UI.afterRacket = location.hash; go("raquette/new"); },
    saveMatch: function () {
      var m = UI.draft;
      if (m.wo) m.minutes = null;
      if (!m.oppRank) return toast("Indique le classement de l'adversaire.");
      if (!m.date && m.source !== "tenup-pdf") return toast("Indique la date du match.");
      var clean = Object.assign({}, m); delete clean._for; delete clean.sets; delete clean._auto;
      var i = S.matches.findIndex(function (x) { return x.id === clean.id; });
      // Adversaire anonyme sur Ten'Up renommé : on garde la version Ten'Up pour reconnaître le match aux synchros
      if (i >= 0 && clean.source === "tenup" && clean.oppTenup == null && isAnon(S.matches[i].opp) && !isAnon(clean.opp)) clean.oppTenup = S.matches[i].opp;
      if (i >= 0 && clean.oppTenup != null && isAnon(clean.opp)) { clean.opp = clean.oppTenup; delete clean.oppTenup; }
      if (i >= 0) S.matches[i] = clean; else S.matches.push(clean);
      // Nouveau match saisi : analyse mise en avant sur l'accueil, palmarès de l'adversaire lu en silence
      if (i < 0 && (clean.result === "V" || clean.result === "D") && !clean.wo) { S.anNew = [clean.id].concat((S.anNew || []).filter(function (x) { return x !== clean.id; })).slice(0, 3); setTimeout(function () { anFetch(clean, true).then(function () { if (route() === "") render(); }); }, 300); }
      if (clean.hid) hcDone(clean.hid, "match");
      var only = {}; only[clean.id] = 1; var merged = i < 0 && !clean.hid ? hcMerge(only) : 0;
      S.onboarded = true; save(); UI.draft = null;
      if (merged) hcMergeToast(merged); else
      toast(!clean.racketId && !clean.wo ? "Enregistré. Choisis une raquette pour qu'il ne soit plus « à annoter »." : i >= 0 ? "Match mis à jour." : "Match ajouté.");
      go(i >= 0 ? "palmares" : "");
    },
    verifySame: function (el) {
      var v = (S.verify || []).filter(function (x) { return x.id === el.dataset.id; })[0]; if (!v) return;
      var a = mById(v.id), b = mById(v.tid);
      if (a && b && isAnon(b.opp) && a.opp && !isAnon(a.opp)) { b.oppTenup = b.opp; b.opp = a.opp; }
      if (a && b) { ["racketId", "string", "tension", "tensionCross", "surface", "indoor", "feel", "note", "minutes"].forEach(function (k) { if (a[k] != null && a[k] !== "" && (b[k] == null || b[k] === "")) b[k] = a[k]; }); b.manualOrigin = true; b.confirmedAt = E.iso(today()); }
      S.matches = S.matches.filter(function (m) { return m.id !== v.id; });
      S.verify = S.verify.filter(function (x) { return x !== v; }); save(); toast("C'est noté : la version Ten'Up remplace ta saisie."); render();
    },
    verifyDiff: function (el) {
      S.verify = (S.verify || []).filter(function (x) { return x.id !== el.dataset.id; });
      S.keepManual = S.keepManual || {}; S.keepManual[el.dataset.id] = true; save(); toast("Les deux matchs sont gardés."); render();
    },
    staleKeep: function (el) { var m = mById(el.dataset.id); if (!m) return; m.kind = "amical"; m.kindSet = true; S.keepManual = S.keepManual || {}; S.keepManual[m.id] = true; save(); toast("Gardé en match d'entraînement : il ne compte pas pour le classement."); render(); },
    staleDel: function (el) { if (!confirm("Supprimer ce match saisi à la main ?")) return; S.matches = S.matches.filter(function (m) { return m.id !== el.dataset.id; }); save(); toast("Match supprimé."); render(); },
    delMatch: function () {
      if (!UI.draft || !isManual(UI.draft)) return; // les matchs officiels Ten'Up ne se suppriment pas
      if (!confirm("Supprimer ce match ?")) return;
      S.matches = S.matches.filter(function (x) { return x.id !== UI.draft.id; }); save(); UI.draft = null; toast("Match supprimé."); go("palmares");
    },
    // raquettes
    quickRestring: function (el) {
      var r = racket(el.dataset.id); if (!r) return;
      r.restrings = (r.restrings || []).concat([E.iso(today())]).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort(); r.brokenOpen = false;
      save(); toast("C'est noté : le compteur de " + r.name + " repart à zéro."); render();
    },
    breakString: function () {
      var d = UI.racketDraft, r = racket(d.id); if (!r) return;
      var st = racketStatus(r);
      if (!confirm("Noter une casse aujourd'hui" + (st.known ? ", à environ " + fmtHours(st.min) + " de jeu" : "") + " ?")) return;
      var br = { date: E.iso(today()), min: st.known ? st.min : 0, string: r.string || "", type: stringType(r) };
      r.breaks = (r.breaks || []).concat([br]); d.breaks = r.breaks.slice(); r.brokenOpen = d.brokenOpen = true;
      save(); toast("Casse notée. Dis-le quand c'est recordé."); render();
    },
    newSlot: function () { UI.slotDraft = null; go("creneau/new"); },
    slset: function (el) { var k = el.dataset.k, v = el.dataset.v; UI.slotDraft[k] = k === "label" ? v : +v; render(); },
    saveSlot: function () {
      var sl = Object.assign({}, UI.slotDraft); delete sl._for;
      if (!sl.time) return toast("Indique l'heure du créneau.");
      S.slots = S.slots || [];
      var i = S.slots.findIndex(function (x) { return x.id === sl.id; });
      if (i >= 0) S.slots[i] = sl; else S.slots.push(sl);
      save(); UI.slotDraft = null; toast("Créneau enregistré : " + DAYS_L[sl.dow] + " " + sl.time + "."); go("materiel");
    },
    delSlot: function () {
      if (!confirm("Supprimer ce créneau ? Les entraînements déjà notés restent.")) return;
      S.slots = (S.slots || []).filter(function (x) { return x.id !== UI.slotDraft.id; }); save(); UI.slotDraft = null; go("materiel");
    },
    slotYes: function (el) {
      var sl = (S.slots || []).filter(function (x) { return x.id === el.dataset.id; })[0]; if (!sl) return;
      var main = racketFor("train");
      S.trainings = S.trainings || [];
      S.trainings.push({ id: uid(), date: el.dataset.d, minutes: sl.minutes, label: sl.label, slot: sl.id, racketId: main ? main.id : "", string: main ? main.string || "" : "", tension: main ? main.tension || null : null, tensionCross: main && main.tensionCross != null ? main.tensionCross : null, newString: false, feel: null, note: "" });
      S.slotLog = S.slotLog || {}; S.slotLog[sl.id + "|" + el.dataset.d] = "yes";
      save(); toast("Noté : " + fmtDur(sl.minutes) + " de jeu."); render();
    },
    slotNo: function (el) { S.slotLog = S.slotLog || {}; S.slotLog[el.dataset.id + "|" + el.dataset.d] = "no"; save(); render(); },
    restring: function () { var r = UI.racketDraft; r.brokenOpen = false; r.restrings = (r.restrings || []).concat([E.iso(today())]).filter(function (v, i, a) { return a.indexOf(v) === i; }); render(); toast("Noté. Pense à enregistrer."); },
    addRestring: function () {
      var r = UI.racketDraft; r.brokenOpen = false; r.restrings = (r.restrings || []).concat([E.iso(today())]); render();
      var inp = app.querySelector('[data-rs="' + (r.restrings.length - 1) + '"]'); if (inp) { inp.focus(); if (inp.showPicker) try { inp.showPicker(); } catch (e) {} }
    },
    gearOpen: function () { if (!bag().length) { UI.afterRacket = location.hash; go("raquette/new"); return; } UI.gearOpen = !UI.gearOpen; render(); },
    rset: function (el) { UI.racketDraft[el.dataset.k] = el.dataset.v; render(); },
    showArchived: function () { UI.showArchived = !UI.showArchived; render(); },
    archiveRacket: function () {
      var r = racket(UI.racketDraft.id); if (!r) return;
      r.archived = !r.archived; UI.racketDraft.archived = r.archived;
      if (r.archived && r.main) { r.main = false; var nx = bag()[0]; if (nx) nx.main = true; }
      save(); toast(r.archived ? r.name + " est rangée. Son historique est gardé." : r.name + " est de retour dans ton sac."); UI.racketDraft = null; go("materiel");
    },
    rtype: function (el) { var r = UI.racketDraft; r.stringType = (r.stringType || guessType(r.string)) === el.dataset.v ? "" : el.dataset.v; render(); },
    delRestring: function (el) { var r = UI.racketDraft; r.restrings.splice(+el.dataset.v, 1); render(); },
    saveRacket: function () {
      var r = Object.assign({}, UI.racketDraft); delete r._for;
      r.restrings = (r.restrings || []).filter(Boolean).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort();
      if (!r.name.trim()) return toast("Donne un nom à ta raquette.");
      if (r.main) S.rackets.forEach(function (x) { x.main = false; });
      var i = S.rackets.findIndex(function (x) { return x.id === r.id; });
      if (i >= 0) S.rackets[i] = r; else S.rackets.push(r);
      if (!S.rackets.some(function (x) { return x.main; })) S.rackets[0].main = true;
      save(); UI.racketDraft = null;
      if (UI.afterRacket && UI.draft) { UI.draft.racketId = r.id; UI.draft.string = r.string; UI.draft.tension = r.tension; UI.draft.tensionCross = r.tensionCross != null ? r.tensionCross : null; var h = UI.afterRacket; UI.afterRacket = null; location.hash = h; return; }
      toast("Raquette enregistrée."); go("materiel");
    },
    delRacket: function () {
      if (!confirm("Supprimer cette raquette ? Les matchs joués avec elle ne seront plus annotés.")) return;
      var id = UI.racketDraft.id;
      S.rackets = S.rackets.filter(function (x) { return x.id !== id; });
      S.matches.forEach(function (m) { if (m.racketId === id) m.racketId = ""; });
      save(); UI.racketDraft = null; go("materiel");
    },
    // import
    bmHelp: function (el, ev) { ev.preventDefault(); toast("Glisse ce bouton dans ta barre de favoris, puis utilise-le sur Ten'Up."); },
    tenupConnect: function () {
      var mail = (document.getElementById("tu-mail") || {}).value || "", pass = (document.getElementById("tu-pass") || {}).value || "";
      var keep = (document.getElementById("tu-keep") || {}).checked;
      UI.tuMail = mail.trim();
      if (!UI.tuMail || !pass) return toast("Indique ton e-mail et ton mot de passe Ten'Up.");
      tenupCall({ email: UI.tuMail, password: pass }, keep);
    },
    tenupRefresh: function () { if (S.tenup.cred) tenupCall(S.tenup.cred, true); else go("tenup"); },
    tenupForget: function () { delete S.tenup.cred; save(); toast("Compte Ten'Up délié."); render(); },
    setupFav: function () { S.tenup.setup = Object.assign({}, S.tenup.setup, { fav: true, favVersion: T.VERSION }); save(); render(); },
    nativeConnect: function () { nativeConnect(); },
    nativeRefresh: function () { nativeRefresh(false); },
    profEdit: function () { UI.profEdit = true; render(); },
    whereTab: function (el) { UI.whereTab = el.dataset.v; render(); },
    persoMove: function (el) {
      var pg = el.dataset.p, pr = prefsOf(pg), i = pr.order.indexOf(el.dataset.k), j = i + (+el.dataset.v);
      if (j < 0 || j >= pr.order.length) return;
      pr.order.splice(j, 0, pr.order.splice(i, 1)[0]); S.prefs[pg] = pr; save(); render();
    },
    persoReset: function (el) { S.prefs = S.prefs || {}; delete S.prefs[el.dataset.p]; save(); render(); toast("Affichage d'origine rétabli."); },
    nativeLogout: function () {
      if (!confirm("Délier ton compte Ten'Up ? Tes matchs restent dans Montée.")) return;
      Tenup.logout().catch(function () {}); S.tenup.linked = false; save(); render();
    },
    tenupMethod: function (el) { UI.tenupMethod = el.dataset.v; UI.importError = null; if (el.dataset.v === "pdf") { UI.wiz = null; S.tenup.setup = Object.assign({}, S.tenup.setup, { skipWiz: true }); } render(); },
    platform: function (el) { UI.platform = el.dataset.v; render(); },
    setupDone: function () { S.tenup.setup = Object.assign({}, S.tenup.setup, (function (o) { o[UI.platform || (/iphone|ipad|ipod/i.test(navigator.userAgent) ? "ios" : /android/i.test(navigator.userAgent) ? "android" : "desktop")] = true; return o; })({})); save(); render(); },
    openTenup: function (el) {
      UI.awaitTenup = true;
      var ua = navigator.userAgent, url = "https://tenup.fft.fr/";
      // Depuis l'app installée, forcer le vrai navigateur (là où sont les signets/favoris)
      if (isStandalone() && /iphone|ipad|ipod/i.test(ua)) { location.href = "x-safari-" + url; return; }
      if (isStandalone() && /android/i.test(ua)) { location.href = "intent://tenup.fft.fr/#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=" + encodeURIComponent(url) + ";end"; return; }
      window.open(url, "_blank", "noopener");
    },
    wizGo: function (el) { UI.wiz = +el.dataset.v; if (UI.wiz >= 4) { S.tenup.setup = Object.assign({}, S.tenup.setup, { fav: true, favVersion: T.VERSION }); save(); } render(); window.scrollTo(0, 0); },
    wizCopy: function (el) {
      var origin = location.origin + location.pathname.replace(/index\.html$/, "").replace(/\/$/, "");
      var code = T.bookmarklet(S.profile.licence || "", origin, tenupWho()), stay = el.dataset.v === "stay";
      var ok = function () { toast("Code copié."); if (!stay) { UI.wiz = 2; render(); window.scrollTo(0, 0); } };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(ok, function () { fallbackCopy(code); ok(); });
      else { fallbackCopy(code); ok(); }
    },
    copyBookmark: function () {
      var origin = location.origin + location.pathname.replace(/index\.html$/, "").replace(/\/$/, "");
      var code = T.bookmarklet(S.profile.licence || "", origin, tenupWho());
      var ok = function () { toast("Favori copié. Colle-le comme adresse du signet."); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(ok, function () { fallbackCopy(code); ok(); });
      else { fallbackCopy(code); ok(); }
    },
    importClipboard: function () {
      UI.backFromTenup = false;
      if (!navigator.clipboard || !navigator.clipboard.readText) { UI.importError = "ce navigateur ne permet pas de lire le presse-papiers : colle le résultat dans « Ça ne marche pas ? »."; render(); return; }
      navigator.clipboard.readText().then(function (t) {
        var pl = T.decode(t);
        if (pl) importPayload(pl);
        else toast("Rien de Ten'Up à importer. Lance d'abord « Envoyer à Montée » depuis Safari.");
      }).catch(function () { toast("Touche « Coller » quand l'iPhone le propose."); });
    },
    copyScript: function () {
      var code = T.script(S.profile.licence || "", "shortcut", "");
      var ok = function () { toast("Script copié. Colle-le dans l'action du raccourci."); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(ok, function () { fallbackCopy(code); ok(); });
      else { fallbackCopy(code); ok(); }
    },
    copyDiag: function () {
      var comps = {}; S.matches.forEach(function (m) { if (m.comp) comps[m.comp] = m.kind; });
      var d = JSON.stringify({ comps: comps, v: "3.7.0", sample: S.tenup.sample, official: S.tenup.official, doubles: (S.doubles || []).map(function (m) { return { date: m.date, r: m.result, opp: m.opp, oppRanks: m.oppRanks, partner: m.partner, partnerRank: m.partnerRank, officialPts: m.officialPts }; }), lastError: S.tenup.lastError, ua: navigator.userAgent }, null, 1);
      var ok = function () { toast("Diagnostic copié : colle-le dans ta conversation avec Claude."); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(d).then(ok, function () { fallbackCopy(d); ok(); }); else { fallbackCopy(d); ok(); }
    },
    parseImport: function () {
      var t = UI.importText || "";
      var pl = T.decode(t); if (pl) { UI.importText = ""; importPayload(pl); return; }
      if (t.trim().length < 20) return toast("Colle d'abord le texte de ta page Palmarès.");
      UI.importRows = rowsFromText(t); render(); window.scrollTo(0, 0);
    },
    cancelImport: function () { UI.importRows = null; render(); },
    doImport: function () {
      var rows = UI.importRows.filter(function (r) { return r.keep && r.oppRank && r.result && r.date; });
      var b4i = idSet(); rows.forEach(addImported); hcMergeToast(hcMergeNew(b4i));
      calibrateFromTenup();
      S.tenup.lastImport = E.iso(today()); S.onboarded = true; save();
      UI.importRows = null; UI.importText = "";
      toast(plural(rows.length, "match importé", "matchs importés") + ".");
      go(S.profile.rank ? "" : "profil");
    },
    // données
    export: function () { backup(false); },
    exportShare: function () { backup(true); },
    wipe: function () {
      if (!confirm("Effacer tout ton palmarès, tes raquettes et ton profil de cet appareil ?")) return;
      S = blank(); save(); UI.draft = null; go("bienvenue");
    }
  };

  function fallbackCopy(text) {
    var ta = document.createElement("textarea"); ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); } catch (e) {} ta.remove();
  }

  // ---------- Événements ----------
  app.addEventListener("click", function (ev) {
    var el = ev.target.closest("[data-a]");
    if (!el || el.tagName === "INPUT") return;
    var a = el.dataset.a;
    if (A[a]) { if (el.tagName !== "A" || a === "bmHelp") ev.preventDefault(); A[a](el, ev); }
  });
  // Pages qui défilent à l'horizontale (mode match) : les points suivent ; sommaire des courbes : la pastille suit
  document.addEventListener("scroll", function (ev) {
    var t = ev.target;
    if (t && t.id === "mm-pages") { var i = Math.round(t.scrollLeft / Math.max(1, t.clientWidth)); Array.prototype.forEach.call(document.querySelectorAll(".mm-dots i"), function (d, k) { d.classList.toggle("on", k === i); }); }
    else if (route() === "courbes") cbSpy();
  }, true);
  app.addEventListener("input", function (ev) {
    var el = ev.target;
    if (el.tagName === "TEXTAREA") growTa(el);
    if (el.dataset.f === "profile.name") { S.profile.name = el.value.trim().slice(0, 30); save(); }
    else if (el.dataset.f === "profile.licence") { S.profile.licence = el.value.replace(/\s+/g, "").toUpperCase().slice(0, 12); save(); }
    else if (el.dataset.f === "importText") UI.importText = el.value;
    else if (el.dataset.d && el.type !== "checkbox" && el.tagName !== "SELECT") UI.draft[el.dataset.d] = el.value;
    else if (el.dataset.r && el.type !== "checkbox") UI.racketDraft[el.dataset.r] = el.value;
    else if (el.dataset.sl) UI.slotDraft[el.dataset.sl] = el.value;
    else if (el.dataset.ff) {
      UI.faf = UI.faf || {}; UI.faf[el.dataset.ff] = el.value;
      if (el.dataset.ff === "q") {
        var kb = document.getElementById("faf-known"); if (kb) kb.innerHTML = knownRows(el.value);
        var clr = el.parentNode && el.parentNode.querySelector(".sb-clr"); if (clr) clr.hidden = !el.value;
        var bar = el.closest(".sbar"); if (bar && bar.classList.contains("done") && el.value !== UI.faf.searched) { bar.classList.remove("done"); var x = bar.querySelector(".sb-x"); if (x) x.outerHTML = '<button class="sb-clr" data-a="fafClear" aria-label="Effacer">' + I.cross + '</button><button class="sb-go" data-a="fafSearch">Chercher</button>'; }
      }
    }
    refreshSaveBar();
  });
  app.addEventListener("change", function (ev) {
    var el = ev.target;

    if (el.dataset.f === "profile.rank") { S.profile.rank = el.value; save(); render(); }
    else if (el.dataset.d === "wo") UI.draft.wo = el.checked;
    else if (el.dataset.d === "newString") UI.draft.newString = el.checked;
    else if (el.dataset.d === "opp" && UI.draft) {
      // Adversaire choisi dans les suggestions : on reprend son classement s'il n'est pas encore saisi
      var kx = oppIndex().filter(function (o) { return o.name === el.value; })[0];
      if (kx && !UI.draft.oppRank && kx.rank) { UI.draft.oppRank = kx.rank; render(); }
    }
    else if (el.dataset.d && el.tagName === "SELECT") UI.draft[el.dataset.d] = el.value;
    else if (el.dataset.d === "date") UI.draft.date = el.value;
    else if (el.dataset.r === "main") UI.racketDraft.main = el.checked;
    else if (el.dataset.split) {
      var o = el.dataset.split === "match" ? UI.draft : UI.racketDraft;
      o.tensionCross = el.checked ? (o.tension || 24) - 1 : null; if (el.checked && !o.tension) o.tension = 24; render();
    }
    else if (el.dataset.on != null) { S.oppNotes = S.oppNotes || {}; var tx = el.value.trim(); if (tx) S.oppNotes[el.dataset.on] = { text: tx, at: E.iso(today()) }; else delete S.oppNotes[el.dataset.on]; save(); toast("Fiche enregistrée.");
      // Le plan de jeu se relit tout de suite avec la nouvelle fiche (après un éventuel tap en cours)
      if (/^#\/joueur\//.test(location.hash)) setTimeout(function () { var y = window.scrollY; render(); window.scrollTo(0, y); }, 250); }
    else if (el.dataset.rs != null) { UI.racketDraft.restrings[+el.dataset.rs] = el.value; }
    else if (el.dataset.ir != null) {
      var r = UI.importRows[+el.dataset.ir], k = el.dataset.k;
      r[k] = el.type === "checkbox" ? el.checked : el.value;
      if (k !== "keep") { r.ok = !!(r.oppRank && r.result && r.date); if (r.ok && !r.dup) r.keep = true; render(); }
    } else if (el.dataset.a === "persoToggle") {
      var pg = el.dataset.p, pr = prefsOf(pg), k = el.dataset.k;
      pr.hidden = pr.hidden.filter(function (x) { return x !== k; }); if (!el.checked) pr.hidden.push(k);
      S.prefs[pg] = pr; save(); render();
    } else if (el.dataset.a === "hcNotify") {
      S.health.notify = el.checked; save(); hcSync(); if (el.checked && LN && LN.requestPermissions) LN.requestPermissions().catch(function () {});
    } else if (el.dataset.a === "notifSwitch") {
      if (el.checked) askNotif(); else { S.notif = false; save(); if (LN) LN.cancel({ notifications: [{ id: 1001 }, { id: 1002 }, { id: 1003 }, { id: 1004 }] }).catch(function () {}); }
    } else if (el.dataset.a === "pdfFile" && el.files && el.files[0]) { importPdfFile(el.files[0]);
    } else if (el.dataset.a === "importFile" && el.files && el.files[0]) {
      var fr = new FileReader();
      fr.onload = function () {
        try {
          var d = JSON.parse(fr.result);
          if (!d || !Array.isArray(d.matches)) throw new Error();
          S = Object.assign(blank(), d); S.onboarded = true; save(); toast("Sauvegarde restaurée."); go("");
        } catch (e) { toast("Ce fichier n'est pas une sauvegarde Montée."); }
      };
      fr.readAsText(el.files[0]);
    }
    refreshSaveBar();
  });
  app.addEventListener("submit", function (ev) { ev.preventDefault(); if (ev.target.dataset.form === "tenup") A.tenupConnect(); });
  // Infobulle de la courbe (toucher ou survol)
  function tip(ev) {
    var t = ev.target.closest && ev.target.closest("[data-tip]"); var box = document.getElementById("tip");
    if (t && box) box.textContent = t.getAttribute("data-tip");
  }
  // Tirer vers le bas (accueil, palmarès, courbes) : synchro Ten'Up
  (function () {
    var y0 = null, x0 = 0, dy = 0, dx = 0, t0 = 0, el = null, busy = false, TH = 140, armed = false;
    function mode() { return (S.prefs && S.prefs.pull) || "normal"; }
    function ok() { return NATIVE && mode() !== "off" && !document.body.classList.contains("locked") && ["", "palmares", "courbes", "faf"].indexOf(route().split("/")[0]) >= 0 && !UI.draft && (window.scrollY || document.documentElement.scrollTop) <= 0; }
    function bar() {
      if (!el) { el = document.createElement("div"); el.className = "ptr"; el.setAttribute("aria-live", "polite"); document.body.appendChild(el); }
      return el;
    }
    function show(h, txt, spin) { var b = bar(); b.style.transform = "translate(-50%," + Math.round(h) + "px)"; b.style.opacity = h > 8 ? 1 : 0; b.innerHTML = (spin ? '<span class="spin"></span>' : '<span class="ptr-arrow' + (dy > TH ? " up" : "") + '">↓</span>') + "<span>" + txt + "</span>"; }
    function hide() { if (el) { el.style.transform = "translate(-50%,-60px)"; el.style.opacity = 0; } }
    document.addEventListener("touchstart", function (e) { if (busy || !ok() || e.touches.length !== 1) { y0 = null; return; } TH = mode() === "ferme" ? 210 : 140; y0 = e.touches[0].clientY; x0 = e.touches[0].clientX; t0 = Date.now(); dy = 0; dx = 0; }, { passive: true });
    document.addEventListener("touchmove", function (e) {
      if (y0 == null) return;
      dy = e.touches[0].clientY - y0; dx = Math.abs(e.touches[0].clientX - x0);
      if (dx > 40 && dx > dy * 0.6) { y0 = null; hide(); return; } // geste plutôt horizontal : on ignore
      if (dy <= 0 || (window.scrollY || 0) > 0) { hide(); return; }
      if (dy > TH && !armed) { armed = true; haptic("medium"); } else if (dy <= TH) armed = false;
      show(Math.min(dy * 0.5, 70) - 10, dy > TH ? "Relâche pour synchroniser Ten'Up" : "Tire pour synchroniser Ten'Up");
    }, { passive: true });
    document.addEventListener("touchend", function () {
      if (y0 == null) return; y0 = null;
      if (dy > TH && Date.now() - t0 > 250) {
        busy = true; show(50, "Synchronisation avec Ten'Up…", true);
        nativeRefresh(false, true).then(function () { busy = false; hide(); }, function () { busy = false; hide(); });
      } else hide();
      dy = 0; armed = false;
    }, { passive: true });
  })();
  // Feuilles du bas (menu +, détails) : glisser vers le bas pour fermer
  (function () {
    var sh = null, y0 = 0, dy = 0, t0 = 0;
    document.addEventListener("touchstart", function (e) {
      sh = null; if (e.touches.length !== 1) return;
      var t = e.target.closest && e.target.closest(".sheet"); if (!t || t.scrollTop > 0) return;
      sh = t; y0 = e.touches[0].clientY; dy = 0; t0 = Date.now();
    }, { passive: true });
    document.addEventListener("touchmove", function (e) {
      if (!sh) return; dy = e.touches[0].clientY - y0;
      if (dy <= 0 || sh.scrollTop > 0) { sh.style.transform = ""; if (dy < -6) sh = null; return; }
      sh.style.transition = "none"; sh.style.transform = "translateY(" + Math.round(dy) + "px)";
    }, { passive: true });
    document.addEventListener("touchend", function () {
      if (!sh) return; var t = sh; sh = null;
      var fast = dy > 40 && Date.now() - t0 < 250;
      if (dy > 110 || fast) {
        t.style.transition = "transform .18s ease-in"; t.style.transform = "translateY(100%)"; haptic("light");
        setTimeout(function () { if (UI.menu) { UI.menu = false; render(); } else if (UI.sheet) { UI.sheet = null; render(); } }, 170);
      } else { t.style.transition = "transform .2s ease"; t.style.transform = ""; }
      dy = 0;
    }, { passive: true });
  })();
  // iPhone : glisser depuis le bord gauche pour revenir en arrière (mêmes règles que la flèche)
  (function () {
    if (!IOS) return;
    var x0 = null, y0 = 0, dx = 0, on = false;
    document.addEventListener("touchstart", function (e) {
      x0 = null; on = false;
      if (e.touches.length !== 1 || e.touches[0].clientX > 22) return;
      if (["", "bienvenue", "palmares", "courbes", "faf"].indexOf(route()) >= 0 || UI.notesOpen || UI.sheet || UI.menu || UI.leaveAsk) return;
      x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; dx = 0;
    }, { passive: true });
    document.addEventListener("touchmove", function (e) {
      if (x0 == null) return;
      dx = e.touches[0].clientX - x0; var dy = Math.abs(e.touches[0].clientY - y0);
      if (!on && dy > 30 && dy > dx) { x0 = null; app.style.transform = ""; return; }
      if (dx > 8) { on = true; app.style.transition = "none"; app.style.transform = "translateX(" + Math.round(Math.min(dx, 220) * 0.55) + "px)"; app.style.boxShadow = "-8px 0 24px rgba(0,0,0,.08)"; }
    }, { passive: true });
    document.addEventListener("touchend", function () {
      if (x0 == null) return; x0 = null;
      app.style.transition = "transform .22s ease"; app.style.transform = ""; app.style.boxShadow = "";
      setTimeout(function () { app.style.transition = ""; }, 260);
      if (on && dx > 90) { haptic("selection"); A.back(); }
      on = false;
    }, { passive: true });
  })();

  // Clavier : on ramène le champ actif au centre de l'écran une fois le clavier ouvert
  document.addEventListener("focusin", function (e) {
    var t = e.target; if (!t || !/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
    setTimeout(function () { try { t.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (x) {} }, 350);
  });
  if (window.visualViewport) window.visualViewport.addEventListener("resize", function () {
    document.body.classList.toggle("kb-open", window.visualViewport.height < window.innerHeight * 0.78);
    var a = document.activeElement; if (a && /^(INPUT|TEXTAREA)$/.test(a.tagName)) try { a.scrollIntoView({ block: "center" }); } catch (x) {}
  });

  app.addEventListener("mouseover", tip);
  app.addEventListener("touchstart", tip, { passive: true });
  app.addEventListener("click", tip);
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && UI.menu) { UI.menu = false; render(); } });
  app.addEventListener("keydown", function (ev) { if (ev.key === "Enter" && ev.target.dataset && ev.target.dataset.ff) { ev.preventDefault(); ev.target.blur(); UI.fafLocal = null; fafSearch(null); } });

  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && UI.awaitTenup) {
      UI.awaitTenup = false; UI.backFromTenup = true;
      if (route() === "tenup") { render(); var b = app.querySelector('[data-a="importClipboard"]'); if (b) { b.scrollIntoView({ block: "center" }); b.focus(); } }
    }
  });
  window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); UI.installEvt = e; });

  // ---------- Démarrage ----------
  if (!NATIVE && "serviceWorker" in navigator && location.protocol === "https:") {
    window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
  }
  if (location.hash.indexOf("#import=") === 0) handleImportHash();
  else render();
  if (NATIVE) {
    try { nativeWake(); } catch (e) {}
    try {
      var l = AppP && AppP.addListener("appStateChange", function (st) { if (st && st.isActive) nativeWake(); });
      if (l && l.catch) l.catch(function () {});
    } catch (e) {}
    // Notification d'un joueur suivi : ouvre sa fiche
    try {
      var ln = LN && LN.addListener && LN.addListener("localNotificationActionPerformed", function (ev) {
        var u = ev && ev.notification && ev.notification.extra && ev.notification.extra.url, mm = u && /joueur\/(\w+)/.exec(u);
        if (mm) { var f = (S.follow || {})[mm[1]]; if (f && f.hit) openScout(f.hit); }
      });
      if (ln && ln.catch) ln.catch(function () {});
    } catch (e) {}
    // Bouton retour du téléphone : mêmes règles que la flèche (garde-fou si modifications en cours)
    try {
      var bl = AppP && AppP.addListener("backButton", function () {
        if (UI.leaveAsk) { UI.leaveAsk = false; render(); return; }
        if (UI.sheet) { UI.sheet = null; render(); return; }
        if (UI.rkMenu || UI.menu) { UI.rkMenu = false; UI.menu = false; render(); return; }
        if (document.querySelector(".confetti")) { var cf = document.querySelector(".confetti"); cf.remove(); return; }
        var r = route();
        if (isDirty()) { UI.leaveAsk = true; render(); return; }
        if (r === "" || r === "bienvenue") { if (AppP.exitApp) AppP.exitApp(); return; }
        A.back();
      });
      if (bl && bl.catch) bl.catch(function () {});
    } catch (e) {}
  }
})();
