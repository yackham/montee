/* Montée — application (vanilla JS, sans serveur : tout reste sur l'appareil). */
(function () {
  "use strict";

  /* ================= À CONFIGURER ================= */
  var CONFIG = {
    // Lien de ta page de don (Lydia, PayPal, Ko-fi, Buy Me a Coffee, Tipeee…)
    DON_URL: "https://ko-fi.com/tamalousante",
    // Lien iCloud du raccourci iPhone « Envoyer à Montée » (Raccourcis › Partager › Copier le lien iCloud)
    SHORTCUT_URL: "",
    // Adresse pour les retours des joueurs (laisser vide pour masquer l'entrée)
    CONTACT_EMAIL: "yann.munier21@gmail.com",
    VERSION: "3.9.1"
  };
  /* ================================================= */

  var E = window.MonteeEngine, P = window.MonteeParser, T = window.MonteeTenup;
  // App iPhone (Capacitor) : plugins natifs
  var CAP = window.Capacitor;
  var NATIVE = !!(CAP && CAP.isNativePlatform && CAP.isNativePlatform());
  // Plugins natifs : registerPlugin vient de vendor/capacitor.js (sinon, ceux exposés par le pont natif)
  function plugin(name) { return CAP.registerPlugin ? CAP.registerPlugin(name) : (CAP.Plugins && CAP.Plugins[name]) || null; }
  var Tenup = NATIVE ? plugin("Tenup") : null;
  var LN = NATIVE ? plugin("LocalNotifications") : null;
  var AppP = NATIVE ? plugin("App") : null;
  var KEY = "montee.v1";
  var app = document.getElementById("app");

  // ---------- Stockage ----------
  function blank() {
    return { v: 1, profile: { name: "", sex: "H", rank: "", licence: "" }, matches: [], rackets: [], trainings: [], tenup: { lastImport: null }, onboarded: false };
  }
  function load() {
    try { var raw = localStorage.getItem(KEY); if (raw) { var s = JSON.parse(raw); return Object.assign(blank(), s); } } catch (e) {}
    return blank();
  }
  var S = load();
  if (S.tenup && S.tenup.cred) { delete S.tenup.cred; try { localStorage.setItem("montee.v1", JSON.stringify(S)); } catch (e) {} }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { toast("Impossible d'enregistrer sur cet appareil."); } }

  var UI = { palTab: "all", matTab: "setup", projLevel: null, menu: false, draft: null, racketDraft: null, importText: "", importRows: null, toastMsg: "", toastT: 0, installEvt: null };

  // ---------- Utilitaires ----------
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 7); }
  function today() { var t = new Date(); t.setHours(0, 0, 0, 0); return t; }
  var MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."];
  var MOIS_L = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
  var JOURS = ["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  function fdate(iso) { if (!iso) return "date ?"; var d = typeof iso === "string" ? E.parseDate(iso) : iso; return d.getDate() + " " + MOIS[d.getMonth()] + (d.getFullYear() !== today().getFullYear() ? " " + d.getFullYear() : ""); }
  function flong(d) { return JOURS[d.getDay()] + " " + d.getDate() + " " + MOIS_L[d.getMonth()]; }
  function plural(n, s, p) { return n + " " + (n > 1 ? (p || s + "s") : s); }
  // Classement « effectif » : dès qu'une montée est acquise pour la prochaine sortie, Montée te passe
  // au nouveau classement (S.ahead) et calcule la suite depuis là. Le classement officiel reste dans S.profile.rank.
  function effRank() { return S.ahead && S.ahead.rank ? S.ahead.rank : S.profile.rank; }
  function curIdx() { var i = E.idx(effRank()); return i == null ? -1 : i; }
  function refreshAhead() {
    var td = E.iso(today());
    if (S.ahead && S.ahead.release <= td) {
      // la sortie est passée : le classement anticipé devient le classement tout court
      if (S.ahead.from === S.profile.rank) S.profile.rank = S.ahead.rank;
      S.ahead = null; save();
    }
    var off = E.idx(S.profile.rank);
    if (off == null || off >= E.TOP) { if (S.ahead) { S.ahead = null; save(); } return; }
    var opts = { today: today(), extra: tenupExtra(E.nextRelease(today()), off) };
    var pr = E.project(allMatches(), off, S.profile.sex, opts);
    if (pr.status === "montee") {
      var a = { rank: lab(pr.projected), from: S.profile.rank, release: E.iso(pr.release) };
      if (!S.ahead || S.ahead.rank !== a.rank || S.ahead.from !== a.from || S.ahead.release !== a.release) { S.ahead = a; save(); }
    } else if (S.ahead) { S.ahead = null; save(); }
  }
  function lab(i) { return E.label(i); }
  function rackets() { return S.rackets; }
  function racket(id) { return S.rackets.filter(function (r) { return r.id === id; })[0]; }
  function bag() { return S.rackets.filter(function (r) { return !r.archived; }); } // raquettes « dans ton sac » (pas rangées)
  function sortedMatches() {
    return S.matches.slice().sort(function (a, b) {
      if (!a.date || !b.date) return (a.date ? 1 : 0) - (b.date ? 1 : 0) || ((b.officialPts || 0) - (a.officialPts || 0));
      return a.date < b.date ? 1 : a.date > b.date ? -1 : 0;
    });
  }
  // Simples + doubles : le moteur compte les doubles uniquement en bonus (barème des doubles)
  // Matchs qui comptent pour le classement : un match libre saisi à la main (amical, non homologué) n'y entre pas.
  // Ceux qui viennent de Ten'Up sont homologués : ils comptent, quel que soit leur type.
  function counts(m) { return !(m.kind === "libre" && isManual(m)); }
  function allMatches() { return S.matches.filter(counts).concat(S.doubles || []); }
  function annotated(m) { return !!m.racketId || !!m.wo; } // un WO ne s'est pas joué : rien à annoter

  function toast(msg) {
    UI.toastMsg = msg; clearTimeout(UI.toastT);
    var el = document.querySelector(".toast"); if (el) el.remove();
    var t = document.createElement("div"); t.className = "toast"; t.setAttribute("role", "status"); t.textContent = msg; document.body.appendChild(t);
    UI.toastT = setTimeout(function () { t.remove(); }, 2800);
  }

  // ---------- Icônes ----------
  function svg(p, sw, extra) { return '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (sw || 2) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (extra || "") + ">" + p + "</svg>"; }
  var I = {
    logo: function (s) { return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="14.5" fill="#D4E64A"/><path d="M4 9.5c3.6 3 3.6 10 0 13M28 9.5c-3.6 3-3.6 10 0 13" stroke="#FFFFFF" stroke-width="1.6" fill="none" stroke-linecap="round"/><path d="M9.5 19.5 16 13l6.5 6.5" stroke="#121212" stroke-width="3.2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'; },
    back: svg('<path d="M19 12H5M11 6l-6 6 6 6"/>'),
    next: svg('<path d="M9 6l6 6-6 6"/>'),
    arrow: svg('<path d="M5 12h14M13 6l6 6-6 6"/>'),
    plus: svg('<path d="M12 5v14M5 12h14"/>', 2.6),
    check: svg('<path d="M5 12l5 5 9-10"/>', 2.8),
    cross: svg('<path d="M6 6l12 12M18 6 6 18"/>', 2.4),
    clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
    home: svg('<path d="M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'),
    list: svg('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),
    chart: svg('<path d="M3 20h18M5 16l4-5 4 3 6-8"/>'),
    racket: svg('<ellipse cx="14.5" cy="8.5" rx="5.5" ry="6.5" transform="rotate(45 14.5 8.5)"/><path d="M10.6 12.4 4 19M3 18l3 3M11.5 6.5l6 6M14 4.6l5.4 5.4"/>'),
    heart: svg('<path d="M12 21s-7.5-4.6-9.5-9.3C1.1 8.3 3.3 4.5 7 4.5c2 0 3.6 1.1 5 3 1.4-1.9 3-3 5-3 3.7 0 5.9 3.8 4.5 7.2C19.5 16.4 12 21 12 21z"/>'),
    link: svg('<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'),
    user: svg('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
    save: svg('<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>'),
    phone: svg('<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>'),
    book: svg('<path d="M4 4h10a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"/><path d="M8 8h6M8 12h6"/>'),
    share: svg('<path d="M12 3v13M7 8l5-5 5 5M5 14v6h14v-6"/>'),
    mail: svg('<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 7l9 6 9-6"/>'),
    info: svg('<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>'),
    edit: svg('<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>'),
    warn: svg('<path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>'),
    spark: svg('<path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4"/>'),
    gear: svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
    more: svg('<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>', 2.4),
    trash: svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>')
  };

  // ---------- Calculs partagés ----------
  function ctx() {
    var cur = curIdx(), sex = S.profile.sex;
    var opts = { today: today() };
    if (S.ahead) { var t = E.parseDate(S.ahead.release); t.setDate(t.getDate() + 1); opts.release = E.nextRelease(t); }
    opts.extra = tenupExtra(opts.release || E.nextRelease(today()), cur);
    var proj = E.project(allMatches(), cur, sex, opts);
    var drops = proj.status === "top" ? [] : E.dropOuts(allMatches(), cur, sex, opts).filter(function (x) { return x.pts > 0; });
    return { cur: cur, sex: sex, proj: proj, drops: drops, opts: opts };
  }
  function levelsAround(cur) {
    var c = cur < 0 ? 0 : cur, out = [];
    for (var i = Math.max(-1, c - 3); i <= Math.min(E.MAX_CALC, c + 3); i++) out.push(i);
    return out;
  }
  // Plus petit classement d'adversaire qui suffit pour monter avec une victoire
  function minWinToRise(c) {
    if (c.proj.status !== "maintien" && c.proj.status !== "descente" && c.proj.status !== "entree") return null;
    var lv = levelsAround(c.cur);
    for (var k = 0; k < lv.length; k++) {
      var s = E.simulateWin(allMatches(), c.cur, c.sex, lv[k], c.opts);
      if (s.after.projected > (c.cur < 0 ? 0 : c.cur)) return lv[k];
    }
    return undefined; // une victoire ne suffit pas
  }
  // ---- Pistes : le chemin le plus accessible pour monter (ou se maintenir) ----
  // Chaque piste est simulée avec le vrai calcul : les victoires ajoutées prennent la place des
  // plus faibles victoires comptées (elles ne rapportent donc que la différence), le nombre de
  // victoires comptées peut bouger avec V − E − 2I − 5G, et la victoire « au palier » est exigée.
  // On ne propose que des adversaires à ta portée (déjà battus), classés par probabilité de réussite
  // d'après ton palmarès.
  var pistesMemo = { key: "", val: null };
  var PRIOR = { "-3": 0.85, "-2": 0.75, "-1": 0.62, "0": 0.45, "1": 0.3, "2": 0.18, "3": 0.1 };
  function winChance(c, L) {
    var cur = c.cur < 0 ? 0 : c.cur, d = Math.max(-3, Math.min(3, L - cur)), v = 0, n = 0;
    S.matches.forEach(function (m) {
      if (m.wo || !(m.result === "V" || m.result === "D") || E.idx(m.oppRank) !== L) return;
      n++; if (m.result === "V") v++;
    });
    return (v + 2 * PRIOR[String(d)]) / (n + 2);
  }
  function maxBeaten() {
    var b = null;
    S.matches.forEach(function (m) { var o = E.idx(m.oppRank); if (m.result === "V" && !m.wo && o != null && (b == null || o > b)) b = o; });
    return b;
  }
  function pistes(c) {
    var p = c.proj;
    if (["maintien", "descente", "entree"].indexOf(p.status) < 0) return { goal: "", list: [] };
    var cur = c.cur < 0 ? 0 : c.cur, keep = p.status === "descente", target = keep ? cur : Math.min(cur + 1, E.MAX_CALC);
    var key = [S.matches.map(function (m) { return m.id + m.result + m.oppRank + m.date + m.kind; }).join(","), (S.doubles || []).length, c.cur, c.sex, E.iso(today()), JSON.stringify(c.opts.extra || 0), JSON.stringify(c.opts.release || "")].join("|");
    if (pistesMemo.key === key) return pistesMemo.val;
    var t = E.iso(today()), base = allMatches();
    var ok = function (levels) {
      var r = E.project(base.concat(levels.map(function (o, i) { return { id: "_sim" + i, date: t, result: "V", oppRank: lab(o), kind: "tournoi" }; })), c.cur, c.sex, c.opts);
      return (keep ? r.status !== "descente" : (r.projected > cur && r.status === "montee")) ? (keep ? r.here : r.next) : null;
    };
    var lo = Math.max(0, cur - 3), mb = maxBeaten(), reach = Math.min(target + 2, Math.max(mb == null ? cur : mb, cur));
    var chance = {}; for (var L = lo; L <= target + 2; L++) chance[L] = winChance(c, L);
    function search(hi) {
      var found = [];
      // 1 victoire, puis 2, 3, 4 : on ne garde que les combinaisons minimales
      for (var k = 1; k <= 4; k++) {
        (function rec(start, acc) {
          if (acc.length === k) {
            if (found.some(function (f) { return isSub(f.levels, acc); })) return; // une partie suffit déjà
            var after = ok(acc);
            if (after) found.push({ levels: acc.slice(), after: after });
            return;
          }
          for (var L = start; L <= hi; L++) { acc.push(L); rec(L, acc); acc.pop(); }
        })(lo, []);
      }
      found.forEach(function (f) {
        f.k = f.levels.length; f.top = Math.max.apply(null, f.levels);
        f.p = f.levels.reduce(function (a, L) { return a * chance[L]; }, 1);
      });
      return found;
    }
    function isSub(a, b) { var bb = b.slice(); return a.every(function (x) { var i = bb.indexOf(x); if (i < 0) return false; bb.splice(i, 1); return true; }); }
    var found = search(reach), stretch = false;
    if (!found.length && reach < target + 2) { found = search(Math.min(target + 2, reach + 1)); stretch = found.length > 0; }
    found.sort(function (a, b) { return b.p - a.p || a.k - b.k; });
    var list = [];
    found.forEach(function (f) {
      if (list.length >= 3) return;
      // pas deux pistes trop proches : on veut des chemins vraiment différents
      if (list.some(function (x) { return x.k === f.k && x.top === f.top; })) return;
      list.push(f);
    });
    var one = found.filter(function (f) { return f.k === 1; }).sort(function (a, b) { return a.top - b.top; })[0];
    pistesMemo = { key: key, val: { goal: keep ? "keep" : "up", target: target, list: list, stretch: stretch, maxBeaten: mb, one: one } };
    return pistesMemo.val;
  }
  function pisteLabel(x) {
    var g = {}; x.levels.forEach(function (L) { g[L] = (g[L] || 0) + 1; });
    var ks = Object.keys(g).map(Number).sort(function (a, b) { return b - a; });
    return ks.map(function (L, i) {
      var n = g[L], w = i === 0 ? (n > 1 ? " victoires" : " victoire") : "";
      return n + w + " contre " + (n > 1 ? "des " : "un ") + lab(L);
    }).join(" et ");
  }
  function easiest(pl) { return pl.list[0] || null; }
  // Plus haut classement contre lequel tu gagnes au moins un match sur deux (2 matchs minimum)
  function plafondIdx(c) {
    var by = {};
    (c.proj.matches || []).forEach(function (m) { var o = E.idx(m.oppRank); if (o == null || m.wo || !(m.result === "V" || m.result === "D")) return; by[o] = by[o] || { v: 0, n: 0 }; by[o].n++; if (m.result === "V") by[o].v++; });
    var best = null; Object.keys(by).forEach(function (k) { var x = by[k]; if (x.n >= 2 && x.v * 2 >= x.n && (best == null || +k > best)) best = +k; });
    return best;
  }
  function countedMap(b) {
    var m = {}; if (!b) return m;
    b.counted.forEach(function (w) { m[w.m.id] = w.pts; });
    return m;
  }

  // Usure du cordage : on découpe les matchs d'une raquette en « cordages » successifs.
  // Un nouveau cordage commence quand : le match est coché « cordage neuf », une date de
  // cordage tombe juste avant lui, ou le cordage / la tension changent par rapport au match
  // précédent. Avant le premier de ces repères, l'usure est inconnue (on ne l'invente pas).
  // Changement de cordage déduit : seulement un autre nom de cordage (pas la tension, souvent corrigée après coup)
  function strKey(x) { return String(x || "").toLowerCase().replace(/[^a-z0-9]/g, ""); }
  function setupChanged(a, b) {
    return !!(strKey(a.string) && strKey(b.string) && strKey(a.string) !== strKey(b.string));
  }
  // Raquette par défaut : la principale si elle sert à ça, sinon la première qui sert à ça
  function racketFor(use) {
    var b = bag(), fits = function (r) { return !r.usage || r.usage === "both" || r.usage === use; };
    var main = b.filter(function (r) { return r.main; })[0];
    return (main && fits(main) ? main : b.filter(fits)[0]) || main || b[0] || null;
  }
  function defaultRacketId(x) {
    var m = racketFor(x && x.opp == null && x.oppRank == null ? "train" : "match");
    return m ? m.id : "";
  }
  function racketOf(x) { return x.racketId || defaultRacketId(x); }
  // ---------- Temps de jeu (estimation) ----------
  // Un jeu dure en moyenne 4 min (changements de côté compris), +10 min d'échauffement,
  // +6 min par jeu décisif, 15 min pour un super tie-break. Sans score : 1 h 30.
  var MIN_GAME = 4, WARMUP = 10, TB_EXTRA = 6, SUPER_TB = 15, DEFAULT_MATCH = 90;
  function setsOf(score) {
    var out = [];
    String(score || "").replace(/(\d{1,2})\s*[-\/]\s*(\d{1,2})(\s*\(\s*\d+(?:\s*[-\/]\s*\d+)?\s*\))?/g, function (_, x, y) { out.push([+x, +y]); return _; });
    return out;
  }
  function isSuperTb(st, i) { return i === 2 && (Math.max(st[0], st[1]) >= 10 || st[0] + st[1] === 1); }
  function isTb(st) { return (st[0] === 7 && st[1] === 6) || (st[0] === 6 && st[1] === 7); }
  function estMinutes(m) {
    if (m.wo) return 0;
    var sets = setsOf(m.score);
    if (!sets.length) return DEFAULT_MATCH;
    var t = WARMUP;
    sets.forEach(function (st, i) { t += isSuperTb(st, i) ? SUPER_TB : (st[0] + st[1]) * MIN_GAME + (isTb(st) ? TB_EXTRA : 0); });
    return Math.round(t / 5) * 5;
  }
  function playMinutes(x) { return x.minutes ? +x.minutes : x.opp != null || x.oppRank != null ? estMinutes(x) : 60; }
  function fmtDur(min) { var h = Math.floor(min / 60), mm = Math.round(min % 60); return h ? h + " h" + (mm ? " " + (mm < 10 ? "0" : "") + mm : "") : mm + " min"; }
  function fmtHours(min) { var h = min / 60; h = h < 10 ? Math.round(h * 2) / 2 : Math.round(h); return String(h).replace(".", ",") + " h"; }

  // Type de cordage : choisi sur la raquette, sinon deviné d'après le nom
  var STYPES = [["mono", "Monofilament (polyester)"], ["multi", "Multifilament"], ["hybride", "Hybride"], ["boyau", "Boyau naturel"], ["synth", "Synthétique"]];
  function guessType(name) {
    var n = String(name || "").toLowerCase();
    if (!n) return "";
    if (/hybrid|\+|\//.test(n)) return "hybride";
    if (/boyau|natural|\bgut\b|\bvs\b|tonic/.test(n) && !/syn/.test(n)) return "boyau";
    if (/multi|xcel|nxt|x-one|addi[cx]|origin|multifeel|pro'?s pro|touch|fusion|hydra/.test(n)) return "multi";
    if (/synth|nylon|syn ?gut|prince|tour ?gut/.test(n)) return "synth";
    if (/poly|mono|rpm|alu|lynx|hurricane|blast|4g|ice ?code|hyper|black ?code|razor|tour ?bite|cyclone|sonic|confidential|ghost|outlast|signum|solinco|kirschbaum|tornado|isospeed|co-?poly|spin/.test(n)) return "mono";
    return "";
  }
  function stringType(r) { return (r && (r.stringType || guessType(r.string))) || ""; }
  function typeLabel(t) { return (STYPES.filter(function (x) { return x[0] === t; })[0] || ["", ""])[1]; }
  var MONO_WARN = 15 * 60, MONO_MAX = 20 * 60;

  // Séances (matchs joués + entraînements) d'une raquette, dans l'ordre
  function playEvents(racketId) {
    var ev = [], td = E.iso(today());
    // Les matchs sans raquette (importés de Ten'Up, par exemple) comptent pour la raquette principale
    S.matches.forEach(function (m) { if (racketOf(m) === racketId && m.date && m.date <= td && !m.wo) ev.push({ o: m, t: "m", min: playMinutes(m) }); });
    (S.doubles || []).forEach(function (m) { if (racketOf(m) === racketId && m.date && m.date <= td && !m.wo) ev.push({ o: m, t: "m", min: playMinutes(m) }); });
    (S.trainings || []).forEach(function (t) { if (racketOf(t) === racketId && t.date && t.date <= td) ev.push({ o: t, t: "t", min: playMinutes(t) }); });
    return ev.sort(function (a, b) { return a.o.date < b.o.date ? -1 : a.o.date > b.o.date ? 1 : (a.t === b.t ? 0 : a.t === "t" ? -1 : 1); });
  }
  function stringInfo(racketId) {
    var r = racket(racketId), map = {};
    if (!r) return { map: map, last: null };
    var rs = (r.restrings || []).filter(Boolean).slice().sort();
    var prev = null, min = 0, nm = 0, nt = 0, known = false, since = null;
    playEvents(racketId).forEach(function (e) {
      var x = e.o;
      var restrungBefore = rs.filter(function (d) { return d <= x.date && (!prev || d > prev.date); });
      var start = x.newString || restrungBefore.length || (!rs.length && prev && setupChanged(prev, x));
      if (start || !prev) { min = 0; nm = 0; nt = 0; known = !!start; since = restrungBefore.length ? restrungBefore[restrungBefore.length - 1] : (start ? x.date : null); }
      map[x.id] = { min: min, known: known }; // usure du cordage au début de la séance
      min += e.min; if (e.t === "m") nm++; else nt++;
      prev = x;
    });
    var lastRs = rs.length ? rs[rs.length - 1] : null, last;
    if (lastRs && (!prev || lastRs > prev.date)) last = { min: 0, nm: 0, nt: 0, known: true, since: lastRs };
    else last = { min: min, nm: nm, nt: nt, known: prev ? known : false, since: since };
    return { map: map, last: last };
  }
  function stringAge(m) {
    var rid = racketOf(m);
    if (!rid || !m.date) return null;
    var i = stringInfo(rid).map[m.id];
    return i && i.known ? i.min : null;
  }
  // Casses : moyenne des heures de jeu au moment de casser (toutes raquettes)
  function breakAvg() {
    var b = []; S.rackets.forEach(function (r) { (r.breaks || []).forEach(function (x) { if (x.min > 0) b.push(x.min); }); });
    return b.length ? { avg: b.reduce(function (a, x) { return a + x; }, 0) / b.length, n: b.length } : null;
  }
  function brokenNow(r) {
    return r.brokenOpen ? (r.breaks || []).slice(-1)[0] || null : null;
  }
  // level : ok · soon (mono ≥ 15 h, ou proche de tes casses) · change (mono ≥ 20 h) · broken · unknown
  function racketStatus(r) {
    var l = stringInfo(r.id).last || { min: 0, nm: 0, nt: 0, known: false };
    var type = stringType(r), level = !l.known ? "unknown" : type === "mono" ? (l.min >= MONO_MAX ? "change" : l.min >= MONO_WARN ? "soon" : "ok") : "ok";
    var ba = breakAvg();
    if (level === "ok" && ba && l.min >= ba.avg * 0.85) level = "soon";
    if (brokenNow(r)) level = "broken";
    return { since: l.since, min: l.min, nm: l.nm, nt: l.nt, known: l.known, type: type, level: level, breakAvg: ba };
  }
  function fmtT(v) { return String(v).replace(".", ","); }
  function fmtTension(o) {
    if (!o || !o.tension) return "";
    return (o.tensionCross != null && o.tensionCross !== o.tension ? fmtT(o.tension) + " / " + fmtT(o.tensionCross) : fmtT(o.tension)) + " kg";
  }
  // Bloc tension : une valeur, ou montants et travers séparés
  function tensionHtml(o, target) {
    var split = o.tensionCross != null;
    var step = function (k, label) {
      var v = o[k] || 24;
      return '<div class="field inline"><span class="lbl">' + label + '</span><span class="stepper"><button data-a="tens" data-t="' + target + '" data-k="' + k + '" data-v="-0.5" aria-label="' + label + ' : baisser">−</button><span>' + fmtT(v) + ' kg</span><button data-a="tens" data-t="' + target + '" data-k="' + k + '" data-v="0.5" aria-label="' + label + ' : monter">+</button></span></div>';
    };
    return (split ? step("tension", "Montants") + step("tensionCross", "Travers") : step("tension", "Tension")) +
      '<label class="field inline check" style="margin:0"><span><span style="display:block">Tensions différentes</span><span class="small">Montants et travers cordés à des tensions différentes</span></span><input type="checkbox" role="switch" data-split="' + target + '"' + (split ? " checked" : "") + "></label>";
  }
  function setupLabel(m) {
    var r = racket(m.racketId);
    if (!r) return "";
    return r.name + (m.string ? " · " + m.string : "") + (m.tension ? " · " + fmtTension(m) : "");
  }

  // ---------- Routage ----------
  function route() { var h = location.hash.replace(/^#\/?/, ""); return h.split("?")[0]; }
  function go(path) { if (location.hash === "#/" + path) render(); else location.hash = "#/" + path; }
  var stack = [route()];
  function back() { if (stack.length > 1) history.back(); else go(""); }

  window.addEventListener("hashchange", function () {
    if (location.hash.indexOf("#import=") === 0) return handleImportHash();
    var r = route(); UI.sheet = null;
    if (stack.length > 1 && stack[stack.length - 2] === r) stack.pop(); else if (stack[stack.length - 1] !== r) stack.push(r);
    UI.menu = false; render(); window.scrollTo(0, 0);
  });

  function handleImportHash() {
    var t = "";
    try { t = decodeURIComponent(location.hash.slice("#import=".length)); } catch (e) {}
    history.replaceState(null, "", location.pathname + "#/tenup");
    var pl = T.decode(t);
    if (pl) { importPayload(pl); return; }
    UI.importText = t; UI.importRows = rowsFromText(t);
    if (!S.onboarded) { S.onboarded = true; save(); }
    render();
  }

  // ---------- Rendu ----------
  function render() {
    var r = route(), parts = r.split("/"), html;
    UI.partyKey = null;
    if (!S.scoreV2) {
      // scores importés écrits du point de vue du vainqueur : on les remet dans ton sens
      S.scoreV2 = 1;
      S.matches.concat(S.doubles || []).forEach(function (m) {
        if (!m.score || /ab|abandon/i.test(m.score) || m.wo || !(m.result === "V" || m.result === "D") || isManual(m)) return;
        var st = setsOf(m.score), w = 0, l = 0;
        st.forEach(function (x) { if (x[0] > x[1]) w++; else if (x[0] < x[1]) l++; });
        if ((m.result === "D" && w > l) || (m.result === "V" && l > w)) m.score = m.score.replace(/(\d{1,2})\s*-\s*(\d{1,2})/g, function (_, a, b) { return b + "-" + a; });
      });
      save();
    }
    if (!S.surfV2) { S.surfV2 = 1; S.matches.forEach(function (m) { if (SURF_OLD[m.surface]) m.surface = SURF_OLD[m.surface]; }); save(); }
    if (!S.tenupRank && S.tenup && S.tenup.official && S.tenup.official.classement) { var tr = T.normRank(S.tenup.official.classement); if (tr && E.idx(tr) != null) { S.tenupRank = tr; save(); } }
    if (S.tenup && S.tenup.official && !S.tenup.cal && !S.tenup.calV2) { S.tenup.calV2 = 1; calibrateFromTenup(); save(); }
    refreshAhead();
    if (S.ahead && S.onboarded) UI.partyKey = S.ahead.release + ">" + S.ahead.rank;
    if (!S.onboarded && (parts[0] === "" || parts[0] === "palmares" || parts[0] === "courbes")) { location.replace("#/bienvenue"); return; }
    switch (parts[0]) {
      case "bienvenue": html = V.welcome(); break;
      case "projection": html = V.projection(); break;
      case "palmares": html = V.palmares(); break;
      case "match": html = V.match(parts[1]); break;
      case "entrainement": html = V.entrainement(parts[1]); break;
      case "creneau": html = V.creneau(parts[1]); break;
      case "courbes": html = V.courbes(); break;
      case "perso": html = V.perso(parts[1]); break;
      case "materiel": html = V.materiel(); break;
      case "raquette": html = V.raquette(parts[1]); break;
      case "adversaire": html = V.adversaire(parts.slice(1).join("/")); break;
      case "tenup": html = V.tenup(); break;
      case "profil": html = V.profil(); break;
      case "donnees": html = V.donnees(); break;
      case "methode": html = V.methode(); break;
      case "apropos": html = V.apropos(); break;
      case "reglages": html = V.reglages(); break;
      default: html = V.home();
    }
    if (UI.menu) html += menuHtml();
    if (UI.leaveAsk) html += leaveSheet();
    if (UI.sheet) html += sheetHtml();
    if (!UI.sheet && !UI.leaveAsk && notesDue()) html += notesHtml();
    document.body.classList.toggle("locked", !!(UI.menu || UI.rkMenu || UI.sheet || UI.leaveAsk || UI.notesOpen));
    app.innerHTML = html;
    var f = app.querySelector("[data-autofocus]"); if (f) f.focus();
    if (UI.partyKey && S.celebrated !== UI.partyKey) { S.celebrated = UI.partyKey; save(); setTimeout(party, 350); }
    syncWidgets();
  }

  // ---------- Barre « Enregistrer » collée en bas + garde-fou au retour ----------
  function snap(o) { return JSON.stringify(o || {}, function (k, v) { return k.charAt(0) === "_" ? undefined : v; }); }
  function editCtx() {
    var r = route().split("/")[0];
    if ((r === "match" || r === "entrainement") && UI.draft) return { d: UI.draft, save: r === "match" ? "saveMatch" : "saveTraining" };
    if (r === "raquette" && UI.racketDraft) return { d: UI.racketDraft, save: "saveRacket" };
    return null;
  }
  function isDirty() { var e = editCtx(); return !!(e && UI.origKey === e.save + (e.d._for || "") && snap(e.d) !== UI.orig); }
  function saveBar(action, draft, isNew) {
    var key = action + (draft._for || "");
    if (UI.origKey !== key) { UI.origKey = key; UI.orig = snap(draft); }
    var dirty = snap(draft) !== UI.orig;
    return '<div class="savebar-space"></div><div class="savebar' + (dirty ? " dirty" : "") + '"><span class="sb-state">' + (isNew ? "Pas encore enregistré" : "Modifications non enregistrées") + "</span>" +
      '<button class="btn primary" data-a="' + action + '"' + (isNew || dirty ? "" : " disabled") + ">Enregistrer</button></div>";
  }
  function refreshSaveBar() {
    var b = app.querySelector(".savebar"); if (!b) return;
    var d = isDirty(), btn = b.querySelector("button");
    b.classList.toggle("dirty", d);
    if (btn && d) btn.disabled = false;
  }
  function leaveSheet() {
    return '<div class="sheet-bg" data-a="leaveStay"></div><div class="sheet" role="dialog" aria-modal="true" aria-label="Modifications non enregistrées"><b>Enregistrer tes modifications ?</b>' +
      '<span class="small">Tu as changé des choses sur cette page.</span>' +
      '<button class="btn primary" data-a="leaveSave">Enregistrer</button><button class="btn soft" data-a="leaveDiscard">Ne pas enregistrer</button><button class="linkbtn" data-a="leaveStay">Rester sur la page</button></div>';
  }
  function topbar(title, sub, right) {
    return '<div class="topbar"><button class="iconbtn" data-a="back" aria-label="Retour">' + I.back + "</button>" +
      '<div class="title" style="flex:1">' + (sub ? '<span class="small">' + esc(sub) + "</span>" : "") + "</div>" + (right || "") + "</div>" +
      (title ? "<h1>" + esc(title) + "</h1>" : "");
  }
  function tabbar(active) {
    var t = function (id, label, icon, path) {
      return '<a class="tab' + (active === id ? " on" : "") + '" href="#/' + path + '"' + (active === id ? ' aria-current="page"' : "") + ">" + icon + label + "</a>";
    };
    return '<div class="tabbar"><nav aria-label="Navigation principale">' +
      t("home", "Accueil", I.home, "") + t("palmares", "Palmarès", I.list, "palmares") +
      '<button class="plus" data-a="menu" aria-label="Ouvrir le menu : ajouter un match, faire un don…" aria-haspopup="dialog">' + svg('<path d="M12 5v14M5 12h14"/>', 2.8, ' width="26" height="26"') + "</button>" +
      t("courbes", "Courbes", I.chart, "courbes") + t("materiel", "Matériel", I.racket, "materiel") +
      "</nav></div>";
  }

  // ---------- Menu + ----------
  function isStandalone() { return (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone; }
  function menuHtml() {
    var item = function (a, ic, t, s, cls, extra) {
      return '<button class="menu-item ' + (cls || "") + '" data-a="' + a + '"' + (extra || "") + '><span class="ic">' + ic + "</span><span><b>" + t + '</b><span class="s">' + s + "</span></span></button>";
    };
    return '<div class="overlay" data-a="closeMenu"></div><div class="sheet" role="dialog" aria-modal="true" aria-label="Menu"><div class="sheet-inner"><span class="grab"></span>' +
      item("newMatch", I.plus, "Ajouter un match", "Adversaire, score, matériel : 20 secondes") +
      item("newTraining", I.clock, "Ajouter un entraînement", "Durée, matériel, ressenti : compte dans l'usure du cordage") +
      (NATIVE ? "" : item("don", I.heart, "Soutenir Montée", "Un don pour garder l'app gratuite et sans pub", "don")) +
      item("goTenup", I.link, "Actualiser depuis Ten'Up", S.tenup.lastImport ? "Dernier import le " + fdate(S.tenup.lastImport) : "Récupère ton palmarès en une fois") +
      item("goRaquettes", I.racket, "Mes raquettes", "Cordage, tension, date du dernier cordage") +
      item("goProfil", I.user, "Mon profil", "Classement actuel, normes hommes ou dames") +
      item("goDonnees", I.save, "Sauvegarder mes données", "Créer ou restaurer une sauvegarde") +
      (isStandalone() || NATIVE ? "" : item("install", I.phone, "Installer l'application", "Sur l'écran d'accueil, comme une vraie app")) +
      item("share", I.share, "Partager Montée", "À ton partenaire de double, à ton club") +
      item("goMethode", I.book, "Comment c'est calculé", "Barème, normes, V-E-2I-5G") +
      (CONFIG.CONTACT_EMAIL ? item("contact", I.mail, "Donner mon avis", "Une idée, un bug, un calcul faux ?") : "") +
      item("goApropos", I.info, "À propos", "Confidentialité, mentions, version " + CONFIG.VERSION) +
      '<button class="btn soft small" data-a="closeMenu">Fermer</button></div></div>';
  }

  var V = {};

  // ---------- Bienvenue ----------
  V.welcome = function () {
    return '<div class="screen">' +
      '<div class="brand">' + I.logo(30) + "montée</div>" +
      '<div class="welcome-ill">' + (window.MonteeIll ? window.MonteeIll.welcome() : "") + "</div>" +
      '<h1 class="xl">Tu montes ce mois-ci&nbsp;?<br>On te le dit avant mardi.</h1>' +
      '<p class="lead">Ton palmarès, ton bilan recalculé chaque jour, et ce qui te manque pour l\'échelon suivant. Sans lancer la simulation.</p>' +
      '<div class="stack" style="margin-top:6px">' +
      '<div class="alert">' + '<span class="badge ok">' + I.check + "</span><span>Ta prochaine sortie de classement, expliquée en une phrase</span></div>" +
      '<div class="alert">' + '<span class="badge ok">' + I.racket + "</span><span>Avec quelle raquette, quel cordage et quelle tension tu gagnes</span></div>" +
      '<div class="alert">' + '<span class="badge ok">' + svg('<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>') + "</span><span>Tout reste sur ton téléphone, rien n'est envoyé</span></div>" +
      "</div>" +
      '<div class="spacer"></div>' +
      '<p class="small">Montée n\'est pas lié à la FFT ni à Ten\'Up. Le calcul est indicatif : seul le classement officiel fait foi.</p>' +
      '<a class="btn primary" href="#/tenup">C\'est parti</a>' +
      "</div>";
  };

  // ---------- Profil ----------
  V.profil = function () {
    var p = S.profile, first = !S.onboarded;
    var opts = '<option value="">Choisis…</option><option value="NC"' + (p.rank === "NC" ? " selected" : "") + ">Non classé</option>" +
      E.ECHELONS.slice(0, 22).map(function (e) { return '<option value="' + e + '"' + (p.rank === e ? " selected" : "") + ">" + e + "</option>"; }).join("") +
      '<option value="N°"' + (p.rank === "N°" ? " selected" : "") + ">Numéroté (Top 100…)</option>";
    var fromTenup = !first && S.tenupRank && S.tenupRank === p.rank && !UI.profEdit;
    if (fromTenup) {
      return '<div class="screen">' + topbar("Mon profil") + '<div class="form">' +
        '<div class="field"><label for="pf-name">Prénom</label><input id="pf-name" type="text" autocomplete="given-name" data-f="profile.name" value="' + esc(p.name) + '" placeholder="Ex. : Yann"></div>' +
        '<div class="field"><span class="lbl">Classement</span><span style="font-size:28px;font-weight:700;letter-spacing:-.02em">' + esc(p.rank) + ' <span class="muted" style="font-size:16px;font-weight:500">' + (p.sex === "F" ? "Dames" : "Messieurs") + "</span></span>" +
        (S.ahead ? '<span class="small">Montée te compte déjà ' + esc(S.ahead.rank) + " pour la sortie du " + esc(fdate(S.ahead.release).replace(/\.$/, "")) + ".</span>" : "") +
        '<span class="small">Repris de Ten\'Up à chaque synchronisation : rien à faire après les sorties.</span></div></div>' +
        '<button class="linkbtn" data-a="profEdit">Corriger à la main</button>' +
        '<div class="spacer"></div><button class="btn primary" data-a="saveProfil">Enregistrer</button></div>';
    }
    return '<div class="screen">' + topbar(first ? "Sans Ten'Up" : "Mon profil", first ? "Saisis ton classement" : "") +
      '<div class="form">' +
      '<div class="field"><label for="pf-name">Prénom</label><input id="pf-name" type="text" autocomplete="given-name" data-f="profile.name" value="' + esc(p.name) + '" placeholder="Ex. : Yann"></div>' +
      '<div class="field"><span class="lbl">Classement</span><span class="small" style="margin-top:-4px">Les normes ne sont pas les mêmes chez les hommes et les dames.</span><div class="seg" role="group" aria-label="Classement hommes ou dames">' +
      '<button data-a="sex" data-v="H" class="' + (p.sex === "H" ? "on" : "") + '" aria-pressed="' + (p.sex === "H") + '">Messieurs</button>' +
      '<button data-a="sex" data-v="F" class="' + (p.sex === "F" ? "on" : "") + '" aria-pressed="' + (p.sex === "F") + '">Dames</button></div></div>' +
      '<div class="field inline"><label for="pf-rank">Classement actuel' + (S.ahead ? '<span class="small" style="display:block;font-weight:400">Montée te compte déjà ' + esc(S.ahead.rank) + " pour la sortie du " + esc(fdate(S.ahead.release).replace(/\.$/, "")) + "</span>" : "") + '</label><select id="pf-rank" data-f="profile.rank">' + opts + "</select></div>" +
      (NATIVE ? "" : '<div class="field"><label for="pf-lic">Numéro de licence FFT <span class="small">(facultatif)</span></label><input id="pf-lic" type="text" inputmode="text" autocapitalize="characters" autocorrect="off" spellcheck="false" autocomplete="off" data-f="profile.licence" value="' + esc(p.licence || "") + '" placeholder="Ex. : 1234567 A"><span class="small">Sert seulement au raccourci Ten\'Up, si ta page palmarès n\'est pas ouverte.</span></div>') +
      "</div>" +
      '<p class="small">Mets le classement affiché aujourd\'hui sur Ten\'Up. Tu le changeras après chaque sortie (on te le rappellera).</p>' +
      '<div class="spacer"></div>' +
      '<button class="btn primary" data-a="saveProfil"' + (p.rank ? "" : " disabled") + ">" + (first ? "Continuer" : "Enregistrer") + "</button>" +
      "</div>";
  };

  // ---------- Accueil ----------
  V.home = function () {
    var c = ctx(), p = c.proj, s = '<div class="screen has-tabs">';
    var d = today();
    s += '<div class="topbar"><div class="title"><span class="small">' + esc(flong(d).replace(/^./, function (x) { return x.toUpperCase(); })) + '</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">' + (S.profile.name ? "Salut " + esc(S.profile.name) : "Salut") + "</span></div>" +
      '<span class="top-actions"><button class="rankchip' + (S.ahead ? " up" : "") + '" data-a="goProfil" aria-label="Mon classement : ' + esc(effRank() || "?") + ', modifier">' + esc(effRank() || "?") + '</button><button class="iconbtn gearbtn" data-a="goReglages" aria-label="Réglages">' + I.gear + "</button></span></div>";

    if (!S.matches.length) {
      s += '<div class="card balle"><span class="eyebrow">Pour commencer</span><span style="font-size:22px;font-weight:600;letter-spacing:-.02em;line-height:1.2">Récupère tes matchs des 12 derniers mois.</span><span style="font-size:15px">Sans eux, impossible de savoir si tu montes.</span></div>' +
        '<div class="stack"><a class="btn primary" href="#/tenup">' + I.link + " Récupérer depuis Ten'Up</a>" +
        '<button class="btn soft" data-a="newMatch">' + I.plus + " Ajouter un match à la main</button>" +
        '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button></div>';
      return s + "</div>" + tabbar("home");
    }
    if (p.status === "top") {
      s += '<div class="card ink"><span class="eyebrow" style="color:var(--hl)">Joueur numéroté</span><span style="font-size:20px;font-weight:600">Ton classement se joue au concours des meilleurs bilans : Montée ne peut pas le simuler.</span><span style="font-size:14px;color:#E6E0D8">Tes stats, tes courbes et ton matériel restent disponibles.</span></div>';
    } else s += heroHtml(c);
    var B = {}; B.official = officialHtml(false);
    B.insight = insightHtml(c);
    B.annoter = qaHtml();
    var stale = !S.tenup.lastImport || (today() - E.parseDate(S.tenup.lastImport)) / 864e5 > 6;
    if (stale) B.sync = '<a class="row" href="#/tenup" style="background:var(--card);border-radius:20px;text-decoration:none"><span class="badge ok">' + I.link + '</span><span class="grow"><span class="t">Actualiser depuis Ten\'Up</span><span class="s">' + (S.tenup.lastImport ? "Dernier import le " + esc(fdate(S.tenup.lastImport)) : "Récupère tes matchs et la simulation officielle") + "</span></span>" + I.next + "</a>";

    B.rate = rateCardHtml();
    B.slot = slotCardHtml();
    B.cordage = "";
    bag().forEach(function (r) {
      var st = racketStatus(r);
      if (st.level !== "soon" && st.level !== "change" && st.level !== "broken") return;
      var txt = st.level === "broken" ? "<b>" + esc(r.name) + " : cordage cassé.</b> Dis-le quand c'est recordé, le compteur repart à zéro." :
        "<b>" + esc(r.name) + " : " + (st.level === "change" ? "à recorder" : "bientôt à recorder") + "</b>. " +
        (st.type === "mono" && st.min >= MONO_WARN ? "Ton monofilament a environ " + fmtHours(st.min) + " de jeu. " + (st.level === "change" ? "Au-delà de 20 h, il a perdu l'essentiel de sa tension : change-le." : "Au-delà de 20 h de jeu, songe à le changer.") :
          "Environ " + fmtHours(st.min) + " de jeu : tu casses en général vers " + fmtHours(st.breakAvg.avg) + ".");
      B.cordage += '<div class="alert" style="flex-direction:column;gap:10px"><a href="#/raquette/' + r.id + '" style="display:flex;gap:12px;text-decoration:none;color:inherit"><span class="badge ko">' + I.warn + "</span><span>" + txt + "</span></a>" +
        '<button class="btn balle small" data-a="quickRestring" data-id="' + r.id + '">J\'ai recordé aujourd\'hui</button></div>';
    });

    // conditions
    if (p.status !== "top") {
      var target = Math.min((c.cur < 0 ? 0 : c.cur) + 1, E.MAX_CALC);
      var winOk = p.next.winAtLevel;
      B.conditions = '<div class="grid2">' +
        '<div class="tile"><span class="badge ' + (winOk ? "ok" : "ko") + '">' + (winOk ? I.check : I.cross) + "</span><span>Victoire contre un " + lab(target) + " ou mieux : <b>" + (winOk ? "acquise" : "il en faut une") + "</b></span></div>" +
        (c.cur <= 0 ? '<div class="tile"><span class="badge ok">' + I.check + "</span><span>Pas de descente possible sous 40</span></div>" :
          '<div class="tile"><span class="badge ' + (p.margin >= 0 ? "ok" : "ko") + '">' + (p.margin >= 0 ? I.check : I.warn) + "</span><span>Maintien à " + esc(effRank()) + " : <b>" + (p.margin >= 0 ? "assuré" : "menacé") + "</b>, " + (p.margin >= 0 ? plural(p.margin, "pt") + " d'avance" : plural(-p.margin, "pt") + " de retard") + "</span></div>") +
        "</div>";
    }
    // victoires qui sortent
    B.drops = "";
    c.drops.forEach(function (x) {
      var when = x.leaves <= p.release ? fdate(x.leaves) : "";
      B.drops += '<div class="alert"><span class="badge ko">' + I.clock + "</span><span><b>Le " + esc(when) + "</b>, ta victoire contre " + esc(x.m.opp || "un " + x.m.oppRank) + " (" + esc(x.m.oppRank) + ", " + esc(fdate(x.m.date)) + ") sort de tes 12 mois. Déjà comptée ici : <span class=\"neg\">−" + x.pts + " pts</span> au bilan " + lab(Math.min((c.cur < 0 ? 0 : c.cur) + 1, E.MAX_CALC)) + ".</span></div>";
    });

    // forme + cordage
    var last = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); });
    var w12 = p.matches || [];
    var nv = w12.filter(function (m) { return m.result === "V"; }).length, nd = w12.filter(function (m) { return m.result === "D"; }).length;
    B.tiles = '<div class="grid2"><a class="tile" href="#/courbes"><span class="k">Forme · 5 derniers</span><span class="form-dots">' +
      last.slice(0, 5).map(function (m) { return '<span class="vd ' + m.result + '" aria-label="' + (m.result === "V" ? "Victoire" : "Défaite") + '">' + m.result + "</span>"; }).join("") +
      "</span><span>" + nv + " V · " + nd + " D sur 12 mois</span></a>";
    var rk = bag().filter(function (r) { return r.main; })[0] || bag()[0];
    if (rk) {
      var st = racketStatus(rk);
      var msg = st.level === "broken" ? '<span class="neg">Cordage cassé</span>' : !st.known ? "Indique quand tu l'as recordée" : st.level === "change" ? '<span class="neg">À recorder</span>' : st.level === "soon" ? '<span class="neg">Bientôt à recorder</span>' : !st.type ? "Précise le type de cordage" : st.type === "mono" ? "à recorder vers 20 h" : "de jeu sur le cordage";
      B.tiles += '<a class="tile" href="#/raquette/' + rk.id + '"><span class="k">' + esc(rk.name) + '</span><span class="v">' + (st.known ? "≈ " + fmtHours(st.min) : "Cordage ?") + "</span><span>" + msg + "</span></a>";
    } else {
      B.tiles += '<a class="tile" href="#/raquette/new"><span class="k">Ton matériel</span><span class="v">Ajoute ta raquette</span><span>Pour savoir avec quoi tu gagnes</span></a>';
    }
    B.tiles += "</div>";
    B.week = weekHtml();

    var todo = S.matches.filter(function (m) { return !annotated(m); }).length;
    if (todo) B.todo = '<button class="row" data-a="palTodo" style="background:var(--card);border-radius:20px"><span class="grow"><span class="t">' + plural(todo, "match", "matchs") + ' à annoter</span><span class="s">Raquette, cordage, ressenti : 20 secondes</span></span>' + I.next + "</button>";
    s += layout("home", B);
    s += '<p class="small">Calcul indicatif d\'après le barème FFT. Seul le classement officiel fait foi.</p>';
    return s + "</div>" + tabbar("home");
  };

  // ---------- Cartes à la carte (accueil, courbes) ----------
  var BLOCKS = {
    home: [["insight", "Le truc à savoir"], ["annoter", "Annoter tes nouveaux matchs"], ["official", "Simulation officielle Ten'Up"], ["sync", "Rappel de synchro Ten'Up"], ["rate", "Noter tes séances"], ["slot", "« T'as joué ? » (semaine type)"],
      ["cordage", "Alertes cordage"], ["conditions", "Victoire et maintien"], ["drops", "Victoires qui sortent"], ["tiles", "Forme et raquette"], ["week", "Ta semaine"], ["todo", "Matchs à annoter"]],
    courbes: [["bilan", "Ton bilan"], ["forme", "Forme du moment"], ["defend", "Points à défendre"], ["plafond", "Ton plafond"], ["mental", "Mental"], ["h2h", "Face-à-face"],
      ["records", "Tes records"], ["where", "Où tu gagnes"], ["temps", "Temps de jeu"]]
  };
  function prefsOf(page) {
    S.prefs = S.prefs || {};
    var pr = S.prefs[page] || { order: [], hidden: [] }, ids = BLOCKS[page].map(function (x) { return x[0]; });
    var order = pr.order.filter(function (k) { return ids.indexOf(k) >= 0; });
    ids.forEach(function (k, i) { if (order.indexOf(k) < 0) order.splice(Math.min(i, order.length), 0, k); });
    return { order: order, hidden: pr.hidden || [] };
  }
  function layout(page, B) {
    var pr = prefsOf(page);
    return pr.order.filter(function (k) { return pr.hidden.indexOf(k) < 0 && B[k]; }).map(function (k) { return B[k]; }).join("") +
      '<a class="btn soft small perso-btn" href="#/perso/' + page + '">' + I.edit + " Personnaliser " + (page === "home" ? "l'accueil" : "les courbes") + "</a>";
  }
  V.perso = function (page) {
    if (!BLOCKS[page]) { go(""); return ""; }
    var pr = prefsOf(page), names = {}; BLOCKS[page].forEach(function (x) { names[x[0]] = x[1]; });
    var s = '<div class="screen">' + topbar(page === "home" ? "Ton accueil" : "Tes courbes", "Choisis les cartes et leur ordre");
    if (page === "home") s += '<p class="small">La carte principale (montée, maintien) reste toujours en haut. Les alertes n\'apparaissent que quand il y a quelque chose à te dire.</p>';
    s += '<div class="list">' + pr.order.map(function (k, i) {
      var on = pr.hidden.indexOf(k) < 0;
      return '<div class="row perso-row' + (on ? "" : " off") + '"><span class="grow"><span class="t">' + esc(names[k]) + "</span></span>" +
        '<button class="iconbtn sm" data-a="persoMove" data-p="' + page + '" data-k="' + k + '" data-v="-1"' + (i ? "" : " disabled") + ' aria-label="Monter">↑</button>' +
        '<button class="iconbtn sm" data-a="persoMove" data-p="' + page + '" data-k="' + k + '" data-v="1"' + (i < pr.order.length - 1 ? "" : " disabled") + ' aria-label="Descendre">↓</button>' +
        '<input type="checkbox" role="switch" data-a="persoToggle" data-p="' + page + '" data-k="' + k + '"' + (on ? " checked" : "") + ' aria-label="Afficher ' + esc(names[k]) + '"></div>';
    }).join("") + "</div>";
    s += '<button class="linkbtn" data-a="persoReset" data-p="' + page + '">Revenir à l\'affichage d\'origine</button>';
    return s + "</div>";
  };

  // ---------- Ta semaine : temps de jeu et régularité ----------
  function mondayOf(d) { var x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - (x.getDay() + 6) % 7); return x; }
  function activity() {
    var by = {};
    S.matches.forEach(function (m) { if (m.date && !m.wo) { by[m.date] = by[m.date] || { m: 0, t: 0, min: 0 }; by[m.date].m++; by[m.date].min += playMinutes(m); } });
    (S.trainings || []).forEach(function (t) { if (t.date) { by[t.date] = by[t.date] || { m: 0, t: 0, min: 0 }; by[t.date].t++; by[t.date].min += playMinutes(t); } });
    return by;
  }
  function weekHtml() {
    var by = activity(), mon = mondayOf(today()), min = 0, dots = "", L = ["L", "M", "M", "J", "V", "S", "D"], td = E.iso(today());
    for (var i = 0; i < 7; i++) {
      var d = new Date(mon); d.setDate(d.getDate() + i); var k = E.iso(d), a = by[k];
      if (a) min += a.min;
      dots += '<span class="wd' + (k === td ? " today" : "") + '"><i class="' + (a ? (a.m ? "m" : "t") : "") + '"></i>' + L[i] + "</span>";
    }
    // semaines actives d'affilée (la semaine en cours ne casse pas la série si elle est encore vide)
    var streak = 0, w = new Date(mon), first = true;
    for (var n = 0; n < 104; n++) {
      var any = false;
      for (var j = 0; j < 7; j++) { var dd = new Date(w); dd.setDate(dd.getDate() + j); if (by[E.iso(dd)]) { any = true; break; } }
      if (any) streak++; else if (!first) break;
      first = false; w.setDate(w.getDate() - 7);
    }
    if (!min && !streak && !(S.slots || []).length) return "";
    return '<div class="card week"><div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px"><span><span class="eyebrow" style="color:var(--muted)">Cette semaine</span><span style="display:block;font-size:24px;font-weight:700;letter-spacing:-.02em">' + (min ? fmtDur(min) + ' <span style="font-size:15px;font-weight:500;color:var(--muted)">de jeu</span>' : "Pas encore joué") + "</span></span>" +
      (streak ? '<span class="streak">' + plural(streak, "semaine active", "semaines actives") + "</span>" : "") + "</div>" +
      '<div class="wdays">' + dots + "</div>" +
      '<span class="small"><span class="dot" style="background:var(--gazon)"></span> match · <span class="dot" style="background:var(--balle)"></span> entraînement' + ((S.slots || []).length ? "" : ' · <button class="linkbtn" data-a="newSlot" style="padding:0;min-height:0;font-size:inherit">Ajoute ta semaine type</button>') + "</span></div>";
  }
  // ---------- Semaine type : créneaux fixes à confirmer d'un tap ----------
  var DAYS_L = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"];
  var TLABELS = ["Collectif", "Cours", "Partenaire", "Autre"];
  function pendingSlots() {
    var out = [], now = new Date(), hhmm = ("0" + now.getHours()).slice(-2) + ":" + ("0" + now.getMinutes()).slice(-2), log = S.slotLog || {};
    (S.slots || []).forEach(function (sl) {
      for (var b = 0; b < 7; b++) {
        var d = today(); d.setDate(d.getDate() - b);
        if ((d.getDay() + 6) % 7 !== sl.dow) continue;
        var k = E.iso(d);
        if (k < sl.since || (b === 0 && (sl.time || "00:00") > hhmm) || log[sl.id + "|" + k]) continue;
        out.push({ sl: sl, date: k, back: b });
      }
    });
    return out.sort(function (a, b) { return a.back - b.back; });
  }
  function slotCardHtml() {
    var list = pendingSlots(); if (!list.length) return "";
    var x = list[0], d = E.parseDate(x.date);
    var when = x.back === 0 ? "Aujourd'hui" : x.back === 1 ? "Hier" : DAYS_L[x.sl.dow].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + d.getDate();
    return '<div class="card" style="gap:10px"><span class="eyebrow" style="color:var(--gazon)">Ta semaine type</span><span style="font-size:20px;font-weight:600;letter-spacing:-.02em">' + esc(when) + " " + esc(x.sl.time || "") + " : t'as joué ?</span>" +
      '<span class="small">' + esc(x.sl.label || "Entraînement") + " · " + fmtDur(x.sl.minutes) + ". Ça s'ajoute aux heures de ton cordage.</span>" +
      '<div class="grid2"><button class="btn primary small" data-a="slotYes" data-id="' + x.sl.id + '" data-d="' + x.date + '">Oui, j\'ai joué</button><button class="btn soft small" style="background:var(--chip)" data-a="slotNo" data-id="' + x.sl.id + '" data-d="' + x.date + '">Non</button></div>' +
      (list.length > 1 ? '<span class="small">encore ' + (list.length - 1) + " à confirmer</span>" : "") + "</div>";
  }
  V.creneau = function (id) {
    var isNew = !id || id === "new";
    if (!UI.slotDraft || UI.slotDraft._for !== (id || "new")) {
      var base = isNew ? { id: uid(), dow: 1, time: "18:30", minutes: 90, label: "Collectif", since: E.iso(today()) } : JSON.parse(JSON.stringify((S.slots || []).filter(function (x) { return x.id === id; })[0] || {}));
      if (!base.id) { go("materiel"); return ""; }
      base._for = id || "new"; UI.slotDraft = base;
    }
    var sl = UI.slotDraft;
    var s = '<div class="screen">' + topbar(isNew ? "Nouveau créneau" : "Créneau", "Ta semaine type", isNew ? "" : '<button class="iconbtn" data-a="delSlot" aria-label="Supprimer ce créneau">' + I.trash + "</button>");
    s += '<div class="form">' +
      '<div class="field"><span class="lbl">Jour</span><div class="chips">' + DAYS_L.map(function (d, i) { return '<button class="chip' + (sl.dow === i ? " on" : "") + '" data-a="slset" data-k="dow" data-v="' + i + '">' + d.slice(0, 3) + ".</button>"; }).join("") + "</div></div>" +
      '<div class="field inline"><label for="sl-time">Heure</label><input id="sl-time" type="time" data-sl="time" value="' + esc(sl.time) + '"></div>' +
      '<div class="field"><span class="lbl">Durée</span><div class="chips">' + [60, 90, 120].map(function (n) { return '<button class="chip' + (sl.minutes === n ? " on" : "") + '" data-a="slset" data-k="minutes" data-v="' + n + '">' + fmtDur(n) + "</button>"; }).join("") + "</div></div>" +
      '<div class="field"><span class="lbl">Type</span><div class="chips">' + TLABELS.map(function (l) { return '<button class="chip' + (sl.label === l ? " on" : "") + '" data-a="slset" data-k="label" data-v="' + l + '">' + l + "</button>"; }).join("") + "</div></div>" +
      "</div>";
    s += '<p class="small">Chaque semaine, après le créneau, Montée te demande sur l\'accueil si tu as joué. Un tap, et l\'entraînement est noté avec ta raquette principale.</p>';
    s += '<div class="spacer"></div><button class="btn primary" data-a="saveSlot">Enregistrer</button></div>';
    return s;
  };

  // ---------- Notation dans le flow : une carte sur l'accueil ----------
  var FEEL = ["Galère", "Bof", "Correct", "Bien", "Au top"];
  // ---------- Annoter en 10 secondes ----------
  // Les matchs récents sans raquette : raquette, surface, intérieur/ext. et ressenti en quelques taps.
  function qaPending(m) {
    var d = today(); d.setDate(d.getDate() - 30);
    return !!(m.date && !m.wo && !m.racketId && !m.qaSkip && m.date >= E.iso(d) && (m.result === "V" || m.result === "D"));
  }
  function qaList() { return S.matches.filter(qaPending).sort(function (a, b) { return a.date < b.date ? 1 : -1; }); }
  function qaHtml() {
    var list = qaList(); if (!list.length) return "";
    var m = list[0], last = S.lastQA || {};
    if (!UI.qa || UI.qa.id !== m.id) {
      var main = racketFor("match");
      UI.qa = { id: m.id, racketId: main ? main.id : "", surface: m.surface || last.surface || "", indoor: m.indoor != null ? m.indoor : (last.indoor != null ? last.indoor : null) };
    }
    var q = UI.qa;
    var chip = function (a, v, on, label) { return '<button class="chip' + (on ? " on" : "") + '" data-a="' + a + '" data-v="' + esc(String(v)) + '" aria-pressed="' + on + '">' + esc(label) + "</button>"; };
    var IL = window.MonteeIll;
    var s = '<div class="card qa"><span class="qa-top"><span class="eyebrow">Annote en 10 secondes' + (list.length > 1 ? " · encore " + (list.length - 1) + " après" : "") + "</span></span>" +
      '<span style="font-size:20px;font-weight:600;letter-spacing:-.02em;line-height:1.2">' + (m.result === "V" ? "Victoire" : "Défaite") + " contre " + esc(m.opp || "un " + m.oppRank) + ' <span style="opacity:.6;font-weight:500">' + esc(m.oppRank) + "</span></span>" +
      '<span class="small" style="color:inherit;opacity:.75;margin-top:-4px">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + (m.comp ? " · " + esc(m.comp) : "") + "</span>" + revHint(m.opp, m.id, true);
    s += '<span class="qa-l">Raquette</span><div class="chips">' + (bag().length ? bag().map(function (r) { return chip("qaRacket", r.id, q.racketId === r.id, r.name); }).join("") : '<a class="chip" href="#/raquette/new">+ Ajoute ta raquette</a>') + "</div>";
    s += '<span class="qa-l">Surface</span><div class="chips">' + SURFACES.map(function (x) { return chip("qaSurface", x, q.surface === x, SURF_LAB[x] || x); }).join("") + "</div>";
    s += '<span class="qa-l">Où</span><div class="chips">' + chip("qaIndoor", "1", q.indoor === true, "Intérieur") + chip("qaIndoor", "0", q.indoor === false, "Extérieur") + "</div>";
    s += '<span class="qa-l">Ton ressenti · un tap pour valider</span><div class="rate-row" role="group" aria-label="Ressenti de 1 à 5, valide l\'annotation">' +
      FEEL.map(function (l, i) { return '<button data-a="qaSave" data-v="' + (i + 1) + '"><b>' + (i + 1) + "</b><span>" + l + "</span></button>"; }).join("") + "</div>";
    s += '<div style="display:flex;justify-content:space-between;align-items:center"><button class="linkbtn" data-a="qaSkip" style="padding:0">Pas cette fois</button><button class="linkbtn" data-a="qaSave" data-v="0" style="padding:0">Valider sans ressenti</button></div></div>';
    return s;
  }

  // ---------- Le truc à savoir ----------
  // Parmi toutes les stats, celle qui ressort le plus en ce moment, en une phrase.
  function insights(c) {
    var win = (c.proj.matches || []).filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); }), out = [];
    var phr = {
      surface: function (x) { return "sur " + x.label.toLowerCase(); },
      lieu: function (x) { return x.label === "Intérieur" ? "en intérieur" : "en extérieur"; },
      kind: function (x) { return x.label === "Tournoi" ? "en tournoi" : x.label === "Par équipes" ? "par équipes" : x.label === "Championnat individuel" ? "en championnat individuel" : "en match libre"; }
    };
    [["surface", surfKey], ["lieu", function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; }],
      ["kind", function (m) { return (KINDS.filter(function (k) { return k[0] === (m.kind || "tournoi"); })[0] || ["", "Tournoi"])[1]; }]].forEach(function (d) {
      var g = groupStats(win, d[1]).filter(function (x) { return x.n >= 3; });
      if (g.length < 2) return;
      var hi = g[0], lo = g[g.length - 1], diff = hi.pct - lo.pct;
      if (diff < 25) return;
      out.push({ id: "split-" + d[0] + "-" + hi.label + "-" + lo.label, score: diff, go: "courbes", tab: d[0],
        text: "Tu gagnes " + hi.v + " matchs sur " + hi.n + " " + phr[d[0]](hi) + ", " + lo.v + " sur " + lo.n + " " + phr[d[0]](lo) + "." });
    });
    var ann = S.matches.filter(function (m) { return m.racketId && !m.wo && (m.result === "V" || m.result === "D"); });
    var gs = groupStats(ann, setupLabel).filter(function (x) { return x.n >= 3; });
    if (gs.length >= 2 && gs[0].pct - gs[gs.length - 1].pct >= 25) out.push({ id: "setup-" + gs[0].label, score: gs[0].pct - gs[gs.length - 1].pct - 5, go: "materiel",
      text: "Avec " + gs[0].label + ", tu gagnes " + gs[0].v + " sur " + gs[0].n + ". Avec " + gs[gs.length - 1].label + ", " + gs[gs.length - 1].v + " sur " + gs[gs.length - 1].n + "." });
    // points qui sortent bientôt
    var b0 = c.proj.status === "descente" ? c.proj.here : c.proj.next;
    if (b0 && b0.counted) {
      var lim = today(); lim.setDate(lim.getDate() + 92);
      var soon = b0.counted.filter(function (w) { if (!w.m.date) return false; var l = E.plus12Months(E.parseDate(w.m.date)); return l > today() && l <= lim; }).sort(function (a, b) { return b.pts - a.pts; });
      if (soon.length && soon[0].pts >= 30) {
        var w = soon[0], lv = E.plus12Months(E.parseDate(w.m.date));
        out.push({ id: "defend-" + w.m.id, score: 20 + w.pts / 3, go: "courbes",
          text: "En " + MOIS_L[lv.getMonth()] + ", ta victoire contre " + (w.m.opp || "un " + w.m.oppRank) + " (" + w.m.oppRank + ", +" + w.pts + " pts) sort de tes 12 mois." + (soon.length > 1 ? " Et " + plural(soon.length - 1, "autre") + " d'ici 3 mois." : "") });
      }
    }
    // revanche : tu viens de rejouer quelqu'un sur qui tu avais pris des notes
    var lim14 = E.iso(new Date(today().getTime() - 14 * 864e5));
    sortedMatches().filter(function (m) { return m.date >= lim14 && m.opp && !m.wo; }).slice(0, 5).forEach(function (m) {
      var prev = revNotes(m.opp, m.id).filter(function (n) { return !n.date || n.date <= m.date; })[0];
      if (!prev) return;
      out.push({ id: "rev-" + m.id, score: 45, go: "adversaire/" + encodeURIComponent(nameKey(m.opp)), ill: "revanche",
        text: (m.result === "V" ? "Revanche prise contre " : "Encore raté contre ") + m.opp + ". Ta note disait : « " + prev.text + " ». " + (m.result === "V" ? "Garde-la pour la prochaine." : "Ajoute ce que tu as appris.") });
    });
    // séries
    var sm = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }), st = 0;
    for (var i = 0; i < sm.length && sm[i].result === sm[0].result; i++) st++;
    if (st >= 3) out.push({ id: "streak-" + sm[0].result + st, score: 18 + st * 4, go: "palmares",
      text: sm[0].result === "V" ? st + " victoires d'affilée : c'est le moment de jouer des tournois." : st + " défaites d'affilée. Ça arrive : regarde contre qui, souvent mieux classés." });
    // tie-breaks d'affilée
    var tbs = []; sm.forEach(function (m) { setsOf(m.score).forEach(function (x, j) { if (isTb(x) || isSuperTb(x, j)) tbs.push(x[0] > x[1]); }); });
    var tr = 0; for (var j = 0; j < tbs.length && tbs[j] === tbs[0]; j++) tr++;
    if (tr >= 3) out.push({ id: "tb-" + tbs[0] + tr, score: 15 + tr * 4, go: "courbes", text: tbs[0] ? tr + " jeux décisifs gagnés d'affilée : dans les fins serrées, tu es là." : tr + " jeux décisifs perdus d'affilée : les fins de set se jouent aussi à la tête." });
    // forme
    var lim30 = E.iso(new Date(today().getTime() - 30 * 864e5)), rec = win.filter(function (m) { return m.date >= lim30; });
    if (rec.length >= 3 && win.length >= 8) {
      var pc = function (ms) { return Math.round(ms.filter(function (m) { return m.result === "V"; }).length * 100 / ms.length); }, dd = pc(rec) - pc(win);
      if (Math.abs(dd) >= 20) out.push({ id: "forme-" + (dd > 0 ? "up" : "down"), score: Math.abs(dd), go: "courbes",
        text: dd > 0 ? "En forme : " + pc(rec) + " % de victoires ce mois-ci, contre " + pc(win) + " % sur l'année." : "Petit creux : " + pc(rec) + " % de victoires ce mois-ci, contre " + pc(win) + " % sur l'année." });
    }
    // 1er set perdu
    var f1 = { v: 0, n: 0 }; win.forEach(function (m) { var x = setsOf(m.score); if (x.length && x[0][0] < x[0][1]) { f1.n++; if (m.result === "V") f1.v++; } });
    if (f1.n >= 4 && f1.v * 2 >= f1.n) out.push({ id: "comeback", score: 22, go: "courbes", text: "Après un premier set perdu, tu as gagné " + f1.v + " matchs sur " + f1.n + " : tu ne lâches rien." });
    // plafond
    var cap = plafondIdx(c);
    if (cap != null) {
      var nx = cap + 1, rs = win.filter(function (m) { return E.idx(m.oppRank) === nx; }), rv = rs.filter(function (m) { return m.result === "V"; }).length;
      out.push({ id: "cap-" + cap, score: 14, go: "courbes", text: "Tu bats régulièrement les " + lab(cap) + "." + (rs.length ? " La marche suivante, les " + lab(nx) + " : " + rv + " sur " + rs.length + " pour l'instant." : "") });
    }
    return out;
  }
  function insightHtml(c) {
    if (c.proj.status === "top") return "";
    var list = insights(c); if (!list.length) return "";
    var cur = S.insight || {}, td = E.iso(today());
    list.forEach(function (x) { if (x.id === cur.id && cur.since) x.score -= Math.max(0, (E.parseDate(td) - E.parseDate(cur.since)) / 864e5) * 4; });
    list.sort(function (a, b) { return b.score - a.score; });
    var x = list[0];
    if (x.id !== cur.id) { S.insight = { id: x.id, since: td }; try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} }
    var IL = window.MonteeIll;
    return '<button class="card insight" data-a="insightGo" data-go="' + x.go + '" data-tab="' + (x.tab || "") + '"><span class="ins-row"><span class="grow"><span class="eyebrow">Le truc à savoir</span><span class="ins-t">' + esc(x.text) + '</span></span></span><span class="go">Voir le détail ' + I.arrow + "</span></button>";
  }

  function toRate() {
    var d = today(); d.setDate(d.getDate() - 30); var lim = E.iso(d);
    return S.matches.filter(function (m) { return m.date && !m.wo && m.feel == null && !m.feelSkip && m.date >= lim && (m.result === "V" || m.result === "D") && !qaPending(m); }).map(function (m) { return { t: "m", o: m }; })
      .concat((S.trainings || []).filter(function (t) { return t.date && t.feel == null && !t.feelSkip && t.date >= lim; }).map(function (t) { return { t: "t", o: t }; }))
      .sort(function (a, b) { return a.o.date < b.o.date ? 1 : a.o.date > b.o.date ? -1 : 0; });
  }
  function rateCardHtml() {
    var list = toRate(); if (!list.length) return "";
    var x = list[0], o = x.o;
    var what = x.t === "m" ? (o.result === "V" ? "Victoire" : "Défaite") + " contre " + esc(o.opp || "un " + o.oppRank) + " (" + esc(o.oppRank) + ")" + (o.score ? " · " + esc(o.score) : "") : "Entraînement · " + fmtDur(playMinutes(o));
    var gear = o.racketId ? setupLabel(o) : "";
    return '<div class="card rate"><span class="eyebrow">À noter · un geste</span><span style="font-size:20px;font-weight:600;letter-spacing:-.02em">Comment tu t\'es senti ?</span>' +
      '<span class="small" style="color:inherit;opacity:.8">' + what + " · " + esc(fdate(o.date)) + (gear ? "<br>" + esc(gear) : "") + "</span>" +
      '<div class="rate-row" role="group" aria-label="Ta note de 1 à 5">' + FEEL.map(function (l, i) { return '<button data-a="rate" data-t="' + x.t + '" data-id="' + o.id + '" data-v="' + (i + 1) + '"><b>' + (i + 1) + "</b><span>" + l + "</span></button>"; }).join("") + "</div>" +
      '<div style="display:flex;justify-content:space-between;align-items:center"><button class="linkbtn" data-a="rateSkip" data-t="' + x.t + '" data-id="' + o.id + '" style="padding:0">Pas cette fois</button>' + (list.length > 1 ? '<span class="small">encore ' + (list.length - 1) + " à noter</span>" : "") + "</div></div>";
  }
  function party() {
    if (document.querySelector(".confetti")) return;
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var box = document.createElement("div"); box.className = "confetti"; box.setAttribute("aria-hidden", "true");
    var cols = ["#D4E64A", "#1F5C3F", "#B04A22", "#121212", "#F6F2EC", "#3B8C5A"], h = "";
    for (var i = 0; i < (reduce ? 0 : 90); i++) {
      var ball = i % 9 === 0, sz = ball ? 18 : 6 + Math.random() * 7;
      h += '<i class="' + (ball ? "ball" : "") + '" style="left:' + (Math.random() * 100).toFixed(1) + "%;width:" + sz.toFixed(0) + "px;height:" + (ball ? sz : sz * 1.6).toFixed(0) + "px;background:" + (ball ? "#D4E64A" : cols[i % cols.length]) +
        ";animation-duration:" + (2.2 + Math.random() * 1.8).toFixed(2) + "s;animation-delay:" + (Math.random() * 0.6).toFixed(2) + "s;--dx:" + ((Math.random() - 0.5) * 140).toFixed(0) + "px;--r:" + (Math.random() * 900 - 450).toFixed(0) + 'deg"></i>';
    }
    box.innerHTML = h + '<div class="confetti-msg">Montée !</div>';
    document.body.appendChild(box);
    if (navigator.vibrate) try { navigator.vibrate([30, 60, 30]); } catch (e) {}
    setTimeout(function () { box.remove(); }, 4300);
  }

  // Cotillons décoratifs de la carte de fête (couleurs du thème, léger mouvement)
  function feteConfetti() {
    // [x, y, couleur, rotation, forme] : regroupés à droite, autour du nouveau classement
    var P = [[188,34,"hl",25,"r"],[222,18,"terre",-30,"r"],[252,40,"on",60,"c"],[282,20,"gazon",-15,"r"],[314,38,"hl",40,"r"],
      [206,70,"on",-50,"r"],[240,62,"gazon",20,"c"],[270,78,"hl",10,"r"],[300,64,"terre",75,"r"],[318,92,"hl",-35,"c"],
      [226,104,"terre",35,"r"],[256,118,"hl",-70,"r"],[288,108,"on",30,"c"],[316,140,"gazon",20,"r"],[276,150,"hl",-40,"r"],
      [176,72,"hl",-60,"c"],[238,146,"on",50,"r"],[198,132,"gazon",-20,"r"]];
    var col = { hl: "var(--hl)", terre: "var(--terre)", gazon: "var(--chart-v)", on: "var(--on-panel)" };
    return '<svg class="fete-conf" viewBox="0 0 330 170" aria-hidden="true">' +
      '<path d="M300 150c-6-14 10-18 4-32s8-18 4-30" fill="none" stroke-width="2.6" stroke-linecap="round" style="stroke:var(--hl)"/>' +
      '<path d="M206 136c12 2 14-12 26-10s14-10 24-8" fill="none" stroke-width="2.4" stroke-linecap="round" style="stroke:var(--chart-v)"/>' +
      P.map(function (q, i) {
        var st = 'style="fill:' + col[q[2]] + ";animation-delay:" + (i * 0.21).toFixed(2) + 's"';
        return q[4] === "c" ? '<circle cx="' + q[0] + '" cy="' + q[1] + '" r="5.5" ' + st + "/>" :
          '<rect x="' + (q[0] - 9) + '" y="' + (q[1] - 3.5) + '" width="18" height="7" rx="2.5" transform="rotate(' + q[3] + " " + q[0] + " " + q[1] + ')" ' + st + "/>";
      }).join("") + "</svg>";
  }
  function feteHtml() {
    var A = S.ahead, rel = E.parseDate(A.release);
    return '<div class="card hero fete" role="status">' + feteConfetti() + '<span class="eyebrow">Sortie du ' + esc(flong(rel)) + '</span><span class="big"><span class="fete-rank">' + esc(A.rank) + "</span>Tu montes !<br>C'est dans la poche.</span>" +
      '<span style="font-size:15px;line-height:1.4">Tu passes de ' + esc(A.from) + " à " + esc(A.rank) + ". Montée t'a déjà mis à jour et calcule la suite depuis " + esc(A.rank) + ".</span></div>";
  }
  function heroHtml(c) {
    var p = c.proj, rel = "Sortie du " + flong(p.release), cur = c.cur < 0 ? 0 : c.cur;
    var nx = p.next, pct = nx.norme ? Math.min(100, Math.round(nx.total * 100 / nx.norme)) : 100;
    var gauge = '<div class="gauge" role="img" aria-label="' + nx.total + " points sur " + nx.norme + '"><span style="width:' + pct + '%"></span></div><div class="gauge-legend"><span><b>' + nx.total + "</b> pts au bilan " + nx.label + "</span><span>il en faut " + nx.norme + "</span></div>";
    var cls = "balle", title, sub = "", pre = S.ahead ? feteHtml() : "";
    if (p.status === "montee") {
      var b = p.steps.filter(function (x) { return x.calc === p.projected; })[0];
      title = "Et ensuite " + lab(p.projected) + " :<br>tu as déjà les points.";
      sub = S.ahead ? "Si rien ne change, tu monterais " + lab(p.projected) + " à la sortie d'après." : "";
      gauge = '<div class="gauge"><span style="width:100%"></span></div><div class="gauge-legend"><span><b>' + b.total + "</b> pts au bilan " + lab(p.projected) + "</span><span>norme " + b.norme + "</span></div>";
    } else if (p.status === "descente") {
      cls = "terre";
      title = "Attention : risque de descente à " + lab(p.projected) + ".";
      sub = "Bilan à " + lab(cur) + " : " + p.here.total + " / " + p.here.norme + ". Il te manque " + plural(p.here.norme - p.here.total, "point") + " pour te maintenir.";
      gauge = "";
    } else {
      var pl = pistes(c), ez = easiest(pl), one = pl.one, head = S.ahead ? "Prochaine étape, " : "Montée à ";
      if (p.gap === 0 && p.needWin) {
        title = head + nx.label + " :<br>tu as les points, il manque la victoire qui valide.";
        sub = "Pour monter, il faut au moins une victoire contre un " + nx.label + " ou mieux. Bats-en un et c'est fait.";
      } else if (ez) {
        title = head + nx.label + " :<br>" + (ez.k === 1 ? "une victoire peut suffire." : "il te manque " + plural(p.gap, "point") + ".");
        sub = ez.k === 1 ? "Contre un " + lab(Math.min(ez.top, one ? one.top : ez.top)) + " ou mieux." :
          "Ton chemin le plus accessible : " + pisteLabel(ez) + "." + (one && one.top <= (pl.maxBeaten == null ? -9 : pl.maxBeaten) ? " Ou une seule, contre un " + lab(one.top) + "." : "");
      } else {
        title = head + nx.label + " :<br>il te manque " + plural(p.gap, "point") + ".";
        sub = "Il faudrait plus de 4 victoires d'ici la sortie : vise plutôt la suivante.";
      }
    }
    return pre + '<button class="card hero ' + cls + '" data-a="goProjection">' + (window.MonteeIll ? '<span class="hero-arc">' + window.MonteeIll.arc() + "</span>" : "") + '<span class="eyebrow">' + esc(rel) + '</span><span class="big">' + title + "</span>" +
      (sub ? '<span style="font-size:15px;line-height:1.4">' + esc(sub) + "</span>" : "") + gauge +
      '<span class="go">Voir le détail ' + I.arrow + "</span></button>";
  }


  // ---------- Projection ----------
  V.projection = function () {
    var c = ctx(), p = c.proj;
    if (p.status === "top") return '<div class="screen">' + topbar("Projection") + '<p class="lead">Les joueurs numérotés sont classés au concours des meilleurs bilans : pas de simulation possible.</p></div>';
    var cur = c.cur < 0 ? 0 : c.cur, nx = p.next;
    var head = p.status === "montee" ? "Tu montes à " + lab(p.projected) : p.status === "descente" ? "Risque de descente à " + lab(p.projected) : (p.gap ? "Il te manque " + plural(p.gap, "point") + " pour " + nx.label : "Il te manque une victoire contre un " + nx.label);
    var s = '<div class="screen">' + topbar(head, "Sortie du " + flong(p.release));
    var hb = p.status === "descente" ? p.here : nx;
    s += '<span class="muted" style="font-size:15px;margin-top:-6px">' + hb.total + " au bilan " + hb.label + " · norme " + hb.norme + " · " + plural(hb.n, "victoire") + " prises en compte</span>";

    // simulateur
    var lv = levelsAround(c.cur), danger = p.status === "descente";
    if (UI.projLevel == null || lv.indexOf(UI.projLevel) < 0) UI.projLevel = danger ? cur : Math.min(cur + 1, E.MAX_CALC);
    var sim = E.simulateWin(allMatches(), c.cur, c.sex, UI.projLevel, c.opts);
    var rose = sim.after.projected > cur && sim.after.status === "montee";
    var wasUp = p.status === "montee", verdict, detail, good = rose || wasUp;
    if (danger && !rose) {
      // Menacé de descente : on regarde d'abord le maintien
      var ah = sim.after.here, g = ah.total - p.here.total, saved = sim.after.status !== "descente";
      good = saved;
      verdict = saved ? "Tu te maintiendrais à " + lab(cur) : "Toujours menacé : il manque " + plural(Math.max(0, ah.norme - ah.total), "pt") + " pour rester " + lab(cur);
      detail = g > 0 ? "+" + g + " pts au bilan " + lab(cur) + ". Bilan : " + ah.total + " / " + ah.norme + "." :
        "Cette victoire ne change rien à ton bilan " + lab(cur) + ".";
    } else {
      verdict = wasUp ? (sim.after.projected > p.projected ? "Tu monterais " + lab(sim.after.projected) : "Tu montes toujours " + lab(p.projected)) :
        rose ? "Tu monterais " + lab(sim.after.projected) : (sim.after.next.total >= sim.after.next.norme && !sim.after.next.winAtLevel ? "Pas encore : il faut battre un " + nx.label : "Pas encore : il manque " + plural(Math.max(0, sim.after.next.norme - sim.after.next.total), "pt") + " pour monter " + nx.label);
      detail = sim.gain > 0 ? "+" + sim.gain + " pts au bilan " + nx.label + (sim.pts > sim.gain ? " (+" + sim.pts + ", qui remplacent ta plus faible victoire comptée)" : "") + ". Bilan : " + sim.after.next.total + " / " + sim.after.next.norme + "." :
        (sim.pts === 0 ? "Une victoire aussi loin en dessous ne rapporte pas de points à " + nx.label + "." : "Cette victoire ne dépasse pas tes victoires déjà comptées : elle ne change rien au bilan.");
    }
    s += '<div class="card"><b style="font-size:15px">Et si tu gagnais contre un…</b><div class="chips" role="group" aria-label="Classement de l\'adversaire">' +
      lv.map(function (i) { return '<button class="chip' + (UI.projLevel === i ? " on" : "") + '" data-a="projLevel" data-v="' + i + '" aria-pressed="' + (UI.projLevel === i) + '" style="flex:1">' + lab(i) + "</button>"; }).join("") + "</div>" +
      '<div class="card ' + (good ? "balle" : "terre") + '" style="padding:14px;gap:4px"><span style="font-size:21px;font-weight:700;letter-spacing:-.02em">' + esc(verdict) + '</span><span style="font-size:14px;line-height:1.4">' + esc(detail) + "</span></div></div>";

    s += pistesHtml(c);
    var mw = null;
    if (mw !== undefined && mw !== null) s += '<div class="card menthe" style="flex-direction:row;align-items:center;gap:10px;padding:12px 14px">' + I.spark + '<span style="font-size:14px;line-height:1.4"><b>À retenir :</b> une victoire contre un ' + lab(mw) + " ou mieux suffit. Joue-la tôt pour qu'elle soit homologuée à temps.</span></div>";

    s += officialHtml(true);
    // détail du bilan
    var keep = cur > 0 && p.status !== "montee" ? bilanDetail(p.here, "Pour rester " + lab(cur) + " : ton bilan à " + lab(cur)) : "";
    var up = bilanDetail(nx, "Pour monter " + nx.label + " : ton bilan à " + nx.label);
    s += danger ? keep + up : up + keep;
    s += '<a class="btn soft small" href="#/methode">Comment c\'est calculé</a>';
    return s + '<p class="small">Calcul indicatif d\'après le barème FFT. Seul le classement officiel fait foi.</p></div>';
  };

  function pistesHtml(c) {
    var pl = pistes(c), p = c.proj;
    if (!pl.goal) return "";
    var goalTxt = pl.goal === "keep" ? "rester " + lab(pl.target) : "monter " + lab(pl.target);
    var s = '<div class="card" style="gap:12px">' + chead("courbe", "Tes pistes pour " + goalTxt, "Si tu gagnes ces matchs avant la sortie du " + fdate(p.release).replace(/\.$/, ""));
    if (pl.goal === "up" && p.gap === 0 && p.needWin) s += '<div class="card balle" style="padding:12px 14px"><span style="font-size:15px;line-height:1.4"><b>Tu as déjà les points.</b> Il manque la victoire qui valide : au moins une contre un ' + lab(pl.target) + " ou mieux.</span></div>";
    if (!pl.list.length) return s + '<span style="font-size:15px;line-height:1.4">Contre des adversaires à ta portée, même 4 victoires ne suffiraient pas d\'ici la sortie. Vise la suivante : chaque victoire compte 12 mois.</span></div>';
    if (pl.stretch) s += '<span class="small">Avec les adversaires que tu as déjà battus, ça ne passe pas : ces pistes demandent un cran de plus.</span>';
    var cap = plafondIdx(c), ez = easiest(pl);
    s += pl.list.map(function (x) {
      var badge = x === ez ? "Le plus accessible" : x.k === 1 ? "Une victoire suffit" : "Sans jouer plus fort que " + lab(x.top);
      var mine = cap != null && x.top <= cap;
      return '<div class="piste' + (x === ez ? " best" : "") + '"><span class="pbadge">' + esc(badge) + "</span><b>" + esc(pisteLabel(x)) + "</b>" +
        '<span class="small">' + (x.p >= 0.45 ? "À ta portée" : x.p >= 0.2 ? "Jouable" : "Ambitieux") + " · bilan " + esc(x.after.label) + " : " + x.after.total + " / " + x.after.norme + " pts" + (mine ? " · <b>dans tes cordes</b> : tu bats régulièrement les " + esc(lab(cap)) : "") + "</span></div>";
    }).join("");
    return s + '<span class="small">Calculé comme ton bilan : une nouvelle victoire remplace ta plus faible victoire comptée, elle ne rapporte donc que la différence. Pistes classées de la plus probable à la moins probable, d\'après tes résultats contre chaque classement' + (pl.maxBeaten != null ? ", sans adversaire plus fort que ton meilleur succès (" + lab(pl.maxBeaten) + ")" : "") + ".</span></div>";
  }
  function bilanDetail(b, title) {
    var s = '<h2>' + esc(title) + '</h2><div class="list">';
    if (!b.counted.length) s += '<div class="row"><span class="grow"><span class="s">Aucune victoire qui rapporte des points à cet échelon pour l\'instant.</span></span></div>';
    b.counted.forEach(function (w, i) {
      s += '<a class="row" href="#/match/' + w.m.id + '"><span class="grow"><span class="t">' + esc(w.m.opp || "Adversaire") + ' <span class="muted" style="font-weight:400">· ' + esc(w.m.oppRank) + '</span></span><span class="s">' + esc(fdate(w.m.date)) + "</span></span>" +
        '<span class="pts"' + (i === b.counted.length - 1 && b.counted.length >= b.n ? ' style="color:var(--terre)"' : "") + ">+" + w.pts + "</span></a>";
    });
    if (b.bonusSD) s += '<div class="row"><span class="grow">Bonus sans défaite significative</span><span class="pts">+' + b.bonusSD + "</span></div>";
    if (b.bonusCh) s += '<div class="row"><span class="grow">Bonus championnats individuels</span><span class="pts">+' + b.bonusCh + "</span></div>";
    if (b.bonusDbl) s += '<div class="row"><span class="grow">Bonus doubles<span class="s" style="display:block">' + plural(b.doubles.length, "victoire en double prise", "victoires en double prises") + " en compte</span></span><span class=\"pts\">+" + b.bonusDbl + "</span></div>";
    if (b.adjust) s += '<div class="row"><span class="grow">Ajustement d\'après Ten\'Up<span class="s" style="display:block">bonus et coefficients que Ten\'Up ne détaille pas</span></span><span class="pts">' + (b.adjust > 0 ? "+" : "") + b.adjust + "</span></div>";
    s += '<div class="row" style="font-weight:700"><span class="grow">Total</span><span class="pts">' + b.total + " / " + b.norme + "</span></div></div>";
    s += '<div class="card" style="gap:2px;padding:12px 16px">' +
      '<div class="kv"><span>Victoires (V)</span><b>' + b.V + "</b></div>" +
      '<div class="kv"><span>Défaites à ' + esc(b.label) + " (E)</span><b>" + b.E + "</b></div>" +
      '<div class="kv"><span>Défaites un échelon en dessous (I)</span><b>' + b.I + "</b></div>" +
      '<div class="kv"><span>Défaites deux échelons ou plus en dessous (G)</span><b>' + b.G + "</b></div>" +
      '<div class="kv"><span>V − E − 2I − 5G</span><b>' + b.ve + "</b></div>" +
      '<div class="kv"><span>Victoires prises en compte</span><b>' + b.n + "</b></div>" +
      (b.extra.length ? '<div class="kv"><span>Victoires hors quota</span><b>' + b.extra.length + "</b></div>" : "") +
      "</div>";
    return s;
  }

  // ---------- Palmarès ----------
  V.palmares = function () {
    var c = ctx(), pts = countedMap(c.proj.next), tab = UI.palTab;
    var from = E.iso(new Date(today().getFullYear() - 1, today().getMonth(), today().getDate()));
    var all = sortedMatches();
    var list = all.filter(function (m) {
      return tab === "all" || (tab === "v" && m.result === "V") || (tab === "d" && m.result === "D") || (tab === "todo" && !annotated(m));
    });
    var s = '<div class="screen has-tabs"><div class="topbar"><div class="title"><span class="small">' + plural(c.proj.matches ? c.proj.matches.length : 0, "match", "matchs") + ' sur 12 mois</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">Palmarès</span></div>' +
      '<button class="iconbtn" data-a="newMatch" aria-label="Ajouter un match" style="background:var(--solid);color:var(--on-solid)">' + I.plus + "</button></div>";
    s += '<div class="tabs" role="group" aria-label="Filtrer">' + [["all", "Tout"], ["v", "Victoires"], ["d", "Défaites"], ["todo", "À annoter"]].concat((S.doubles || []).length ? [["dbl", "Doubles"]] : []).map(function (t) {
      return '<button data-a="palTab" data-v="' + t[0] + '" class="' + (tab === t[0] ? "on" : "") + '" aria-pressed="' + (tab === t[0]) + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    if (tab === "dbl") return s + doublesListHtml(c) + "</div>" + tabbar("palmares");
    if (!list.length) {
      s += '<div class="card empty"><b>' + (all.length ? "Rien ici" : "Pas encore de match") + '</b><span class="small">' + (all.length ? "Aucun match pour ce filtre." : "Récupère ton palmarès Ten'Up ou ajoute un match.") + "</span>" +
        (all.length ? "" : '<a class="btn primary small" href="#/tenup">Récupérer depuis Ten\'Up</a>') + "</div>";
    }
    var curMonth = "", old = false;
    s += '<div class="stack" style="gap:8px">';
    list.forEach(function (m) {
      if (!m.date) { if (curMonth !== "nd") { curMonth = "nd"; s += "<h2>Période en cours · importés de Ten'Up</h2>"; } }
      else {
        if (!old && m.date <= from) { old = true; s += "<h2>Plus de 12 mois · ne comptent plus</h2>"; curMonth = "x"; }
        var dd = E.parseDate(m.date), mk = MOIS_L[dd.getMonth()] + " " + dd.getFullYear();
        if (!old && mk !== curMonth) { curMonth = mk; s += "<h2>" + mk.replace(/^./, function (x) { return x.toUpperCase(); }) + "</h2>"; }
      }
      var pt = pts[m.id];
      var ptsHtml = !counts(m) ? '<span class="pts muted" style="font-weight:500;font-size:13px">ne compte pas</span>' : m.result === "V" ? (old ? "" : pt != null ? '<span class="pts pos">+' + pt + "</span>" : '<span class="pts muted" style="font-weight:500;font-size:13px">hors quota</span>') : "";
      var tag = m.wo ? '<span class="tag">Forfait · non joué</span>' : annotated(m) ? '<span class="tag">' + esc(setupLabel(m)) + "</span>" : '<span class="tag todo">À annoter</span>';
      if (isManual(m)) tag = '<span class="tags"><span class="tag manual" title="Pas encore sur Ten\'Up">' + I.edit + " Saisi à la main</span>" + tag + "</span>";
      else if (m.manualOrigin && m.confirmedAt && dayDiff(m.confirmedAt, E.iso(today())) <= 14) tag = '<span class="tags"><span class="tag ok">' + I.check + " Confirmé par Ten'Up</span>" + tag + "</span>";
      s += '<a class="row" href="#/match/' + m.id + '" style="background:var(--card);border-radius:20px' + (old ? ";opacity:.65" : "") + '"><span class="vd lg ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(m.opp || "Adversaire") + ' <span class="muted" style="font-weight:400">· ' + esc(m.oppRank) + '</span></span><span class="s">' + (m.date ? esc(fdate(m.date)) : "") + (m.score ? (m.date ? " · " : "") + esc(m.score) : "") + (!m.date && !m.score ? "Ajoute date et score si tu veux" : "") + "</span>" + tag + "</span>" + ptsHtml + "</a>";
    });
    s += "</div>";
    return s + "</div>" + tabbar("palmares");
  };

  function doublesListHtml(c) {
    var nx = c.proj.next || {}, got = {};
    (nx.doubles || []).forEach(function (x) { got[x.m.id] = x; });
    var kinds = { perf: "en perf", egal: "à poids égal", contre: "en contre" };
    var list = (S.doubles || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    var s = '<div class="card" style="gap:6px"><b style="font-size:15px">Tes doubles comptent en bonus</b><span style="font-size:14px;line-height:1.45">Une victoire en double ne compte pas comme une victoire en simple : elle rapporte un petit bonus selon la force des deux paires (en perf, à poids égal ou en contre). Seules tes meilleures victoires comptent' + (nx.calc != null ? " : " + E.BAREME.double(nx.calc).max + " au maximum à " + nx.label : "") + ".</span>" +
      (nx.bonusDbl ? '<span class="pos" style="font-size:15px">+' + nx.bonusDbl + " pts au bilan " + esc(nx.label) + "</span>" : "") + "</div>";
    s += '<div class="stack" style="gap:8px">' + list.map(function (m) {
      var g = got[m.id];
      return '<div class="row" style="background:var(--card);border-radius:20px"><span class="vd lg ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(m.opp || "Adversaires") + ' <span class="muted" style="font-weight:400">· ' + esc((m.oppRanks || [m.oppRank]).join(" et ")) + '</span></span><span class="s">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + (m.partner ? " · avec " + esc(m.partner) + (m.partnerRank ? " (" + esc(m.partnerRank) + ")" : "") : "") + "</span>" +
        (g ? '<span class="tag">' + kinds[g.kind] + "</span>" : "") + "</span>" + (g ? '<span class="pts pos">+' + g.pts + "</span>" : m.result === "V" && !m.wo ? '<span class="pts muted" style="font-weight:500;font-size:13px">hors quota</span>' : "") + "</div>";
    }).join("") + "</div>";
    return s;
  }

  // ---------- Fiche match ----------
  var SURFACES = ["Terre battue", "Terre artificielle", "Résine", "Béton poreux", "Gazon synthétique", "Moquette", "Gazon naturel", "Autre"];
  var SURF_LAB = { "Autre": "Autre (gymnase, parquet…)" };
  // « Autre » est gardé sur la fiche mais exclu des comparaisons par surface (trop disparate)
  function surfKey(m) { return m.surface && m.surface !== "Autre" ? m.surface : null; }
  var SURF_OLD = { "Dur": "Résine", "Synthétique": "Gazon synthétique", "Gazon": "Gazon naturel" };
  var KINDS = [["tournoi", "Tournoi"], ["champ", "Championnat individuel"], ["equipes", "Par équipes"], ["libre", "Match libre"]];
  var WIN_SETS = ["6-0", "6-1", "6-2", "6-3", "6-4", "7-5", "7-6"], LOSE_SETS = ["0-6", "1-6", "2-6", "3-6", "4-6", "5-7", "6-7"];
  var WIN_STB = ["10-0", "10-1", "10-2", "10-3", "10-4", "10-5", "10-6", "10-7", "10-8"];
  // Deux colonnes : à gauche ce que tu as gagné (vert), à droite ce que tu as perdu (orange), lignes en miroir
  function pickCols(i, st, stb) {
    var cur = st ? st.join("-") : "", ext = UI.stbExt || 11;
    var col = function (side, list, title) {
      var h = '<div class="sc-col ' + side + '"><span class="sc-head">' + (side === "w" ? I.check : I.cross) + title + "</span>";
      list.forEach(function (v) { h += '<button class="sc-chip' + (cur === v ? " on" : "") + '" data-a="scorePick" data-i="' + i + '" data-v="' + v + '" aria-label="' + (side === "w" ? "Gagné " : "Perdu ") + v + '">' + v + "</button>"; });
      if (stb) {
        var v = side === "w" ? ext + "-" + (ext - 2) : (ext - 2) + "-" + ext;
        h += '<div class="sc-ext"><button data-a="stbExt" data-v="-1" aria-label="Moins">−</button><button class="sc-chip' + (cur === v ? " on" : "") + '" data-a="scorePick" data-i="' + i + '" data-v="' + v + '">' + v + '</button><button data-a="stbExt" data-v="1" aria-label="Plus">+</button></div>';
      }
      return h + "</div>";
    };
    var win = stb ? WIN_STB : WIN_SETS, lose = stb ? WIN_STB.map(function (v) { return v.split("-").reverse().join("-"); }) : LOSE_SETS;
    return '<div class="sc-cols">' + col("w", win, stb ? "Tu gagnes le super TB" : "Tu gagnes le set") + col("l", lose, stb ? "Tu perds le super TB" : "Tu perds le set") + "</div>" +
      (stb ? '<span class="small">Au-delà de 10-8, ça se gagne avec 2 points d\'écart : règle la dernière ligne avec − et +.</span>' : "");
  }
  function scoreHtml(m) {
    if (UI.scoreManual) return '<div class="field"><label for="m-score">Score</label><input id="m-score" type="text" data-d="score" value="' + esc(m.score) + '" placeholder="6-4 3-6 7-5 ab."><button class="linkbtn" data-a="scoreManual" style="align-self:flex-start;padding:0">Revenir à la saisie rapide</button></div>';
    var sets = m.sets || [], w = 0, l = 0, s = '<div class="field"><span class="lbl">Score <span class="small">· de ton point de vue</span></span><div class="sets">';
    for (var i = 0; i < 3; i++) {
      var st = sets[i];
      if (!st && (w === 2 || l === 2 || i > sets.length)) break;
      var editing = !st || UI.scoreEdit === i;
      if (!editing) {
        s += '<button class="setrow" data-a="scoreEdit" data-v="' + i + '"><span class="small">' + (isSuperTb(st, i) ? "Super tie-break" : "Set " + (i + 1)) + '</span><b class="' + (st[0] > st[1] ? "w" : "l") + '">' + st[0] + "-" + st[1] + '</b><span class="small">modifier</span></button>';
      } else {
        var stb = i === 2 && UI.stb;
        s += '<div class="setpick"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b style="font-size:15px">' + (stb ? "Super tie-break" : "Set " + (i + 1)) + "</b>" +
          (i === 2 ? '<span class="seg mini"><button data-a="scoreStb" data-v="0" class="' + (stb ? "" : "on") + '">Set</button><button data-a="scoreStb" data-v="1" class="' + (stb ? "on" : "") + '">Super TB</button></span>' : "") + "</div>" +
          pickCols(i, st, stb) + "</div>";
      }
      if (!st) break;
      if (st[0] > st[1]) w++; else l++;
    }
    s += "</div>";
    s += '<div style="display:flex;gap:16px;flex-wrap:wrap">' + (sets.length ? '<button class="linkbtn" data-a="scoreClear" style="padding:0">Effacer le score</button>' : "") + '<button class="linkbtn" data-a="scoreManual" style="padding:0">Abandon ou score spécial</button></div></div>';
    return s;
  }
  function applySets(m, sets) {
    var out = [], w = 0, l = 0;
    sets.forEach(function (st) { if (!st || w === 2 || l === 2) return; out.push(st); if (st[0] > st[1]) w++; else l++; });
    m.sets = out; m.score = out.map(function (st) { return st[0] + "-" + st[1]; }).join(" ");
    if (w === 2) m.result = "V"; else if (l === 2) m.result = "D";
    UI.stb = out[2] ? isSuperTb(out[2], 2) : UI.stb;
  }
  function durationHtml(m, isMatch) {
    var est = isMatch ? estMinutes(m) : 60, v = m.minutes || est;
    return '<div class="field inline"><span class="lbl">' + (isMatch ? "Durée" : "Ajuster") + (isMatch ? '<span class="small" style="display:block;font-weight:400">' + (m.minutes ? "corrigée par toi · " + '<button class="linkbtn" data-a="dminReset" style="padding:0;min-height:0;font-size:inherit">estimer</button>' : "estimée d'après le score") + "</span>" : "") + '</span><span class="stepper"><button data-a="dmin" data-v="-15" aria-label="Moins 15 minutes">−</button><span>' + fmtDur(v) + '</span><button data-a="dmin" data-v="15" aria-label="Plus 15 minutes">+</button></span></div>';
  }
  function feelHtml(m, label) {
    return '<div class="field"><span class="lbl">' + esc(label) + '</span><div class="rate-row soft">' + FEEL.map(function (l, i) { return '<button data-a="dset" data-k="feel" data-v="' + (i + 1) + '" class="' + (m.feel === i + 1 ? "on" : "") + '" aria-pressed="' + (m.feel === i + 1) + '"><b>' + (i + 1) + "</b><span>" + l + "</span></button>"; }).join("") + "</div></div>";
  }
  function gearHtml(m) {
    var r = racket(m.racketId), IL = window.MonteeIll;
    if (!UI.gearOpen) {
      if (!r) return '<button class="gear-card" data-a="gearOpen"><span class="g-ill">' + (IL ? IL.racket("noir") : "") + '</span><span class="grow"><b>' + (bag().length ? "Choisir ta raquette" : "Ajoute ta raquette") + '</b><span class="small">Pour suivre tes cordages et savoir avec quoi tu gagnes</span></span><span class="g-go">' + I.next + "</span></button>";
      var st = racketStatus(r);
      return '<div class="gear-card"><span class="g-ill">' + (IL ? IL.racket(r.color || "noir", r.accent, r.pattern) : "") + '</span><span class="grow"><b>' + esc(r.name) + (r.main ? ' <span class="tag">principale</span>' : "") + "</b>" +
        '<span class="small">' + esc([m.string, fmtTension(m)].filter(Boolean).join(" · ") || "Cordage à renseigner") + (st.known ? " · " + (m.newString ? "cordage neuf" : fmtHours(st.min) + " sur ce cordage") : "") + "</span></span>" +
        '<button class="linkbtn g-change" data-a="gearOpen">Changer</button></div>';
    }
    return '<div class="form"><div class="gear-list">' + bag().map(function (r) {
        var st = racketStatus(r), on = m.racketId === r.id;
        return '<button class="gear-opt' + (on ? " on" : "") + '" data-a="dracket" data-v="' + r.id + '" aria-pressed="' + on + '"><span class="g-ill">' + (IL ? IL.racket(r.color || "noir", r.accent, r.pattern) : "") + '</span><span class="grow"><b>' + esc(r.name) + '</b><span class="small">' + esc([r.string, fmtTension(r)].filter(Boolean).join(" · ")) + (st.known ? " · " + fmtHours(st.min) + " sur son cordage" : "") + '</span></span><span class="g-check">' + (on ? I.check : "") + "</span></button>";
      }).join("") + '<button class="gear-opt add" data-a="newRacketFromMatch"><span class="g-ill">' + I.plus + '</span><span class="grow"><b>Ajouter une raquette</b></span></button></div>' +
      (m.racketId ? '<div class="field"><label for="m-str">Cordage</label><input id="m-str" type="text" data-d="string" value="' + esc(m.string) + '" placeholder="Ex. : RPM Blast 1,25"></div>' +
        tensionHtml(m, "match") +
        '<label class="field inline check" style="margin:0"><span><span style="display:block">Cordage neuf</span><span class="small">Coche si tu as recordé juste avant</span></span><input type="checkbox" role="switch" data-d="newString"' + (m.newString ? " checked" : "") + "></label>" : "") + '<button class="btn soft small" data-a="gearOpen">Terminé</button></div>';
  }

  // ---------- Entraînement ----------
  V.entrainement = function (id) {
    var isNew = !id || id === "new", key = "t:" + (id || "new");
    if (!UI.draft || UI.draft._for !== key) {
      var base = isNew ? { id: uid(), date: E.iso(today()), minutes: 60, racketId: "", string: "", tension: null, tensionCross: null, newString: false, feel: null, note: "" } :
        JSON.parse(JSON.stringify((S.trainings || []).filter(function (t) { return t.id === id; })[0] || {}));
      if (!base.id) { go("materiel"); return ""; }
      if (isNew) {
        var main = racketFor("train");
        if (main) { base.racketId = main.id; base.string = main.string || ""; base.tension = main.tension || null; base.tensionCross = main.tensionCross != null ? main.tensionCross : null; }
      }
      base._for = key; UI.draft = base; UI.gearOpen = false;
    }
    var t = UI.draft;
    var s = '<div class="screen">' + topbar(isNew ? "Nouvel entraînement" : "Entraînement", isNew ? "" : fdate(t.date), isNew ? "" : '<button class="iconbtn" data-a="delTraining" aria-label="Supprimer cet entraînement">' + I.trash + "</button>");
    s += '<div class="form">' +
      '<div class="field inline"><label for="t-date">Date</label><input id="t-date" type="date" data-d="date" value="' + esc(t.date) + '" max="' + E.iso(today()) + '"></div>' +
      '<div class="field"><span class="lbl">Durée</span><div class="chips">' + [30, 45, 60, 90, 120].map(function (n) { return '<button class="chip' + (t.minutes === n ? " on" : "") + '" data-a="dset" data-k="minutes" data-v="' + n + '">' + fmtDur(n) + "</button>"; }).join("") + "</div></div>" +
      durationHtml(t, false) +
      '<div class="field"><span class="lbl">Type</span><div class="chips">' + TLABELS.map(function (l) { return '<button class="chip' + (t.label === l ? " on" : "") + '" data-a="dset" data-k="label" data-v="' + l + '">' + l + "</button>"; }).join("") + "</div></div>" + "</div>";
    s += '<h2>Ta raquette</h2>' + gearHtml(t);
    s += '<h2>Ton ressenti</h2><div class="form">' + feelHtml(t, "Comment tu t'es senti avec ce matériel ?") +
      '<div class="field"><label for="t-note">Ce que tu as travaillé</label><input id="t-note" type="text" data-d="note" value="' + esc(t.note) + '" placeholder="Ex. : service, retours, match à thème"></div></div>';
    s += '<p class="small">La durée compte dans les heures de jeu de ton cordage.</p>';
    s += saveBar("saveTraining", t, isNew) + "</div>";
    return s;
  };

  V.match = function (id) {
    var isNew = !id || id === "new";
    if (!UI.draft || UI.draft._for !== (id || "new")) {
      var base = isNew ? { id: uid(), date: E.iso(today()), opp: "", oppRank: "", result: "V", wo: false, score: "", kind: "tournoi", surface: "", indoor: null, racketId: "", string: "", tension: null, tensionCross: null, feel: null, note: "", source: "manuel" } :
        JSON.parse(JSON.stringify(S.matches.filter(function (m) { return m.id === id; })[0] || {}));
      if (!base.id) { go("palmares"); return ""; }
      // Match neuf ou pas encore annoté : on présélectionne la raquette principale
      if (isNew || (!base.racketId && !base.wo)) {
        var main = racketFor("match");
        if (main) { base.racketId = main.id; base.string = main.string || ""; base.tension = main.tension || null; base.tensionCross = main.tensionCross != null ? main.tensionCross : null; base._auto = !isNew; }
      }
      base._for = id || "new"; UI.draft = base; UI.gearOpen = false;
      base.sets = setsOf(base.score);
      UI.scoreEdit = null; UI.stb = base.sets[2] ? isSuperTb(base.sets[2], 2) : false;
      UI.stbExt = base.sets[2] && Math.max(base.sets[2][0], base.sets[2][1]) > 10 ? Math.max(base.sets[2][0], base.sets[2][1]) : 11;
      UI.scoreManual = !!(base.score && (!base.sets.length || /ab|abandon|disq/i.test(base.score)));
    }
    var m = UI.draft;
    var rankOpts = '<option value="">Classement…</option><option value="NC"' + (m.oppRank === "NC" ? " selected" : "") + ">NC</option>" +
      E.ECHELONS.slice(0, 22).map(function (e) { return '<option' + (m.oppRank === e ? " selected" : "") + ">" + e + "</option>"; }).join("") + '<option value="N°"' + (/^N°/.test(m.oppRank) ? " selected" : "") + ">Numéroté</option>";
    var c = ctx(), pts = countedMap(c.proj.next)[m.id];
    var s = '<div class="screen">' + topbar(isNew ? "Nouveau match" : "", isNew ? "" : (annotated(m) ? "Fiche du match" : "À annoter"),
      isNew ? "" : '<button class="iconbtn" data-a="delMatch" aria-label="Supprimer ce match">' + I.trash + "</button>");
    if (!isNew) {
      s += '<div class="card ink" style="flex-direction:row;justify-content:space-between;align-items:center"><span style="display:flex;flex-direction:column;gap:3px"><span style="font-size:13px;color:var(--sub)">' + esc(fdate(m.date)) + " · " + esc((KINDS.filter(function (k) { return k[0] === m.kind; })[0] || ["", "Match"])[1]) + (m.comp ? '</span><span style="font-size:12px;color:var(--sub);line-height:1.3">' + esc(m.comp) : "") + '</span><span style="font-size:20px;font-weight:600">' + esc(m.opp || "Adversaire") + " · " + esc(m.oppRank) + '</span><span style="color:#E6E0D8">' + esc(m.score || "") + "</span></span>" +
        '<span style="display:flex;flex-direction:column;align-items:flex-end;gap:4px"><span style="height:32px;padding:0 12px;border-radius:16px;background:' + (m.result === "V" ? "var(--balle)" : "var(--terre-soft)") + ";color:" + (m.result === "V" ? "var(--on-balle)" : "var(--terre-dark)") + ';font-weight:700;display:flex;align-items:center">' + (m.result === "V" ? "Victoire" : "Défaite") + (m.wo ? " (WO)" : "") + "</span>" +
        (m.result === "V" ? '<span style="color:var(--hl);font-weight:600;font-size:14px">' + (pts != null ? "+" + pts + " pts" : "hors quota") + "</span>" : "") + "</span></div>";
    }
    if (!isNew && isManual(m)) s += '<div class="card" style="flex-direction:row;gap:10px;align-items:flex-start;padding:12px 14px">' + I.edit + '<span style="font-size:14px;line-height:1.45"><b>Saisi à la main.</b> Quand Ten\'Up l\'aura homologué, la synchro le reconnaîtra : la date, l\'adversaire et le score officiels remplaceront ta saisie, tes annotations restent. Pas de doublon.</span></div>';
    else if (!isNew && m.manualOrigin && m.confirmedAt) s += '<div class="card menthe" style="flex-direction:row;gap:10px;align-items:flex-start;padding:12px 14px">' + I.check + '<span style="font-size:14px;line-height:1.45"><b>Confirmé par Ten\'Up le ' + esc(fdate(m.confirmedAt).replace(/\.$/, "")) + '.</b> Tu l\'avais saisi à la main : les infos officielles ont remplacé ta saisie, tes annotations sont gardées.</span></div>';
    s += '<h2>Le match</h2><div class="form">' +
      '<div class="field"><span class="lbl">Résultat</span><div class="seg"><button data-a="dset" data-k="result" data-v="V" class="' + (m.result === "V" ? "on" : "") + '">Victoire</button><button data-a="dset" data-k="result" data-v="D" class="' + (m.result === "D" ? "on" : "") + '">Défaite</button></div>' +
      '<label class="check"><input type="checkbox" data-d="wo"' + (m.wo ? " checked" : "") + "> Par forfait (WO)</label></div>" +
      '<div class="field"><label for="m-opp">Adversaire</label><input id="m-opp" type="text" data-d="opp" value="' + esc(m.opp) + '" placeholder="Nom de l\'adversaire" autocomplete="off">' + revHint(m.opp, m.id) + "</div>" +
      '<div class="field inline"><label for="m-rank">Son classement le jour du match</label><select id="m-rank" data-d="oppRank">' + rankOpts + "</select></div>" +
      '<div class="field inline"><label for="m-date">Date</label><input id="m-date" type="date" data-d="date" value="' + esc(m.date) + '" max="' + E.iso(today()) + '"></div>' +
      (m.wo ? "" : scoreHtml(m)) +
      '<div class="field"><span class="lbl">Type de match</span><div class="chips">' + KINDS.map(function (k) { return '<button class="chip' + (m.kind === k[0] ? " on" : "") + '" data-a="dset" data-k="kind" data-v="' + k[0] + '">' + k[1] + "</button>"; }).join("") + "</div>" +
        (m.kind === "libre" && isManual(m) ? '<span class="small">Un match libre saisi à la main (amical) ne compte pas pour le classement. S\'il est homologué sur Ten\'Up, la synchro le fera compter.</span>' : "") + "</div>" +
      "</div>";
    s += '<h2>Les conditions</h2><div class="form">' +
      '<div class="field"><span class="lbl">Surface</span><div class="chips">' + SURFACES.map(function (x) { return '<button class="chip' + (m.surface === x ? " on" : "") + '" data-a="dset" data-k="surface" data-v="' + x + '">' + (SURF_LAB[x] || x) + "</button>"; }).join("") + "</div></div>" +
      '<div class="field"><span class="lbl">Où</span><div class="seg"><button data-a="dset" data-k="indoor" data-v="1" class="' + (m.indoor === true ? "on" : "") + '">Intérieur</button><button data-a="dset" data-k="indoor" data-v="0" class="' + (m.indoor === false ? "on" : "") + '">Extérieur</button></div></div>' +
      (m.wo ? "" : durationHtml(m, true)) +
      feelHtml(m, "Comment tu t'es senti ?") +
      '<div class="field"><label for="m-note">Une note pour la revanche</label><input id="m-note" type="text" data-d="note" value="' + esc(m.note) + '" placeholder="Ex. : gaucher, revers slicé très bas"><span class="small">Elle ressortira la prochaine fois que tu joueras ' + (m.opp ? esc(m.opp.split(" ")[0]) : "ce joueur") + ".</span></div>" +
      "</div>";
    s += '<h2>Ta raquette</h2>' + gearHtml(m);
    s += saveBar("saveMatch", m, isNew) + "</div>";
    return s;
  };

  // ---------- Courbes ----------
  V.courbes = function () {
    var c = ctx(), cur = c.cur < 0 ? 0 : c.cur, target = Math.min(cur + 1, E.MAX_CALC);
    var s = '<div class="screen has-tabs"><div class="topbar"><div class="title"><span class="small">12 derniers mois</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">Courbes</span></div></div>';
    if (!S.matches.length) return s + '<div class="card empty">' + (window.MonteeIll ? window.MonteeIll.vide() : "") + '<b>Pas encore de données</b><span class="small">Ajoute des matchs pour voir tes courbes.</span></div></div>' + tabbar("courbes");
    var B = {};
    if (c.proj.status !== "top") {
      var h = E.history(allMatches(), target, c.sex, cur, today(), c.opts.extra);
      B.bilan = '<div class="card chart">' + chead("courbe", "Ton bilan à " + lab(target), h[h.length - 1].total + " pts à la prochaine sortie") + lineChart(h) +
        '<span class="small">Pointillés : la norme pour être ' + lab(target) + " (" + h[0].norme + " pts). Dernier point : projection pour la prochaine sortie.</span></div>";
      UI._hist = { h: h, target: target, cur: cur };
    }
    // contre qui
    var win = c.proj.matches || [], byRank = {};
    win.forEach(function (m) {
      var o = E.idx(m.oppRank); if (o == null || m.wo) return;
      byRank[o] = byRank[o] || { o: o, v: 0, d: 0 };
      if (m.result === "V") byRank[o].v++; else if (m.result === "D") byRank[o].d++;
    });
    if (!byRank[c.cur] && c.cur >= 0) byRank[c.cur] = { o: c.cur, v: 0, d: 0 };
    var rows = Object.keys(byRank).map(function (k) { return byRank[k]; }).sort(function (a, b) { return b.o - a.o; });
    var mx = Math.max.apply(null, rows.map(function (r) { return Math.max(r.v, r.d); }).concat([1]));
    B.forme = formeHtml(win);
    B.defend = defendHtml(c);
    B.plafond = '<div class="card">' + chead("plafond", "Ton plafond", "Par classement de l'adversaire") + ceilingMsg(rows, c.cur) +
      '<div class="div-row small"><span style="text-align:right">Défaites</span><span></span><span>Victoires</span></div>' +
      rows.map(function (r) {
        var me = r.o === c.cur;
        return '<button class="div-row' + (me ? " me" : "") + '" data-a="sheet" data-k="plafond" data-v="' + r.o + '" aria-label="Contre les ' + lab(r.o) + " : " + r.v + " victoires, " + r.d + ' défaites, voir les matchs"><div class="l"><span class="n">' + (r.d || "") + '</span><span class="bar d" style="width:' + (r.d / mx * 100) + '%"></span></div><span class="lab">' + lab(r.o) + (me ? '<span class="you">toi</span>' : "") + '</span><div class="r"><span class="bar v" style="width:' + (r.v / mx * 100) + '%"></span><span class="n">' + (r.v || "") + "</span></div></button>";
      }).join("") + '<span class="small">Mieux classés en haut, moins bien classés en bas. Touche un classement pour voir les matchs.</span></div>';
    B.mental = mentalHtml(win);
    B.h2h = h2hHtml();
    B.records = recordsHtml(win, c.cur);
    B.where = whereHtml(win);
    B.temps = playTimeHtml();
    s += layout("courbes", B);
    return s + "</div>" + tabbar("courbes");
  };
  // En-tête de carte : titre, sous-titre, petite illustration
  function chead(ill, title, sub) {
    var I2 = window.MonteeIll || {};
    return '<div class="chead"><div class="ct"><b>' + esc(title) + "</b>" + (sub ? '<span class="small">' + esc(sub) + "</span>" : "") + "</div>" +
      "</div>";
  }
  var WHERE_TABS = [["kind", "Compétition"], ["surface", "Surface"], ["lieu", "Intérieur / ext."]];
  function whereTabs() {
    return '<div class="chips" role="group" aria-label="Regrouper par">' + WHERE_TABS.map(function (t) {
      var on = (UI.whereTab || "kind") === t[0];
      return '<button class="chip' + (on ? " on" : "") + '" data-a="whereTab" data-v="' + t[0] + '" aria-pressed="' + on + '">' + t[1] + "</button>";
    }).join("") + "</div>";
  }
  // ---------- Détails (feuille qui monte du bas) ----------
  function playedWin() { var c = ctx(); return (c.proj.matches || []).filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); }); }
  function byDateDesc(a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; }
  function mrowHtml(m, right, note) {
    return '<a class="row dl" href="#/match/' + m.id + '"><span class="vd ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(m.opp || "Adversaire") + ' <span class="muted" style="font-weight:400">· ' + esc(m.oppRank || "") + '</span></span><span class="s">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + (note ? " · " + note : "") + "</span></span>" + (right != null ? '<span class="pts">' + right + "</span>" : "") + "</a>";
  }
  function listHtml(ms, rightFn, noteFn) {
    if (!ms.length) return '<span class="small">Aucun match.</span>';
    return '<div class="list">' + ms.map(function (m) { return mrowHtml(m, rightFn ? rightFn(m) : null, noteFn ? noteFn(m) : ""); }).join("") + "</div>";
  }
  var DET = {
    plafond: function (v) {
      var o = +v, ms = playedWin().filter(function (m) { return E.idx(m.oppRank) === o; }).sort(byDateDesc), w = ms.filter(function (m) { return m.result === "V"; }).length;
      return { title: "Contre les " + lab(o) + " · " + w + " V – " + (ms.length - w) + " D", sub: "Tes matchs des 12 derniers mois contre des joueurs classés " + lab(o) + " le jour du match.", body: listHtml(ms, null, function (m) { return m.comp ? esc(m.comp) : ""; }) };
    },
    bilan: function (v) {
      var H = UI._hist; if (!H) return null;
      var c = ctx(), p = H.h[+v]; if (!p) return null;
      var b = p.projected ? E.bilanAt(E.windowMatches(allMatches(), p.date, today()), H.target, c.sex, H.cur, c.opts.extra) : E.bilanAt(E.windowMatches(allMatches(), p.date, p.date, false), H.target, c.sex, H.cur);
      var body = '<div class="kvs"><div class="kv"><span>Victoires prises en compte</span><b>' + b.counted.length + " sur " + b.n + " possibles</b></div>" +
        (b.bonusSD ? '<div class="kv"><span>Bonus sans défaite significative</span><b>+' + b.bonusSD + "</b></div>" : "") + (b.bonusCh ? '<div class="kv"><span>Bonus championnats</span><b>+' + b.bonusCh + "</b></div>" : "") +
        (b.bonusDbl ? '<div class="kv"><span>Bonus doubles</span><b>+' + b.bonusDbl + "</b></div>" : "") + (b.adjust ? '<div class="kv"><span>Ajustement d\'après Ten\'Up</span><b>' + (b.adjust > 0 ? "+" : "") + b.adjust + "</b></div>" : "") +
        '<div class="kv" style="font-weight:700"><span>Total</span><b>' + b.total + " / " + b.norme + "</b></div></div>";
      body += "<h3>Les victoires qui comptent</h3>" + listHtml(b.counted.map(function (w) { return w.m; }), function (m) { var w = b.counted.filter(function (x) { return x.m === m; })[0]; return "+" + w.pts; });
      if (b.extra && b.extra.length) body += "<h3>Hors quota</h3><span class=\"small\">Elles ne rapportent rien à cette sortie, mais prendront le relais si une victoire comptée sort.</span>" + listHtml(b.extra.map(function (w) { return w.m; }), function () { return "0"; });
      return { title: p.projected ? "Prochaine sortie, en projection" : "Sortie du " + fdate(p.date).replace(/\.$/, ""), sub: "Ton bilan à " + lab(H.target) + " : les 12 mois avant cette date", body: body };
    },
    defend: function (v) {
      var D = UI._defend; if (!D) return null;
      var i = +v, x = D.pts[i]; if (!x) return null;
      var body = '<div class="kvs"><div class="kv"><span>Bilan à ' + esc(D.label) + '</span><b>' + x.total + " / " + x.norme + "</b></div>" + (i ? '<div class="kv"><span>Par rapport au mois d\'avant</span><b>' + (x.total - D.pts[i - 1].total >= 0 ? "+" : "") + (x.total - D.pts[i - 1].total) + " pts</b></div>" : "") + "</div>";
      if (!i) body += '<span class="small">C\'est ton bilan pour la prochaine sortie, avec tes matchs actuels.</span>';
      else {
        var prev = D.pts[i - 1].b.counted.map(function (w) { return w.m.id; }), now = x.b.counted.map(function (w) { return w.m.id; });
        var gone = D.pts[i - 1].b.counted.filter(function (w) { return now.indexOf(w.m.id) < 0; });
        var cameIn = x.b.counted.filter(function (w) { return prev.indexOf(w.m.id) < 0; });
        body += "<h3>Ce qui sort de tes 12 mois</h3>" + (gone.length ? listHtml(gone.map(function (w) { return w.m; }), function (m) { return "−" + gone.filter(function (w) { return w.m === m; })[0].pts; }) : '<span class="small">Aucune victoire comptée ne sort ce mois-ci.</span>');
        if (cameIn.length) body += "<h3>Ce qui prend le relais</h3><span class=\"small\">Des victoires hors quota remontent dans les victoires comptées.</span>" + listHtml(cameIn.map(function (w) { return w.m; }), function (m) { return "+" + cameIn.filter(function (w) { return w.m === m; })[0].pts; });
      }
      body += '<span class="small">Calcul sans aucun nouveau match : chaque victoire gagnée d\'ici là compte en plus.</span>';
      return { title: "Sortie de " + MOIS_L[x.rel.getMonth()] + " " + x.rel.getFullYear(), sub: "Si tu ne rejoues pas d'ici là", body: body };
    },
    mental: function (k) {
      var ms = playedWin().filter(function (m) { return setsOf(m.score).length; }).sort(byDateDesc);
      var first = function (m) { var t = setsOf(m.score)[0]; return t[0] > t[1] ? 1 : t[0] < t[1] ? -1 : 0; };
      var D = {
        f1w: ["1er set gagné", "Les matchs où tu as gagné le premier set. « Conclus » = tu as gagné le match derrière.", ms.filter(function (m) { return first(m) > 0; })],
        f1l: ["1er set perdu", "Les matchs où tu as perdu le premier set. « Renversés » = tu as quand même gagné le match.", ms.filter(function (m) { return first(m) < 0; })],
        three: ["Matchs en 3 sets", "Les matchs allés au troisième set (super tie-break compris).", ms.filter(function (m) { return setsOf(m.score).length === 3; })],
        tb: ["Tie-breaks (7-6)", "Les matchs avec au moins un set à 7-6 ou 6-7.", ms.filter(function (m) { return setsOf(m.score).some(isTb); })],
        stb: ["Super tie-breaks", "Les matchs décidés au super tie-break (10 points) au troisième set.", ms.filter(function (m) { var t = setsOf(m.score); return t.length === 3 && isSuperTb(t[2], 2); })],
        sets: ["Sets", "Tous les sets de tes matchs sur 12 mois, gagnés et perdus.", ms],
        games: ["Jeux", "Tous les jeux joués sur 12 mois (hors super tie-breaks). Plus de 50 % de jeux gagnés, c'est que tu domines tes matchs, même ceux que tu perds.", ms]
      }[k];
      if (!D) return null;
      var note = function (m) {
        var t = setsOf(m.score), w = 0, l = 0, gw = 0, gl = 0;
        t.forEach(function (x, i) { if (x[0] > x[1]) w++; else l++; if (!isSuperTb(x, i)) { gw += x[0]; gl += x[1]; } });
        if (k === "sets") return w + " set" + (w > 1 ? "s" : "") + " gagné" + (w > 1 ? "s" : "") + " sur " + (w + l);
        if (k === "games") return gw + " jeux sur " + (gw + gl);
        if (k === "f1l") return m.result === "V" ? "<b class=\"pos\">renversé</b>" : "";
        if (k === "f1w") return m.result === "V" ? "<b class=\"pos\">conclu</b>" : "<b class=\"neg\">laissé filer</b>";
        if (k === "tb") {
          var tw = t.filter(function (x) { return isTb(x) && x[0] > x[1]; }).length, tn = t.filter(isTb).length;
          return tn > 1 ? "<b>" + tw + " tie-break" + (tw > 1 ? "s" : "") + " gagné" + (tw > 1 ? "s" : "") + " sur " + tn + "</b>" : tw ? "<b class=\"pos\">tie-break gagné</b>" : "<b class=\"neg\">tie-break perdu</b>";
        }
        if (k === "stb") { var sx = t[2]; return sx && sx[0] > sx[1] ? "<b class=\"pos\">gagné</b>" : "<b class=\"neg\">perdu</b>"; }
        return "";
      };
      var sub = D[1];
      if (k === "tb") {
        var all = [].concat.apply([], D[2].map(function (m) { return setsOf(m.score).filter(isTb); })), won = all.filter(function (x) { return x[0] > x[1]; }).length;
        sub += " Un match peut en compter plusieurs : " + won + " gagné" + (won > 1 ? "s" : "") + " sur " + all.length + " tie-breaks, répartis sur " + plural(D[2].length, "match", "matchs") + ".";
      }
      return { title: D[0], sub: sub, body: listHtml(D[2], null, note) + '<span class="small">Scores lus de ton point de vue (ta manche d\'abord). Matchs des 12 derniers mois, forfaits exclus.</span>' };
    },
    record: function (k) {
      var c = ctx(), cur = c.cur, ms = playedWin().sort(byDateDesc), out;
      if (k === "perfs") out = ["Tes perfs", "Les victoires contre des joueurs mieux classés que toi aujourd'hui.", ms.filter(function (m) { var o = E.idx(m.oppRank); return m.result === "V" && o != null && o > cur; })];
      else if (k === "matchs") out = ["Tes matchs sur 12 mois", "Tous les matchs joués, forfaits exclus.", ms];
      else if (k === "bagel") out = ["Tes 6-0", "Les matchs où tu as gagné au moins un set 6-0.", ms.filter(function (m) { return setsOf(m.score).some(function (t) { return t[0] === 6 && t[1] === 0; }); })];
      else if (k === "streak" || k === "run") {
        var asc = ms.slice().reverse(), best = [], run = [];
        if (k === "run") { asc.forEach(function (m) { if (m.result === "V") { run.push(m); if (run.length > best.length) best = run.slice(); } else run = []; }); out = ["Ta meilleure série", "Tes victoires d'affilée les plus longues sur 12 mois.", best.reverse()]; }
        else { var all = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }), st = []; for (var i = 0; i < all.length && all[i].result === all[0].result; i++) st.push(all[i]); out = ["Ta série en cours", "Tes derniers matchs, tant que le résultat ne change pas.", st]; }
      } else if (k === "month") {
        var wm = {}; ms.forEach(function (m) { if (m.result === "V" && m.date) { var kk = m.date.slice(0, 7); wm[kk] = (wm[kk] || 0) + 1; } });
        var bm = Object.keys(wm).sort(function (a, b) { return wm[b] - wm[a] || (a < b ? 1 : -1); })[0];
        out = [bm ? "Meilleur mois : " + MOIS_L[+bm.slice(5) - 1] + " " + bm.slice(0, 4) : "Meilleur mois", "Le mois où tu as gagné le plus de matchs.", bm ? ms.filter(function (m) { return m.date && m.date.slice(0, 7) === bm; }) : []];
      }
      if (!out) return null;
      return { title: out[0], sub: out[1], body: listHtml(out[2]) };
    },
    where: function (label) {
      var tab = UI.whereTab || "kind", ms = playedWin().sort(byDateDesc);
      var key = { kind: function (m) { return (KINDS.filter(function (k) { return k[0] === (m.kind || "tournoi"); })[0] || ["", "Tournoi"])[1]; }, surface: surfKey, lieu: function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; } }[tab];
      var list = ms.filter(function (m) { return key(m) === label; }), v = list.filter(function (m) { return m.result === "V"; }).length;
      var how = tab === "kind" ? "Le type vient du nom de la compétition sur Ten\'Up (tournoi, championnat individuel, par équipes…). Si un match est mal rangé, corrige son type dans sa fiche." :
        "D\'après ce que tu as indiqué en annotant tes matchs.";
      return { title: label + " · " + v + " sur " + list.length, sub: how, body: listHtml(list, null, function (m) { return tab === "kind" && m.comp ? esc(m.comp) : ""; }) };
    },
    temps: function (mk) {
      var y = +mk.slice(0, 4), mo = +mk.slice(5) - 1;
      var ms = S.matches.filter(function (m) { return m.date && !m.wo && m.date.slice(0, 7) === mk; }).sort(byDateDesc);
      var tr = (S.trainings || []).filter(function (t) { return t.date && t.date.slice(0, 7) === mk; }).sort(byDateDesc);
      var tm = ms.reduce(function (a, m) { return a + playMinutes(m); }, 0), tt = tr.reduce(function (a, t) { return a + playMinutes(t); }, 0);
      var body = '<div class="kvs"><div class="kv"><span>Matchs</span><b>' + plural(ms.length, "match", "matchs") + " · ≈ " + fmtHours(tm) + '</b></div><div class="kv"><span>Entraînements</span><b>' + plural(tr.length, "séance") + " · " + fmtHours(tt) + "</b></div></div>";
      if (ms.length) body += "<h3>Matchs</h3>" + listHtml(ms, function (m) { return fmtDur(playMinutes(m)); });
      if (tr.length) body += "<h3>Entraînements</h3><div class=\"list\">" + tr.map(function (t) { return '<a class="row dl" href="#/entrainement/' + t.id + '"><span class="grow"><span class="t">' + esc(t.label || "Entraînement") + '</span><span class="s">' + esc(fdate(t.date)) + (t.racketId && racket(t.racketId) ? " · " + esc(racket(t.racketId).name) : "") + '</span></span><span class="pts">' + fmtDur(playMinutes(t)) + "</span></a>"; }).join("") + "</div>";
      if (!ms.length && !tr.length) body += '<span class="small">Rien de noté ce mois-ci.</span>';
      return { title: MOIS_L[mo].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + y, sub: "Durée des matchs estimée d'après le score, entraînements tels que tu les as notés", body: body };
    }
  };
  function sheetHtml() {
    var d = DET[UI.sheet.k] && DET[UI.sheet.k](UI.sheet.v);
    if (!d) { UI.sheet = null; return ""; }
    return '<div class="sheet-bg" data-a="sheetClose"></div><div class="sheet big" role="dialog" aria-modal="true" aria-label="' + esc(d.title) + '"><div class="sh-grab"></div><div class="sh-head"><b>' + esc(d.title) + '</b><button class="iconbtn sm" data-a="sheetClose" aria-label="Fermer">' + I.cross + "</button></div>" +
      (d.sub ? '<span class="small">' + esc(d.sub) + "</span>" : "") + '<div class="sh-body">' + d.body + "</div></div>";
  }
  // Plafond : jusqu'où tu bats régulièrement
  function ceilingMsg(rows, cur) {
    if (cur < 0) return "";
    var ok = rows.filter(function (r) { return r.v + r.d >= 2; });
    if (!ok.length) return '<span class="small">Il faut au moins deux matchs contre un même classement pour dégager une tendance.</span>';
    var good = ok.filter(function (r) { return r.v * 2 >= r.v + r.d; }).sort(function (a, b) { return b.o - a.o; })[0];
    var above = ok.filter(function (r) { return (!good || r.o > good.o); }).sort(function (a, b) { return a.o - b.o; })[0];
    var pct = function (r) { return Math.round(r.v * 100 / (r.v + r.d)); };
    var msg = good ? "Tu bats régulièrement jusqu'aux <b>" + lab(good.o) + "</b> (" + r2(good) + ")." : "Pour l'instant, tu gagnes moins d'un match sur deux, quel que soit le classement en face.";
    function r2(r) { return r.v + " sur " + (r.v + r.d) + ", " + pct(r) + " %"; }
    if (above) msg += " Contre les <b>" + lab(above.o) + "</b>, c'est " + r2(above) + " : " + (above.o > cur ? "c'est là que se joue ta montée." : "c'est là que ça coince.");
    return '<div class="card balle" style="padding:12px 14px;font-size:15px;line-height:1.4"><span>' + msg + "</span></div>";
  }
  // Forme du moment : 30 derniers jours (ou 5 derniers matchs) contre la moyenne sur 12 mois
  function formeHtml(win) {
    var played = win.filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    if (played.length < 4) return "";
    var lim = E.iso(new Date(today().getTime() - 30 * 864e5)), recent = played.filter(function (m) { return m.date >= lim; }), lbl = "30 derniers jours";
    if (recent.length < 3) { recent = played.slice(0, 5); lbl = "5 derniers matchs"; }
    var pc = function (ms) { return Math.round(ms.filter(function (m) { return m.result === "V"; }).length * 100 / ms.length); };
    var a = pc(recent), b = pc(played), d = a - b;
    var arrow = d >= 10 ? "↗" : d <= -10 ? "↘" : "→", tone = d >= 10 ? "balle" : d <= -10 ? "terre" : "";
    var lvl = function (ms) { var o = ms.map(function (m) { return E.idx(m.oppRank); }).filter(function (x) { return x != null; }); return o.length ? o.reduce(function (s, x) { return s + x; }, 0) / o.length : null; };
    var lr = lvl(recent), la = lvl(played), lvMsg = "";
    if (lr != null && la != null && Math.abs(lr - la) >= 0.75) lvMsg = lr > la ? " Et tu joues des adversaires mieux classés que d'habitude." : " Mais contre des adversaires moins bien classés que d'habitude.";
    var verdict = d >= 10 ? "Tu es en forme." : d <= -10 ? "Petit creux en ce moment." : "Dans ta moyenne.";
    return '<div class="card ' + tone + '" style="gap:8px">' + chead("forme", "Forme du moment", lbl.replace(/^./, function (x) { return x.toUpperCase(); })) +
      '<div style="display:flex;align-items:baseline;gap:12px"><span style="font-size:40px;font-weight:700;letter-spacing:-.03em;line-height:1">' + a + ' %</span><span style="font-size:28px;font-weight:700">' + arrow + '</span><span class="small">de victoires<br>contre ' + b + " % sur 12 mois</span></div>" +
      '<span style="font-size:15px;line-height:1.4">' + verdict + " " + plural(recent.length, "match") + " : " + recordOf(recent) + "." + lvMsg + "</span></div>";
  }
  // Points à défendre : ton bilan aux prochaines sorties si tu ne rejoues pas
  function defendHtml(c) {
    var p = c.proj; if (p.status === "top" || c.cur < 0) return "";
    var b0 = p.status === "descente" ? p.here : p.next, calc = b0.calc, all = allMatches(), rel = p.release, pts = [];
    for (var k = 0; k < 6; k++) {
      var b = E.bilanAt(E.windowMatches(all, rel, today()), calc, c.sex, c.cur, c.opts.extra);
      pts.push({ rel: rel, total: b.total, norme: b.norme, lost: [], b: b });
      rel = E.nextRelease(rel);
    }
    // victoires comptées qui sortent à chaque sortie
    b0.counted.forEach(function (w) {
      if (!w.m.date) return;
      var leave = E.plus12Months(E.parseDate(w.m.date));
      for (var i = 1; i < pts.length; i++) if (leave <= pts[i].rel && leave > pts[i - 1].rel) { pts[i].lost.push(w); break; }
    });
    var drop = pts[0].total - pts[pts.length - 1].total;
    UI._defend = { pts: pts, label: b0.label };
    if (drop <= 0) return '<div class="card" style="gap:6px">' + chead("defend", "Points à défendre", "") + '<span style="font-size:15px">Aucune victoire comptée ne sort d\'ici 6 mois : ton bilan à ' + esc(b0.label) + " tient.</span></div>";
    var mx = Math.max.apply(null, pts.map(function (x) { return Math.max(x.total, x.norme); })) || 1, W = 320, H = 130, bw = W / pts.length, ny = H - 22 - pts[0].norme / mx * (H - 34);
    var bars = pts.map(function (x, i) {
      var h = x.total / mx * (H - 34), xx = i * bw + 6, under = x.total < x.norme;
      return '<rect x="' + xx.toFixed(1) + '" y="' + (H - 22 - h).toFixed(1) + '" width="' + (bw - 12).toFixed(1) + '" height="' + h.toFixed(1) + '" rx="4" fill="' + (under ? "var(--chart-d)" : "var(--chart-v)") + '"/>' +
        '<text x="' + (xx + (bw - 12) / 2).toFixed(1) + '" y="' + (H - 26 - h).toFixed(1) + '" text-anchor="middle" font-size="10" font-weight="700" fill="var(--ink)">' + x.total + "</text>" +
        '<text x="' + (xx + (bw - 12) / 2).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle" font-size="10" fill="var(--muted)">' + MOIS[x.rel.getMonth()] + "</text>" +
        '<rect class="hit" data-a="sheet" data-k="defend" data-v="' + i + '" x="' + (i * bw).toFixed(1) + '" y="0" width="' + bw.toFixed(1) + '" height="' + H + '" fill="transparent"/>';
    }).join("") + '<line x1="0" x2="' + W + '" y1="' + ny.toFixed(1) + '" y2="' + ny.toFixed(1) + '" stroke="var(--ink)" stroke-dasharray="4 4" stroke-width="1"/>';
    var worst = pts.slice(1).filter(function (x) { return x.lost.length; }).sort(function (a, b) { return b.lost.reduce(function (s, w) { return s + w.pts; }, 0) - a.lost.reduce(function (s, w) { return s + w.pts; }, 0); })[0];
    var msg = worst ? "En " + MOIS_L[worst.rel.getMonth()] + ", " + worst.lost.map(function (w) { return "ta victoire contre " + esc(w.m.opp || "un " + w.m.oppRank) + " (" + esc(w.m.oppRank) + ", +" + w.pts + ")"; }).join(" et ") + " sort" + (worst.lost.length > 1 ? "ent" : "") + " de tes 12 mois." : "";
    return '<div class="card chart" style="gap:8px">' + chead("defend", "Points à défendre", "Ton bilan à " + b0.label + " si tu ne rejoues pas") +
      '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Bilan aux six prochaines sorties">' + bars + "</svg>" +
      '<span style="font-size:15px;line-height:1.4">D\'ici ' + MOIS_L[pts[pts.length - 1].rel.getMonth()] + ", ton bilan perd <b>" + drop + " pts</b> sans nouvelle victoire. " + msg + "</span>" +
      '<span class="small">Pointillés : la norme ' + esc(b0.label) + " (" + pts[0].norme + " pts). Une victoire hors quota peut prendre le relais d'une victoire qui sort. Touche une barre pour le détail du mois.</span></div>";
  }
  // Mental : sets décisifs, premier set, jeux décisifs
  function mentalHtml(win) {
    var played = win.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); });
    var f1w = { v: 0, n: 0 }, f1l = { v: 0, n: 0 }, three = { v: 0, n: 0 }, tb = { v: 0, n: 0 }, stb = { v: 0, n: 0 }, setsW = { v: 0, n: 0 }, games = { v: 0, n: 0 };
    played.forEach(function (m) {
      var sets = setsOf(m.score); if (!sets.length) return;
      var won = m.result === "V";
      sets.forEach(function (st, i) { setsW.n++; if (st[0] > st[1]) setsW.v++; if (!isSuperTb(st, i)) { games.n += st[0] + st[1]; games.v += st[0]; } });
      if (sets[0][0] > sets[0][1]) { f1w.n++; if (won) f1w.v++; } else if (sets[0][0] < sets[0][1]) { f1l.n++; if (won) f1l.v++; }
      if (sets.length === 3) { three.n++; if (won) three.v++; }
      sets.forEach(function (st, i) { if (isSuperTb(st, i)) { stb.n++; if (st[0] > st[1]) stb.v++; } else if (isTb(st)) { tb.n++; if (st[0] > st[1]) tb.v++; } });
    });
    var rows = [["1er set gagné", f1w, "conclus", "f1w"], ["1er set perdu", f1l, "renversés", "f1l"], ["Matchs en 3 sets", three, "gagnés", "three"], ["Tie-breaks", tb, "gagnés", "tb"], ["Super tie-breaks", stb, "gagnés", "stb"], ["Sets", setsW, "sets gagnés", "sets"], ["Jeux", games, "jeux gagnés", "games"]].filter(function (r) { return r[1].n; });
    if (!rows.length) return "";
    var line = function (r) {
      var x = r[1], pc = Math.round(x.v * 100 / x.n);
      return '<button class="mrow" data-a="sheet" data-k="mental" data-v="' + r[3] + '"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + r[0] + ' <span class="chev">›</span></span><span class="small">' + x.v + " sur " + x.n + " " + r[2] + " · <b>" + pc + " %</b></span></div>" +
        '<div class="meter"><span class="track"><span class="fill" style="display:block;width:' + pc + "%;background:" + (pc >= 50 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span></div></button>';
    };
    var close = three.n + tb.n + stb.n, closeV = three.v + tb.v + stb.v, msg = "";
    if (close >= 4) msg = closeV * 2 >= close ? "Dans les moments serrés, tu tiens : " + closeV + " sur " + close + " gagnés (3es sets et jeux décisifs)." : "Les fins serrées t'échappent : " + closeV + " sur " + close + " gagnés (3es sets et jeux décisifs).";
    return '<div class="card" style="gap:14px">' + chead("mental", "Mental", "Sur 12 mois, d'après les scores · touche une ligne pour le détail") + rows.map(line).join("") +
      (msg ? '<div class="card balle" style="padding:12px 14px;font-size:15px;font-weight:600">' + esc(msg) + "</div>" : "") + "</div>";
  }
  // Face-à-face : adversaires rencontrés plusieurs fois
  // ---------- Notes pour la revanche ----------
  // Ce que tu as noté sur un adversaire : la note de sa fiche et celles de vos matchs, la plus récente d'abord.
  function revNotes(name, exceptId) {
    var k = nameKey(name); if (k.length < 3) return [];
    var out = [], on = (S.oppNotes || {})[k];
    if (on && on.text) out.push({ text: on.text, date: on.at, fiche: true });
    S.matches.forEach(function (m) { if (m.id !== exceptId && m.note && m.opp && nameKey(m.opp) === k) out.push({ text: m.note, date: m.date, m: m }); });
    return out.sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; });
  }
  function revHint(name, exceptId, dark) {
    var n = revNotes(name, exceptId); if (!n.length) return "";
    var IL = window.MonteeIll, x = n[0];
    return '<a class="rev-hint' + (dark ? " dark" : "") + '" href="#/adversaire/' + encodeURIComponent(nameKey(name)) + '">' + 
      '<span class="grow"><span class="eyebrow">Ta note pour la revanche</span><span class="rv-t">« ' + esc(x.text) + ' »</span><span class="small">' + (x.m ? (x.m.result === "V" ? "Victoire" : "Défaite") + (x.date ? " le " + esc(fdate(x.date)) : "") + (x.m.score ? " · " + esc(x.m.score) : "") : "Sur sa fiche") + (n.length > 1 ? " · " + plural(n.length - 1, "autre note", "autres notes") : "") + "</span></span></a>";
  }
  V.adversaire = function (key) {
    key = decodeURIComponent(key || "");
    var ms = S.matches.filter(function (m) { return m.opp && nameKey(m.opp) === key; }).sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; });
    if (!ms.length) { go("palmares"); return ""; }
    var name = ms[0].opp, v = ms.filter(function (m) { return m.result === "V" && !m.wo; }).length, d = ms.filter(function (m) { return m.result === "D" && !m.wo; }).length;
    var on = (S.oppNotes || {})[key] || {}, IL = window.MonteeIll;
    var s = '<div class="screen">' + topbar(name, ms[0].oppRank ? "Classé " + ms[0].oppRank + " au dernier match" : "");
    s += '<div class="card opp-head">' +  '<span class="grow"><span class="eyebrow">Face-à-face</span><span class="opp-score" style="color:' + (v > d ? "var(--gazon)" : v < d ? "var(--terre)" : "var(--ink)") + '">' + v + " – " + d + '</span><span class="small">' + plural(ms.length, "match", "matchs") + " contre lui</span></span></div>";
    s += '<h2>Ta fiche sur lui</h2><div class="form"><div class="field"><label for="o-note">Ce qu\'il faut retenir</label><textarea id="o-note" data-on="' + esc(key) + '" placeholder="Ex. : gaucher, adore la diagonale revers, craque sur les balles hautes">' + esc(on.text || "") + '</textarea><span class="small">Elle s\'affichera quand tu ajouteras un match contre lui, et sur l\'accueil quand vous vous serez rejoués.</span></div></div>';
    s += "<h2>Vos matchs</h2><div class=\"list\">" + ms.map(function (m) {
      return '<a class="row" href="#/match/' + m.id + '"><span class="vd lg ' + m.result + '">' + (m.wo ? "WO" : m.result) + '</span><span class="grow"><span class="t">' + esc(fdate(m.date)) + (m.score ? " · " + esc(m.score) : "") + '</span><span class="s">' + esc(m.oppRank || "") + (m.comp ? " · " + esc(m.comp) : "") + "</span>" + (m.note ? '<span class="s rev">« ' + esc(m.note) + " »</span>" : "") + "</span>" + I.next + "</a>";
    }).join("") + "</div>";
    return s + "</div>";
  };
  function h2hHtml() {
    var g = {};
    S.matches.forEach(function (m) {
      if (!m.opp || m.wo || !(m.result === "V" || m.result === "D")) return;
      var k = nameKey(m.opp); if (k.length < 3) return;
      (g[k] = g[k] || { name: m.opp, ms: [] }).ms.push(m);
    });
    var list = Object.keys(g).map(function (k) { return g[k]; }).filter(function (x) { return x.ms.length >= 2; })
      .sort(function (a, b) { return b.ms.length - a.ms.length; }).slice(0, 6);
    if (!list.length) return "";
    return '<div class="card" style="gap:4px">' + chead("h2h", "Face-à-face", "Les adversaires que tu as joués plusieurs fois") +
      list.map(function (x) {
        var ms = x.ms.sort(function (a, b) { return (a.date || "") < (b.date || "") ? 1 : -1; }), v = ms.filter(function (m) { return m.result === "V"; }).length, d = ms.length - v;
        var nt = revNotes(x.name)[0];
        return '<a class="row" href="#/adversaire/' + encodeURIComponent(nameKey(x.name)) + '" style="padding:10px 0;border-bottom:1px solid var(--line)"><span class="grow"><span class="t">' + esc(x.name) + ' <span class="muted" style="font-weight:400">· ' + esc(ms[0].oppRank || "") + '</span></span><span class="s">Dernier : ' + (ms[0].result === "V" ? "victoire" : "défaite") + (ms[0].date ? " le " + esc(fdate(ms[0].date)) : "") + (ms[0].score ? " · " + esc(ms[0].score) : "") + "</span>" + (nt ? '<span class="s rev">« ' + esc(nt.text) + " »</span>" : "") + "</span>" +
          '<span class="pts" style="color:' + (v > d ? "var(--gazon)" : v < d ? "var(--terre)" : "var(--ink)") + '">' + v + " – " + d + "</span></a>";
      }).join("") + "</div>";
  }
  // Tes records sur 12 mois
  function recordsHtml(win, cur) {
    var played = win.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); });
    if (!played.length) return "";
    var best = null, perfs = 0, tb = { v: 0, n: 0 }, three = { v: 0, n: 0 }, back = 0, bagels = 0, months = {};
    played.forEach(function (m) {
      var o = E.idx(m.oppRank), sets = setsOf(m.score);
      if (m.date) { var k = m.date.slice(0, 7); months[k] = (months[k] || 0) + 1; }
      if (m.result === "V") {
        if (o != null && (!best || o > E.idx(best.oppRank))) best = m;
        if (o != null && o > cur) perfs++;
        if (sets.length && sets[0][0] < sets[0][1]) back++;
      }
      if (sets.length === 3) { three.n++; if (m.result === "V") three.v++; }
      sets.forEach(function (st, i) {
        if (isTb(st) || isSuperTb(st, i)) { tb.n++; if (st[0] > st[1]) tb.v++; }
        if (st[0] === 6 && st[1] === 0) bagels++;
      });
    });
    var mk = Object.keys(months).sort(function (a, b) { return months[b] - months[a]; })[0];
    var bestRun = 0, run = 0;
    played.slice().sort(function (a, b) { return (a.date || "") < (b.date || "") ? -1 : 1; }).forEach(function (m) { run = m.result === "V" ? run + 1 : 0; if (run > bestRun) bestRun = run; });
    var streak = 0, sm = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); });
    for (var i = 0; i < sm.length && sm[i].result === sm[0].result; i++) streak++;
    var tile = function (k, v, sub, key) { return '<button class="rec" data-a="sheet" data-k="record" data-v="' + key + '"><span class="k">' + k + '</span><span class="v">' + v + '</span><span class="s">' + sub + "</span></button>"; };
    var wm = {}; played.forEach(function (m) { if (m.result === "V" && m.date) { var k = m.date.slice(0, 7); wm[k] = (wm[k] || 0) + 1; } });
    var bm = Object.keys(wm).sort(function (a, b) { return wm[b] - wm[a] || (a < b ? 1 : -1); })[0];
    var s = '<div class="card" style="gap:12px">' + chead("records", "Tes records sur 12 mois", "Touche une case pour voir les matchs") ;
    if (best) s += '<a class="rec-best" href="#/match/' + best.id + '"><span class="eyebrow">Plus belle victoire</span><span class="rk">' + esc(best.oppRank) + '</span><span class="who">' + esc(best.opp || "Adversaire") + (best.score ? "<br>" + esc(best.score) : "") + "</span></a>";
    s += '<div class="rec-grid">' +
      tile("Perfs", perfs, perfs > 1 ? "mieux classés battus" : "mieux classé battu", "perfs") +
      tile("Matchs", played.length, "joués sur 12 mois (WO exclus)", "matchs") +
      tile("Meilleure série", bestRun + " V", "victoires d'affilée sur 12 mois", "run") +
      tile("6-0 donnés", bagels, bagels > 1 ? "sets blancs" : "set blanc", "bagel") +
      tile("Série en cours", sm.length ? streak + " " + (sm[0].result === "V" ? "V" : "D") : "—", sm.length ? (sm[0].result === "V" ? "victoires" : "défaites") + " d'affilée (WO exclus)" : "", "streak") +
      tile("Meilleur mois", bm ? wm[bm] + " V" : "—", bm ? MOIS_L[+bm.slice(5) - 1] + " " + bm.slice(0, 4) : "pas encore de victoire", "month") +
      "</div>" +
      (mk ? '<span class="small">Mois le plus chargé : ' + MOIS_L[+mk.slice(5) - 1] + " " + mk.slice(0, 4) + ", " + plural(months[mk], "match", "matchs") + ". Scores lus de ton point de vue (ta manche d\'abord).</span>" : "") + "</div>";
    return s;
  }
  // Où tu gagnes : par type de match
  function whereHtml(win) {
    var played = win.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); });
    var tab = UI.whereTab || "kind";
    var keyFn = {
      kind: function (m) { return (KINDS.filter(function (k) { return k[0] === (m.kind || "tournoi"); })[0] || ["", "Tournoi"])[1]; },
      surface: surfKey,
      lieu: function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; }
    }[tab];
    var g = groupStats(played, keyFn);
    if (!played.length) return "";
    var ok = g.filter(function (x) { return x.n >= 3; }), msg = "";
    var low = function (x) {
      if (tab === "kind") return x.label === "Tournoi" ? "en tournoi" : x.label === "Par équipes" ? "par équipes" : x.label === "Championnat individuel" ? "en championnat individuel" : "en match libre";
      if (tab === "lieu") return x.label === "Intérieur" ? "en intérieur" : "en extérieur";
      return "sur " + x.label.toLowerCase();
    };
    if (ok.length >= 2) {
      var hi = ok[0], lo = ok[ok.length - 1];
      msg = hi.pct - lo.pct >= 20 ? "Tu gagnes " + hi.v + " sur " + hi.n + " " + low(hi) + ", contre " + lo.v + " sur " + lo.n + " " + low(lo) + "." : "Pas de grosse différence pour l'instant.";
    }
    if (!g.length || (tab !== "kind" && ok.length < 2)) {
      var known = played.filter(function (m) { return keyFn(m); }).length;
      var empty = '<span class="small">' + (tab === "surface" ? "Indique la surface" : "Indique intérieur ou extérieur") + " dans la fiche de tes matchs (" + known + " sur " + played.length + " renseignés). Il en faut au moins 3 dans deux catégories pour comparer.</span>";
      if (!g.length) return '<div class="card" style="gap:14px">' + chead("where", "Où tu gagnes", "Sur 12 mois") + whereTabs() + empty + "</div>";
      msg = ""; g.push({ _note: empty });
    }
    return '<div class="card" style="gap:14px">' + chead("where", "Où tu gagnes", "Sur 12 mois · touche une ligne pour voir les matchs") + whereTabs() +
      g.map(function (x) {
        if (x._note) return x._note;
        return '<button class="mrow" data-a="sheet" data-k="where" data-v="' + esc(x.label) + '"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + esc(x.label) + ' <span class="chev">›</span> <span class="small">' + x.v + " V · " + x.d + " D</span></span><b>" + x.pct + " %</b></div>" +
          '<div class="meter" role="img" aria-label="' + x.pct + ' % de victoires"><span class="track"><span class="fill" style="display:block;width:' + x.pct + "%;background:" + (x.pct >= 50 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span></div></button>';
      }).join("") + (msg ? '<div class="card balle" style="padding:12px 14px;font-size:15px;font-weight:600">' + esc(msg) + "</div>" : "") + "</div>";
  }
  function playTimeHtml() {
    var t = today(), months = [];
    for (var k = 11; k >= 0; k--) { var d = new Date(t.getFullYear(), t.getMonth() - k, 1); months.push({ key: E.iso(d).slice(0, 7), m: d.getMonth(), match: 0, train: 0 }); }
    var by = {}; months.forEach(function (x) { by[x.key] = x; });
    S.matches.forEach(function (m) { if (m.date && !m.wo && by[m.date.slice(0, 7)]) by[m.date.slice(0, 7)].match += playMinutes(m); });
    (S.trainings || []).forEach(function (x) { if (x.date && by[x.date.slice(0, 7)]) by[x.date.slice(0, 7)].train += playMinutes(x); });
    var tot = months.reduce(function (a, x) { return a + x.match + x.train; }, 0), tr = months.reduce(function (a, x) { return a + x.train; }, 0);
    if (!tot) return "";
    var mx = Math.max.apply(null, months.map(function (x) { return x.match + x.train; })) || 1, W = 320, H = 110, bw = W / 12;
    var bars = months.map(function (x, i) {
      var hm = x.match / mx * (H - 18), ht = x.train / mx * (H - 18), xx = i * bw + 4;
      return '<rect x="' + xx.toFixed(1) + '" y="' + (H - 16 - hm).toFixed(1) + '" width="' + (bw - 8).toFixed(1) + '" height="' + hm.toFixed(1) + '" rx="3" fill="var(--ink)"/>' +
        '<rect x="' + xx.toFixed(1) + '" y="' + (H - 16 - hm - ht).toFixed(1) + '" width="' + (bw - 8).toFixed(1) + '" height="' + ht.toFixed(1) + '" rx="3" fill="var(--balle)"/>' +
        '<text x="' + (xx + (bw - 8) / 2).toFixed(1) + '" y="' + (H - 3) + '" text-anchor="middle" font-size="9" fill="var(--muted)">' + MOIS[x.m].charAt(0).toUpperCase() + "</text>" +
        '<rect class="hit" data-a="sheet" data-k="temps" data-v="' + x.key + '" x="' + (i * bw).toFixed(1) + '" y="0" width="' + bw.toFixed(1) + '" height="' + H + '" fill="transparent"/>';
    }).join("");
    return '<div class="card chart">' + chead("temps", "Temps de jeu", "≈ " + fmtHours(tot) + " sur 12 mois") +
      '<svg viewBox="0 0 ' + W + " " + H + '" width="100%" role="img" aria-label="Temps de jeu par mois">' + bars + "</svg>" +
      '<span class="small"><span class="dot" style="background:var(--ink)"></span> Matchs ≈ ' + fmtHours(tot - tr) + ' · <span class="dot" style="background:var(--balle)"></span> Entraînements ' + fmtHours(tr) + ". Durée des matchs estimée d'après le score (4 min par jeu, échauffement compris). Touche un mois pour le détail.</span></div>";
  }
  function recordOf(ms) { if (!ms.length) return "—"; var v = ms.filter(function (m) { return m.result === "V"; }).length; return v + " V · " + (ms.length - v) + " D"; }

  function lineChart(h) {
    var W = 320, H = 156, pad = 10, top = 26;
    var vals = h.map(function (x) { return x.total; }).concat([h[0].norme]);
    var mx = Math.max.apply(null, vals) * 1.08 || 1, mn = 0;
    var x = function (i) { return pad + i * (W - 2 * pad) / (h.length - 1); };
    var y = function (v) { return H - 8 - (v - mn) / (mx - mn) * (H - 8 - top); };
    var sel = UI.bilanSel == null || UI.bilanSel >= h.length ? h.length - 1 : UI.bilanSel, sp = h[sel];
    var pts = h.map(function (p, i) { return x(i).toFixed(1) + "," + y(p.total).toFixed(1); });
    var solid = pts.slice(0, h.length - 1).join(" "), dash = pts.slice(h.length - 2).join(" ");
    var ny = y(h[0].norme).toFixed(1);
    var dots = h.map(function (p, i) { return i === sel ? "" : '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(p.total).toFixed(1) + '" r="3.2" style="fill:var(--card);stroke:var(--gazon)" stroke-width="1.8"/>'; }).join("");
    var hits = h.map(function (p, i) { return '<rect class="hit" data-a="bilanSel" data-v="' + i + '" x="' + (x(i) - 13).toFixed(1) + '" y="0" width="26" height="' + H + '" fill="transparent"/>'; }).join("");
    var sx = x(sel), sy = y(sp.total), bx = Math.max(24, Math.min(W - 24, sx));
    var bubble = '<line x1="' + sx.toFixed(1) + '" x2="' + sx.toFixed(1) + '" y1="' + (sy + 6).toFixed(1) + '" y2="' + (H - 8) + '" style="stroke:var(--ink)" stroke-width="1" stroke-dasharray="2 3" opacity=".5"/>' +
      '<rect x="' + (bx - 22).toFixed(1) + '" y="' + (sy - 30).toFixed(1) + '" width="44" height="20" rx="10" style="fill:var(--panel)"/><text x="' + bx.toFixed(1) + '" y="' + (sy - 16).toFixed(1) + '" text-anchor="middle" font-size="11" font-weight="700" style="fill:var(--hl)">' + sp.total + "</text>" +
      '<circle cx="' + sx.toFixed(1) + '" cy="' + sy.toFixed(1) + '" r="6.5" style="fill:var(--balle);stroke:var(--ink)" stroke-width="2.2"/>';
    var lbl = h.map(function (p, i) { return '<span class="' + (i === sel ? "on" : "") + '">' + (i % 2 === 0 || i === h.length - 1 || i === sel ? (p.projected ? "→" : MOIS[p.date.getMonth()].replace(".", "")) : "") + "</span>"; }).join("");
    var when = sp.projected ? "Prochaine sortie (" + fdate(sp.date).replace(/\.$/, "") + ", projection)" : "Sortie du " + fdate(sp.date).replace(/\.$/, "");
    return '<svg viewBox="0 0 ' + W + " " + H + '" class="tapchart" role="img" aria-label="Bilan de ' + h[0].total + " à " + h[h.length - 1].total + " points sur 12 mois, norme " + h[0].norme + '">' +
      '<line x1="0" x2="' + W + '" y1="' + (H - 8) + '" y2="' + (H - 8) + '" style="stroke:var(--line)"/>' +
      '<line x1="0" x2="' + W + '" y1="' + ny + '" y2="' + ny + '" style="stroke:var(--ink)" stroke-width="1.2" stroke-dasharray="4 4"/>' +
      '<polyline points="' + solid + '" fill="none" style="stroke:var(--gazon)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>' +
      '<polyline points="' + dash + '" fill="none" style="stroke:var(--gazon)" stroke-width="2.5" stroke-dasharray="3 4" stroke-linecap="round"/>' +
      dots + bubble + hits + "</svg>" + '<div class="axis">' + lbl + "</div>" +
      '<button class="sel-panel" data-a="sheet" data-k="bilan" data-v="' + sel + '"><span class="grow"><b>' + esc(when) + "</b><span class=\"small\">" + sp.total + " / " + sp.norme + " pts" + (sp.total >= sp.norme ? " · norme atteinte" : " · il manque " + (sp.norme - sp.total) + " pts") + '</span></span><span class="sel-go">Détail ' + I.next + "</span></button>" +
      '<span class="small tap-hint">Touche un point de la courbe pour voir une autre sortie.</span>';
  }

  // ---------- Matériel ----------
  function groupStats(ms, keyFn) {
    var g = {};
    ms.forEach(function (m) { var k = keyFn(m); if (!k) return; g[k] = g[k] || { label: k, v: 0, d: 0 }; if (m.result === "V") g[k].v++; else g[k].d++; });
    return Object.keys(g).map(function (k) { var x = g[k]; x.n = x.v + x.d; x.pct = Math.round(x.v * 100 / x.n); return x; })
      .sort(function (a, b) { return b.pct - a.pct || b.n - a.n; });
  }
  var USURE = ["moins de 5 h", "5 à 12 h", "12 à 20 h", "plus de 20 h"];
  function usureBucket(m) { var a = stringAge(m); if (a == null) return null; a = a / 60; return a < 5 ? USURE[0] : a < 12 ? USURE[1] : a < 20 ? USURE[2] : USURE[3]; }
  V.materiel = function () {
    var ms = S.matches.filter(function (m) { return annotated(m) && !m.wo && (m.result === "V" || m.result === "D"); });
    var tab = UI.matTab; if (["setup", "usure", "feel"].indexOf(tab) < 0) tab = UI.matTab = "setup";
    var head = '<div class="screen has-tabs"><div class="topbar"><div class="title"><span class="small">Raquettes, cordages, entraînements</span><span style="font-size:28px;font-weight:600;letter-spacing:-.03em">Matériel</span></div></div>';
    var s = '<div class="sec-head">' + chead("raquette", "Avec quoi tu gagnes", "D'après tes " + plural(ms.length, "match annoté", "matchs annotés")) + "</div>";
    s += '<div class="tabs" role="group" aria-label="Regrouper par">' + [["setup", "Raquette + cordage"], ["usure", "Usure"], ["feel", "Ressenti"]].map(function (t) {
      return '<button data-a="matTab" data-v="' + t[0] + '" class="' + (tab === t[0] ? "on" : "") + '" aria-pressed="' + (tab === t[0]) + '">' + t[1] + "</button>";
    }).join("") + "</div>";
    var keyFn = {
      setup: setupLabel, usure: usureBucket,
      surface: surfKey,
      lieu: function (m) { return m.indoor === true ? "Intérieur" : m.indoor === false ? "Extérieur" : null; },
      feel: function (m) { return m.feel ? (m.feel >= 4 ? "Bonnes sensations (4-5)" : m.feel === 3 ? "Moyen (3)" : "Pas dans le match (1-2)") : null; }
    }[tab];
    var src = tab === "surface" || tab === "lieu" || tab === "feel" ? S.matches.filter(function (m) { return !m.wo && (m.result === "V" || m.result === "D"); }) : ms;
    var g = groupStats(src, keyFn);
    var ok = g.filter(function (x) { return x.n >= 3; });
    if (tab === "usure") {
      g.sort(function (a, b) { return USURE.indexOf(a.label) - USURE.indexOf(b.label); });
      var unknown = ms.filter(function (m) { return m.racketId && stringAge(m) == null; }).length;
      var fresh = g.filter(function (x) { return x.label === USURE[0]; })[0];
      var older = g.filter(function (x) { return x.label !== USURE[0] && x.n >= 3; });
      var oldV = older.reduce(function (a, x) { return a + x.v; }, 0), oldN = older.reduce(function (a, x) { return a + x.n; }, 0);
      var oldPct = oldN ? Math.round(oldV * 100 / oldN) : null;
      if (fresh && fresh.n >= 3 && oldN >= 3) {
        var title, sub;
        if (fresh.pct - oldPct >= 15) { title = "Tu gagnes plus avec un cordage frais."; sub = fresh.pct + " % de victoires quand ton cordage a moins de 5 h de jeu, " + oldPct + " % au-delà. Recorde avant tes tournois importants."; }
        else if (oldPct - fresh.pct >= 15) { title = "Pas d'effet d'usure visible."; sub = "Tu gagnes même plus avec un cordage rodé (" + oldPct + " %) que tout neuf (" + fresh.pct + " %)."; }
        else { title = "Pas d'écart net entre cordage neuf et rodé."; sub = fresh.pct + " % sous 5 h de jeu, " + oldPct + " % au-delà."; }
        s += '<div class="card balle"><span class="eyebrow">Ce qu\'on remarque</span><span style="font-size:21px;line-height:1.2;font-weight:600;letter-spacing:-.02em">' + esc(title) + '</span><span style="font-size:14px">' + esc(sub) + "</span></div>";
      } else {
        s += '<div class="card"><b>Pas encore assez d\'infos sur tes cordages</b><span class="small">Il faut au moins 3 matchs joués avec un cordage de moins de 5 h, et 3 avec un cordage plus usé, pour comparer.</span></div>';
      }
      s += '<div class="card" style="gap:6px"><b style="font-size:15px">Comment c\'est compté</b><span style="font-size:14px;line-height:1.45">Pour chaque match, Montée regarde combien d\'heures de jeu ton cordage avait déjà : matchs (estimés d\'après le score, 4 min par jeu + échauffement) et entraînements que tu as notés. Un nouveau cordage commence quand tu coches <b>Cordage neuf</b> sur un match ou un entraînement, quand tu indiques une <b>date de cordage</b> sur la raquette, ou quand le cordage ou la tension du match changent.' +
        (unknown ? " <b>" + plural(unknown, "match est ignoré", "matchs sont ignorés") + "</b> : on ne sait pas quand leur cordage a été posé." : "") + "</span></div>";
    } else if (ok.length >= 2) {
      var best = ok[0], worst = ok[ok.length - 1];
      var ins = {
        setup: "Avec " + best.label + ", tu gagnes " + best.v + " matchs sur " + best.n + ".",

        surface: "Ton terrain, c'est " + best.label.toLowerCase() + " : " + best.v + " sur " + best.n + ".",
        lieu: "En " + best.label.toLowerCase() + ", tu gagnes " + best.v + " sur " + best.n + ".",
        feel: "Quand tu as de " + (best.label.indexOf("Bonnes") === 0 ? "bonnes sensations" : "moins bonnes sensations") + ", tu gagnes " + best.pct + " %."
      }[tab];
      var adv = best.pct - worst.pct >= 15 ? "Contre " + worst.pct + " % pour " + worst.label + "." : "Pas d'écart net pour l'instant : continue d'annoter.";
      s += '<div class="card balle"><span class="eyebrow">Ce qu\'on remarque</span><span style="font-size:21px;line-height:1.2;font-weight:600;letter-spacing:-.02em">' + esc(ins) + '</span><span style="font-size:14px">' + esc(adv) + "</span></div>";
    } else {
      s += '<div class="card"><b>Pas encore assez de matchs</b><span class="small">Il faut au moins 3 matchs dans deux groupes pour comparer. ' + (S.matches.some(function (m) { return !annotated(m); }) ? "Annote tes matchs depuis le palmarès." : "") + "</span></div>";
    }
    if (tab === "feel") {
      var gf = {}, all = S.matches.filter(function (m) { return !m.wo && m.feel; }).concat((S.trainings || []).filter(function (t) { return t.feel; }));
      all.forEach(function (x) { var k = x.racketId ? setupLabel(x) : null; if (!k) return; gf[k] = gf[k] || { k: k, sum: 0, n: 0, nt: 0 }; gf[k].sum += x.feel; gf[k].n++; if (x.opp == null) gf[k].nt++; });
      var lf = Object.keys(gf).map(function (k) { return gf[k]; }).sort(function (a, b) { return b.sum / b.n - a.sum / a.n; });
      if (lf.length) s += '<div class="card" style="gap:12px"><b style="font-size:15px">Ton ressenti par matériel</b>' + lf.map(function (x) {
        var avg = x.sum / x.n;
        return '<div style="display:flex;flex-direction:column;gap:6px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + esc(x.k) + '</span><span class="small" style="white-space:nowrap">' + plural(x.n, "séance") + (x.nt ? " dont " + x.nt + " entraîn." : "") + "</span></div>" +
          '<div class="meter" role="img" aria-label="' + avg.toFixed(1) + ' sur 5"><span class="track"><span class="fill" style="display:block;width:' + (avg * 20) + "%;background:" + (avg >= 3.5 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span><b>' + avg.toFixed(1).replace(".", ",") + "/5</b></div></div>";
      }).join("") + '<span class="small">Moyenne de tes notes, matchs et entraînements compris.</span></div>';
    }
    if (g.length) {
      s += '<div class="card" style="gap:16px">' + g.map(function (x) {
        return '<div style="display:flex;flex-direction:column;gap:6px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><span style="font-size:15px;font-weight:600">' + esc(tab === "usure" ? "Cordage de " + x.label : x.label) + '</span><span class="small" style="white-space:nowrap">' + x.v + " V · " + x.d + " D</span></div>" +
          '<div class="meter" role="img" aria-label="' + x.pct + ' % de victoires"><span class="track"><span class="fill" style="display:block;width:' + x.pct + "%;background:" + (x.pct >= 50 ? "var(--chart-v)" : "var(--chart-d)") + '"></span></span><b>' + x.pct + " %</b></div></div>";
      }).join("") + "</div>";
    }
    s += '<p class="small">Sur ' + plural(src.length, "match", "matchs") + ", c'est une tendance, pas une certitude. Plus tu annotes, plus c'est fiable.</p>";
    var analysis = s; s = head;
    s += bagHtml();
    s += '<div class="sec-gap"></div>' + analysis;
    s += "<h2>Ta semaine type</h2><div class=\"list\">" + (S.slots || []).slice().sort(function (a, b) { return a.dow - b.dow || (a.time < b.time ? -1 : 1); }).map(function (sl) {
      return '<a class="row" href="#/creneau/' + sl.id + '"><span class="ic badge ok">' + I.clock + '</span><span class="grow"><span class="t">' + DAYS_L[sl.dow].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + esc(sl.time) + '</span><span class="s">' + esc(sl.label) + " · " + fmtDur(sl.minutes) + "</span></span>" + I.next + "</a>";
    }).join("") + '<button class="row" data-a="newSlot"><span class="badge wait">' + I.plus + '</span><span class="grow"><span class="t">Ajouter un créneau fixe</span><span class="s">Ton entraînement du mardi, ton match du dimanche…</span></span></button></div>';
    var tr = (S.trainings || []).slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; });
    s += "<h2>Entraînements</h2><div class=\"list\">" + tr.slice(0, 8).map(function (t) {
      return '<a class="row" href="#/entrainement/' + t.id + '"><span class="ic badge ok">' + I.clock + '</span><span class="grow"><span class="t">' + esc(fdate(t.date)) + " · " + fmtDur(playMinutes(t)) + '</span><span class="s">' + esc([t.label, t.racketId ? setupLabel(t) : "Matériel non indiqué", t.feel ? "ressenti " + t.feel + "/5" : "", t.note].filter(Boolean).join(" · ")) + "</span></span>" + I.next + "</a>";
    }).join("") + '<button class="row" data-a="newTraining"><span class="badge wait">' + I.plus + '</span><span class="grow"><span class="t">Ajouter un entraînement</span><span class="s">Ça compte dans les heures de jeu de ton cordage</span></span></button></div>';
    return s + "</div>" + tabbar("materiel");
  };

  // Ton sac : chaque raquette en carte, avec ses heures de jeu sur le cordage
  function wearRef(st) { return st.type === "mono" ? MONO_MAX : st.breakAvg ? st.breakAvg.avg : 30 * 60; }
  function bagHtml() {
    var list = bag(), IL = window.MonteeIll, gone = S.rackets.length - list.length;
    var s = '<div class="card bag"><div class="bag-h"><span class="eyebrow">Ton sac · ' + plural(list.length, "raquette") + "</span>" +
      '<span class="bag-t">' + (!list.length ? "Ton sac est vide." : list.some(function (r) { var l = racketStatus(r).level; return l === "change" || l === "broken"; }) ? "Un cordage à refaire." : "Ton sac est prêt.") + "</span>" +
      '<span class="small">Montée compte les heures de jeu de chaque cordage et te dit quand recorder.</span></div><div class="bag-grid">';
    s += list.map(function (r) {
      var st = racketStatus(r), ref = wearRef(st), pct = st.known ? Math.min(100, Math.round(st.min * 100 / ref)) : 0;
      var warn = st.level === "change" || st.level === "broken" || st.level === "soon";
      var lbl = st.level === "broken" ? "Cordage cassé" : !st.known ? "Date de cordage ?" : (st.min ? fmtHours(st.min) : "0 h") + " de jeu";
      return '<a class="rkt' + (r.main ? " main" : "") + '" href="#/raquette/' + r.id + '"><span class="rkt-ill">' + (IL ? IL.racket(r.color || "noir", r.accent, r.pattern) : "") + '</span><span class="rkt-b">' +
        '<b>' + esc(r.name || "Raquette") + (r.main ? ' <span class="rkt-tag">principale</span>' : "") + "</b>" + '<span class="rk-s">' + esc([r.model, r.string, fmtTension(r)].filter(Boolean).join(" · ") || "Cordage à renseigner") + "</span>" +
        '<span class="rk-bar"><span style="width:' + pct + "%;background:" + (warn ? "var(--terre)" : "var(--chart-v)") + '"></span></span>' +
        '<span class="rk-h' + (warn ? " neg" : "") + '">' + esc(lbl) + (st.level === "change" ? " · à recorder" : st.level === "soon" ? " · bientôt" : "") + "</span></span>" + I.next + "</a>";
    }).join("") + '<a class="rkt add" href="#/raquette/new"><span class="rk-plus">' + I.plus + "</span><b>Ajouter une raquette</b></a></div>" +
      (gone ? '<button class="linkbtn" data-a="showArchived" style="color:var(--sub)">' + (UI.showArchived ? "Masquer" : "Voir") + " " + plural(gone, "raquette rangée", "raquettes rangées") + "</button>" : "") +
      (UI.showArchived ? S.rackets.filter(function (r) { return r.archived; }).map(function (r) { return '<a class="row" href="#/raquette/' + r.id + '" style="color:var(--on-panel)"><span class="grow"><span class="t">' + esc(r.name) + '</span><span class="s" style="color:var(--sub)">Rangée · son historique est gardé</span></span>' + I.next + "</a>"; }).join("") : "") +
      "</div>";
    return s;
  }
  V.raquette = function (id) {
    var isNew = !id || id === "new";
    if (!UI.racketDraft || UI.racketDraft._for !== (id || "new")) {
      var r = isNew ? { id: uid(), name: "", string: "", tension: 24, tensionCross: null, restrings: [], main: !S.rackets.length } : JSON.parse(JSON.stringify(racket(id) || {}));
      if (!r.id) { go("materiel"); return ""; }
      if (r.tensionCross === undefined) r.tensionCross = null;
      r._for = id || "new"; UI.racketDraft = r;
    }
    var r2 = UI.racketDraft;
    var rs = (r2.restrings || []).map(function (d, i) { return { d: d, i: i }; }).sort(function (a, b) { return a.d < b.d ? 1 : -1; });
    var st = isNew ? { min: 0, nm: 0, nt: 0, known: false, level: "unknown" } : racketStatus(Object.assign({}, racket(r2.id) || r2, { stringType: r2.stringType, string: r2.string }));
    var ty = r2.stringType || guessType(r2.string);
    var s = '<div class="screen has-save">' + topbar(isNew ? "Nouvelle raquette" : r2.name, "", isNew ? "" : '<button class="iconbtn" data-a="rkMenu" aria-label="Plus d\'actions" aria-expanded="' + !!UI.rkMenu + '">' + I.more + "</button>" + (UI.rkMenu ? '<div class="popmenu"><button data-a="archiveRacket">' + I.save + " " + (r2.archived ? "Remettre dans ton sac" : "Ranger cette raquette") + '</button><button class="danger" data-a="delRacket">' + I.trash + " Supprimer</button></div>" : "") + "</button>");
    var IL = window.MonteeIll;
    if (IL) s += '<div class="rk-hero"><span class="rk-ill">' + IL.racket(r2.color || "noir", r2.accent, r2.pattern) + "</span>" + (r2.model ? '<span class="rk-model">' + esc(r2.model) + "</span>" : "") + "</div>";
    s += '<div class="form">' +
      '<div class="field"><label for="r-name">Son nom dans ton sac</label><input id="r-name" type="text" data-r="name" value="' + esc(r2.name) + '" placeholder="Ex. : N°1, Pure Drive, la 24 kg"></div>' +
      '<div class="field"><label for="r-model">Modèle <span class="small">(facultatif)</span></label><input id="r-model" type="text" data-r="model" value="' + esc(r2.model || "") + '" placeholder="Ex. : Pure Aero 2023, Blade 98"></div>' +
      (IL ? '<div class="field"><span class="lbl">Couleur du cadre</span><div class="swatches">' + Object.keys(IL.RCOL).map(function (k) { var on = (r2.color || "noir") === k; return '<button class="sw' + (on ? " on" : "") + '" data-a="rset" data-k="color" data-v="' + k + '" aria-label="' + k + '" aria-pressed="' + on + '" style="background:' + IL.RCOL[k][0] + '"></button>'; }).join("") + "</div></div>" +
        '<div class="field"><span class="lbl">Deuxième couleur</span><div class="swatches"><button class="sw none' + (!r2.accent ? " on" : "") + '" data-a="rset" data-k="accent" data-v="" aria-label="Aucune">' + I.cross + "</button>" + Object.keys(IL.RCOL).map(function (k) { var on = r2.accent === k; return '<button class="sw' + (on ? " on" : "") + '" data-a="rset" data-k="accent" data-v="' + k + '" aria-label="' + k + '" aria-pressed="' + on + '" style="background:' + IL.RCOL[k][0] + '"></button>'; }).join("") + "</div></div>" +
        (r2.accent ? '<div class="field"><span class="lbl">Motif du cadre</span><div class="chips">' + IL.PATTERNS.map(function (pt) { var on = (r2.pattern || "uni") === pt[0]; return '<button class="chip' + (on ? " on" : "") + '" data-a="rset" data-k="pattern" data-v="' + pt[0] + '" aria-pressed="' + on + '">' + pt[1] + "</button>"; }).join("") + "</div></div>" : "") : "") +
      '<div class="field"><label for="r-str">Cordage</label><input id="r-str" type="text" data-r="string" value="' + esc(r2.string) + '" placeholder="Ex. : RPM Blast 1,25"></div>' +
      '<div class="field"><span class="lbl">Type de cordage' + (!r2.stringType && ty ? ' <span class="small">· deviné d\'après le nom</span>' : "") + '</span><div class="chips">' + STYPES.map(function (x) { return '<button class="chip' + (ty === x[0] ? " on" : "") + '" data-a="rtype" data-v="' + x[0] + '">' + x[1] + "</button>"; }).join("") + "</div></div>" +
      tensionHtml(r2, "racket") +
      '<label class="field inline check" style="margin:0"><span>Raquette principale</span><input type="checkbox" data-r="main"' + (r2.main ? " checked" : "") + "></label>" +
      "</div>";
    s += "<h2>Cordages</h2><div class=\"card\" style=\"gap:8px\">" +
      (st.known ? '<span style="font-size:22px;font-weight:700;letter-spacing:-.02em">' + (st.min ? "≈ " + fmtHours(st.min) + " de jeu" : "Cordage neuf") + "</span>" +
        (ty === "mono" ? '<div class="meter" role="img" aria-label="' + fmtHours(st.min) + ' sur 20 h"><span class="track"><span class="fill" style="display:block;width:' + Math.min(100, st.min / MONO_MAX * 100) + "%;background:" + (st.level === "ok" ? "var(--chart-v)" : "var(--terre)") + '"></span></span><b>20 h</b></div>' : "") +
        '<span class="small">' + esc([st.nm ? plural(st.nm, "match") : "", st.nt ? plural(st.nt, "entraînement") : ""].filter(Boolean).join(" et ")) + (st.nm || st.nt ? " · " : "") + "depuis " + (st.since ? "le " + fdate(st.since).replace(/\.$/, "") : "le dernier changement") + ".</span>" +
        (st.level === "change" ? '<span class="neg">Plus de 20 h sur un monofilament : il est temps de le changer.</span>' : st.level === "soon" ? '<span class="neg">Bientôt 20 h : prévois de le changer.</span>' : "")
      : '<span style="font-size:20px;font-weight:700">Date de cordage inconnue</span>' +
        '<span class="small">Ajoute la date du dernier cordage ci-dessous (ou coche « Cordage neuf » sur le premier match ou entraînement après). Sans ça, Montée ne sait pas si ton cordage est frais.</span>') +
      rs.map(function (x) {
        return '<div class="kv" style="align-items:center"><label for="rs-' + x.i + '">Cordée le</label><span style="display:flex;gap:6px;align-items:center"><input id="rs-' + x.i + '" type="date" data-rs="' + x.i + '" value="' + esc(x.d) + '" max="' + E.iso(today()) + '" style="border:none;background:var(--bg);border-radius:10px;min-height:40px;padding:4px 8px;font-size:15px"><button class="iconbtn" data-a="delRestring" data-v="' + x.i + '" aria-label="Retirer ce cordage" style="width:40px;height:40px;background:var(--chip)">' + I.cross + "</button></span></div>";
      }).join("") +
      '<div class="grid2"><button class="btn balle small" data-a="restring">Recordée aujourd\'hui</button><button class="btn soft small" data-a="addRestring" style="background:var(--chip)">Autre date</button></div>' +
      (isNew ? "" : st.level === "broken" ? '<span class="neg">Cordage cassé le ' + fdate(brokenNow(racket(r2.id) || r2).date).replace(/\.$/, "") + " : touche « Recordée aujourd\'hui » quand c\'est fait.</span>" : '<button class="btn danger small" data-a="breakString">J\'ai cassé mon cordage</button>') +
      ((r2.breaks || []).length ? '<span class="small">' + plural(r2.breaks.length, "casse notée", "casses notées") + (st.breakAvg ? " · en moyenne vers " + fmtHours(st.breakAvg.avg) + " de jeu (toutes raquettes). Montée te prévient quand tu t\'en approches." : "") + "</span>" : "") +
      "</div>";
    if (!isNew) s += adviceHtml(r2, st, ty);
    s += saveBar("saveRacket", r2, isNew) + "</div>";
    return s;
  };

  // Conseils cordage et raquette : repères courants des cordeurs, adaptés à ta raquette
  function adviceHtml(r, st, ty) {
    var tips = [];
    var regle = ["Un repère simple", "Recorde au moins autant de fois par an que tu joues de fois par semaine : 2 séances par semaine, 2 cordages par an minimum. N'attends pas la casse."];
    if (ty === "mono") {
      tips.push(["Recorde vers 15 à 20 h de jeu", "Un monofilament (polyester) perd vite sa tension, puis devient raide et « mort » bien avant de casser. Au-delà de 20 h, il ne te rend plus ce qu'il te donnait neuf."]);
      tips.push(["Ménage ton bras", "Le polyester est le cordage le plus raide. Au moindre mal au coude ou à l'épaule, passe en hybride (mono en montants, multi en travers) ou en multifilament."]);
      tips.push(["Tension : un peu plus bas", "Si tu viens d'un multifilament, baisse de 1 à 2 kg pour compenser la raideur, puis ajuste à l'essai."]);
      if (st.since && (today() - E.parseDate(st.since)) / 864e5 > 70) tips.unshift(["Plus de 10 semaines", "Même sans jouer beaucoup, un polyester posé il y a plus de 10 semaines a perdu de sa tension. Pense à le changer."]);
    } else if (ty === "multi") {
      tips.push(["Confort et puissance", "Un multifilament est souple et doux pour le bras. Pas besoin de surveiller les heures comme un polyester : change-le quand il s'effiloche ou que tu perds en contrôle."]);
      tips.push(regle);
    } else if (ty === "hybride") {
      tips.push(["Le meilleur des deux", "Le monofilament en montants apporte contrôle et durée, le multi ou le boyau en travers apporte du confort. Il vieillit plus doucement qu'un full polyester."]);
      tips.push(regle);
    } else if (ty === "boyau") {
      tips.push(["Boyau naturel", "Le plus confortable et celui qui garde le mieux sa tension. Il craint l'humidité : évite de jouer sous la pluie avec."]);
      tips.push(regle);
    } else if (ty === "synth") {
      tips.push(["Synthétique", "Économique et polyvalent, mais il perd ses sensations assez vite. Si tu casses souvent ou veux plus d'effet, essaie un hybride."]);
      tips.push(regle);
    } else {
      tips.push(["Indique le type de cordage", "Monofilament, multifilament ou hybride : c'est ce qui permet à Montée de te dire quand recorder."]);
    }
    tips.push(["La tension baisse dès la pose", "Un cordage perd 10 à 30 % de sa tension dans les 48 h après la pose, même sans jouer. Ne laisse pas ta raquette dans une voiture au soleil : la chaleur accélère la perte."]);
    var others = S.rackets.filter(function (x) { return x.id !== r.id; });
    var diff = others.filter(function (x) { return x.tension && r.tension && (Math.abs(x.tension - r.tension) >= 1 || stringType(x) !== ty); })[0];
    if (diff) tips.push(["Tes raquettes ne sont pas cordées pareil", esc(r.name) + " : " + esc([typeLabel(ty), fmtTension(r)].filter(Boolean).join(", ")) + ". " + esc(diff.name) + " : " + esc([typeLabel(stringType(diff)), fmtTension(diff)].filter(Boolean).join(", ")) + ". En match, mieux vaut deux raquettes identiques, recordées ensemble avant un tournoi."]);
    else if (!others.length) tips.push(["Une raquette de secours", "Une casse en match sans deuxième raquette, c'est un match qui bascule. Idéalement, une seconde raquette identique, cordée pareil."]);
    var ms = S.matches.filter(function (m) { return m.racketId === r.id && !m.wo && (m.result === "V" || m.result === "D") && r.string && m.string && m.string.trim().toLowerCase() === r.string.trim().toLowerCase(); });
    if (ms.length >= 3) { var v = ms.filter(function (m) { return m.result === "V"; }).length; tips.push(["Avec ce cordage, toi", "Tu as gagné " + v + " matchs sur " + ms.length + " avec " + esc(r.string) + "."]); }
    return '<details class="card advice"><summary><b>Conseils cordage</b><span class="small">' + plural(tips.length + 1, "repère") + " pour ta raquette</span></summary><div class=\"stack\" style=\"gap:8px\">" + tips.map(function (t) { return '<div class="card" style="gap:4px;padding:14px 16px"><b style="font-size:15px">' + t[0] + '</b><span style="font-size:14px;line-height:1.45">' + t[1] + "</span></div>"; }).join("") +
      '<p class="small">Repères courants des cordeurs, pas une règle : ton ressenti passe avant.</p></div></details>';
  }

  // ---------- Ten'Up ----------
  function rowsFromText(t) {
    var rows = P.parse(t);
    var have = {};
    S.matches.forEach(function (m) { have[m.date + "|" + m.oppRank + "|" + m.result] = 1; });
    return rows.map(function (r) { r.dup = !!have[r.date + "|" + r.oppRank + "|" + r.result]; r.keep = r.ok && !r.dup; r.id = uid(); return r; });
  }
  // ---------- Rapprochement Ten'Up ↔ matchs déjà dans Montée ----------
  // Chaque match Ten'Up est rapproché d'au plus un match existant (un-pour-un), même saisi à la main :
  // même résultat, date à 3 jours près (ou sans date), et même adversaire ou même classement.
  // Le match existant garde tes annotations (raquette, ressenti, notes) et prend les infos officielles.
  function nameTokens(n) { return String(n || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().split(/[^a-z]+/).filter(function (t) { return t.length >= 3; }); }
  function sameName(a, b) {
    var ta = nameTokens(a), tb = nameTokens(b);
    return ta.some(function (t) { return tb.indexOf(t) >= 0; });
  }
  function dayDiff(a, b) { return Math.abs((E.parseDate(a) - E.parseDate(b)) / 864e5); }
  function reconcile(rows) {
    var claimed = {}, removed = 0, confirmed = 0;
    var key = function (x) { return x.date + "|" + nameKey(x.opp) + "|" + x.oppRank + "|" + x.result; };
    // 1. correspondances exactes avec ce qui vient déjà de Ten'Up
    var exact = {};
    S.matches.forEach(function (m) { if (m.source === "tenup" && m.date) (exact[key(m)] = exact[key(m)] || []).push(m); });
    rows.forEach(function (r) {
      var l = exact[key(r)]; if (!l) return;
      var m = l.filter(function (x) { return !claimed[x.id]; })[0];
      if (m) { claimed[m.id] = 1; r.match = m; }
    });
    // 2. rapprochement souple avec les matchs saisis à la main (ou venus d'un PDF sans date)
    rows.forEach(function (r) {
      if (r.match || !r.result) return;
      var best = null, bestScore = 0;
      S.matches.forEach(function (m) {
        if (claimed[m.id] || m.result !== r.result || (m.source === "tenup" && m.date)) return;
        var d = m.date && r.date ? dayDiff(m.date, r.date) : 0;
        if (d > 3) return;
        var sc = (sameName(m.opp, r.opp) ? 3 : 0) + (m.oppRank && m.oppRank === r.oppRank ? 2 : 0) - d * 0.5;
        if (!sameName(m.opp, r.opp) && !(m.oppRank && m.oppRank === r.oppRank)) return;
        if (sc > bestScore) { bestScore = sc; best = m; }
      });
      if (best) { claimed[best.id] = 1; r.match = best; }
    });
    // 3. fusion : Ten'Up fait foi pour la date, l'adversaire, le score ; tes annotations restent
    rows.forEach(function (r) {
      var m = r.match;
      if (m) {
        if (isManual(m)) { confirmed++; m.confirmedAt = E.iso(today()); m.manualOrigin = true; }
        m.date = r.date || m.date; if (r.opp) m.opp = r.opp; if (r.oppRank) m.oppRank = r.oppRank;
        if (r.score) m.score = r.score; if (!m.kindSet) m.kind = r.kind; m.wo = r.wo; m.source = "tenup"; if (r.comp) m.comp = r.comp;
      }
      r.dup = !!m; r.keep = r.ok && !m; r.id = uid(); delete r.match;
    });
    // 4. ce qui venait de Ten'Up et n'y est plus (ex. doubles importés par erreur) est retiré
    S.matches = S.matches.filter(function (m) {
      if (m.source !== "tenup" || !m.date || claimed[m.id]) return true;
      removed++; return false;
    });
    return { removed: removed, confirmed: confirmed };
  }
  function isManual(m) { return !m.source || m.source === "manual"; }
  function importPayload(pl, opts) {
    opts = opts || {};
    if (!opts.quiet) history.replaceState(null, "", location.pathname + "#/tenup");
    if (pl.error) { if (opts.quiet) return; UI.importError = pl.error; UI.importRows = null; render(); return; }
    if (!NATIVE && pl.sv !== T.VERSION) setTimeout(function () { toast("Ton favori Montée est ancien : recopie-le depuis l'écran Ten'Up."); }, 3200);
    UI.importError = null; UI.wiz = null;
    var rows = T.rows(pl), have = {};
    var rec = reconcile(rows), removed = rec.removed, confirmedN = rec.confirmed;
    var doubles = 0;
    if (pl.raw && pl.raw.length) {
      S.doubles = T.doublesRows(pl).map(function (r) { r.id = "d" + uid(); r.source = "tenup"; return r; });
      doubles = S.doubles.length;
    }
    // profil
    var pr = pl.profil || {}, msg = [];
    var rk = T.normRank(pr.classement);
    if (rk && E.idx(rk) != null && rk !== S.profile.rank) { if (S.profile.rank) msg.push("classement mis à jour : " + rk); S.profile.rank = rk; }
    if (pr.sexe === "F" || pr.sexe === "H") S.profile.sex = pr.sexe;
    if (rk && E.idx(rk) != null) S.tenupRank = rk;
    if (!S.profile.name && pr.prenom) S.profile.name = (function (n) { return n.charAt(0).toUpperCase() + n.slice(1).toLowerCase(); })(String(pr.prenom).split(/[\s-]/)[0]);
    if (pr.licence && !S.profile.licence) S.profile.licence = String(pr.licence);
    S.tenup = Object.assign({}, S.tenup, { lastImport: E.iso(today()), official: T.official(pl), sample: pl.sample || null, id: pl.id });
    matchOfficialDoubles();
    S.onboarded = true;
    var todo = rows.filter(function (r) { return !r.ok && !r.dup; });
    if (opts.quiet) {
      var addq = rows.filter(function (r) { return r.keep; });
      addq.forEach(addImported);
      calibrateFromTenup();
      S.tenup.lastAuto = Date.now(); save(); syncNative();
      var parts = [];
      if (addq.length) parts.push(plural(addq.length, "nouveau match", "nouveaux matchs") + " importé" + (addq.length > 1 ? "s" : ""));
      if (confirmedN) parts.push(plural(confirmedN, "match saisi à la main confirmé", "matchs saisis à la main confirmés") + " par Ten'Up");
      if (msg.length) parts.push(msg.join(", "));
      if (parts.length) toast(parts.join(" · ").replace(/^./, function (x) { return x.toUpperCase(); }) + ".");
      else if (opts.pull) toast("Tout est à jour : rien de nouveau sur Ten'Up.");
      render();
      return;
    }
    if (!todo.length) {
      var add = rows.filter(function (r) { return r.keep; });
      add.forEach(addImported);
      calibrateFromTenup();
      save(); syncNative();
      toast((add.length ? plural(add.length, "nouveau match", "nouveaux matchs") + " depuis Ten'Up" : "Ton palmarès est à jour") +
        (doubles ? " · " + plural(doubles, "double", "doubles") + " (bonus)" : "") + (removed ? " · " + plural(removed, "match retiré", "matchs retirés") : "") + (confirmedN ? " · " + plural(confirmedN, "match saisi à la main confirmé", "matchs saisis à la main confirmés") : "") + (msg.length ? " · " + msg.join(", ") : "") + ".");
      go(S.profile.rank ? "" : "profil");
      return;
    }
    save();
    UI.importRows = rows; render();
  }
  // Ten'Up donne son propre bilan pour la prochaine sortie : on s'aligne dessus.
  // L'écart (règles que Ten'Up ne détaille pas) devient « Ajustement d'après Ten'Up ».
  // On mémorise les bilans officiels par échelon et les matchs que Ten'Up connaissait.
  // L'écart est recalculé à chaque affichage (classement, palmarès à jour) ; les matchs
  // ajoutés ensuite à la main s'ajoutent par-dessus.
  function calibrateFromTenup() {
    var o = S.tenup && S.tenup.official; if (!o) return;
    var raw = o.pdf ? [{ c: o.atRank, pts: o.pts }] : (o.simulation || []);
    var lines = raw.map(function (x) {
      return { at: E.idx(T.normRank(x.c) || x.c), pts: x.pts === "" || x.pts == null ? NaN : Number(x.pts) };
    }).filter(function (l) { return l.at != null && l.at >= 0 && l.at <= E.MAX_CALC && isFinite(l.pts); });
    delete S.tenup.extra;
    if (!lines.length) { delete S.tenup.cal; return; }
    var day = o.at ? new Date(o.at) : today(); day = new Date(day.getFullYear(), day.getMonth(), day.getDate());
    var rel = E.nextRelease(day);
    var w = E.windowMatches(allMatches(), rel, day);
    S.tenup.cal = { release: E.iso(rel), ids: w.map(function (m) { return m.id; }), lines: lines };
  }
  function tenupExtra(release, me) {
    var c = S.tenup && S.tenup.cal;
    if (!c || !c.lines || !c.lines.length || c.release !== E.iso(release)) return 0;
    var ids = {}; c.ids.forEach(function (i) { ids[i] = 1; });
    var w = E.windowMatches(allMatches().filter(function (m) { return ids[m.id]; }), release, today());
    if (me == null || me < -1) me = -1;
    var map = {}, n = 0;
    c.lines.forEach(function (l) {
      var g = l.pts - E.bilanAt(w, l.at, S.profile.sex, me).total;
      if (Math.abs(g) <= 300) { map[l.at] = g; n++; }
    });
    return n ? map : 0;
  }
  function tenupCall(cred, keep) {
    if (UI.loading) return;
    UI.loading = true; UI.importError = null; render();
    fetch("api/tenup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: cred.email, password: cred.password, licence: S.profile.licence || "" }) })
      .then(function (r) {
        if (r.status === 404) throw new Error("La connexion directe n'est pas installée sur ce site : déploie Montée avec Git ou la commande Netlify (voir README), pas par glisser-déposer.");
        return r.json();
      })
      .then(function (j) {
        UI.loading = false;
        if (!j.ok) {
          if (j.code === "credentials") delete S.tenup.cred;
          S.tenup.lastError = { at: new Date().toISOString(), code: j.code, error: j.error, trace: j.trace || [], page: j.page || null }; save();
          UI.importError = j.error || "Erreur inconnue.";
          if (route() !== "tenup") go("tenup"); else render();
          return;
        }
        if (keep) S.tenup.cred = { email: cred.email, password: cred.password };
        save();
        importPayload(j.payload);
      })
      .catch(function (e) {
        UI.loading = false;
        UI.importError = e && e.message && e.message.indexOf("Netlify") >= 0 ? e.message : "Pas de réponse. Vérifie ta connexion internet et réessaie.";
        if (route() !== "tenup") go("tenup"); else render();
      });
  }
  // Points du bonus double donnés par Ten'Up : on les rattache à nos doubles par les noms des adversaires
  function pairKey(names) { return names.map(function (n) { return nameKey(String(n).split(/\s+/).slice(-1)[0]); }).filter(Boolean).sort().join("+"); }
  function matchOfficialDoubles() {
    var od = (S.tenup && S.tenup.official && S.tenup.official.doubles) || [];
    (S.doubles || []).forEach(function (m) { delete m.officialPts; });
    if (!od.length) return;
    var pool = od.map(function (x) { return { k: pairKey(x.names), pts: x.pts, used: false }; });
    (S.doubles || []).filter(function (m) { return m.result === "V" && !m.wo; }).sort(function (a, b) { return a.date < b.date ? 1 : -1; }).forEach(function (m) {
      var k = pairKey(String(m.opp || "").split(" / "));
      var hit = pool.filter(function (p) { return !p.used && p.k === k; })[0];
      if (hit) { hit.used = true; m.officialPts = hit.pts; }
    });
  }
  function addImported(r) {
    S.matches.push({ id: uid(), date: r.date, opp: r.opp, oppRank: r.oppRank, result: r.result, wo: r.wo, score: r.score, kind: r.kind, comp: r.comp || "", surface: "", indoor: null, racketId: "", string: "", tension: null, tensionCross: null, feel: null, note: "", source: "tenup" });
  }
  function officialHtml(full) {
    var o = S.tenup && S.tenup.official;
    if (!o || !o.at) return "";
    var d = new Date(o.at), age = (today() - new Date(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5;
    if (age > 45) return "";
    var s = '<div class="card" style="gap:6px"><div style="display:flex;justify-content:space-between;gap:8px;align-items:baseline"><b style="font-size:15px">Simulation officielle Ten\'Up</b><span class="small">importée le ' + esc(fdate(E.iso(d))) + "</span></div>";
    if (o.pdf) {
      if (o.month) s += '<span class="small">Classement de ' + esc(o.month) + "</span>";
      if (o.calculated) s += '<div class="kv"><span>Classement calculé</span><b>' + esc(o.calculated) + "</b></div>";
      if (o.pts != null) s += '<div class="kv"><span>Bilan à ' + esc(o.atRank || "") + "</span><b>" + o.pts + (o.needed != null ? " / " + o.needed : "") + "</b></div>";
      if (full && o.counted != null) s += '<div class="kv"><span>Victoires comptabilisées</span><b>' + o.counted + "</b></div>";
    } else {
      var lines = (o.simulation && o.simulation.length ? o.simulation : o.bilans || []).filter(function (x) { return x.c; });
      if (o.message) s += '<span style="font-size:15px;line-height:1.4">' + esc(o.message) + "</span>";
      s += lines.slice(0, 4).map(function (x) { return '<div class="kv"><span>À ' + esc(x.c) + "</span><b>" + (x.pts != null ? x.pts : "?") + (x.quota != null ? " / " + x.quota : "") + "</b></div>"; }).join("");
    }
    if (age > 7) s += '<span class="small">Pense à la réimporter après tes prochains matchs.</span>';
    return s + "</div>";
  }

  // ---- Import d'une page Ten'Up en PDF ----
  function nameKey(n) { return String(n || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z]/g, ""); }
  function importPdfFile(file) {
    if (!file) return;
    UI.loading = true; UI.importError = null; render();
    window.MonteePdf.linesFromFile(file).then(function (lines) {
      UI.loading = false;
      var r = window.MonteePdf.parse(lines);
      if (r.kind === "simulation") return applySimulation(r);
      if (r.kind === "palmares") {
        UI.importError = "C'est la page Palmarès : elle ne dit pas qui a gagné. Ouvre plutôt l'onglet « Simu » de Ten'Up et refais le PDF.";
        return render();
      }
      UI.importError = "Ce PDF ne ressemble pas à une page Ten'Up. Ouvre l'onglet « Simu » de ta page joueur, puis refais le PDF.";
      render();
    }).catch(function () {
      UI.loading = false; UI.importError = "Impossible de lire ce fichier. Choisis le PDF de la page « Simu » de Ten'Up."; render();
    });
  }
  function applySimulation(r) {
    var msg = [];
    var pr = r.profile || {};
    if (pr.rank && E.idx(pr.rank) != null && pr.rank !== S.profile.rank) { if (S.profile.rank) msg.push("classement : " + pr.rank); S.profile.rank = pr.rank; }
    if (pr.name && !S.profile.name) S.profile.name = (function (n) { return n.charAt(0).toUpperCase() + n.slice(1).toLowerCase(); })(pr.name.split(/\s+/)[0]);
    if (pr.licence) S.profile.licence = pr.licence;
    // Les matchs Ten'Up de la période remplacent l'import précédent ; on garde les annotations.
    var old = S.matches.filter(function (m) { return m.source === "tenup-pdf"; });
    var keep = S.matches.filter(function (m) { return m.source !== "tenup-pdf"; });
    var used = {}, added = 0;
    var take = function (pool, k) {
      for (var i = 0; i < pool.length; i++) {
        var m = pool[i];
        if (!used[m.id] && nameKey(m.opp) + "|" + m.oppRank + "|" + m.result === k) { used[m.id] = 1; return m; }
      }
      return null;
    };
    var fresh = r.rows.map(function (x) {
      var k = nameKey(x.opp) + "|" + x.oppRank + "|" + x.result;
      var prev = take(old, k) || take(keep, k);
      if (!prev) added++;
      var m = prev ? Object.assign({}, prev) : { id: uid(), date: "", score: "", wo: false, kind: "tournoi", surface: "", indoor: null, racketId: "", string: "", tension: null, tensionCross: null, feel: null, note: "" };
      m.opp = prev && prev.opp ? prev.opp : x.opp; m.oppRank = x.oppRank; m.result = x.result; m.officialPts = x.pts; m.source = "tenup-pdf";
      return m;
    });
    S.matches = keep.filter(function (m) { return !used[m.id]; }).concat(fresh);
    // Écart entre notre calcul et Ten'Up (bonus, coefficients) à l'échelon calculé par Ten'Up
    var o = r.official || {};
    S.tenup.official = { pdf: true, at: new Date().toISOString(), month: r.month, period: r.period, atRank: o.at, pts: o.pts, needed: o.needed, counted: o.counted, calculated: o.calculated };
    calibrateFromTenup();
    S.tenup.snapshots = (S.tenup.snapshots || []).concat([{ at: E.iso(today()), month: r.month, rank: o.at, pts: o.pts, needed: o.needed }]).slice(-24);
    S.tenup.lastImport = E.iso(today()); S.onboarded = true; save();
    toast(plural(r.rows.length, "match", "matchs") + " importés" + (added ? " (" + added + " nouveau" + (added > 1 ? "x" : "") + ")" : "") + (msg.length ? " · " + msg.join(", ") : "") + ".");
    go("");
  }

  // ---------- App iPhone : liaison Ten'Up, actualisation, notifications ----------
  function nativeScript() { return T.nativeScript(S.profile.licence || "", S.tenup.id || ""); }
  function tenupKeys() {
    return S.matches.filter(function (m) { return m.source === "tenup" && m.date; }).map(function (m) { return m.date + "|" + m.oppRank + "|" + m.result; });
  }
  function syncNative() {
    if (!NATIVE || !S.tenup.linked) return;
    var me = E.idx(S.profile.rank);
    var st = { keys: tenupKeys(), rank: S.profile.rank, sex: S.profile.sex, extra: tenupExtra(E.nextRelease(today()), me == null ? -1 : me) };
    Tenup.setState({ state: JSON.stringify(st), script: nativeScript() }).catch(function () {});
    scheduleReleaseNotif();
  }
  function scheduleReleaseNotif() {
    if (!NATIVE || !S.notif) return;
    var c = ctx(), rel = new Date(c.proj.release.getTime()); rel.setHours(8, 30, 0, 0);
    if (rel <= new Date() || c.proj.status === "top") return;
    var body = window.monteeStatusLine ? window.monteeStatusLine(c.proj) : "";
    LN.cancel({ notifications: [{ id: 1001 }] }).catch(function () {}).then(function () {
      return LN.schedule({ notifications: [{ id: 1001, title: "Sortie du classement aujourd'hui", body: body || "Ouvre Montée pour voir où tu en es.", schedule: { at: rel } }] });
    }).catch(function () {});
  }
  function handleNativeResult(data, quiet, pull) {
    var pl = T.decode(data || "");
    if (pl && !pl.error) { S.tenup.linked = true; S.tenup.expired = false; importPayload(pl, { quiet: quiet || pull, pull: pull }); return true; }
    // Session Ten'Up perdue (page de connexion au lieu de Ten'Up) : on rouvre directement la connexion
    var why = String((pl && pl.error) || data || "");
    if (/connecte-toi|ouvre d'abord|tenup\.fft\.fr|auth/i.test(why)) {
      S.tenup.expired = true; save();
      if (!quiet) { UI.importError = null; toast("Ta session Ten'Up a expiré : reconnecte-toi sur la page qui s'ouvre."); render(); setTimeout(nativeConnect, 600); }
    }
    else if (pull) toast("Ten'Up n'a pas répondu. Réessaie dans un instant.");
    else if (!quiet) { UI.importError = (pl && pl.error) || "Ten'Up n'a pas répondu. Réessaie dans un instant."; render(); }
    return false;
  }
  function nativeConnect() {
    UI.importError = null;
    Tenup.connect({ script: nativeScript() }).then(function (r) {
      if (r && r.data) { S.tenup.linked = true; handleNativeResult(r.data, false); askNotif(); }
    }).catch(function (e) { UI.importError = "Connexion impossible (" + (e && e.message || e) + ")."; render(); });
  }
  function nativeRefresh(quiet, pull) {
    if (!NATIVE || UI.loading) return Promise.resolve();
    if (!S.tenup.linked || S.tenup.expired) { if (pull) { toast("Connecte-toi à Ten'Up sur la page qui s'ouvre."); nativeConnect(); } return Promise.resolve(); }
    UI.loading = true; if (!quiet && !pull) render();
    return Tenup.refresh({ script: nativeScript() }).then(function (r) {
      UI.loading = false; S.tenup.lastAuto = Date.now(); save();
      if (!handleNativeResult(r && r.data, quiet, pull) && (quiet || pull)) render();
    }).catch(function () { UI.loading = false; if (pull) toast("Ten'Up n'a pas répondu. Réessaie dans un instant."); else if (!quiet) { UI.importError = "Ten'Up n'a pas répondu."; render(); } });
  }
  function askNotif() {
    if (!NATIVE) return;
    LN.requestPermissions().then(function (p) { S.notif = p && p.display === "granted"; save(); syncNative(); render(); }).catch(function () {});
  }
  // ---------- Widgets de l'écran d'accueil (app native) ----------
  // Montée calcule ici ce que les widgets affichent ; le téléphone ne fait que le dessiner.
  function widgetData() {
    var d = { v: 1, updated: Date.now(), rank: effRank() || "", status: "none" };
    if (!S.matches.length || !S.profile.rank) { d.line = "Ajoute tes matchs pour savoir si tu montes"; d.headline = d.line; return finishWidget(d); }
    var c = ctx(), p = c.proj;
    d.releaseIso = E.iso(p.release);
    if (S.ahead) {
      d.status = "montee"; d.rank = S.ahead.rank; d.from = S.ahead.from; d.releaseIso = S.ahead.release;
      d.line = "dans la poche"; d.headline = "Tu montes à " + S.ahead.rank + " : c'est dans la poche";
      d.target = S.ahead.from + " → " + S.ahead.rank;
      if (p.status !== "top" && p.next) d.next = "Prochain objectif : " + p.next.label + (p.gap ? ", il manque " + p.gap + " pts" : p.needWin ? ", une victoire contre un " + p.next.label : "");
    } else if (p.status === "top") {
      d.status = "top"; d.line = "Joueur numéroté"; d.headline = "Classement au concours des meilleurs bilans";
    } else if (p.status === "descente") {
      d.status = "descente"; d.line = "maintien menacé : −" + (p.here.norme - p.here.total) + " pts"; d.headline = "Attention : risque de descente à " + lab(p.projected);
      d.target = effRank() + " → " + lab(p.projected);
    } else {
      d.status = "maintien";
      var nx = p.next, ezp = easiest(pistes(c)), mw = ezp && ezp.k === 1 ? ezp.top : undefined;
      d.target = effRank() + " → " + nx.label;
      d.line = "→ " + nx.label + " : " + (p.gap ? "il manque " + p.gap + " pts" : "une victoire contre un " + nx.label);
      d.headline = p.gap === 0 && p.needWin ? "Il te manque une victoire contre un " + nx.label : (mw !== undefined && mw !== null) ? "Ça se joue à une victoire contre un " + lab(mw) : "Il te manque " + plural(p.gap, "point") + " pour " + nx.label;
    }
    if (p.next && p.status !== "top") { d.total = p.next.total; d.norme = p.next.norme; d.pct = p.next.norme ? Math.min(100, Math.round(p.next.total * 100 / p.next.norme)) : 100; d.label = p.next.label; }
    // forme
    var played = sortedMatches().filter(function (m) { return m.date && !m.wo && (m.result === "V" || m.result === "D"); });
    d.form = played.slice(0, 5).map(function (m) { return m.result; }).reverse();
    var st = 0; for (var i = 0; i < played.length && played[i].result === played[0].result; i++) st++;
    d.streak = played.length ? plural(st, played[0].result === "V" ? "victoire" : "défaite") + " d'affilée" : "Pas encore de match";
    var w12 = p.matches || [];
    d.record = w12.filter(function (m) { return m.result === "V" && !m.wo; }).length + " V · " + w12.filter(function (m) { return m.result === "D" && !m.wo; }).length + " D sur 12 mois";
    d.recordShort = d.record.replace(" sur 12 mois", "");
    // Textes courts pour les widgets
    d.rankNow = effRank();
    if (d.status === "maintien") {
      var nx2 = p.next, ez2 = easiest(pistes(c)), one2 = ez2 && ez2.k === 1;
      d.short = p.gap === 0 && p.needWin ? "Tu as les points" : one2 ? "Une victoire peut suffire" : "Il manque " + plural(p.gap, "pt");
      d.sub = p.gap === 0 && p.needWin ? "Il manque la victoire qui valide : bats un " + nx2.label + "." : one2 ? "Contre un " + lab(ez2.top) + " ou mieux." : ez2 ? "Piste : " + pisteLabel(ez2) + "." : "Vise plutôt la sortie suivante.";
    } else if (d.status === "descente") {
      d.short = "Il manque " + plural(p.here.norme - p.here.total, "pt") + " pour rester";
      d.sub = "Bilan à " + lab(c.cur < 0 ? 0 : c.cur) + " : " + p.here.total + " / " + p.here.norme;
    }
    try {
      var b0 = p.status === "descente" ? p.here : p.next;
      if (b0 && c.cur >= 0 && p.status !== "top") {
        var rel = p.release, ser = [], all = allMatches(), MO = ["janv", "févr", "mars", "avr", "mai", "juin", "juil", "août", "sept", "oct", "nov", "déc"];
        for (var k6 = 0; k6 < 6; k6++) { var bb = E.bilanAt(E.windowMatches(all, rel, today()), b0.calc, c.sex, c.cur, c.opts.extra); ser.push({ m: MO[rel.getMonth()], total: bb.total, norme: bb.norme }); rel = E.nextRelease(rel); }
        var worst = 0, wd = 0;
        for (var j6 = 1; j6 < ser.length; j6++) { var dd6 = ser[j6 - 1].total - ser[j6].total; if (dd6 > wd) { wd = dd6; worst = j6; } }
        if (ser[0].total - ser[5].total > 0) d.defend = { pts: ser, worst: wd ? worst : -1, caption: wd ? ser[worst].m.replace(/^./, function (x) { return x.toUpperCase(); }) + " : −" + wd + " pts" : "" };
      }
      var ins = insights(c); if (ins.length) { ins.sort(function (a, b) { return b.score - a.score; }); d.truc = ins[0].text; }
    } catch (e) {}
    var pts = countedMap(p.next);
    d.last = played.slice(0, 8).map(function (m) { var dt = E.parseDate(m.date); return { r: m.result, date: dt.getDate() + " " + MOIS[dt.getMonth()], opp: (m.opp || "Adversaire") + " · " + m.oppRank, right: m.result === "V" ? (pts[m.id] != null ? "+" + pts[m.id] : "hors quota") : (m.score || "") }; });
    return finishWidget(d);
  }
  function finishWidget(d) {
    var rk = bag().filter(function (r) { return r.main; })[0] || bag()[0];
    if (rk) {
      var st = racketStatus(rk);
      d.racket = { id: rk.id, name: rk.name, hours: st.known ? "≈ " + fmtHours(st.min) : "?", level: st.level,
        pct: st.known && st.type === "mono" ? Math.min(100, Math.round(st.min * 100 / MONO_MAX)) : st.known ? Math.min(100, Math.round(st.min * 100 / (40 * 60))) : 0,
        msg: st.level === "broken" ? "Cordage cassé" : st.level === "change" ? "À recorder" : st.level === "soon" ? "Bientôt à recorder" : !st.known ? "Date de cordage ?" : st.type === "mono" ? "recorder vers 20 h" : "de jeu sur le cordage" };
    }
    // Détails pour les widgets dessinés (illustration, titre, sac complet)
    var wr = function (r) {
      var st2 = racketStatus(r), mono = st2.type === "mono";
      return { id: r.id, name: r.name || "Raquette", color: r.color || "noir", accent: r.accent, pattern: r.pattern, known: st2.known, level: st2.level,
        hours: st2.known ? fmtHours(st2.min) : "?", max: st2.known && mono ? "sur " + Math.round(MONO_MAX / 60) + " h" : st2.known ? "de jeu" : "",
        pct: st2.known && mono ? Math.min(100, Math.round(st2.min * 100 / MONO_MAX)) : st2.known ? Math.min(100, Math.round(st2.min * 100 / (40 * 60))) : 0,
        title: [r.name, r.string ? r.string.replace(/\s*\d+([.,]\d+)?\s*$/, "") : r.model, fmtTension(r)].filter(Boolean).join(" · "),
        short: st2.level === "broken" ? "cassé" : st2.level === "change" ? "à recorder" : st2.level === "soon" ? "bientôt" : !st2.known ? "date ?" : "OK" };
    };
    if (rk) { var full = wr(rk); for (var kk in full) if (d.racket[kk] === undefined || kk === "hours" || kk === "pct") d.racket[kk] = full[kk]; d.racket.msg = d.racket.msg; }
    d.bag = bag().map(wr);
    // semaine
    var by = activity(), mon = mondayOf(today()), min = 0, days = [];
    for (var i = 0; i < 7; i++) { var x = new Date(mon); x.setDate(x.getDate() + i); var a = by[E.iso(x)]; if (a) min += a.min; days.push(a ? (a.m ? "m" : "t") : ""); }
    var streak = 0, w = new Date(mon), first = true;
    for (var n = 0; n < 104; n++) { var any = false; for (var j = 0; j < 7; j++) { var dd = new Date(w); dd.setDate(dd.getDate() + j); if (by[E.iso(dd)]) { any = true; break; } } if (any) streak++; else if (!first) break; first = false; w.setDate(w.getDate() - 7); }
    var wmins = [], wcount = 0;
    for (var i2 = 0; i2 < 7; i2++) { var x2 = new Date(mon); x2.setDate(x2.getDate() + i2); var a2 = by[E.iso(x2)]; wmins.push(a2 && a2.min ? fmtDur(a2.min) : ""); if (a2) wcount += a2.m + a2.t; }
    d.week = { mins: wmins, count: wcount ? plural(wcount, "séance") : "", total: min ? fmtDur(min) : "0 h", days: days, todayIdx: (today().getDay() + 6) % 7, streak: streak ? plural(streak, "semaine active", "semaines actives") : "" };
    var pend = pendingSlots()[0];
    if (pend) d.week.slot = { label: DAYS_L[pend.sl.dow].replace(/^./, function (c) { return c.toUpperCase(); }) + " " + pend.sl.time + " · " + (pend.sl.label || "Entraînement"), id: pend.sl.id, date: pend.date, ask: true };
    else if ((S.slots || []).length) {
      var nxt = S.slots.slice().map(function (sl) { var k = (sl.dow - (today().getDay() + 6) % 7 + 7) % 7; return { sl: sl, k: k }; }).sort(function (a, b) { return a.k - b.k || (a.sl.time < b.sl.time ? -1 : 1); })[0];
      d.week.slot = { label: "Prochain : " + DAYS_L[nxt.sl.dow] + " " + nxt.sl.time + " · " + (nxt.sl.label || "Entraînement"), ask: false };
    }
    return d;
  }
  var lastWidgetJson = "", widgetTimer = 0, widgetBusy = false;
  function widgetTheme() { var w = (S.prefs && S.prefs.wtheme) || "app"; return w === "app" ? themeNow() : w; }
  function syncWidgets(force) {
    if (!NATIVE || !Tenup || !S.onboarded) return;
    if (force) lastWidgetJson = "";
    clearTimeout(widgetTimer);
    widgetTimer = setTimeout(function () {
      if (widgetBusy) { syncWidgets(); return; }
      var d, json; try { d = widgetData(); delete d.updated; json = JSON.stringify(d); } catch (e) { return; }
      var Art = window.MonteeWidgetArt, theme = widgetTheme();
      // Ancienne version native (sans widgets dessinés) : on envoie juste les données
      if (!Art || !Tenup.widgetInfo) {
        if (json === lastWidgetJson) return; lastWidgetJson = json;
        try { var r = Tenup.setWidgets({ data: json }); if (r && r.catch) r.catch(function () {}); } catch (e) {}
        return;
      }
      widgetBusy = true;
      Promise.resolve(Tenup.widgetInfo()).then(function (info) {
        info = info || {};
        var kinds = info.kinds || [], sizes = info.sizes || {}, scale = Math.min(3, Math.max(2, info.density || 2.5));
        var key = json + "|" + theme + "|" + JSON.stringify(sizes) + "|" + kinds.join(",");
        if (key === lastWidgetJson) return;
        var images = {}, chain = Promise.resolve();
        kinds.forEach(function (k) {
          var sz = sizes[k] || Art.SIZES[k] || [170, 170];
          chain = chain.then(function () { return Art.render(k, d, theme, sz[0], sz[1], scale); }).then(function (b64) { images[k] = b64; }).catch(function () {});
        });
        return chain.then(function () {
          lastWidgetJson = key;
          return Tenup.setWidgetImages({ data: json, images: images });
        });
      }).catch(function () {}).then(function () { widgetBusy = false; });
    }, 700);
  }
  // Action demandée depuis un widget (ouvrir un écran, « J'ai joué »)
  function widgetAction(url) {
    var m = /^montee:\/\/(open|slot)\/?(.*)$/.exec(url || ""); if (!m) return;
    if (m[1] === "open") { go(m[2] || ""); return; }
    var q = {}; (m[2].split("?")[1] || "").split("&").forEach(function (kv) { var p = kv.split("="); if (p[0]) q[p[0]] = decodeURIComponent(p[1] || ""); });
    if (q.id && q.d) { A.slotYes({ dataset: { id: q.id, d: q.d } }); go(""); }
  }
  function nativeWake() {
    if (!NATIVE) return;
    syncWidgets(true); // un widget a pu être ajouté ou redimensionné
    try { var ta = Tenup.takeAction(); if (ta && ta.then) ta.then(function (r) { if (r && r.action) widgetAction(r.action); }).catch(function () {}); } catch (e) {}
    Tenup.takePending().then(function (r) { if (r && r.data) handleNativeResult(r.data, true); }).catch(function () {}).then(function () {
      // Après une mise à jour de l'appli, on resynchronise tout de suite : les nouvelles règles
      // (type de compétition, sens des scores…) s'appliquent à tout le palmarès sans attendre.
      var fresh = S.syncedVersion !== CONFIG.VERSION;
      if (S.tenup.linked && (fresh || !S.tenup.lastAuto || Date.now() - S.tenup.lastAuto > 2 * 3600 * 1000)) {
        var p = nativeRefresh(true);
        if (fresh && p && p.then) p.then(function () { S.syncedVersion = CONFIG.VERSION; save(); });
      }
    });
  }
  // Moteur web Android trop ancien : la page Ten'Up s'affiche mal et ses boutons ne répondent pas
  function oldWebView() {
    if (!(CAP && CAP.getPlatform && CAP.getPlatform() === "android")) return 0;
    var m = /Chrome\/(\d+)/.exec(navigator.userAgent); var v = m ? +m[1] : 0;
    return v && v < 100 ? v : 0;
  }
  function nativeTenupHtml() {
    var s = "", ow = oldWebView();
    if (ow) s += '<div class="card terre" style="gap:8px"><b>Ton téléphone doit d\'abord mettre à jour son moteur web</b>' +
      '<span style="font-size:14px;line-height:1.45">Montée affiche Ten\'Up avec le moteur web d\'Android, et celui de ce téléphone est trop ancien (version ' + ow + ') : la page Ten\'Up s\'affiche en vrac et ses boutons ne marchent pas. Dans le Play Store, mets à jour <b>Android System WebView</b> et <b>Chrome</b>, puis rouvre Montée.</span>' +
      '<a class="btn primary small" href="https://play.google.com/store/apps/details?id=com.google.android.webview">Mettre à jour Android System WebView</a>' +
      '<a class="btn soft small" style="background:var(--chip)" href="https://play.google.com/store/apps/details?id=com.android.chrome">Mettre à jour Chrome</a></div>';
    if (UI.importError) s += '<div class="card terre"><b>Ten\'Up</b><span>' + esc(UI.importError) + "</span>" +
      (S.tenup.linked && !S.tenup.expired ? '<button class="btn soft small" data-a="nativeConnect">' + I.link + " Me reconnecter à Ten'Up</button>" : "") + "</div>";
    if (!S.tenup.linked || S.tenup.expired) {
      s += '<p class="lead" style="font-size:16px">' + (S.tenup.expired ? "Ta session Ten'Up a expiré. Reconnecte-toi : tes matchs reviendront tout seuls." :
        "Connecte ton compte Ten'Up une fois, sur la page officielle de la FFT. Ensuite, Montée récupère tes nouveaux matchs toute seule et te prévient.") + "</p>";
      s += '<button class="btn primary" data-a="nativeConnect">' + I.link + " " + (S.tenup.expired ? "Me reconnecter à Ten'Up" : "Connecter mon compte Ten'Up") + "</button>";
      s += '<p class="small">Tu te connectes directement sur tenup.fft.fr. Montée ne voit pas ton mot de passe et rien n\'est envoyé sur un serveur. Montée n\'est pas lié à la FFT.</p>';
    } else {
      s += '<div class="card"><span class="eyebrow" style="color:var(--gazon)">Compte Ten\'Up lié</span>' +
        '<span style="font-size:15px">' + (S.tenup.lastImport ? "Dernière mise à jour : " + esc(fdate(S.tenup.lastImport)).replace(/\.$/, "") + ". " : "") + "Montée vérifie tes nouveaux matchs à chaque ouverture, et de temps en temps en arrière-plan.</span>" +
        '<button class="btn primary small" data-a="nativeRefresh"' + (UI.loading ? " disabled" : "") + ">" + (UI.loading ? '<span class="spin"></span> Lecture de Ten\'Up…' : "Actualiser maintenant") + "</button></div>";
      s += '<label class="card" style="flex-direction:row;align-items:center;justify-content:space-between;gap:12px;cursor:pointer"><span><b style="display:block;font-size:15px">Notifications</b><span class="small">Nouveau match détecté, points, montée ou pas, jour de sortie</span></span>' +
        '<input type="checkbox" role="switch" data-a="notifSwitch"' + (S.notif ? " checked" : "") + "></label>";
      s += '<button class="linkbtn" data-a="nativeLogout">Délier mon compte Ten\'Up</button>';
    }
    s += '<details class="card"><summary style="font-weight:600;cursor:pointer;min-height:28px">Sans compte : importer un PDF</summary>' +
      '<span style="font-size:14px;line-height:1.45">' + (CAP && CAP.getPlatform && CAP.getPlatform() === "android" ? "Sur Ten\'Up dans Chrome, onglet « Simu » : menu ⋮ › Partager › Imprimer › Enregistrer au format PDF." : "Sur Ten\'Up, onglet « Simu », capture d\'écran › Page entière › Enregistrer le PDF dans Fichiers.") + "</span>" +
      '<label class="btn soft small" style="cursor:pointer;background:var(--chip)">' + (UI.loading ? '<span class="spin"></span> Lecture…' : "Choisir le PDF") + '<input type="file" accept="application/pdf,.pdf" data-a="pdfFile" hidden></label></details>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="skipImport">Pas de compte Ten\'Up ? Je saisis mes matchs à la main</button>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button>';
    return s;
  }

  // ---------- Assistant favori Ten'Up : une étape par écran, avec le dessin de ce qu'on voit ----------
  function wizardHtml(ios, android) {
    var plat = UI.platform || (ios ? "ios" : android ? "android" : "ios"), st = UI.wiz == null ? 0 : UI.wiz, N = 5;
    var and = plat === "android";
    var mock = function (inner, cap) { return '<div class="mock" aria-hidden="true">' + inner + "</div>" + (cap ? '<span class="small" style="text-align:center">' + cap + "</span>" : ""); };
    var bar = function (txt, sugg) { return '<div class="mk-bar"><span class="mk-url">' + txt + '<i class="mk-caret"></i></span></div>' + (sugg ? '<div class="mk-sugg"><span class="mk-star">' + "☆" + "</span><span><b>montee</b><br><span class=\"mk-dim\">javascript:(function(){…</span></span></div>" : ""); };
    var steps = [
      { t: "Relie Ten'Up à Montée", b: "Une seule fois, 2 minutes. Tu vas créer un favori nommé <b>montee</b> dans " + (and ? "Chrome" : "Safari") + ". Ensuite, pour récupérer ton palmarès, tu ouvres Ten'Up et tu touches ce favori. C'est tout.",
        m: mock('<div class="mk-flow"><span class="mk-pill">Ten\'Up</span><span class="mk-arrow">→</span><span class="mk-pill hl">☆ montee</span><span class="mk-arrow">→</span><span class="mk-pill">Montée</span></div>'),
        go: '<button class="btn primary" data-a="wizGo" data-v="1">C\'est parti</button>' },
      { t: "Copie le code du favori", b: "C'est le petit programme qui lira ton palmarès sur Ten'Up, depuis ton téléphone. Rien ne passe par un serveur.",
        m: "", go: '<button class="btn primary" data-a="wizCopy">Copier le code</button>' },
      { t: and ? "Ajoute n'importe quelle page en favori" : "Crée un signet",
        b: and ? "Dans Chrome, sur cette page par exemple : menu <b>⋮</b> en haut à droite, puis touche l'<b>étoile ☆</b>. Un bandeau « Favori ajouté » s'affiche en bas : touche <b>Modifier</b>." :
          "Dans Safari, sur cette page par exemple : touche <b>Partager</b> (le carré avec la flèche), puis <b>Ajouter un signet</b>, puis <b>Enregistrer</b>.",
        m: and ? mock('<div class="mk-menu"><span>← &nbsp; ☆ &nbsp; ⤓ &nbsp; ⓘ &nbsp; ⟳</span><span class="mk-hl">☆</span></div><div class="mk-snack">Favori ajouté <b>Modifier</b></div>', "Le menu ⋮ de Chrome, puis le bandeau en bas") :
          mock('<div class="mk-sheet"><span>Copier</span><span class="mk-hl2">Ajouter un signet</span><span>Ajouter à l\'écran d\'accueil</span></div>', "La feuille Partager de Safari"),
        go: '<button class="btn primary" data-a="wizGo" data-v="3">C\'est fait</button>' },
      { t: "Remplace son adresse par le code", b: and ? "Dans l'écran Modifier : nom <b>montee</b>, puis dans URL, efface tout et colle. Valide avec la flèche en haut." :
          "Ouvre tes signets (icône livre), touche <b>Modifier</b> en bas, puis le signet. Nom : <b>montee</b>. Adresse : efface tout et colle. Touche <b>OK</b>.",
        m: mock('<div class="mk-form"><span class="mk-dim">Nom</span><span class="mk-field">montee</span><span class="mk-dim">' + (and ? "URL" : "Adresse") + '</span><span class="mk-field hl">javascript:(function(){…<i class="mk-caret"></i></span></div>', "Efface l'ancienne adresse, colle à la place"),
        go: '<button class="btn primary" data-a="wizGo" data-v="4">C\'est fait</button><button class="btn soft small" data-a="wizCopy" data-v="stay" style="background:var(--chip)">Recopier le code</button>' },
      { t: "Utilise-le sur Ten'Up", b: "Ouvre Ten'Up dans " + (and ? "Chrome" : "Safari") + " et connecte-toi. Touche la barre d'adresse, tape <b>montee</b>, puis touche le favori proposé" + (and ? " (avec l'étoile)" : "") + ". Un bouton <b>Copier pour Montée</b> apparaît : touche-le, puis reviens ici.",
        m: mock(bar("montee", true), "Tape « montee » : le favori apparaît dans les suggestions"),
        go: '<a class="btn primary" href="https://tenup.fft.fr" target="_blank" rel="noopener" data-a="openTenup">Ouvrir Ten\'Up</a><button class="btn ' + (UI.backFromTenup ? "balle" : "soft") + '" data-a="importClipboard"' + (UI.backFromTenup ? "" : ' style="background:var(--chip)"') + ">J'ai copié : importer</button>" }
    ];
    var x = steps[st];
    var s = '<div class="seg" role="group" aria-label="Ton téléphone"><button data-a="platform" data-v="ios" class="' + (!and ? "on" : "") + '">iPhone · Safari</button><button data-a="platform" data-v="android" class="' + (and ? "on" : "") + '">Android · Chrome</button></div>';
    s += '<div class="card wiz"><div class="wiz-dots" aria-label="Étape ' + (st + 1) + " sur " + N + '">' + steps.map(function (_, i) { return '<i class="' + (i <= st ? "on" : "") + '"></i>'; }).join("") + "</div>" +
      '<span class="eyebrow" style="color:var(--muted)">Étape ' + (st + 1) + " sur " + N + '</span><span style="font-size:24px;font-weight:700;letter-spacing:-.02em;line-height:1.15">' + x.t + "</span>" +
      '<span style="font-size:16px;line-height:1.5">' + x.b + "</span>" + x.m + '<div class="stack" style="gap:8px">' + x.go + "</div>" +
      (st > 0 ? '<button class="linkbtn" data-a="wizGo" data-v="' + (st - 1) + '" style="align-self:flex-start;padding:0">← Étape précédente</button>' : "") + "</div>";
    if (UI.importError) s = '<div class="card terre"><b>Import impossible</b><span>' + esc(UI.importError) + "</span></div>" + s;
    s += '<details class="card"><summary style="font-weight:600;cursor:pointer;min-height:28px">Bloqué ? Autres solutions</summary>' +
      '<span style="font-size:15px;line-height:1.45">Sans favori, tu peux importer le PDF de la page « Simu » de Ten\'Up (sans dates ni scores), ou ajouter tes derniers matchs à la main. Si tu as déjà des matchs dans Montée, l\'import Ten\'Up ne les comptera pas en double.</span>' +
      '<div class="grid2"><button class="btn soft small" style="background:var(--chip)" data-a="tenupMethod" data-v="pdf">Importer un PDF</button><button class="btn soft small" style="background:var(--chip)" data-a="newMatch">Ajouter un match</button></div>' +
      '<span style="font-size:15px">Le favori a copié quelque chose mais l\'import ne part pas ? Colle-le ici :</span>' +
      '<div class="field" style="padding:0"><label for="imp" class="sr">Texte à importer</label><textarea id="imp" data-f="importText" placeholder="Colle ici">' + esc(UI.importText) + "</textarea></div>" +
      '<button class="btn soft small" data-a="parseImport" style="background:var(--chip)">Lire</button></details>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="skipImport">Pas de compte Ten\'Up ? Je saisis mes matchs à la main</button>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button>';
    return s;
  }
  V.tenup = function () {
    var s = '<div class="screen">' + topbar(NATIVE ? "Ton compte Ten'Up" : "Importer depuis Ten'Up", S.onboarded ? "" : "Pour commencer");
    if (UI.importRows) {
      var rows = UI.importRows, n = rows.filter(function (r) { return r.keep; }).length;
      s += '<p class="lead">' + plural(rows.length, "match trouvé", "matchs trouvés") + ". Vérifie, corrige si besoin, puis importe.</p>";
      s += '<div class="list">' + rows.map(function (r, i) {
        var ro = '<option value="">?</option><option' + (r.oppRank === "NC" ? " selected" : "") + ">NC</option>" + E.ECHELONS.slice(0, 22).map(function (e) { return "<option" + (r.oppRank === e ? " selected" : "") + ">" + e + "</option>"; }).join("") + '<option value="N°"' + (/^N°/.test(r.oppRank) ? " selected" : "") + ">N°</option>";
        return '<div class="preview-row' + (r.ok ? "" : " warnrow") + '"><input type="checkbox" aria-label="Importer ce match" data-ir="' + i + '" data-k="keep"' + (r.keep ? " checked" : "") + ' style="width:22px;height:22px;accent-color:var(--gazon);margin-top:2px">' +
          '<div><div style="font-size:15px;font-weight:600">' + esc(r.opp || "Adversaire ?") + ' <span class="muted" style="font-weight:400">· ' + esc(fdate(r.date)) + "</span></div>" +
          '<div class="small">' + esc(r.score || "score ?") + (r.dup ? " · déjà dans ton palmarès" : "") + "</div>" +
          '<div class="edit"><select aria-label="Classement de l\'adversaire" data-ir="' + i + '" data-k="oppRank">' + ro + "</select>" +
          '<select aria-label="Résultat" data-ir="' + i + '" data-k="result"><option value="">?</option><option value="V"' + (r.result === "V" ? " selected" : "") + '>Victoire</option><option value="D"' + (r.result === "D" ? " selected" : "") + ">Défaite</option></select>" +
          '<input type="date" aria-label="Date" data-ir="' + i + '" data-k="date" value="' + esc(r.date) + '"></div></div></div>';
      }).join("") + "</div>";
      s += '<div class="spacer"></div><button class="btn primary" data-a="doImport"' + (n ? "" : " disabled") + ">Importer " + plural(n, "match", "matchs") + "</button>" +
        '<button class="linkbtn" data-a="cancelImport">Recommencer</button></div>';
      return s;
    }
    if (NATIVE) return s + nativeTenupHtml() + "</div>";
    var ios = /iphone|ipad|ipod/i.test(navigator.userAgent), android = /android/i.test(navigator.userAgent);
    var step = function (n, title, body) {
      return '<div style="display:flex;gap:12px;align-items:flex-start"><span class="vd lg" style="background:var(--solid);color:var(--on-solid);flex-shrink:0">' + n + '</span><span style="display:flex;flex-direction:column;gap:6px;flex:1;min-width:0"><b style="font-size:16px">' + title + "</b>" + (body ? '<span style="font-size:14px;line-height:1.45">' + body + "</span>" : "") + "</span></div>";
    };
    if (UI.importError) s += '<div class="card terre"><b>Import impossible</b><span>' + esc(UI.importError) + "</span></div>";
    var meth = UI.tenupMethod || "fav";
    var origin = location.origin + location.pathname.replace(/index\.html$/, "").replace(/\/$/, "");
    s += '<div class="seg" role="group" aria-label="Méthode"><button data-a="tenupMethod" data-v="fav" class="' + (meth === "fav" ? "on" : "") + '">Favori · complet</button><button data-a="tenupMethod" data-v="pdf" class="' + (meth === "pdf" ? "on" : "") + '">PDF · simple</button></div>';
    if (meth === "fav") {
      var ready = !!(S.tenup.setup && S.tenup.setup.fav && S.tenup.setup.favVersion === T.VERSION);
      s += '<p class="lead" style="font-size:16px">Le favori Montée lit Ten\'Up comme le fait la page elle-même : <b>dates, scores, victoires, classements et simulation officielle</b>. Ton mot de passe ne passe jamais par Montée.</p>';
      var setup = '<div class="card balle"><span class="eyebrow">' + (S.tenup.setup && S.tenup.setup.fav && !ready ? "Mets ton favori à jour" : "Une seule fois · 1 minute") + '</span><div class="stack" style="gap:14px">' +
        step(1, "Copie le favori", '<button class="btn primary small" data-a="copyBookmark" style="margin-top:4px">Copier</button>') +
        (ios ? step(2, "Crée un signet dans Safari", "Sur n'importe quelle page : Partager › <b>Ajouter un signet</b> › Enregistrer.") +
          step(3, "Colle-le comme adresse", "Icône livre › <b>Modifier</b› › touche le signet. Nom : <b>Montée</b>. Adresse : efface tout, colle.".replace("</b›", "</b>")) :
          (android ? step(2, "Crée un favori dans Chrome", "Sur n'importe quelle page : menu ⋮ › touche l'<b>étoile</b>.") +
            step(3, "Colle-le comme adresse", "Menu ⋮ › <b>Favoris</b> › appui long sur ce favori › <b>Modifier</b>. Nom : <b>Montée</b>. URL : efface tout, colle.") :
            step(2, "Crée un favori", "Ajoute n'importe quelle page en favori, puis modifie-le. Nom : <b>Montée</b>. Adresse : efface tout, colle."))) +
        '<button class="btn soft small" data-a="setupFav">C\'est fait</button></div></div>';
      var use = '<div class="card"><span class="eyebrow" style="color:var(--gazon)">Pour actualiser</span><div class="stack" style="gap:14px">' +
        step(1, "Ouvre Ten'Up, connecté", '<a class="btn soft small" href="https://tenup.fft.fr" target="_blank" rel="noopener" data-a="openTenup" style="margin-top:4px;background:var(--chip)">Ouvrir Ten\'Up</a>N\'importe quelle page de ton compte. Si Ten\'Up s\'ouvre à l\'intérieur de Montée, touche l\'icône ' + (/android/i.test(navigator.userAgent) ? "⋮ › Ouvrir dans Chrome" : "Safari (boussole) en bas à droite") + ".") +
        step(2, "Tape « Montée » dans la barre d'adresse", (android ? "Touche le favori ☆ Montée proposé" : "Touche le signet") + ", puis <b>Copier pour Montée</b>." + (android ? " Si Montée est installée sur ton écran d'accueil, tu peux aussi toucher « Ou ouvrir Montée » : l'import est direct." : "")) +
        step(3, "Reviens ici", '<button class="btn ' + (UI.backFromTenup ? "balle" : "primary") + ' small" data-a="importClipboard" style="margin-top:4px">Importer</button>') +
        "</div></div>";
      if (!ready || UI.wiz != null) return '<div class="screen">' + topbar("Relier Ten'Up", S.onboarded ? "" : "Pour commencer") + wizardHtml(ios, android) + "</div>";
      s += use + '<button class="linkbtn" data-a="wizGo" data-v="1">Réinstaller le favori, pas à pas</button>';
    } else {
      s += '<p class="lead" style="font-size:16px">Sans rien installer : Montée lit le PDF de la page « Simu ». Mais Ten\'Up n\'y met ni les dates ni les scores.</p>';
      s += '<div class="card"><div class="stack" style="gap:16px">' +
        step(1, "Ouvre l'onglet « Simu » de Ten'Up", '<a class="btn soft small" href="https://tenup.fft.fr" target="_blank" rel="noopener" style="margin-top:4px;background:var(--chip)">Ouvrir Ten\'Up</a>') +
        step(2, "Enregistre la page en PDF", ios ? "Capture d'écran › touche l'aperçu › <b>Page entière</b> › <b>OK › Enregistrer le PDF dans Fichiers</b>." :
          android ? "Menu ⋮ › <b>Partager</b> › <b>Imprimer</b> › <b>Enregistrer au format PDF</b>." : "Menu du navigateur › <b>Imprimer</b> › <b>Enregistrer au format PDF</b>.") +
        step(3, "Donne-le à Montée", '<label class="btn primary small" style="margin-top:4px;cursor:pointer">' + (UI.loading ? '<span class="spin"></span> Lecture…' : "Choisir le PDF") + '<input type="file" accept="application/pdf,.pdf" data-a="pdfFile" hidden></label>') +
        "</div></div>";
    }
    s += '<details class="card"><summary style="font-weight:600;cursor:pointer;min-height:28px">Ça ne marche pas ?</summary>' +
      '<span style="font-size:15px">Colle ici ce que le favori a copié.</span>' +
      '<div class="field" style="padding:0"><label for="imp" class="sr">Texte à importer</label><textarea id="imp" data-f="importText" placeholder="Colle ici">' + esc(UI.importText) + "</textarea></div>" +
      '<button class="btn soft small" data-a="parseImport" style="background:var(--chip)">Lire</button></details>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="skipImport">Pas de compte Ten\'Up ? Je saisis mes matchs à la main</button>';
    s += S.onboarded ? "" : '<button class="linkbtn" data-a="demo">Essayer avec un exemple</button>';
    return s + "</div>";
  };

  // ---------- Thèmes ----------
  var THEMES = [["auto", "Auto", "Lin le jour, Nuit le soir"], ["lin", "Lin", "Clair, le classique"], ["nuit", "Nuit", "Sombre"], ["terre", "Terre battue", "Argile et abricot"], ["dur", "Dur", "Bleu court et ciel"], ["gazon", "Gazon", "Pelouse et olive"]];
  var THEME_SW = { lin: ["#F6F2EC", "#FFFFFF", "#1F5C3F", "#D4E64A"], nuit: ["#17181C", "#272930", "#6FC28F", "#D4E64A"], terre: ["#F8F1EA", "#FFFFFF", "#B4442A", "#EE9D63"], dur: ["#F1F5FA", "#FFFFFF", "#1F5FAF", "#72B6EE"], gazon: ["#F2F5EE", "#FFFFFF", "#2D6A33", "#5C692B"] };
  var darkMq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
  function themeNow() { var t = (S.prefs && S.prefs.theme) || "auto"; return t === "auto" ? (darkMq && darkMq.matches ? "nuit" : "lin") : t; }
  function applyTheme() {
    var t = themeNow(), r = document.documentElement;
    if (t === "lin") r.removeAttribute("data-theme"); else r.setAttribute("data-theme", t);
    var bg = (THEME_SW[t] || THEME_SW.lin)[0];
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute("content", bg);
    // Barres système Android (notifications, navigation) à la couleur du fond, icônes claires en Nuit
    if (Tenup && Tenup.setBars) try { Tenup.setBars({ color: bg, light: t !== "nuit" }).catch(function () {}); } catch (e) {}
  }
  if (darkMq && darkMq.addEventListener) darkMq.addEventListener("change", function () { applyTheme(); syncWidgets(true); });
  applyTheme();

  // ---------- Réglages ----------
  V.reglages = function () {
    var cur = (S.prefs && S.prefs.theme) || "auto", pull = (S.prefs && S.prefs.pull) || "normal";
    var s = '<div class="screen">' + topbar("Réglages");
    s += "<h2>Thème de l'appli</h2><div class=\"themes\">" + THEMES.map(function (t) {
      var sw = THEME_SW[t[0] === "auto" ? "lin" : t[0]], on = cur === t[0];
      var mini = function (w, cls) { return '<span class="th-prev' + (cls || "") + '" style="background:' + w[0] + '"><i class="hh" style="background:' + w[3] + '"></i><i class="c1" style="background:' + w[1] + '"></i><i class="c2" style="background:' + w[1] + '"></i><i class="ac" style="background:' + w[2] + '"></i></span>'; };
      var prev = t[0] === "auto" ? '<span class="th-wrap">' + mini(THEME_SW.lin, " half") + mini(THEME_SW.nuit, " half r") + "</span>" : mini(sw);
      return '<button class="theme' + (on ? " on" : "") + '" data-a="setTheme" data-v="' + t[0] + '" aria-pressed="' + on + '" aria-label="' + t[1] + " : " + t[2] + '">' + prev + "<b>" + t[1] + "</b></button>";
    }).join("") + "</div>";
    // Thème des widgets de l'écran d'accueil
    var wcur = (S.prefs && S.prefs.wtheme) || "app";
    var wmini = function (bg, card, bar) { return '<span class="th-prev" style="background:' + bg + '"><i class="wt-card" style="background:' + card + '"></i><i class="wt-bar" style="background:' + bar + '"></i><i class="wt-sq" style="background:' + card + '"></i></span>'; };
    var WT = { lin: ["#E9E3D9", "#F0F5CF", "#1F5C3F"], nuit: ["#3A3D44", "#2A2E1F", "#D4E64A"] };
    s += "<h2>Thème des widgets</h2><div class=\"themes\">" + [["app", "Appli"], ["lin", "Lin"], ["nuit", "Nuit"]].map(function (o) {
      var on = wcur === o[0], prev = o[0] === "app" ? (function () { var a = THEME_SW[themeNow()] || THEME_SW.lin, c = themeNow() === "nuit" ? WT.nuit : themeNow() === "lin" ? WT.lin : [a[0], a[3], a[2]]; return wmini(c[0], c[1], c[2]); })() : wmini(WT[o[0]][0], WT[o[0]][1], WT[o[0]][2]);
      return '<button class="theme' + (on ? " on" : "") + '" data-a="setWTheme" data-v="' + o[0] + '" aria-pressed="' + on + '">' + prev + "<b>" + o[1] + "</b></button>";
    }).join("") + '</div><p class="small" style="margin-top:-4px">« Appli » : les widgets suivent le thème de l\'appli. Ils se mettent à jour à chaque ouverture de Montée.</p>';
    s += '<h2>Synchronisation Ten\'Up</h2><div class="card" style="gap:10px"><b style="font-size:15px">Tirer l\'écran vers le bas</b><span class="small">Pour lancer la synchro depuis l\'accueil, le palmarès ou les courbes.</span><div class="seg">' +
      [["normal", "Normal"], ["ferme", "Plus ferme"], ["off", "Désactivé"]].map(function (o) { return '<button data-a="setPull" data-v="' + o[0] + '" class="' + (pull === o[0] ? "on" : "") + '">' + o[1] + "</button>"; }).join("") + "</div>" +
      '<a class="btn soft small" href="#/tenup" style="background:var(--chip)">' + I.link + " Ton compte Ten'Up</a></div>";
    s += "<h2>Affichage</h2><div class=\"list\">" +
      '<a class="row" href="#/perso/home"><span class="grow"><span class="t">Personnaliser l\'accueil</span><span class="s">Choisir les cartes et leur ordre</span></span>' + I.next + "</a>" +
      '<a class="row" href="#/perso/courbes"><span class="grow"><span class="t">Personnaliser les courbes</span></span>' + I.next + "</a></div>";
    s += "<h2>Montée</h2><div class=\"list\">" +
      '<button class="row" data-a="openNotes"><span class="grow"><span class="t">Quoi de neuf</span><span class="s">Les nouveautés de la version ' + esc(CONFIG.VERSION) + "</span></span>" + I.next + "</button>" +
      (NATIVE ? '<button class="row" data-a="openStore"><span class="grow"><span class="t">Mettre à jour Montée</span><span class="s">Ouvre la fiche sur le Play Store</span></span>' + I.next + "</button>" : "") +
      '<a class="row" href="#/donnees"><span class="grow"><span class="t">Sauvegarder mes données</span></span>' + I.next + "</a>" +
      '<a class="row" href="#/apropos"><span class="grow"><span class="t">À propos</span><span class="s">Version ' + esc(CONFIG.VERSION) + "</span></span>" + I.next + "</a></div>";
    return s + "</div>";
  };

  // ---------- Quoi de neuf (une fois par version) ----------
  var NOTES = {
    v: "3.9",
    pages: [
      { hero: true, title: "Montée 3.9", text: "Des thèmes, des widgets refaits, des courbes qu'on touche du doigt et une saisie plus confortable. Voici ce qui change." },
      { tag: "Nouveau", tone: "rose", title: "Des thèmes", text: "Lin, Nuit, Terre battue, Dur ou Gazon : choisis l'ambiance de Montée dans les Réglages (la roue crantée à côté de ton classement). En Auto, Montée passe en Nuit quand ton téléphone est en mode sombre.", vis: "themes" },
      { tag: "Nouveau", tone: "rose", title: "Des widgets refaits", text: "Dix widgets aux couleurs de ton thème, qui suivent ta montée, ta raquette et ta semaine. Choisis leur thème dans les Réglages, puis ajoute-les depuis l'écran d'accueil de ton téléphone.", vis: "widgets" },
      { tag: "Amélioré", tone: "bleu", title: "Des courbes qui répondent", text: "Touche un point de ton bilan, une barre des points à défendre, une ligne du mental ou un classement de ton plafond : le détail s'ouvre, match par match.", vis: "courbe" },
      { tag: "Amélioré", tone: "bleu", title: "Saisie plus confortable", text: "Le clavier ne cache plus ce que tu tapes, une surface « Autre » accueille gymnases et parquets sans fausser tes stats, et la synchro par glissement se déclenche moins facilement (réglable).", vis: "clavier" }
    ]
  };
  function notesDue() {
    if (UI.notesOpen) return true;
    if (!S.onboarded || !S.matches.length) return false;
    if (!S.seenNotes) { S.seenNotes = NOTES.v; save(); return false; } // première installation : rien à annoncer
    if (S.seenNotes !== NOTES.v && route() === "") { UI.notesOpen = true; UI.notesPage = 0; return true; }
    return false;
  }
  function notesVis(k) {
    if (k === "widgets" && window.MonteeWidgetArt) {
      var A2 = window.MonteeWidgetArt, dd = { status: "maintien", rank: "15/4", releaseIso: E.iso(today()).slice(0, 8) + "28", target: "15/4 → 15/3", short: "Une victoire peut suffire", total: 310, norme: 325, pct: 95, form: ["V", "D", "V", "V", "V"], streak: "3 victoires d'affilée", recordShort: "12 V · 5 D" };
      return '<div class="nv-widgets"><style>' + A2.css + '</style><div class="nv-w">' + A2.html("classement", dd, "lin", 170, 170) + '</div><div class="nv-w">' + A2.html("classement", Object.assign({}, dd, { status: "montee", rank: "15/3" }), "nuit", 170, 170) + "</div></div>";
    }
    if (k === "themes") return '<div class="nv-themes">' + ["lin", "nuit", "terre", "dur", "gazon"].map(function (t) { var w = THEME_SW[t]; return '<span class="nv-ph" style="background:' + w[0] + '"><i style="background:' + w[1] + '"></i><b style="background:' + w[3] + '"></b><u style="background:' + w[2] + '"></u><u style="background:' + w[1] + ';width:70%"></u></span>'; }).join("") + "</div>";
    if (k === "courbe") return '<svg viewBox="0 0 300 130" class="nv-chart"><line x1="0" x2="300" y1="34" y2="34" stroke="#fff" stroke-opacity=".5" stroke-dasharray="4 4"/><polyline points="10,110 50,104 90,96 130,98 170,70 210,64 250,52 290,40" fill="none" stroke="#6FC28F" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/><line x1="170" x2="170" y1="76" y2="122" stroke="#fff" stroke-opacity=".4" stroke-dasharray="2 3"/><rect x="146" y="38" width="48" height="22" rx="11" fill="#D4E64A"/><text x="170" y="53" text-anchor="middle" font-size="12" font-weight="700" fill="#121212">245</text><circle cx="170" cy="70" r="7" fill="#D4E64A" stroke="#121212" stroke-width="2"/></svg>';
    if (k === "clavier") return '<div class="nv-kb"><div class="nv-field">Gaucher, slice revers très bas<i></i></div><div class="nv-keys">' + new Array(28).join("<span></span>") + "</div></div>";
    return "";
  }
  function notesHtml() {
    var p = NOTES.pages[UI.notesPage || 0], last = (UI.notesPage || 0) === NOTES.pages.length - 1, IL = window.MonteeIll;
    var dots = '<div class="nv-dots">' + NOTES.pages.map(function (x, i) { return '<i class="' + (i === (UI.notesPage || 0) ? "on" : "") + '"></i>'; }).join("") + "</div>";
    var body = p.hero ? '<div class="nv-hero">' + (IL ? IL.welcome() : "") + '<span class="nv-big">' + esc(p.title) + '</span><span class="nv-lead">' + esc(p.text) + "</span></div>" :
      '<div class="nv-vis">' + notesVis(p.vis) + '</div><span class="nv-tag ' + p.tone + '">' + esc(p.tag) + '</span><span class="nv-title">' + esc(p.title) + '</span><span class="nv-text">' + esc(p.text) + "</span>";
    return '<div class="notes" role="dialog" aria-modal="true" aria-label="Quoi de neuf"><button class="iconbtn nv-close" data-a="notesClose" aria-label="Fermer">' + I.cross + '</button><div class="nv-body">' + body + "</div>" +
      '<div class="nv-foot">' + dots + '<button class="btn nv-next" data-a="notesNext">' + (last ? "C'est parti" : "Suivant " + I.next) + "</button></div></div>";
  }

  // ---------- Données ----------
  function backup(share) {
    var copy = JSON.parse(JSON.stringify(S)); if (copy.tenup) delete copy.tenup.cred;
    var name = "montee-sauvegarde-" + E.iso(today()) + ".json", txt = JSON.stringify(copy, null, 2);
    var done = function (msg) { S.lastBackup = E.iso(today()); save(); toast(msg); render(); };
    var web = function () {
      var file = typeof File === "function" ? new File([txt], name, { type: "application/json" }) : null;
      if ((NATIVE || share) && file && navigator.canShare && navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], title: "Sauvegarde Montée" }).then(function () { done("Sauvegarde créée."); }).catch(function () {});
        return;
      }
      var blob = new Blob([txt], { type: "application/json" });
      var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name;
      document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
      done("Sauvegarde créée : " + name);
    };
    if (NATIVE && Tenup) {
      Promise.resolve().then(function () { return Tenup.saveFile({ name: name, content: txt, mime: "application/json", share: !!share }); })
        .then(function (r) { done(r && r.saved === "downloads" ? "Sauvegarde créée dans Téléchargements : " + name : "Choisis où ranger ta sauvegarde."); })
        .catch(web);
      return;
    }
    web();
  }
  V.donnees = function () {
    return '<div class="screen">' + topbar("Tes données") +
      '<p class="lead">Tout est stocké sur cet appareil uniquement. Si tu changes de téléphone ou vides ton navigateur, tout est perdu : fais une sauvegarde de temps en temps.</p>' +
      '<div class="card"><b>' + plural(S.matches.length, "match", "matchs") + " · " + plural(S.rackets.length, "raquette") + "</b>" +
      '<button class="btn primary small" data-a="export">' + I.save + " Créer une sauvegarde</button>" +
      '<span class="small">' + (S.lastBackup ? "Dernière sauvegarde le " + esc(fdate(S.lastBackup).replace(/\.$/, "")) + ". " : "") + (NATIVE ? "Un fichier est rangé dans Téléchargements, sur ce téléphone." : "Un fichier est téléchargé sur cet appareil.") + "</span>" +
      (NATIVE ? '<button class="btn soft small" data-a="exportShare">' + I.share + " Envoyer la sauvegarde (Drive, e-mail…)</button>" +
        '<span class="small">Utile si tu changes de téléphone : garde-la ailleurs que sur celui-ci.</span>' : "") +
      '<label class="btn soft small" style="cursor:pointer">Restaurer une sauvegarde<input type="file"' + (NATIVE ? "" : ' accept="application/json,.json"') + ' data-a="importFile" hidden></label></div>' +
      (S.tenup && (S.tenup.sample || S.tenup.lastError) ? '<button class="btn soft small" data-a="copyDiag">Copier le diagnostic Ten\'Up</button>' : "") +
      '<button class="btn danger small" data-a="wipe">Tout effacer</button></div>';
  };

  // ---------- Méthode ----------
  V.methode = function () {
    var sex = S.profile.sex;
    var rows = E.ECHELONS.slice(1, 22).map(function (e, i) { return "<tr><td>" + e + "</td><td>" + E.BAREME.norme[sex][i + 1] + "</td><td>" + E.BAREME.base[sex][i + 1] + "</td></tr>"; }).join("");
    return '<div class="screen">' + topbar("Comment c'est calculé") +
      '<div class="card"><b>Le principe</b><span style="font-size:15px;line-height:1.5">Le classement sort le premier mardi de chaque mois. Il compte tes matchs des 12 derniers mois. Pour monter, il faut atteindre la norme de l\'échelon au-dessus <b>et</b> avoir battu un joueur déjà classé à cet échelon (hors WO).</span></div>' +
      '<div class="card"><b>Ce que rapporte une victoire</b><table class="simple"><tr><th>Adversaire, par rapport à l\'échelon calculé</th><th>Points</th></tr>' +
      [["2 échelons ou plus au-dessus", 120], ["1 échelon au-dessus", 90], ["Même échelon", 60], ["1 échelon en dessous", 30], ["2 échelons en dessous", 20], ["3 échelons en dessous", 15], ["4 échelons ou plus en dessous", 0]].map(function (r) { return "<tr><td>" + r[0] + "</td><td>" + r[1] + "</td></tr>"; }).join("") + "</table></div>" +
      '<div class="card"><b>Combien de victoires comptent</b><span style="font-size:15px;line-height:1.5">Seules tes meilleures victoires comptent. Leur nombre dépend de l\'échelon et de ton V − E − 2I − 5G : V tes victoires, E tes défaites à échelon égal, I à un échelon en dessous, G à deux échelons ou plus en dessous. Les deux premières défaites par WO ne comptent pas.</span></div>' +
      '<div class="card"><b>Les bonus</b><span style="font-size:15px;line-height:1.5">Sans défaite (WO compris) contre un joueur classé à l\'échelon calculé ou en dessous : +50 (30/2 et 30/1, 5 matchs minimum), +50 (3e série, 10 matchs), +100 (2e série, 10 matchs). Championnats individuels (France et phases qualificatives) : +15 par victoire en 4e série, +20 en 3e série, +25 en 2e série, 3 meilleures bonifications (5 à partir de -2/6).</span></div>' +
      '<div class="card"><b>Les doubles</b><span style="font-size:15px;line-height:1.5">Une victoire en double ne compte pas comme une victoire en simple : elle rapporte un bonus selon le poids des paires (la somme des classements des deux joueurs, le jour du match). En perf, à poids égal ou en contre : 5, 3 ou 1 point en 3e et 4e série, 7, 4 ou 2 en 2e série, 10, 6 ou 3 à partir de -2/6. Seules les meilleures comptent : 5 en 4e série, 7 au-delà. Les défaites en double ne comptent pas.</span></div>' +
      '<div class="card"><b>L\'ajustement Ten\'Up</b><span style="font-size:15px;line-height:1.5">Quand tu importes depuis Ten\'Up, Montée récupère aussi le bilan officiel de ta simulation et s\'aligne dessus. L\'écart éventuel apparaît dans le détail sous « Ajustement d\'après Ten\'Up ».</span></div>' +
      '<div class="card"><b>Normes ' + (sex === "F" ? "dames" : "messieurs") + '</b><table class="simple"><tr><th>Échelon</th><th>Points</th><th>Victoires de base</th></tr>' + rows + "</table></div>" +
      '<p class="small">Valeurs publiées par la FFT (normes mises à jour en janvier 2023). Les échelons 40/2 et 40/1, la 1re série et les cas particuliers (coefficients de format, blocages, WO à répétition au-delà du bilan) ne sont pas simulés. Calcul indicatif : seul le classement officiel fait foi.</p></div>';
  };

  V.apropos = function () {
    return '<div class="screen">' + topbar("À propos") +
      '<div class="brand">' + I.logo(30) + "montée</div>" +
      '<div class="card"><b>Tes données restent chez toi</b><span style="font-size:15px;line-height:1.5">Pas de compte, pas de serveur, pas de pub, pas de pisteur. Ton palmarès et ton matériel sont enregistrés uniquement dans ce navigateur.</span></div>' +
      '<div class="card"><b>Pas lié à la FFT</b><span style="font-size:15px;line-height:1.5">Montée est une application indépendante. Elle n\'est ni éditée ni approuvée par la Fédération Française de Tennis. Ten\'Up est un service de la FFT. Le calcul est indicatif : seul le classement officiel fait foi.</span></div>' +
      (NATIVE ? '<div class="card"><b>Gratuite et sans pub</b><span style="font-size:15px;line-height:1.5">Parle de Montée à ton club, c\'est la meilleure façon de l\'aider.</span></div>' :
      '<div class="card"><b>Gratuit grâce à toi</b><span style="font-size:15px;line-height:1.5">Si Montée t\'aide à monter, un petit don aide à la garder gratuite.</span><button class="btn balle small" data-a="don">' + I.heart + " Soutenir Montée</button></div>") +
      '<p class="small">Version ' + CONFIG.VERSION + "</p></div>";
  };

  // ---------- Données d'exemple ----------
  function demo() {
    var t = today();
    var ago = function (days) { var d = new Date(t); d.setDate(d.getDate() - days); return E.iso(d); };
    var r1 = { id: "r1", name: "Raquette n°1", string: "Polyester 1,25", stringType: "mono", tension: 24, restrings: [ago(380), ago(40)], main: true };
    var r2 = { id: "r2", name: "Raquette n°2", string: "Multifilament 1,30", stringType: "multi", tension: 25, restrings: [ago(150)], main: false };
    r1.breaks = [{ date: ago(120), min: 1250, string: "Polyester 1,25", type: "mono" }];
    S.slots = [{ id: "s1", dow: (today().getDay() + 4) % 7, time: "18:30", minutes: 90, label: "Collectif", since: ago(20) }];
    S.slotLog = {};
    S.trainings = [[3, 120, null], [9, 90, 3], [16, 120, 4], [23, 90, 5], [30, 90, 3], [37, 120, 4]].map(function (x) {
      return { id: uid(), date: ago(x[0]), minutes: x[1], racketId: "r1", string: "Polyester 1,25", tension: 24, tensionCross: null, newString: false, feel: x[2], note: "" };
    });
    var M = function (days, opp, rank, res, score, o) {
      return Object.assign({ id: uid(), date: ago(days), opp: opp, oppRank: rank, result: res, wo: false, score: score, kind: "tournoi", surface: "Dur", indoor: true, racketId: "r1", string: "Polyester 1,25", tension: 24, feel: 4, note: "", source: "exemple" }, o || {});
    };
    S.profile = { name: S.profile.name || "Alex", sex: "H", rank: "15/2", licence: S.profile.licence || "" };
    S.rackets = [r1, r2];
    S.matches = [
      M(4, "J. Lefèvre", "15/1", "V", "6-4 3-6 7-5", { racketId: "", string: "", tension: null, feel: null }),
      M(6, "E. Blanc", "15/2", "V", "", { wo: true, racketId: "", string: "", tension: null, feel: null }),
      M(11, "A. Moreau", "15/2", "V", "6-3 6-2", { racketId: "", string: "", tension: null, feel: null, kind: "equipes" }),
      M(17, "K. Benali", "15", "D", "4-6 2-6", { feel: 2 }),
      M(25, "T. Martin", "15/1", "V", "7-6 6-4"),
      M(32, "P. Garnier", "15/3", "V", "6-1 6-3", { surface: "Terre battue", indoor: false }),
      M(46, "M. Girard", "15/1", "D", "3-6 6-7", { racketId: "r2", string: "Multifilament 1,30", tension: 25, surface: "Terre battue", indoor: false, feel: 3 }),
      M(53, "S. Roux", "15/2", "V", "6-2 4-6 6-3", { surface: "Terre battue", indoor: false }),
      M(88, "L. Faure", "15/4", "V", "6-2 6-2", { racketId: "r2", string: "Multifilament 1,30", tension: 25 }),
      M(120, "N. Petit", "15/3", "V", "6-4 6-4", { tension: 23 }),
      M(150, "B. Leroy", "15/2", "D", "6-7 4-6", { tension: 23, feel: 2 }),
      M(175, "C. Bernard", "15/3", "V", "7-5 6-3"),
      M(210, "F. Lambert", "15/4", "V", "6-0 6-1", { racketId: "r2", string: "Multifilament 1,30", tension: 25, kind: "equipes" }),
      M(245, "G. Mercier", "15/3", "D", "2-6 7-6 4-6", { tension: 23, feel: 3 }),
      M(280, "H. Simon", "15/5", "V", "6-3 6-2"),
      M(355, "R. Petit", "15/2", "V", "6-4 7-6", { kind: "equipes" }),
      M(420, "D. Fontaine", "15/3", "V", "6-2 6-4")
    ];
    var Dd = function (days, opp, r1, r2, res, partnerRank, score) { return { id: "d" + uid(), date: ago(days), opp: opp, oppRanks: [r1, r2], oppRank: r1, result: res, wo: false, dbl: true, partner: "P. Durand", partnerRank: partnerRank, score: score, source: "exemple" }; };
    S.doubles = [Dd(9, "L. Roy / M. Blanc", "15/1", "15/2", "V", "15/3", "6-4 7-5"), Dd(40, "T. Gay / B. Noël", "15/3", "15/4", "V", "15/2", "6-2 6-3"), Dd(70, "R. Diaz / S. Morel", "15/2", "15/2", "V", "15/2", "7-6 6-4"), Dd(130, "J. Faure / K. Ly", "15", "15/1", "D", "15/2", "4-6 3-6")];
    S.onboarded = true; save();
    toast("Exemple chargé : 17 matchs, 4 doubles et 6 entraînements. Tu peux tout effacer dans Sauvegarder mes données.");
    go("");
  }

  // ---------- Actions ----------
  var A = {
    back: function () {
      if (isDirty()) { UI.leaveAsk = true; render(); return; }
      UI.draft = null; UI.racketDraft = null; UI.rkMenu = false; back();
    },
    leaveStay: function () { UI.leaveAsk = false; render(); },
    leaveDiscard: function () { UI.leaveAsk = false; UI.draft = null; UI.racketDraft = null; UI.rkMenu = false; UI.origKey = null; back(); },
    leaveSave: function () { var e = editCtx(); UI.leaveAsk = false; if (e) A[e.save](); },
    rkMenu: function () { UI.rkMenu = !UI.rkMenu; render(); },
    bilanSel: function (el) { UI.bilanSel = +el.dataset.v; render(); },
    sheet: function (el) { UI.sheet = { k: el.dataset.k, v: el.dataset.v }; render(); },
    sheetClose: function () { UI.sheet = null; render(); },
    menu: function () { UI.menu = true; render(); var b = app.querySelector(".sheet .menu-item"); if (b) b.focus(); },
    closeMenu: function () { UI.menu = false; render(); },
    newMatch: function () { UI.menu = false; UI.draft = null; go("match/new"); },
    newTraining: function () { UI.menu = false; UI.draft = null; go("entrainement/new"); },
    saveTraining: function () {
      var t = UI.draft;
      if (!t.date) return toast("Indique la date de l'entraînement.");
      var clean = Object.assign({}, t); delete clean._for;
      S.trainings = S.trainings || [];
      var i = S.trainings.findIndex(function (x) { return x.id === clean.id; });
      if (i >= 0) S.trainings[i] = clean; else S.trainings.push(clean);
      S.onboarded = true; save(); UI.draft = null;
      toast(i >= 0 ? "Entraînement mis à jour." : "Entraînement ajouté : " + fmtDur(clean.minutes) + " de jeu.");
      if (i >= 0) back(); else go("materiel");
    },
    delTraining: function () {
      if (!confirm("Supprimer cet entraînement ?")) return;
      S.trainings = (S.trainings || []).filter(function (x) { return x.id !== UI.draft.id; }); save(); UI.draft = null; toast("Entraînement supprimé."); back();
    },
    dmin: function (el) { var d = UI.draft, isM = d.opp != null; d.minutes = Math.max(15, Math.min(300, (d.minutes || (isM ? estMinutes(d) : 60)) + (+el.dataset.v))); render(); },
    dminReset: function () { UI.draft.minutes = null; render(); },
    scorePick: function (el) { var d = UI.draft, sets = (d.sets || []).slice(); sets[+el.dataset.i] = el.dataset.v.split("-").map(Number); UI.scoreEdit = null; applySets(d, sets); render(); },
    scoreEdit: function (el) { UI.scoreEdit = +el.dataset.v; render(); },
    scoreClear: function () { UI.draft.sets = []; UI.draft.score = ""; UI.scoreEdit = null; UI.stb = false; render(); },
    scoreStb: function (el) { UI.stb = el.dataset.v === "1"; render(); },
    stbExt: function (el) { UI.stbExt = Math.max(11, Math.min(40, (UI.stbExt || 11) + (+el.dataset.v))); render(); },
    scoreManual: function () { UI.scoreManual = !UI.scoreManual; if (!UI.scoreManual) { UI.draft.sets = setsOf(UI.draft.score); } render(); },
    qaRacket: function (el) { UI.qa.racketId = UI.qa.racketId === el.dataset.v ? "" : el.dataset.v; render(); },
    qaSurface: function (el) { UI.qa.surface = UI.qa.surface === el.dataset.v ? "" : el.dataset.v; render(); },
    qaIndoor: function (el) { var v = el.dataset.v === "1"; UI.qa.indoor = UI.qa.indoor === v ? null : v; render(); },
    qaSkip: function () { var m = S.matches.filter(function (x) { return x.id === UI.qa.id; })[0]; if (m) { m.qaSkip = true; save(); } UI.qa = null; render(); },
    qaSave: function (el) {
      var q = UI.qa, m = q && S.matches.filter(function (x) { return x.id === q.id; })[0]; if (!m) return;
      var r = racket(q.racketId);
      if (r) { m.racketId = r.id; m.string = r.string || ""; m.tension = r.tension || null; m.tensionCross = r.tensionCross != null ? r.tensionCross : null; }
      else m.qaSkip = true;
      if (q.surface) m.surface = q.surface;
      if (q.indoor != null) m.indoor = q.indoor;
      var v = +el.dataset.v; if (v) m.feel = v;
      S.lastQA = { surface: q.surface || (S.lastQA || {}).surface, indoor: q.indoor != null ? q.indoor : (S.lastQA || {}).indoor };
      UI.qa = null; save(); toast("Match annoté" + (v ? " · " + FEEL[v - 1].toLowerCase() : "") + "."); render();
    },
    insightGo: function (el) { if (el.dataset.tab) UI.whereTab = el.dataset.tab; go(el.dataset.go || "courbes"); },
    rate: function (el) {
      var arr = el.dataset.t === "t" ? (S.trainings || []) : S.matches, o = arr.filter(function (x) { return x.id === el.dataset.id; })[0];
      if (!o) return; o.feel = +el.dataset.v; save(); toast("Noté : " + FEEL[o.feel - 1].toLowerCase() + "."); render();
    },
    rateSkip: function (el) {
      var arr = el.dataset.t === "t" ? (S.trainings || []) : S.matches, o = arr.filter(function (x) { return x.id === el.dataset.id; })[0];
      if (o) { o.feelSkip = true; save(); render(); }
    },
    party: function () { party(); },

    shareMontee: function () {
      if (!S.ahead) return;
      var url = NATIVE ? "https://montennis.netlify.app" : location.origin + location.pathname;
      var text = "Je monte " + S.ahead.rank + " à la sortie du classement du " + flong(E.parseDate(S.ahead.release)) + " ! Calculé avec Montée.";
      if (navigator.share) navigator.share({ title: "Montée", text: text, url: url }).catch(function () {});
      else if (navigator.clipboard) navigator.clipboard.writeText(text + " " + url).then(function () { toast("Message copié."); });
    },
    don: function () {
      UI.menu = false;
      if (CONFIG.DON_URL) { window.open(CONFIG.DON_URL, "_blank", "noopener"); render(); }
      else { render(); toast("Le lien de don n'est pas encore configuré."); }
    },
    goTenup: function () { UI.menu = false; UI.importRows = null; go("tenup"); },
    goRaquettes: function () { UI.menu = false; go("materiel"); setTimeout(function () { var h = app.querySelector("h2:last-of-type"); if (h) h.scrollIntoView({ behavior: "smooth" }); }, 50); },
    goProfil: function () { UI.menu = false; go("profil"); },
    goReglages: function () { UI.menu = false; go("reglages"); },
    setTheme: function (el) { S.prefs = S.prefs || {}; S.prefs.theme = el.dataset.v; save(); applyTheme(); render(); syncWidgets(true); },
    setWTheme: function (el) { S.prefs = S.prefs || {}; S.prefs.wtheme = el.dataset.v; save(); render(); syncWidgets(true); toast("Widgets mis à jour"); },
    setPull: function (el) { S.prefs = S.prefs || {}; S.prefs.pull = el.dataset.v; save(); render(); },
    openNotes: function () { UI.notesPage = 0; UI.notesOpen = true; render(); },
    notesNext: function () { if (UI.notesPage < NOTES.pages.length - 1) { UI.notesPage++; render(); } else A.notesClose(); },
    notesClose: function () { S.seenNotes = NOTES.v; UI.notesOpen = false; UI.notesPage = 0; save(); render(); },
    openStore: function () { var u = NATIVE ? "market://details?id=fr.montennis.app" : "https://play.google.com/store/apps/details?id=fr.montennis.app"; window.open(u, "_system"); },
    goDonnees: function () { UI.menu = false; go("donnees"); },
    goMethode: function () { UI.menu = false; go("methode"); },
    goApropos: function () { UI.menu = false; go("apropos"); },
    goProjection: function () { go("projection"); },
    contact: function () { location.href = "mailto:" + CONFIG.CONTACT_EMAIL + "?subject=" + encodeURIComponent("Montée — mon avis"); },
    share: function () {
      UI.menu = false; render();
      var data = { title: "Montée", text: "Tu montes ce mois-ci ? Montée recalcule ton bilan FFT avant la sortie.", url: location.origin + location.pathname };
      if (navigator.share) navigator.share(data).catch(function () {});
      else if (navigator.clipboard) navigator.clipboard.writeText(data.url).then(function () { toast("Lien copié."); });
    },
    install: function () {
      UI.menu = false; render();
      if (UI.installEvt) { UI.installEvt.prompt(); UI.installEvt = null; return; }
      var ios = /iphone|ipad|ipod/i.test(navigator.userAgent);
      toast(ios ? "Dans Safari : Partager, puis « Sur l'écran d'accueil »." : "Menu du navigateur ⋮, puis « Ajouter à l'écran d'accueil ».");
    },
    demo: demo,
    sex: function (el) { S.profile.sex = el.dataset.v; save(); render(); },
    saveProfil: function () {
      if (!S.profile.rank) return toast("Choisis ton classement.");
      UI.profEdit = false;
      save();
      if (!S.onboarded) { S.onboarded = true; save(); var nx = UI.afterProfil || ""; UI.afterProfil = null; go(nx); } else if (!S.matches.length || stack.length < 2) { toast("Profil enregistré."); go(""); } else { toast("Profil enregistré."); back(); }
    },
    skipImport: function () { UI.draft = null; if (!S.profile.rank) { UI.afterProfil = "match/new"; go("profil"); return; } S.onboarded = true; save(); go("match/new"); },
    palTab: function (el) { UI.palTab = el.dataset.v; render(); },
    palTodo: function () { UI.palTab = "todo"; go("palmares"); },
    matTab: function (el) { UI.matTab = el.dataset.v; render(); },
    projLevel: function (el) { UI.projLevel = +el.dataset.v; render(); },
    // fiche match
    dset: function (el) {
      var k = el.dataset.k, v = el.dataset.v;
      if (k === "kind" && UI.draft) UI.draft.kindSet = true; // choix à la main : la synchro ne l'écrase plus
      if (k === "indoor") v = v === "1";
      if (k === "feel" || k === "minutes") v = +v;
      UI.draft[k] = UI.draft[k] === v && (k === "surface" || k === "feel" || k === "indoor" || k === "label") ? (k === "surface" || k === "label" ? "" : null) : v;
      render();
    },
    dracket: function (el) {
      var r = racket(el.dataset.v);
      if (UI.draft.racketId === r.id) { UI.draft.racketId = ""; }
      else { UI.draft.racketId = r.id; UI.draft.string = r.string || ""; UI.draft.tension = r.tension || null; UI.draft.tensionCross = r.tensionCross != null ? r.tensionCross : null; }
      render();
    },
    tens: function (el) {
      var o = el.dataset.t === "match" ? UI.draft : UI.racketDraft, k = el.dataset.k;
      o[k] = Math.max(15, Math.min(32, (o[k] || 24) + (+el.dataset.v))); render();
    },
    newRacketFromMatch: function () { UI.racketDraft = null; UI.afterRacket = location.hash; go("raquette/new"); },
    saveMatch: function () {
      var m = UI.draft;
      if (m.wo) m.minutes = null;
      if (!m.oppRank) return toast("Indique le classement de l'adversaire.");
      if (!m.date && m.source !== "tenup-pdf") return toast("Indique la date du match.");
      var clean = Object.assign({}, m); delete clean._for; delete clean.sets; delete clean._auto;
      var i = S.matches.findIndex(function (x) { return x.id === clean.id; });
      if (i >= 0) S.matches[i] = clean; else S.matches.push(clean);
      S.onboarded = true; save(); UI.draft = null;
      toast(!clean.racketId && !clean.wo ? "Enregistré. Choisis une raquette pour qu'il ne soit plus « à annoter »." : i >= 0 ? "Match mis à jour." : "Match ajouté.");
      go(i >= 0 ? "palmares" : "");
    },
    delMatch: function () {
      if (!confirm("Supprimer ce match ?")) return;
      S.matches = S.matches.filter(function (x) { return x.id !== UI.draft.id; }); save(); UI.draft = null; toast("Match supprimé."); go("palmares");
    },
    // raquettes
    quickRestring: function (el) {
      var r = racket(el.dataset.id); if (!r) return;
      r.restrings = (r.restrings || []).concat([E.iso(today())]).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort(); r.brokenOpen = false;
      save(); toast("C'est noté : le compteur de " + r.name + " repart à zéro."); render();
    },
    breakString: function () {
      var d = UI.racketDraft, r = racket(d.id); if (!r) return;
      var st = racketStatus(r);
      if (!confirm("Noter une casse aujourd'hui" + (st.known ? ", à environ " + fmtHours(st.min) + " de jeu" : "") + " ?")) return;
      var br = { date: E.iso(today()), min: st.known ? st.min : 0, string: r.string || "", type: stringType(r) };
      r.breaks = (r.breaks || []).concat([br]); d.breaks = r.breaks.slice(); r.brokenOpen = d.brokenOpen = true;
      save(); toast("Casse notée. Dis-le quand c'est recordé."); render();
    },
    newSlot: function () { UI.slotDraft = null; go("creneau/new"); },
    slset: function (el) { var k = el.dataset.k, v = el.dataset.v; UI.slotDraft[k] = k === "label" ? v : +v; render(); },
    saveSlot: function () {
      var sl = Object.assign({}, UI.slotDraft); delete sl._for;
      if (!sl.time) return toast("Indique l'heure du créneau.");
      S.slots = S.slots || [];
      var i = S.slots.findIndex(function (x) { return x.id === sl.id; });
      if (i >= 0) S.slots[i] = sl; else S.slots.push(sl);
      save(); UI.slotDraft = null; toast("Créneau enregistré : " + DAYS_L[sl.dow] + " " + sl.time + "."); go("materiel");
    },
    delSlot: function () {
      if (!confirm("Supprimer ce créneau ? Les entraînements déjà notés restent.")) return;
      S.slots = (S.slots || []).filter(function (x) { return x.id !== UI.slotDraft.id; }); save(); UI.slotDraft = null; go("materiel");
    },
    slotYes: function (el) {
      var sl = (S.slots || []).filter(function (x) { return x.id === el.dataset.id; })[0]; if (!sl) return;
      var main = racketFor("train");
      S.trainings = S.trainings || [];
      S.trainings.push({ id: uid(), date: el.dataset.d, minutes: sl.minutes, label: sl.label, slot: sl.id, racketId: main ? main.id : "", string: main ? main.string || "" : "", tension: main ? main.tension || null : null, tensionCross: main && main.tensionCross != null ? main.tensionCross : null, newString: false, feel: null, note: "" });
      S.slotLog = S.slotLog || {}; S.slotLog[sl.id + "|" + el.dataset.d] = "yes";
      save(); toast("Noté : " + fmtDur(sl.minutes) + " de jeu."); render();
    },
    slotNo: function (el) { S.slotLog = S.slotLog || {}; S.slotLog[el.dataset.id + "|" + el.dataset.d] = "no"; save(); render(); },
    restring: function () { var r = UI.racketDraft; r.brokenOpen = false; r.restrings = (r.restrings || []).concat([E.iso(today())]).filter(function (v, i, a) { return a.indexOf(v) === i; }); render(); toast("Noté. Pense à enregistrer."); },
    addRestring: function () {
      var r = UI.racketDraft; r.brokenOpen = false; r.restrings = (r.restrings || []).concat([E.iso(today())]); render();
      var inp = app.querySelector('[data-rs="' + (r.restrings.length - 1) + '"]'); if (inp) { inp.focus(); if (inp.showPicker) try { inp.showPicker(); } catch (e) {} }
    },
    gearOpen: function () { if (!bag().length) { UI.afterRacket = location.hash; go("raquette/new"); return; } UI.gearOpen = !UI.gearOpen; render(); },
    rset: function (el) { UI.racketDraft[el.dataset.k] = el.dataset.v; render(); },
    showArchived: function () { UI.showArchived = !UI.showArchived; render(); },
    archiveRacket: function () {
      var r = racket(UI.racketDraft.id); if (!r) return;
      r.archived = !r.archived; UI.racketDraft.archived = r.archived;
      if (r.archived && r.main) { r.main = false; var nx = bag()[0]; if (nx) nx.main = true; }
      save(); toast(r.archived ? r.name + " est rangée. Son historique est gardé." : r.name + " est de retour dans ton sac."); UI.racketDraft = null; go("materiel");
    },
    rtype: function (el) { var r = UI.racketDraft; r.stringType = (r.stringType || guessType(r.string)) === el.dataset.v ? "" : el.dataset.v; render(); },
    delRestring: function (el) { var r = UI.racketDraft; r.restrings.splice(+el.dataset.v, 1); render(); },
    saveRacket: function () {
      var r = Object.assign({}, UI.racketDraft); delete r._for;
      r.restrings = (r.restrings || []).filter(Boolean).filter(function (v, i, a) { return a.indexOf(v) === i; }).sort();
      if (!r.name.trim()) return toast("Donne un nom à ta raquette.");
      if (r.main) S.rackets.forEach(function (x) { x.main = false; });
      var i = S.rackets.findIndex(function (x) { return x.id === r.id; });
      if (i >= 0) S.rackets[i] = r; else S.rackets.push(r);
      if (!S.rackets.some(function (x) { return x.main; })) S.rackets[0].main = true;
      save(); UI.racketDraft = null;
      if (UI.afterRacket && UI.draft) { UI.draft.racketId = r.id; UI.draft.string = r.string; UI.draft.tension = r.tension; UI.draft.tensionCross = r.tensionCross != null ? r.tensionCross : null; var h = UI.afterRacket; UI.afterRacket = null; location.hash = h; return; }
      toast("Raquette enregistrée."); go("materiel");
    },
    delRacket: function () {
      if (!confirm("Supprimer cette raquette ? Les matchs joués avec elle ne seront plus annotés.")) return;
      var id = UI.racketDraft.id;
      S.rackets = S.rackets.filter(function (x) { return x.id !== id; });
      S.matches.forEach(function (m) { if (m.racketId === id) m.racketId = ""; });
      save(); UI.racketDraft = null; go("materiel");
    },
    // import
    bmHelp: function (el, ev) { ev.preventDefault(); toast("Glisse ce bouton dans ta barre de favoris, puis utilise-le sur Ten'Up."); },
    tenupConnect: function () {
      var mail = (document.getElementById("tu-mail") || {}).value || "", pass = (document.getElementById("tu-pass") || {}).value || "";
      var keep = (document.getElementById("tu-keep") || {}).checked;
      UI.tuMail = mail.trim();
      if (!UI.tuMail || !pass) return toast("Indique ton e-mail et ton mot de passe Ten'Up.");
      tenupCall({ email: UI.tuMail, password: pass }, keep);
    },
    tenupRefresh: function () { if (S.tenup.cred) tenupCall(S.tenup.cred, true); else go("tenup"); },
    tenupForget: function () { delete S.tenup.cred; save(); toast("Compte Ten'Up délié."); render(); },
    setupFav: function () { S.tenup.setup = Object.assign({}, S.tenup.setup, { fav: true, favVersion: T.VERSION }); save(); render(); },
    nativeConnect: function () { nativeConnect(); },
    nativeRefresh: function () { nativeRefresh(false); },
    profEdit: function () { UI.profEdit = true; render(); },
    whereTab: function (el) { UI.whereTab = el.dataset.v; render(); },
    persoMove: function (el) {
      var pg = el.dataset.p, pr = prefsOf(pg), i = pr.order.indexOf(el.dataset.k), j = i + (+el.dataset.v);
      if (j < 0 || j >= pr.order.length) return;
      pr.order.splice(j, 0, pr.order.splice(i, 1)[0]); S.prefs[pg] = pr; save(); render();
    },
    persoReset: function (el) { S.prefs = S.prefs || {}; delete S.prefs[el.dataset.p]; save(); render(); toast("Affichage d'origine rétabli."); },
    nativeLogout: function () {
      if (!confirm("Délier ton compte Ten'Up ? Tes matchs restent dans Montée.")) return;
      Tenup.logout().catch(function () {}); S.tenup.linked = false; save(); render();
    },
    tenupMethod: function (el) { UI.tenupMethod = el.dataset.v; UI.importError = null; if (el.dataset.v === "pdf") { UI.wiz = null; S.tenup.setup = Object.assign({}, S.tenup.setup, { skipWiz: true }); } render(); },
    platform: function (el) { UI.platform = el.dataset.v; render(); },
    setupDone: function () { S.tenup.setup = Object.assign({}, S.tenup.setup, (function (o) { o[UI.platform || (/iphone|ipad|ipod/i.test(navigator.userAgent) ? "ios" : /android/i.test(navigator.userAgent) ? "android" : "desktop")] = true; return o; })({})); save(); render(); },
    openTenup: function (el) {
      UI.awaitTenup = true;
      var ua = navigator.userAgent, url = "https://tenup.fft.fr/";
      // Depuis l'app installée, forcer le vrai navigateur (là où sont les signets/favoris)
      if (isStandalone() && /iphone|ipad|ipod/i.test(ua)) { location.href = "x-safari-" + url; return; }
      if (isStandalone() && /android/i.test(ua)) { location.href = "intent://tenup.fft.fr/#Intent;scheme=https;package=com.android.chrome;S.browser_fallback_url=" + encodeURIComponent(url) + ";end"; return; }
      window.open(url, "_blank", "noopener");
    },
    wizGo: function (el) { UI.wiz = +el.dataset.v; if (UI.wiz >= 4) { S.tenup.setup = Object.assign({}, S.tenup.setup, { fav: true, favVersion: T.VERSION }); save(); } render(); window.scrollTo(0, 0); },
    wizCopy: function (el) {
      var origin = location.origin + location.pathname.replace(/index\.html$/, "").replace(/\/$/, "");
      var code = T.bookmarklet(S.profile.licence || "", origin), stay = el.dataset.v === "stay";
      var ok = function () { toast("Code copié."); if (!stay) { UI.wiz = 2; render(); window.scrollTo(0, 0); } };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(ok, function () { fallbackCopy(code); ok(); });
      else { fallbackCopy(code); ok(); }
    },
    copyBookmark: function () {
      var origin = location.origin + location.pathname.replace(/index\.html$/, "").replace(/\/$/, "");
      var code = T.bookmarklet(S.profile.licence || "", origin);
      var ok = function () { toast("Favori copié. Colle-le comme adresse du signet."); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(ok, function () { fallbackCopy(code); ok(); });
      else { fallbackCopy(code); ok(); }
    },
    importClipboard: function () {
      UI.backFromTenup = false;
      if (!navigator.clipboard || !navigator.clipboard.readText) { UI.importError = "ce navigateur ne permet pas de lire le presse-papiers : colle le résultat dans « Ça ne marche pas ? »."; render(); return; }
      navigator.clipboard.readText().then(function (t) {
        var pl = T.decode(t);
        if (pl) importPayload(pl);
        else toast("Rien de Ten'Up à importer. Lance d'abord « Envoyer à Montée » depuis Safari.");
      }).catch(function () { toast("Touche « Coller » quand l'iPhone le propose."); });
    },
    copyScript: function () {
      var code = T.script(S.profile.licence || "", "shortcut", "");
      var ok = function () { toast("Script copié. Colle-le dans l'action du raccourci."); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(code).then(ok, function () { fallbackCopy(code); ok(); });
      else { fallbackCopy(code); ok(); }
    },
    copyDiag: function () {
      var comps = {}; S.matches.forEach(function (m) { if (m.comp) comps[m.comp] = m.kind; });
      var d = JSON.stringify({ comps: comps, v: "3.7.0", sample: S.tenup.sample, official: S.tenup.official, doubles: (S.doubles || []).map(function (m) { return { date: m.date, r: m.result, opp: m.opp, oppRanks: m.oppRanks, partner: m.partner, partnerRank: m.partnerRank, officialPts: m.officialPts }; }), lastError: S.tenup.lastError, ua: navigator.userAgent }, null, 1);
      var ok = function () { toast("Diagnostic copié : colle-le dans ta conversation avec Claude."); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(d).then(ok, function () { fallbackCopy(d); ok(); }); else { fallbackCopy(d); ok(); }
    },
    parseImport: function () {
      var t = UI.importText || "";
      var pl = T.decode(t); if (pl) { UI.importText = ""; importPayload(pl); return; }
      if (t.trim().length < 20) return toast("Colle d'abord le texte de ta page Palmarès.");
      UI.importRows = rowsFromText(t); render(); window.scrollTo(0, 0);
    },
    cancelImport: function () { UI.importRows = null; render(); },
    doImport: function () {
      var rows = UI.importRows.filter(function (r) { return r.keep && r.oppRank && r.result && r.date; });
      rows.forEach(addImported);
      calibrateFromTenup();
      S.tenup.lastImport = E.iso(today()); S.onboarded = true; save();
      UI.importRows = null; UI.importText = "";
      toast(plural(rows.length, "match importé", "matchs importés") + ".");
      go(S.profile.rank ? "" : "profil");
    },
    // données
    export: function () { backup(false); },
    exportShare: function () { backup(true); },
    wipe: function () {
      if (!confirm("Effacer tout ton palmarès, tes raquettes et ton profil de cet appareil ?")) return;
      S = blank(); save(); UI.draft = null; go("bienvenue");
    }
  };

  function fallbackCopy(text) {
    var ta = document.createElement("textarea"); ta.value = text; ta.setAttribute("readonly", ""); ta.style.position = "fixed"; ta.style.opacity = "0";
    document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); } catch (e) {} ta.remove();
  }

  // ---------- Événements ----------
  app.addEventListener("click", function (ev) {
    var el = ev.target.closest("[data-a]");
    if (!el || el.tagName === "INPUT") return;
    var a = el.dataset.a;
    if (A[a]) { if (el.tagName !== "A" || a === "bmHelp") ev.preventDefault(); A[a](el, ev); }
  });
  app.addEventListener("input", function (ev) {
    var el = ev.target;
    if (el.dataset.f === "profile.name") { S.profile.name = el.value.trim().slice(0, 30); save(); }
    else if (el.dataset.f === "profile.licence") { S.profile.licence = el.value.replace(/\s+/g, "").toUpperCase().slice(0, 12); save(); }
    else if (el.dataset.f === "importText") UI.importText = el.value;
    else if (el.dataset.d && el.type !== "checkbox" && el.tagName !== "SELECT") UI.draft[el.dataset.d] = el.value;
    else if (el.dataset.r && el.type !== "checkbox") UI.racketDraft[el.dataset.r] = el.value;
    else if (el.dataset.sl) UI.slotDraft[el.dataset.sl] = el.value;
    refreshSaveBar();
  });
  app.addEventListener("change", function (ev) {
    var el = ev.target;
    if (el.dataset.f === "profile.rank") { S.profile.rank = el.value; save(); render(); }
    else if (el.dataset.d === "wo") UI.draft.wo = el.checked;
    else if (el.dataset.d === "newString") UI.draft.newString = el.checked;
    else if (el.dataset.d && el.tagName === "SELECT") UI.draft[el.dataset.d] = el.value;
    else if (el.dataset.d === "date") UI.draft.date = el.value;
    else if (el.dataset.r === "main") UI.racketDraft.main = el.checked;
    else if (el.dataset.split) {
      var o = el.dataset.split === "match" ? UI.draft : UI.racketDraft;
      o.tensionCross = el.checked ? (o.tension || 24) - 1 : null; if (el.checked && !o.tension) o.tension = 24; render();
    }
    else if (el.dataset.on != null) { S.oppNotes = S.oppNotes || {}; var tx = el.value.trim(); if (tx) S.oppNotes[el.dataset.on] = { text: tx, at: E.iso(today()) }; else delete S.oppNotes[el.dataset.on]; save(); toast("Fiche enregistrée."); }
    else if (el.dataset.rs != null) { UI.racketDraft.restrings[+el.dataset.rs] = el.value; }
    else if (el.dataset.ir != null) {
      var r = UI.importRows[+el.dataset.ir], k = el.dataset.k;
      r[k] = el.type === "checkbox" ? el.checked : el.value;
      if (k !== "keep") { r.ok = !!(r.oppRank && r.result && r.date); if (r.ok && !r.dup) r.keep = true; render(); }
    } else if (el.dataset.a === "persoToggle") {
      var pg = el.dataset.p, pr = prefsOf(pg), k = el.dataset.k;
      pr.hidden = pr.hidden.filter(function (x) { return x !== k; }); if (!el.checked) pr.hidden.push(k);
      S.prefs[pg] = pr; save(); render();
    } else if (el.dataset.a === "notifSwitch") {
      if (el.checked) askNotif(); else { S.notif = false; save(); if (LN) LN.cancel({ notifications: [{ id: 1001 }] }).catch(function () {}); }
    } else if (el.dataset.a === "pdfFile" && el.files && el.files[0]) { importPdfFile(el.files[0]);
    } else if (el.dataset.a === "importFile" && el.files && el.files[0]) {
      var fr = new FileReader();
      fr.onload = function () {
        try {
          var d = JSON.parse(fr.result);
          if (!d || !Array.isArray(d.matches)) throw new Error();
          S = Object.assign(blank(), d); S.onboarded = true; save(); toast("Sauvegarde restaurée."); go("");
        } catch (e) { toast("Ce fichier n'est pas une sauvegarde Montée."); }
      };
      fr.readAsText(el.files[0]);
    }
    refreshSaveBar();
  });
  app.addEventListener("submit", function (ev) { ev.preventDefault(); if (ev.target.dataset.form === "tenup") A.tenupConnect(); });
  // Infobulle de la courbe (toucher ou survol)
  function tip(ev) {
    var t = ev.target.closest && ev.target.closest("[data-tip]"); var box = document.getElementById("tip");
    if (t && box) box.textContent = t.getAttribute("data-tip");
  }
  // Tirer vers le bas (accueil, palmarès, courbes) : synchro Ten'Up
  (function () {
    var y0 = null, x0 = 0, dy = 0, dx = 0, t0 = 0, el = null, busy = false, TH = 140;
    function mode() { return (S.prefs && S.prefs.pull) || "normal"; }
    function ok() { return NATIVE && mode() !== "off" && !document.body.classList.contains("locked") && ["", "palmares", "courbes"].indexOf(route().split("/")[0]) >= 0 && !UI.draft && (window.scrollY || document.documentElement.scrollTop) <= 0; }
    function bar() {
      if (!el) { el = document.createElement("div"); el.className = "ptr"; el.setAttribute("aria-live", "polite"); document.body.appendChild(el); }
      return el;
    }
    function show(h, txt, spin) { var b = bar(); b.style.transform = "translate(-50%," + Math.round(h) + "px)"; b.style.opacity = h > 8 ? 1 : 0; b.innerHTML = (spin ? '<span class="spin"></span>' : '<span class="ptr-arrow' + (dy > TH ? " up" : "") + '">↓</span>') + "<span>" + txt + "</span>"; }
    function hide() { if (el) { el.style.transform = "translate(-50%,-60px)"; el.style.opacity = 0; } }
    document.addEventListener("touchstart", function (e) { if (busy || !ok() || e.touches.length !== 1) { y0 = null; return; } TH = mode() === "ferme" ? 210 : 140; y0 = e.touches[0].clientY; x0 = e.touches[0].clientX; t0 = Date.now(); dy = 0; dx = 0; }, { passive: true });
    document.addEventListener("touchmove", function (e) {
      if (y0 == null) return;
      dy = e.touches[0].clientY - y0; dx = Math.abs(e.touches[0].clientX - x0);
      if (dx > 40 && dx > dy * 0.6) { y0 = null; hide(); return; } // geste plutôt horizontal : on ignore
      if (dy <= 0 || (window.scrollY || 0) > 0) { hide(); return; }
      show(Math.min(dy * 0.5, 70) - 10, dy > TH ? "Relâche pour synchroniser Ten'Up" : "Tire pour synchroniser Ten'Up");
    }, { passive: true });
    document.addEventListener("touchend", function () {
      if (y0 == null) return; y0 = null;
      if (dy > TH && Date.now() - t0 > 250) {
        busy = true; show(50, "Synchronisation avec Ten'Up…", true);
        nativeRefresh(false, true).then(function () { busy = false; hide(); }, function () { busy = false; hide(); });
      } else hide();
      dy = 0;
    }, { passive: true });
  })();

  // Clavier : on ramène le champ actif au centre de l'écran une fois le clavier ouvert
  document.addEventListener("focusin", function (e) {
    var t = e.target; if (!t || !/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)) return;
    setTimeout(function () { try { t.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (x) {} }, 350);
  });
  if (window.visualViewport) window.visualViewport.addEventListener("resize", function () {
    document.body.classList.toggle("kb-open", window.visualViewport.height < window.innerHeight * 0.78);
    var a = document.activeElement; if (a && /^(INPUT|TEXTAREA)$/.test(a.tagName)) try { a.scrollIntoView({ block: "center" }); } catch (x) {}
  });

  app.addEventListener("mouseover", tip);
  app.addEventListener("touchstart", tip, { passive: true });
  app.addEventListener("click", tip);
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && UI.menu) { UI.menu = false; render(); } });

  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && UI.awaitTenup) {
      UI.awaitTenup = false; UI.backFromTenup = true;
      if (route() === "tenup") { render(); var b = app.querySelector('[data-a="importClipboard"]'); if (b) { b.scrollIntoView({ block: "center" }); b.focus(); } }
    }
  });
  window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); UI.installEvt = e; });

  // ---------- Démarrage ----------
  if (!NATIVE && "serviceWorker" in navigator && location.protocol === "https:") {
    window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
  }
  if (location.hash.indexOf("#import=") === 0) handleImportHash();
  else render();
  if (NATIVE) {
    try { nativeWake(); } catch (e) {}
    try {
      var l = AppP && AppP.addListener("appStateChange", function (st) { if (st && st.isActive) nativeWake(); });
      if (l && l.catch) l.catch(function () {});
    } catch (e) {}
    // Bouton retour du téléphone : mêmes règles que la flèche (garde-fou si modifications en cours)
    try {
      var bl = AppP && AppP.addListener("backButton", function () {
        if (UI.leaveAsk) { UI.leaveAsk = false; render(); return; }
        if (UI.sheet) { UI.sheet = null; render(); return; }
        if (UI.rkMenu || UI.menu) { UI.rkMenu = false; UI.menu = false; render(); return; }
        if (document.querySelector(".confetti")) { var cf = document.querySelector(".confetti"); cf.remove(); return; }
        var r = route();
        if (isDirty()) { UI.leaveAsk = true; render(); return; }
        if (r === "" || r === "bienvenue") { if (AppP.exitApp) AppP.exitApp(); return; }
        A.back();
      });
      if (bl && bl.catch) bl.catch(function () {});
    } catch (e) {}
  }
})();
