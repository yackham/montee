# Fiche App Store — Montée

Textes prêts à copier dans App Store Connect (Distribution › ta version iOS).

## Informations de l'app

| Champ | Valeur |
|---|---|
| Nom (30 car. max) | Montée – Classement tennis |
| Sous-titre (30 car. max) | Ton classement avant la sortie |
| Identifiant de lot (Bundle ID) | fr.montennis.app |
| SKU | montee |
| Langue principale | Français |
| Catégorie principale | Sports |
| Catégorie secondaire | Utilitaires |
| Prix | Gratuit |
| URL d'assistance | https://montennis.netlify.app/confidentialite.html#contact |
| URL de confidentialité | https://montennis.netlify.app/confidentialite.html |
| URL marketing (facultatif) | https://montennis.netlify.app |
| Copyright | 2026 Yann Munier |

> Si le nom « Montée – Classement tennis » est déjà pris, essaie « Montée : classement tennis » ou « Montée Tennis ».

## Texte promotionnel (170 car. max, modifiable sans nouvelle version)

Tu montes ce mois-ci ? Montée recalcule ton bilan avant chaque sortie du classement et te dit exactement ce qu'il te manque.

## Description

Tu montes ce mois-ci ? Montée te le dit avant mardi.

Montée récupère ton palmarès depuis ton compte Ten'Up et recalcule ton bilan comme le fait le classement mensuel : 12 mois glissants, points de chaque victoire, victoires prises en compte, normes de chaque échelon.

CE QUE TU VOIS EN UN COUP D'ŒIL
• Si tu montes, te maintiens ou risques de descendre à la prochaine sortie
• Combien de points il te manque pour l'échelon d'au-dessus
• Contre quel classement une victoire suffit pour monter
• Les victoires qui vont sortir de tes 12 mois, et ce qu'elles te coûtent
• Ta simulation officielle, sans avoir à la relancer

TES MATCHS, AUTOMATIQUEMENT
Connecte ton compte une fois sur la page officielle : Montée vérifie tes nouveaux matchs et te prévient. Nouveau match détecté, points gagnés, montée ou pas : tu le sais tout de suite.

LE CHEMIN LE PLUS COURT
Montée simule tes prochaines victoires avec le vrai calcul et te propose les pistes à ta portée : contre qui une victoire suffit, ou quelle combinaison de victoires te fait monter.

TES COURBES, AU TOUCHER
• L'évolution de ton bilan, mois par mois : touche un point pour voir le détail
• Les points à défendre aux prochaines sorties
• Ton plafond : contre quels classements tu gagnes et tu perds, match par match
• Ton mental : premiers sets, matchs en trois sets, tie-breaks
• Tes records, ton temps de jeu, où tu gagnes le plus

SIX THÈMES
Lin, Nuit, Terre battue, Dur, Gazon, ou Auto qui suit le mode sombre de ton iPhone.

TON MATÉRIEL
Note ta raquette, ton cordage et ta tension (y compris montants et travers différents), et tes entraînements. Montée estime tes heures de jeu sur chaque cordage, te prévient quand un monofilament approche des 20 h, et te montre avec quoi tu gagnes et comment tu te sens. Tu sais quand recorder.

TES DONNÉES RESTENT CHEZ TOI
Pas de compte Montée, pas de serveur, pas de pub, pas de pisteur. Ton mot de passe Ten'Up n'est jamais vu par Montée. Tout reste sur ton téléphone.

Montée est une application indépendante. Elle n'est ni éditée ni approuvée par la Fédération Française de Tennis. Les calculs sont indicatifs : seul le classement officiel fait foi.

## Mots-clés (100 car. max, séparés par des virgules, sans espace)

tennis,classement,FFT,palmarès,simulation,montée,15/1,30/1,bilan,tournoi,cordage,raquette,stats

## Nouveautés de cette version

Première version de Montée sur l'App Store : calcul du classement, pistes pour monter, courbes interactives, suivi du matériel et six thèmes.

## Captures d'écran

Dossier `captures/` : 6 images 1290 × 2796 (format iPhone 6,7 pouces, accepté pour l'iPhone 6,9 pouces), dans l'ordre des numéros : 1-accueil, 2-pistes, 3-courbes, 4-materiel, 5-themes, 6-palmares.

## Confidentialité (questionnaire « App Privacy »)

- Collectez-vous des données à partir de cette app ? **Non, nous ne collectons pas de données.**
  (Tout est stocké sur l'appareil ; rien n'est envoyé au développeur ni à un tiers.)

## Classification par âge

Répondre « Aucun » partout → **4+**.

## Conformité export (chiffrement)

Déjà déclaré dans l'app (`ITSAppUsesNonExemptEncryption = NO`) : rien à faire.

## Notes pour l'équipe de vérification Apple (App Review Information)

À coller dans « Notes » :

> Montée helps French tennis players understand their FFT ranking (the monthly "classement" computed by the French Tennis Federation). Players can import their own match history from their personal Ten'Up account (tenup.fft.fr): the official Ten'Up login page is displayed in a web view, the user signs in there, and the app reads the user's own match list with that session, directly on the device. No credentials are seen or stored by the app, and no data leaves the device (no backend).
>
> To review without a Ten'Up account: on the first screen tap "C'est parti", then "Essayer avec un exemple" at the bottom of the next screen. This loads sample data and shows every feature (home projection, paths to the next ranking, interactive charts, equipment tracking, themes in the gear menu next to the ranking).
>
> Montée is an independent app, not affiliated with or endorsed by the Fédération Française de Tennis. Notifications are local only.

Compte de démonstration : laisser vide (cocher « Connexion requise » : non).
