package fr.montennis.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/**
 * Widgets de l'écran d'accueil. L'app web calcule les données (Tenup.setWidgets),
 * ici on ne fait que les dessiner. Toucher un widget ouvre Montée sur le bon écran.
 */
public final class MonteeWidgets {
    private MonteeWidgets() {}

    static final int INK = 0xFF121212, WHITE = 0xFFFFFFFF, GAZON = 0xFF1F5C3F, BALLE = 0xFFD4E64A, TERRE = 0xFFB04A22, TERRE_DARK = 0xFF7A3115;

    static final Class<?>[] ALL = {
            WidgetClassement.class, WidgetCordage.class, WidgetForme.class,
            WidgetSortie.class, WidgetSemaine.class, WidgetTableau.class
    };

    static JSONObject data(Context ctx) {
        try {
            String s = MonteeStore.get(ctx, "widgets");
            return s == null ? new JSONObject() : new JSONObject(s);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    static void updateAll(Context ctx) {
        AppWidgetManager m = AppWidgetManager.getInstance(ctx);
        for (Class<?> c : ALL) {
            int[] ids = m.getAppWidgetIds(new ComponentName(ctx, c));
            if (ids == null || ids.length == 0) continue;
            Intent i = new Intent(ctx, c).setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
            i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
            ctx.sendBroadcast(i);
        }
    }

    /** Ouvre Montée avec une adresse montee://… que l'app web exécute. */
    static PendingIntent open(Context ctx, String url) {
        Intent i = new Intent(ctx, MainActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse(url))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, url.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** « J-17 », « Aujourd'hui » ou « » selon la date de sortie. */
    static String countdown(JSONObject d) {
        String iso = d.optString("releaseIso", "");
        if (iso.length() < 10) return "";
        try {
            Calendar r = Calendar.getInstance();
            r.set(Integer.parseInt(iso.substring(0, 4)), Integer.parseInt(iso.substring(5, 7)) - 1, Integer.parseInt(iso.substring(8, 10)), 0, 0, 0);
            Calendar t = Calendar.getInstance();
            t.set(Calendar.HOUR_OF_DAY, 0); t.set(Calendar.MINUTE, 0); t.set(Calendar.SECOND, 0);
            long days = Math.round((r.getTimeInMillis() - t.getTimeInMillis()) / 86400000.0);
            if (days < 0) return "";
            return days == 0 ? "Aujourd'hui" : "J-" + days;
        } catch (Exception e) {
            return "";
        }
    }

    static String releaseLabel(JSONObject d) {
        String iso = d.optString("releaseIso", "");
        if (iso.length() < 10) return "";
        String[] mois = {"janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."};
        try {
            int m = Integer.parseInt(iso.substring(5, 7)), day = Integer.parseInt(iso.substring(8, 10));
            return day + " " + mois[m - 1];
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- Base commune ----------
    public abstract static class Base extends AppWidgetProvider {
        abstract RemoteViews build(Context ctx, JSONObject d);

        @Override
        public void onUpdate(Context ctx, AppWidgetManager m, int[] ids) {
            JSONObject d = data(ctx);
            for (int id : ids) {
                try {
                    m.updateAppWidget(id, build(ctx, d));
                } catch (Exception ignored) {
                }
            }
        }
    }

    // ---------- 1. Mon classement (petit) ----------
    static RemoteViews classement(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_classement);
        boolean up = "montee".equals(d.optString("status"));
        boolean down = "descente".equals(d.optString("status"));
        v.setInt(R.id.w_root, "setBackgroundResource", up ? R.drawable.w_bg_gazon : down ? R.drawable.w_bg_terre : R.drawable.w_bg_balle);
        String cd = countdown(d);
        v.setTextViewText(R.id.w_k, up ? "Montée !" : "Sortie" + (cd.isEmpty() ? "" : " · " + cd));
        v.setTextViewText(R.id.w_big, d.optString("rank", "—").isEmpty() ? "—" : d.optString("rank"));
        String line = d.optString("line", "Ouvre Montée");
        if (up) line = "dans la poche\nsortie du " + releaseLabel(d);
        v.setTextViewText(R.id.w_t, line);
        int fg = up ? WHITE : down ? TERRE_DARK : INK;
        v.setTextColor(R.id.w_k, up ? BALLE : fg);
        v.setTextColor(R.id.w_big, up ? BALLE : fg);
        v.setTextColor(R.id.w_t, fg);
        v.setOnClickPendingIntent(R.id.w_root, open(ctx, "montee://open/projection"));
        return v;
    }

    // ---------- 2. Mon cordage (petit) ----------
    static RemoteViews cordage(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_cordage);
        JSONObject r = d.optJSONObject("racket");
        if (r == null) {
            v.setTextViewText(R.id.w_k, "Ton matériel");
            v.setTextViewText(R.id.w_big, "+");
            v.setTextViewText(R.id.w_t, "Ajoute ta raquette");
            v.setOnClickPendingIntent(R.id.w_root, open(ctx, "montee://open/raquette/new"));
            return v;
        }
        String level = r.optString("level", "ok");
        boolean warn = "soon".equals(level) || "change".equals(level) || "broken".equals(level);
        v.setTextViewText(R.id.w_k, r.optString("name"));
        v.setTextViewText(R.id.w_big, r.optString("hours", "?").replace("≈ ", ""));
        v.setViewVisibility(R.id.w_ring_ok, warn ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.w_ring_warn, warn ? View.VISIBLE : View.GONE);
        v.setProgressBar(warn ? R.id.w_ring_warn : R.id.w_ring_ok, 100, r.optInt("pct", 0), false);
        v.setTextViewText(R.id.w_t, r.optString("msg"));
        v.setTextColor(R.id.w_t, warn ? TERRE : INK);
        v.setOnClickPendingIntent(R.id.w_root, open(ctx, "montee://open/raquette/" + r.optString("id")));
        return v;
    }

    // ---------- 3. Ma forme (petit) ----------
    static RemoteViews forme(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_forme);
        int[] ids = {R.id.w_d1, R.id.w_d2, R.id.w_d3, R.id.w_d4, R.id.w_d5};
        JSONArray f = d.optJSONArray("form");
        for (int i = 0; i < 5; i++) {
            String r = f != null && i < f.length() ? f.optString(i) : "";
            v.setTextViewText(ids[i], r);
            v.setInt(ids[i], "setBackgroundResource", "V".equals(r) ? R.drawable.w_dot_v : "D".equals(r) ? R.drawable.w_dot_d : R.drawable.w_dot_empty);
            v.setTextColor(ids[i], "D".equals(r) ? TERRE : WHITE);
        }
        v.setTextViewText(R.id.w_t, d.optString("streak", ""));
        v.setTextViewText(R.id.w_s, d.optString("record", ""));
        v.setOnClickPendingIntent(R.id.w_root, open(ctx, "montee://open/palmares"));
        return v;
    }

    // ---------- 4. Prochaine sortie (moyen) ----------
    static RemoteViews sortie(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_sortie);
        boolean up = "montee".equals(d.optString("status"));
        boolean down = "descente".equals(d.optString("status"));
        v.setInt(R.id.w_root, "setBackgroundResource", up ? R.drawable.w_bg_gazon : down ? R.drawable.w_bg_terre : R.drawable.w_bg_balle);
        String cd = countdown(d), rel = releaseLabel(d);
        v.setTextViewText(R.id.w_k, (rel.isEmpty() ? "Prochaine sortie" : "Sortie du " + rel) + (cd.isEmpty() ? "" : " · " + cd));
        v.setTextViewText(R.id.w_k2, d.optString("target", ""));
        v.setTextViewText(R.id.w_h, d.optString("headline", "Ouvre Montée"));
        boolean hasBar = d.has("norme");
        v.setViewVisibility(R.id.w_bar, hasBar && !up ? View.VISIBLE : View.GONE);
        v.setViewVisibility(R.id.w_bar2, hasBar && up ? View.VISIBLE : View.GONE);
        v.setProgressBar(up ? R.id.w_bar2 : R.id.w_bar, 100, d.optInt("pct", 0), false);
        if (up) {
            v.setTextViewText(R.id.w_l, d.optString("next", ""));
            v.setTextViewText(R.id.w_r, "");
        } else if (hasBar) {
            v.setTextViewText(R.id.w_l, d.optInt("total") + " pts au bilan");
            v.setTextViewText(R.id.w_r, "il en faut " + d.optInt("norme"));
        }
        int fg = up ? WHITE : down ? TERRE_DARK : INK;
        for (int id : new int[]{R.id.w_k, R.id.w_k2, R.id.w_l, R.id.w_r}) v.setTextColor(id, up ? 0xCCFFFFFF : fg);
        v.setTextColor(R.id.w_h, up ? BALLE : fg);
        v.setOnClickPendingIntent(R.id.w_root, open(ctx, "montee://open/projection"));
        return v;
    }

    // ---------- 5. Ma semaine (moyen) ----------
    static RemoteViews semaine(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_semaine);
        JSONObject w = d.optJSONObject("week");
        if (w == null) w = new JSONObject();
        v.setTextViewText(R.id.w_big, w.optString("total", "0 h"));
        v.setTextViewText(R.id.w_k2, w.optString("streak", ""));
        int[] days = {R.id.w_day0, R.id.w_day1, R.id.w_day2, R.id.w_day3, R.id.w_day4, R.id.w_day5, R.id.w_day6};
        int[] labels = {R.id.w_dl0, R.id.w_dl1, R.id.w_dl2, R.id.w_dl3, R.id.w_dl4, R.id.w_dl5, R.id.w_dl6};
        JSONArray a = w.optJSONArray("days");
        int today = w.optInt("todayIdx", -1);
        for (int i = 0; i < 7; i++) {
            String k = a != null && i < a.length() ? a.optString(i) : "";
            v.setInt(days[i], "setBackgroundResource", "m".equals(k) ? R.drawable.w_dot_v : "t".equals(k) ? R.drawable.w_dot_t : R.drawable.w_dot_empty);
            v.setTextColor(labels[i], i == today ? INK : 0xB3121212);
        }
        JSONObject sl = w.optJSONObject("slot");
        if (sl != null) {
            v.setTextViewText(R.id.w_t, sl.optString("label"));
            boolean ask = sl.optBoolean("ask", false);
            v.setViewVisibility(R.id.w_btn, ask ? View.VISIBLE : View.GONE);
            if (ask) v.setOnClickPendingIntent(R.id.w_btn, open(ctx, "montee://slot/yes?id=" + Uri.encode(sl.optString("id")) + "&d=" + Uri.encode(sl.optString("date"))));
        } else {
            v.setTextViewText(R.id.w_t, "Ajoute ta semaine type");
            v.setViewVisibility(R.id.w_btn, View.GONE);
        }
        v.setOnClickPendingIntent(R.id.w_root, open(ctx, "montee://open/materiel"));
        return v;
    }

    // ---------- 6. Tableau de bord (grand) ----------
    static RemoteViews tableau(Context ctx, JSONObject d) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_tableau);
        boolean up = "montee".equals(d.optString("status"));
        v.setTextViewText(R.id.w_big, d.optString("rank", "—").isEmpty() ? "—" : d.optString("rank"));
        v.setTextColor(R.id.w_big, up ? GAZON : INK);
        String cd = countdown(d);
        v.setTextViewText(R.id.w_k, up ? "Montée !" : "Sortie" + (cd.isEmpty() ? "" : " · " + cd));
        String h = d.optString("headline", "Ouvre Montée");
        if (up && d.has("next")) h += ". " + d.optString("next") + ".";
        v.setTextViewText(R.id.w_h, h);
        v.setViewVisibility(R.id.w_bar, d.has("norme") ? View.VISIBLE : View.GONE);
        v.setProgressBar(R.id.w_bar, 100, d.optInt("pct", 0), false);
        int[] rows = {R.id.w_row1, R.id.w_row2, R.id.w_row3}, rb = {R.id.w_rb1, R.id.w_rb2, R.id.w_rb3}, ro = {R.id.w_ro1, R.id.w_ro2, R.id.w_ro3}, rr = {R.id.w_rr1, R.id.w_rr2, R.id.w_rr3};
        JSONArray last = d.optJSONArray("last");
        v.setViewVisibility(R.id.w_lasttitle, last != null && last.length() > 0 ? View.VISIBLE : View.GONE);
        for (int i = 0; i < 3; i++) {
            JSONObject m = last != null && i < last.length() ? last.optJSONObject(i) : null;
            if (m == null) { v.setViewVisibility(rows[i], View.GONE); continue; }
            v.setViewVisibility(rows[i], View.VISIBLE);
            boolean win = "V".equals(m.optString("r"));
            v.setTextViewText(rb[i], win ? "V" : "D");
            v.setInt(rb[i], "setBackgroundResource", win ? R.drawable.w_badge_v : R.drawable.w_badge_d);
            v.setTextColor(rb[i], win ? WHITE : TERRE);
            v.setTextViewText(ro[i], m.optString("opp"));
            v.setTextViewText(rr[i], m.optString("right"));
            v.setTextColor(rr[i], win ? GAZON : 0xB3121212);
        }
        JSONObject r = d.optJSONObject("racket");
        if (r != null) {
            String level = r.optString("level", "ok");
            boolean warn = "soon".equals(level) || "change".equals(level) || "broken".equals(level);
            v.setViewVisibility(R.id.w_rk, View.VISIBLE);
            v.setInt(R.id.w_rk, "setBackgroundResource", warn ? R.drawable.w_box_terre : R.drawable.w_box_chip);
            v.setTextViewText(R.id.w_rkn, r.optString("name") + " · " + r.optString("hours"));
            v.setTextViewText(R.id.w_rkm, r.optString("msg"));
            v.setTextColor(R.id.w_rkn, warn ? TERRE_DARK : INK);
            v.setTextColor(R.id.w_rkm, warn ? TERRE_DARK : INK);
        } else {
            v.setViewVisibility(R.id.w_rk, View.GONE);
        }
        v.setOnClickPendingIntent(R.id.w_root, open(ctx, "montee://open/"));
        return v;
    }
}
