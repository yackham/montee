package fr.montennis.app;

/** Widget « cordage » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetCordage extends MonteeWidgets.Base {
}
