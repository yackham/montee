package fr.montennis.app;

/** Widget « joueurs » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetJoueurs extends MonteeWidgets.Base {
}
