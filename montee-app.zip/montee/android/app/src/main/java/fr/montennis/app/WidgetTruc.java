package fr.montennis.app;

/** Widget « truc » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetTruc extends MonteeWidgets.Base {
}
