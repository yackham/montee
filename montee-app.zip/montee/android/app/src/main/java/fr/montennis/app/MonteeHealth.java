package fr.montennis.app;

import android.content.Context;
import android.content.pm.PackageManager;
import android.health.connect.HealthConnectException;
import android.health.connect.HealthConnectManager;
import android.health.connect.ReadRecordsRequestUsingFilters;
import android.health.connect.ReadRecordsResponse;
import android.health.connect.TimeInstantRangeFilter;
import android.health.connect.datatypes.Device;
import android.health.connect.datatypes.ExerciseSessionRecord;
import android.health.connect.datatypes.ExerciseSessionType;
import android.health.connect.datatypes.Metadata;
import android.os.Build;
import android.os.OutcomeReceiver;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Santé connectée (Health Connect, intégré à Android 14 et plus) : lecture seule des séances de tennis.
 * Montée n'écrit rien et n'envoie rien : les séances sont seulement proposées dans l'app.
 */
final class MonteeHealth {
    private MonteeHealth() {}

    static final String READ_EXERCISE = "android.permission.health.READ_EXERCISE";
    static final String READ_BACKGROUND = "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND";

    /** Health Connect est intégré au système à partir d'Android 14. */
    static boolean supported() {
        return Build.VERSION.SDK_INT >= 34;
    }

    static boolean granted(Context ctx) {
        return supported() && ContextCompat.checkSelfPermission(ctx, READ_EXERCISE) == PackageManager.PERMISSION_GRANTED;
    }

    /** Lecture en arrière-plan : Android 15 et plus, sur autorisation. */
    static boolean background(Context ctx) {
        return Build.VERSION.SDK_INT >= 35 && granted(ctx)
                && ContextCompat.checkSelfPermission(ctx, READ_BACKGROUND) == PackageManager.PERMISSION_GRANTED;
    }

    static String[] permissions() {
        return Build.VERSION.SDK_INT >= 35 ? new String[]{READ_EXERCISE, READ_BACKGROUND} : new String[]{READ_EXERCISE};
    }

    /** Séances de tennis des `days` derniers jours. À appeler hors du fil principal. Null si erreur. */
    static JSONArray readTennis(Context ctx, int days) {
        if (Build.VERSION.SDK_INT < 34 || !granted(ctx)) return null;
        return Reader.read(ctx, days);
    }

    @RequiresApi(api = 34)
    private static final class Reader {
        static JSONArray read(Context ctx, int days) {
            final HealthConnectManager hcm = ctx.getSystemService(HealthConnectManager.class);
            if (hcm == null) return null;
            final JSONArray out = new JSONArray();
            final boolean[] ok = {false};
            final CountDownLatch latch = new CountDownLatch(1);
            final ExecutorService ex = Executors.newSingleThreadExecutor();
            try {
                Instant end = Instant.now();
                Instant start = end.minus(Math.max(1, days), ChronoUnit.DAYS);
                ReadRecordsRequestUsingFilters<ExerciseSessionRecord> req =
                        new ReadRecordsRequestUsingFilters.Builder<>(ExerciseSessionRecord.class)
                                .setTimeRangeFilter(new TimeInstantRangeFilter.Builder().setStartTime(start).setEndTime(end).build())
                                .setPageSize(500)
                                .build();
                hcm.readRecords(req, ex, new OutcomeReceiver<ReadRecordsResponse<ExerciseSessionRecord>, HealthConnectException>() {
                    @Override
                    public void onResult(ReadRecordsResponse<ExerciseSessionRecord> res) {
                        try {
                            for (ExerciseSessionRecord r : res.getRecords()) {
                                if (r.getExerciseType() != ExerciseSessionType.EXERCISE_SESSION_TYPE_TENNIS) continue;
                                JSONObject o = new JSONObject();
                                Metadata md = r.getMetadata();
                                o.put("id", md.getId());
                                o.put("start", r.getStartTime().toEpochMilli());
                                o.put("end", r.getEndTime().toEpochMilli());
                                CharSequence t = r.getTitle();
                                if (t != null) o.put("title", t.toString());
                                if (md.getDataOrigin() != null) o.put("origin", md.getDataOrigin().getPackageName());
                                Device dv = md.getDevice();
                                if (dv != null) {
                                    String name = ((dv.getManufacturer() == null ? "" : dv.getManufacturer()) + " " + (dv.getModel() == null ? "" : dv.getModel())).trim();
                                    if (!name.isEmpty()) o.put("device", name);
                                    o.put("deviceType", dv.getType());
                                }
                                out.put(o);
                            }
                            ok[0] = true;
                        } catch (Exception ignored) {
                        }
                        latch.countDown();
                    }

                    @Override
                    public void onError(@NonNull HealthConnectException e) {
                        latch.countDown();
                    }
                });
                latch.await(20, TimeUnit.SECONDS);
            } catch (Exception ignored) {
            } finally {
                ex.shutdown();
            }
            return ok[0] ? out : null;
        }
    }
}
