package fr.montennis.app;

/** Widget « sortie » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetSortie extends MonteeWidgets.Base {
}
