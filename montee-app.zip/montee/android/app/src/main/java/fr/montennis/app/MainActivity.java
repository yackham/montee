package fr.montennis.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Le plugin maison doit être enregistré avant super.onCreate
        registerPlugin(TenupPlugin.class);
        super.onCreate(savedInstanceState);
        keepWidgetAction(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        keepWidgetAction(intent);
    }

    /** Un widget a été touché : on garde l'action, l'app web la lit au réveil (Tenup.takeAction). */
    private void keepWidgetAction(Intent intent) {
        if (intent == null) return;
        Uri u = intent.getData();
        if (u != null && "montee".equals(u.getScheme())) {
            MonteeStore.put(this, "action", u.toString());
            intent.setData(null);
        }
    }
}
