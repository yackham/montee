package fr.montennis.app;

/** Widget « semaine » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetSemaine extends MonteeWidgets.Base {
}
