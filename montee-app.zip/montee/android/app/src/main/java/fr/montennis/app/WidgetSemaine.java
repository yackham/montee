package fr.montennis.app;

import android.content.Context;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class WidgetSemaine extends MonteeWidgets.Base {
    @Override
    RemoteViews build(Context ctx, JSONObject d) {
        return MonteeWidgets.semaine(ctx, d);
    }
}
