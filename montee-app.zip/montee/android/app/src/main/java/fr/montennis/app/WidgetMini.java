package fr.montennis.app;

/** Widget « mini » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetMini extends MonteeWidgets.Base {
}
