package fr.montennis.app;

import android.content.Context;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class WidgetForme extends MonteeWidgets.Base {
    @Override
    RemoteViews build(Context ctx, JSONObject d) {
        return MonteeWidgets.forme(ctx, d);
    }
}
