package fr.montennis.app;

/** Widget « forme » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetForme extends MonteeWidgets.Base {
}
