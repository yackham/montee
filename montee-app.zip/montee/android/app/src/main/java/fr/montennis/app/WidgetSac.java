package fr.montennis.app;

/** Widget « sac » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetSac extends MonteeWidgets.Base {
}
