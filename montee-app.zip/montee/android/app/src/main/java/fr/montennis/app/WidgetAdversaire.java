package fr.montennis.app;

/** Widget « adversaire » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetAdversaire extends MonteeWidgets.Base {
}
