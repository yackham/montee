package fr.montennis.app;

/** Widget « defend » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetDefend extends MonteeWidgets.Base {
}
