package fr.montennis.app;

import android.content.Context;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class WidgetTableau extends MonteeWidgets.Base {
    @Override
    RemoteViews build(Context ctx, JSONObject d) {
        return MonteeWidgets.tableau(ctx, d);
    }
}
