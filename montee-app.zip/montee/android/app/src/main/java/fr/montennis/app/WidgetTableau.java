package fr.montennis.app;

/** Widget « tableau » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetTableau extends MonteeWidgets.Base {
}
