package fr.montennis.app;

/** Widget « classement » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetClassement extends MonteeWidgets.Base {
}
