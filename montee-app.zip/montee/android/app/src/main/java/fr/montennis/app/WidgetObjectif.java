package fr.montennis.app;

/** Widget « objectif » : image dessinée par l'app (voir MonteeWidgets). */
public class WidgetObjectif extends MonteeWidgets.Base {
}
