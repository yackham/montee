package fr.montennis.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** En arrière-plan (toutes les 3 h environ, quand Android le permet) : nouveaux matchs et notification. */
public class MonteeWorker extends Worker {
    static final String NAME = "montee-refresh";

    public MonteeWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    static void schedule(Context ctx) {
        Constraints c = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(MonteeWorker.class, 3, TimeUnit.HOURS)
                .setConstraints(c)
                .setInitialDelay(1, TimeUnit.HOURS)
                .build();
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req);
    }

    static void cancel(Context ctx) {
        WorkManager.getInstance(ctx).cancelUniqueWork(NAME);
    }

    /** Lecture silencieuse de Ten'Up ; à appeler hors du fil principal. */
    static String fetch(final Context ctx, final String script, long timeoutSec) {
        return fetch(ctx, null, script, timeoutSec);
    }

    static String fetch(final Context ctx, final android.app.Activity activity, final String script, long timeoutSec) {
        final String[] out = {null};
        final CountDownLatch latch = new CountDownLatch(1);
        final Handler main = new Handler(Looper.getMainLooper());
        final TenupWeb[] holder = {null};
        main.post(() -> {
            TenupWeb tw = new TenupWeb(activity != null ? activity : ctx, script);
            holder[0] = tw;
            tw.listener = text -> { out[0] = text; latch.countDown(); return true; };
            tw.attachHidden(activity);
            tw.load();
        });
        try { latch.await(timeoutSec, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        main.post(() -> { if (holder[0] != null) holder[0].destroy(); });
        return out[0] == null ? "MONTEE-ERR délai dépassé" : out[0];
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        String script = MonteeStore.get(ctx, "script");
        String state = MonteeStore.get(ctx, "state");
        if (script == null || state == null) return Result.success();
        String text = fetch(ctx, script, 40);
        if (text.startsWith("MONTEE1")) {
            MonteeStore.put(ctx, "pending", text);
            String[] note = MonteeSummary.compute(ctx, text, MonteeStore.get(ctx, "state"));
            if (note != null) MonteeNotify.show(ctx, note[0], note[1]);
        } else if (text.contains("connecte-toi") && !MonteeStore.flag(ctx, "expiredNotified")) {
            MonteeStore.flag(ctx, "expiredNotified", true);
            MonteeNotify.show(ctx, "Ten'Up t'a déconnecté", "Ouvre Montée et reconnecte-toi pour suivre tes nouveaux matchs.");
        }
        return Result.success();
    }
}
