package fr.montennis.app;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.graphics.Color;
import android.view.View;
import android.view.Window;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import android.webkit.CookieManager;
import android.webkit.WebStorage;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Plugin appelé depuis l'app web (même interface que sur iPhone). */
@CapacitorPlugin(name = "Tenup")
public class TenupPlugin extends Plugin {

    @PluginMethod
    public void connect(final PluginCall call) {
        final String script = call.getString("script");
        if (script == null || script.isEmpty()) { call.reject("script manquant"); return; }
        final Context ctx = getContext();
        MonteeStore.put(ctx, "script", script);
        getActivity().runOnUiThread(() -> {
            TenupActivity.script = script;
            TenupActivity.callback = text -> {
                JSObject r = new JSObject();
                if (text != null) {
                    MonteeStore.flag(ctx, "expiredNotified", false);
                    r.put("data", text);
                } else {
                    r.put("cancelled", true);
                }
                call.resolve(r);
            };
            getActivity().startActivity(new Intent(getActivity(), TenupActivity.class));
        });
    }

    @PluginMethod
    public void refresh(final PluginCall call) {
        String s = call.getString("script");
        if (s == null || s.isEmpty()) s = MonteeStore.get(getContext(), "script");
        if (s == null || s.isEmpty()) { call.reject("script manquant"); return; }
        final String script = s;
        final Context ctx = getContext();
        final android.app.Activity activity = getActivity();
        MonteeStore.put(ctx, "script", script);
        new Thread(() -> {
            String text = MonteeWorker.fetch(ctx, activity, script, 25);
            JSObject r = new JSObject();
            r.put("data", text);
            call.resolve(r);
        }).start();
    }

    /** Requête ponctuelle sur Ten'Up (recherche de joueur, fiche d'un joueur) : le script n'est pas mémorisé. */
    @PluginMethod
    public void query(final PluginCall call) {
        final String script = call.getString("script");
        if (script == null || script.isEmpty()) { call.reject("script manquant"); return; }
        final Context ctx = getContext();
        final android.app.Activity activity = getActivity();
        new Thread(() -> {
            String text = MonteeWorker.fetch(ctx, activity, script, 30);
            JSObject r = new JSObject();
            r.put("data", text);
            call.resolve(r);
        }).start();
    }

    @PluginMethod
    public void setState(PluginCall call) {
        Context ctx = getContext();
        String state = call.getString("state");
        String script = call.getString("script");
        if (state != null) MonteeStore.put(ctx, "state", state);
        if (script != null && !script.isEmpty()) MonteeStore.put(ctx, "script", script);
        MonteeWorker.schedule(ctx);
        call.resolve();
    }

    @PluginMethod
    public void takePending(PluginCall call) {
        Context ctx = getContext();
        String pending = MonteeStore.get(ctx, "pending");
        JSObject r = new JSObject();
        if (pending != null) {
            MonteeStore.put(ctx, "pending", null);
            r.put("data", pending);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void setWidgets(PluginCall call) {
        String data = call.getString("data");
        if (data != null) MonteeStore.put(getContext(), "widgets", data);
        MonteeWidgets.updateAll(getContext());
        call.resolve();
    }

    /** Widgets posés sur l'écran d'accueil et leur taille, pour que l'app les dessine au bon format. */
    @PluginMethod
    public void widgetInfo(PluginCall call) {
        try {
            call.resolve(JSObject.fromJSONObject(MonteeWidgets.info(getContext())));
        } catch (Exception e) {
            call.resolve(new JSObject());
        }
    }

    /** Images des widgets dessinées par l'app (PNG en base64), plus les données utiles aux zones de toucher. */
    @PluginMethod
    public void setWidgetImages(PluginCall call) {
        Context ctx = getContext();
        String data = call.getString("data");
        if (data != null) MonteeStore.put(ctx, "widgets", data);
        JSObject imgs = call.getObject("images");
        if (imgs != null) {
            java.util.Iterator<String> it = imgs.keys();
            while (it.hasNext()) {
                String k = it.next();
                String b64 = imgs.optString(k, null);
                if (b64 != null && !b64.isEmpty()) MonteeWidgets.saveImage(ctx, k, b64);
            }
        }
        MonteeWidgets.updateAll(ctx);
        call.resolve();
    }

    @PluginMethod
    public void takeAction(PluginCall call) {
        Context ctx = getContext();
        String a = MonteeStore.get(ctx, "action");
        JSObject r = new JSObject();
        if (a != null) {
            MonteeStore.put(ctx, "action", null);
            r.put("action", a);
        }
        call.resolve(r);
    }

    /** Partager Montée : sélecteur de partage Android avec un texte (et son lien). */
    @PluginMethod
    public void shareText(PluginCall call) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_TEXT, call.getString("text", ""));
            send.putExtra(Intent.EXTRA_SUBJECT, call.getString("title", "Montée"));
            getActivity().startActivity(Intent.createChooser(send, call.getString("title", "Partager Montée")));
            call.resolve();
        } catch (Exception e) {
            call.reject("Partage impossible : " + e.getMessage());
        }
    }

    /** Carte du mois : image PNG (base64) partagée avec le sélecteur Android (Instagram, WhatsApp, Galerie…). */
    @PluginMethod
    public void shareImage(final PluginCall call) {
        try {
            String b64 = call.getString("base64", "");
            byte[] bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            Context ctx = getContext();
            File f = new File(ctx.getCacheDir(), call.getString("name", "montee-carte.png"));
            try (FileOutputStream os = new FileOutputStream(f)) { os.write(bytes); }
            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/png");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            String text = call.getString("text", "");
            if (text != null && !text.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, text);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Partager ta carte");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("Partage impossible : " + e.getMessage());
        }
    }

    /** Sauvegarde : enregistre le fichier dans Téléchargements (Android 10+), sinon ouvre le partage. */
    @PluginMethod
    public void saveFile(final PluginCall call) {
        String name = call.getString("name", "montee-sauvegarde.json");
        String content = call.getString("content", "");
        String mime = call.getString("mime", "application/json");
        boolean share = Boolean.TRUE.equals(call.getBoolean("share", false));
        Context ctx = getContext();
        byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
        if (!share && Build.VERSION.SDK_INT >= 29) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert");
                try (OutputStream os = ctx.getContentResolver().openOutputStream(uri)) { os.write(bytes); }
                JSObject r = new JSObject(); r.put("saved", "downloads"); call.resolve(r);
                return;
            } catch (Exception e) { /* on bascule sur le partage */ }
        }
        try {
            File f = new File(ctx.getCacheDir(), name);
            try (FileOutputStream os = new FileOutputStream(f)) { os.write(bytes); }
            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, name);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Enregistrer la sauvegarde");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            JSObject r = new JSObject(); r.put("saved", "share"); call.resolve(r);
        } catch (Exception e) {
            call.reject("Impossible d'enregistrer : " + e.getMessage());
        }
    }

    @PluginMethod
    public void logout(final PluginCall call) {
        Context ctx = getContext();
        MonteeStore.put(ctx, "state", null);
        MonteeStore.put(ctx, "pending", null);
        MonteeWorker.cancel(ctx);
        getActivity().runOnUiThread(() -> {
            // Seulement Ten'Up : les données de Montée (stockage de l'app) ne sont pas touchées
            WebStorage.getInstance().deleteOrigin("https://tenup.fft.fr");
            CookieManager.getInstance().removeAllCookies(ok -> {
                CookieManager.getInstance().flush();
                call.resolve();
            });
        });
    }

    /** Couleur des barres système (notifications en haut, navigation en bas) selon le thème de l'app. */
    @PluginMethod
    public void setBars(final PluginCall call) {
        final String hex = call.getString("color", "#F6F2EC");
        final boolean light = call.getBoolean("light", true);
        getActivity().runOnUiThread(() -> {
            try {
                int c = Color.parseColor(hex);
                Window w = getActivity().getWindow();
                w.setStatusBarColor(c);
                w.setNavigationBarColor(c);
                // Edge-to-edge (Android 15+) : la zone derrière les barres est le fond de la fenêtre et du conteneur
                w.getDecorView().setBackgroundColor(c);
                View wv = getBridge().getWebView();
                if (wv != null) {
                    wv.setBackgroundColor(c);
                    if (wv.getParent() instanceof View) ((View) wv.getParent()).setBackgroundColor(c);
                }
                WindowInsetsControllerCompat ic = WindowCompat.getInsetsController(w, w.getDecorView());
                ic.setAppearanceLightStatusBars(light);
                ic.setAppearanceLightNavigationBars(light);
            } catch (Exception e) { /* couleur invalide : on ignore */ }
            call.resolve();
        });
    }

    // ---------- Santé connectée (Health Connect, Android 14+) ----------

    @PluginMethod
    public void healthStatus(PluginCall call) {
        Context ctx = getContext();
        JSObject r = new JSObject();
        r.put("supported", MonteeHealth.supported());
        r.put("granted", MonteeHealth.granted(ctx));
        r.put("background", MonteeHealth.background(ctx));
        r.put("bgPossible", Build.VERSION.SDK_INT >= 35);
        r.put("sdk", Build.VERSION.SDK_INT);
        call.resolve(r);
    }

    /** Ouvre la demande d'autorisation (écran Health Connect). L'app web relit l'état au retour. */
    @PluginMethod
    public void healthRequest(PluginCall call) {
        if (!MonteeHealth.supported()) { call.reject("Santé connectée : Android 14 ou plus"); return; }
        final android.app.Activity a = getActivity();
        a.runOnUiThread(() -> {
            try {
                androidx.core.app.ActivityCompat.requestPermissions(a, MonteeHealth.permissions(), 4711);
            } catch (Exception ignored) {}
        });
        call.resolve();
    }

    /** Réglages des autorisations de Montée dans Health Connect (si la demande a été refusée). */
    @PluginMethod
    public void healthSettings(PluginCall call) {
        final android.app.Activity a = getActivity();
        a.runOnUiThread(() -> {
            try {
                Intent i = new Intent("android.health.connect.action.MANAGE_HEALTH_PERMISSIONS");
                i.putExtra(Intent.EXTRA_PACKAGE_NAME, a.getPackageName());
                a.startActivity(i);
            } catch (Exception e) {
                try { a.startActivity(new Intent("android.health.connect.action.HEALTH_HOME_SETTINGS")); } catch (Exception ignored) {}
            }
        });
        call.resolve();
    }

    /** Séances de tennis des derniers jours (lecture seule). */
    @PluginMethod
    public void healthRead(final PluginCall call) {
        final Context ctx = getContext();
        final int days = call.getInt("days", 30);
        new Thread(() -> {
            org.json.JSONArray list = MonteeHealth.readAll(ctx, days);
            JSObject r = new JSObject();
            if (list == null) { r.put("error", MonteeHealth.granted(ctx) ? "lecture impossible" : "non autorisé"); }
            else r.put("sessions", list.toString());
            call.resolve(r);
        }).start();
    }

    /** L'app web partage ce que le travail en arrière-plan doit savoir : séances déjà traitées, jours de match. */
    @PluginMethod
    public void healthSync(PluginCall call) {
        Context ctx = getContext();
        boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        boolean notify = Boolean.TRUE.equals(call.getBoolean("notify", true));
        MonteeStore.flag(ctx, "healthOn", on);
        MonteeStore.flag(ctx, "healthNotify", notify);
        String known = call.getString("known"), days = call.getString("matchDays"), since = call.getString("since");
        if (known != null) MonteeStore.put(ctx, "healthKnown", known);
        if (days != null) MonteeStore.put(ctx, "healthMatchDays", days);
        if (since != null) MonteeStore.put(ctx, "healthSince", since);
        if (on && notify && MonteeHealth.background(ctx)) MonteeHealthWorker.schedule(ctx); else MonteeHealthWorker.cancel(ctx);
        call.resolve();
    }

    // ---------- Montée+ : Google Play Billing (même interface que StoreKit sur iPhone) ----------
    @PluginMethod
    public void storeProducts(final PluginCall call) {
        MonteeBilling.get(getContext()).products(list -> {
            com.getcapacitor.JSArray arr = new com.getcapacitor.JSArray();
            for (com.android.billingclient.api.ProductDetails d : list) {
                String pr = MonteeBilling.priceOf(d);
                if (pr == null) continue;
                JSObject o = new JSObject(); o.put("id", d.getProductId()); o.put("price", pr); arr.put(o);
            }
            JSObject r = new JSObject(); r.put("products", arr); call.resolve(r);
        });
    }

    @PluginMethod
    public void storeBuy(final PluginCall call) {
        final String id = call.getString("id");
        if (id == null) { call.reject("produit manquant"); return; }
        MonteeBilling.get(getContext()).buy(getActivity(), id, (state, ids) -> {
            JSObject r = new JSObject(); r.put("state", state);
            if (ids != null) { com.getcapacitor.JSArray a = new com.getcapacitor.JSArray(); for (String x : ids) a.put(x); r.put("ids", a); }
            call.resolve(r);
        });
    }

    @PluginMethod
    public void storeOwned(final PluginCall call) {
        MonteeBilling.get(getContext()).owned((ids, ok) -> {
            JSObject r = new JSObject();
            if (!ok) { r.put("offline", true); call.resolve(r); return; }
            com.getcapacitor.JSArray a = new com.getcapacitor.JSArray(); for (String x : ids) a.put(x);
            r.put("ids", a); call.resolve(r);
        });
    }

    /** Gérer / résilier l'abonnement : la page « Abonnements » de Google Play pour Montée. */
    @PluginMethod
    public void storeManage(final PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/account/subscriptions?package=" + getContext().getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception ignored) { }
        call.resolve();
    }
}
