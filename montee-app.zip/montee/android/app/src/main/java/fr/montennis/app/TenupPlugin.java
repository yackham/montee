package fr.montennis.app;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.webkit.CookieManager;
import android.webkit.WebStorage;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Plugin appelé depuis l'app web (même interface que sur iPhone). */
@CapacitorPlugin(name = "Tenup")
public class TenupPlugin extends Plugin {

    @PluginMethod
    public void connect(final PluginCall call) {
        final String script = call.getString("script");
        if (script == null || script.isEmpty()) { call.reject("script manquant"); return; }
        final Context ctx = getContext();
        MonteeStore.put(ctx, "script", script);
        getActivity().runOnUiThread(() -> {
            TenupActivity.script = script;
            TenupActivity.callback = text -> {
                JSObject r = new JSObject();
                if (text != null) {
                    MonteeStore.flag(ctx, "expiredNotified", false);
                    r.put("data", text);
                } else {
                    r.put("cancelled", true);
                }
                call.resolve(r);
            };
            getActivity().startActivity(new Intent(getActivity(), TenupActivity.class));
        });
    }

    @PluginMethod
    public void refresh(final PluginCall call) {
        String s = call.getString("script");
        if (s == null || s.isEmpty()) s = MonteeStore.get(getContext(), "script");
        if (s == null || s.isEmpty()) { call.reject("script manquant"); return; }
        final String script = s;
        final Context ctx = getContext();
        final android.app.Activity activity = getActivity();
        MonteeStore.put(ctx, "script", script);
        new Thread(() -> {
            String text = MonteeWorker.fetch(ctx, activity, script, 25);
            JSObject r = new JSObject();
            r.put("data", text);
            call.resolve(r);
        }).start();
    }

    @PluginMethod
    public void setState(PluginCall call) {
        Context ctx = getContext();
        String state = call.getString("state");
        String script = call.getString("script");
        if (state != null) MonteeStore.put(ctx, "state", state);
        if (script != null && !script.isEmpty()) MonteeStore.put(ctx, "script", script);
        MonteeWorker.schedule(ctx);
        call.resolve();
    }

    @PluginMethod
    public void takePending(PluginCall call) {
        Context ctx = getContext();
        String pending = MonteeStore.get(ctx, "pending");
        JSObject r = new JSObject();
        if (pending != null) {
            MonteeStore.put(ctx, "pending", null);
            r.put("data", pending);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void setWidgets(PluginCall call) {
        String data = call.getString("data");
        if (data != null) MonteeStore.put(getContext(), "widgets", data);
        MonteeWidgets.updateAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void takeAction(PluginCall call) {
        Context ctx = getContext();
        String a = MonteeStore.get(ctx, "action");
        JSObject r = new JSObject();
        if (a != null) {
            MonteeStore.put(ctx, "action", null);
            r.put("action", a);
        }
        call.resolve(r);
    }

    /** Sauvegarde : enregistre le fichier dans Téléchargements (Android 10+), sinon ouvre le partage. */
    @PluginMethod
    public void saveFile(final PluginCall call) {
        String name = call.getString("name", "montee-sauvegarde.json");
        String content = call.getString("content", "");
        String mime = call.getString("mime", "application/json");
        boolean share = Boolean.TRUE.equals(call.getBoolean("share", false));
        Context ctx = getContext();
        byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
        if (!share && Build.VERSION.SDK_INT >= 29) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("insert");
                try (OutputStream os = ctx.getContentResolver().openOutputStream(uri)) { os.write(bytes); }
                JSObject r = new JSObject(); r.put("saved", "downloads"); call.resolve(r);
                return;
            } catch (Exception e) { /* on bascule sur le partage */ }
        }
        try {
            File f = new File(ctx.getCacheDir(), name);
            try (FileOutputStream os = new FileOutputStream(f)) { os.write(bytes); }
            Uri uri = FileProvider.getUriForFile(ctx, ctx.getPackageName() + ".fileprovider", f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.putExtra(Intent.EXTRA_SUBJECT, name);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Enregistrer la sauvegarde");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            JSObject r = new JSObject(); r.put("saved", "share"); call.resolve(r);
        } catch (Exception e) {
            call.reject("Impossible d'enregistrer : " + e.getMessage());
        }
    }

    @PluginMethod
    public void logout(final PluginCall call) {
        Context ctx = getContext();
        MonteeStore.put(ctx, "state", null);
        MonteeStore.put(ctx, "pending", null);
        MonteeWorker.cancel(ctx);
        getActivity().runOnUiThread(() -> {
            // Seulement Ten'Up : les données de Montée (stockage de l'app) ne sont pas touchées
            WebStorage.getInstance().deleteOrigin("https://tenup.fft.fr");
            CookieManager.getInstance().removeAllCookies(ok -> {
                CookieManager.getInstance().flush();
                call.resolve();
            });
        });
    }
}
