package fr.montennis.app;

import android.content.Context;
import android.content.Intent;
import android.webkit.CookieManager;
import android.webkit.WebStorage;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Plugin appelé depuis l'app web (même interface que sur iPhone). */
@CapacitorPlugin(name = "Tenup")
public class TenupPlugin extends Plugin {

    @PluginMethod
    public void connect(final PluginCall call) {
        final String script = call.getString("script");
        if (script == null || script.isEmpty()) { call.reject("script manquant"); return; }
        final Context ctx = getContext();
        MonteeStore.put(ctx, "script", script);
        getActivity().runOnUiThread(() -> {
            TenupActivity.script = script;
            TenupActivity.callback = text -> {
                JSObject r = new JSObject();
                if (text != null) {
                    MonteeStore.flag(ctx, "expiredNotified", false);
                    r.put("data", text);
                } else {
                    r.put("cancelled", true);
                }
                call.resolve(r);
            };
            getActivity().startActivity(new Intent(getActivity(), TenupActivity.class));
        });
    }

    @PluginMethod
    public void refresh(final PluginCall call) {
        String s = call.getString("script");
        if (s == null || s.isEmpty()) s = MonteeStore.get(getContext(), "script");
        if (s == null || s.isEmpty()) { call.reject("script manquant"); return; }
        final String script = s;
        final Context ctx = getContext();
        final android.app.Activity activity = getActivity();
        MonteeStore.put(ctx, "script", script);
        new Thread(() -> {
            String text = MonteeWorker.fetch(ctx, activity, script, 25);
            JSObject r = new JSObject();
            r.put("data", text);
            call.resolve(r);
        }).start();
    }

    @PluginMethod
    public void setState(PluginCall call) {
        Context ctx = getContext();
        String state = call.getString("state");
        String script = call.getString("script");
        if (state != null) MonteeStore.put(ctx, "state", state);
        if (script != null && !script.isEmpty()) MonteeStore.put(ctx, "script", script);
        MonteeWorker.schedule(ctx);
        call.resolve();
    }

    @PluginMethod
    public void takePending(PluginCall call) {
        Context ctx = getContext();
        String pending = MonteeStore.get(ctx, "pending");
        JSObject r = new JSObject();
        if (pending != null) {
            MonteeStore.put(ctx, "pending", null);
            r.put("data", pending);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void setWidgets(PluginCall call) {
        String data = call.getString("data");
        if (data != null) MonteeStore.put(getContext(), "widgets", data);
        MonteeWidgets.updateAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void takeAction(PluginCall call) {
        Context ctx = getContext();
        String a = MonteeStore.get(ctx, "action");
        JSObject r = new JSObject();
        if (a != null) {
            MonteeStore.put(ctx, "action", null);
            r.put("action", a);
        }
        call.resolve(r);
    }

    @PluginMethod
    public void logout(final PluginCall call) {
        Context ctx = getContext();
        MonteeStore.put(ctx, "state", null);
        MonteeStore.put(ctx, "pending", null);
        MonteeWorker.cancel(ctx);
        getActivity().runOnUiThread(() -> {
            // Seulement Ten'Up : les données de Montée (stockage de l'app) ne sont pas touchées
            WebStorage.getInstance().deleteOrigin("https://tenup.fft.fr");
            CookieManager.getInstance().removeAllCookies(ok -> {
                CookieManager.getInstance().flush();
                call.resolve();
            });
        });
    }
}
