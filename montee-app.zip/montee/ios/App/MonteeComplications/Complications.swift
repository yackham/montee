import WidgetKit
import SwiftUI

// Montée · complications Apple Watch.
// L'app montre écrit dans le groupe d'apps ce qu'elle reçoit de l'iPhone (classement, adversaires…)
// et le score du match en cours ; les complications ne font que le lire.

let MGROUP = "group.fr.montennis.app"
let mBalle = Color(red: 0.831, green: 0.902, blue: 0.290)
let mGazon = Color(red: 0.435, green: 0.761, blue: 0.561)

struct CCtx: Codable {
    var rank: String = ""
    var next: String = ""
    var pct: Int? = nil
    var gap: Int? = nil
    var short: String = ""
    var plus: Bool = false
    var defend: Int? = nil
    var record: String? = nil
    var rel: Int? = nil
    var opps: [COpp] = []
}
struct COpp: Codable {
    var name: String
    var rank: String
    var p: Int? = nil
    var tag: String? = nil
}
struct CLive: Codable {
    var me: String
    var him: String
    var sets: String
    var srvMe: Bool
    var on: Bool
}

struct MEntry: TimelineEntry {
    let date: Date
    let ctx: CCtx
    let live: CLive?
    let plus: Bool
    var planned: COpp? { ctx.opps.first { ($0.tag ?? "").hasPrefix("Prévu") } }
}

func loadEntry() -> MEntry {
    let d = UserDefaults(suiteName: MGROUP)
    var c = CCtx()
    if let data = d?.data(forKey: "montee.ctx"), let x = try? JSONDecoder().decode(CCtx.self, from: data) { c = x }
    var live: CLive? = nil
    if let data = d?.data(forKey: "montee.liveScore"), let x = try? JSONDecoder().decode(CLive.self, from: data), x.on { live = x }
    let plus = c.plus || (d?.bool(forKey: "montee.plus") ?? false)
    return MEntry(date: Date(), ctx: c, live: live, plus: plus)
}

struct MProvider: TimelineProvider {
    func placeholder(in context: Context) -> MEntry {
        MEntry(date: Date(),
               ctx: CCtx(rank: "15/2", next: "15/1", pct: 70, gap: 75, short: "Il manque 75 pts", plus: true, defend: 120, record: "12 V · 5 D", rel: 12,
                         opps: [COpp(name: "Théo Durand", rank: "15/1", p: 58, tag: "Prévu sam. 7")]),
               live: CLive(me: "30", him: "15", sets: "6-4 3-2", srvMe: true, on: true), plus: true)
    }
    func getSnapshot(in context: Context, completion: @escaping (MEntry) -> Void) {
        completion(context.isPreview ? placeholder(in: context) : loadEntry())
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<MEntry>) -> Void) {
        completion(Timeline(entries: [loadEntry()], policy: .after(Date().addingTimeInterval(3600))))
    }
}

/// Complication réservée à Montée+ : un cadenas tant que l'abonnement n'est pas actif
struct Locked: View {
    @Environment(\.widgetFamily) var family
    var body: some View {
        switch family {
        case .accessoryInline: Text("Montée+")
        case .accessoryRectangular:
            VStack(alignment: .leading) {
                Text("Montée+").font(.headline).foregroundColor(mBalle)
                Text("Abonne-toi dans Montée sur l'iPhone").font(.caption2)
            }
        default: Image(systemName: "lock.fill")
        }
    }
}

// MARK: - 1. Classement (gratuite)

struct RankView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var v: Double { Double(min(100, max(0, e.ctx.pct ?? 0))) / 100 }
    var rank: String { e.ctx.rank.isEmpty ? "–" : e.ctx.rank }
    var body: some View {
        switch family {
        case .accessoryCorner:
            Text(rank).font(.system(size: 18, weight: .bold))
                .widgetLabel { Gauge(value: v) { Text("") }.tint(mBalle) }
        case .accessoryInline:
            Text(e.ctx.next.isEmpty ? "Montée · \(rank)" : "\(rank) → \(e.ctx.next)")
        case .accessoryRectangular:
            VStack(alignment: .leading, spacing: 1) {
                Text("CLASSEMENT").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                Text(e.ctx.next.isEmpty ? rank : "\(rank) → \(e.ctx.next)").font(.system(size: 20, weight: .bold))
                if !e.ctx.short.isEmpty { Text(e.ctx.short).font(.system(size: 12)).lineLimit(1) }
            }
        default:
            Gauge(value: v) { Text("") } currentValueLabel: { Text(rank).font(.system(size: 12, weight: .bold)) }
                .gaugeStyle(.accessoryCircular).tint(mBalle)
        }
    }
}

// MARK: - 2. Points manquants

struct GapView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var gap: Int? { e.ctx.gap }
    var body: some View {
        if !e.plus { Locked() } else {
            switch family {
            case .accessoryCorner:
                Text(gap.map { "−\($0)" } ?? "OK").font(.system(size: 18, weight: .bold)).foregroundColor(mBalle)
                    .widgetLabel { Text(e.ctx.next.isEmpty ? "pts" : "pts pour \(e.ctx.next)") }
            case .accessoryInline:
                Text(gap.map { $0 > 0 ? "Il manque \($0) pts" : "Tu as les points" } ?? (e.ctx.short.isEmpty ? "Montée" : e.ctx.short))
            default:
                ZStack {
                    AccessoryWidgetBackground()
                    VStack(spacing: -2) {
                        Text(gap.map { $0 > 0 ? "−\($0)" : "OK" } ?? "–").font(.system(size: 17, weight: .heavy)).foregroundColor(mBalle)
                        Text("PTS").font(.system(size: 9, weight: .bold))
                    }
                }
            }
        }
    }
}

// MARK: - 3. Prochain match

struct NextView: View {
    let e: MEntry
    var body: some View {
        if !e.plus { Locked() } else if let o = e.planned {
            VStack(alignment: .leading, spacing: 1) {
                Text((o.tag ?? "").replacingOccurrences(of: "Prévu ", with: "").uppercased()).font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                Text(o.name + (o.rank.isEmpty ? "" : " · " + o.rank)).font(.system(size: 15, weight: .bold)).lineLimit(1)
                if let p = o.p { Text("Tu gagnes \(p) % du temps").font(.system(size: 12)).lineLimit(1) }
            }
        } else {
            VStack(alignment: .leading, spacing: 1) {
                Text("PROCHAIN MATCH").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                Text("Aucun match prévu").font(.system(size: 14, weight: .semibold))
                Text("« Je joue contre lui » sur l'iPhone").font(.system(size: 11)).lineLimit(1)
            }
        }
    }
}

// MARK: - 4. Score en direct

struct LiveView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var body: some View {
        if !e.plus { Locked() } else if let l = e.live {
            switch family {
            case .accessoryRectangular:
                VStack(alignment: .leading, spacing: 2) {
                    Text("MATCH EN COURS").font(.system(size: 11, weight: .heavy)).foregroundColor(.red)
                    HStack { Text("Toi" + (l.srvMe ? " •" : "")).bold(); Spacer(); Text(l.me).font(.system(size: 16, weight: .heavy)).foregroundColor(mBalle) }
                    HStack { Text("Lui" + (l.srvMe ? "" : " •")).bold(); Spacer(); Text(l.him).font(.system(size: 16, weight: .heavy)) }
                }.font(.system(size: 13))
            default:
                ZStack {
                    AccessoryWidgetBackground()
                    VStack(spacing: -1) {
                        Text(l.me).font(.system(size: 15, weight: .heavy)).foregroundColor(mBalle)
                        Text(l.him).font(.system(size: 13, weight: .bold))
                    }
                }
            }
        } else {
            switch family {
            case .accessoryRectangular:
                VStack(alignment: .leading, spacing: 1) {
                    Text("SCORE EN DIRECT").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                    Text("Pas de match en cours").font(.system(size: 14, weight: .semibold))
                }
            default:
                ZStack { AccessoryWidgetBackground(); Image(systemName: "figure.tennis") }
            }
        }
    }
}

// MARK: - 5. Lancer un match (gratuite : ouvre l'app sur « Nouveau match »)

struct StartView: View {
    var body: some View {
        ZStack {
            AccessoryWidgetBackground()
            Image(systemName: "figure.tennis").font(.system(size: 20, weight: .bold)).foregroundColor(mBalle)
        }
        .widgetURL(URL(string: "montee://start"))
    }
}

// MARK: - 6. Points à défendre

struct DefendView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var body: some View {
        if !e.plus { Locked() } else {
            switch family {
            case .accessoryInline:
                Text(e.ctx.defend.map { "\($0) pts à défendre ce mois-ci" } ?? "Rien à défendre ce mois-ci")
            case .accessoryCorner:
                Text(e.ctx.defend.map { "\($0)" } ?? "0").font(.system(size: 18, weight: .bold)).foregroundColor(mBalle)
                    .widgetLabel { Text("pts à défendre") }
            default:
                ZStack {
                    AccessoryWidgetBackground()
                    VStack(spacing: -2) {
                        Text(e.ctx.defend.map { "\($0)" } ?? "0").font(.system(size: 16, weight: .heavy)).foregroundColor(mBalle)
                        Text("À DÉF.").font(.system(size: 8, weight: .bold))
                    }
                }
            }
        }
    }
}

// MARK: - 7. Bilan de saison · 8. Prochain classement

struct SeasonView: View {
    let e: MEntry
    var body: some View {
        if !e.plus { Locked() } else { Text(e.ctx.record ?? "Pas encore de match") }
    }
}

struct ReleaseView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var body: some View {
        if !e.plus { Locked() } else if family == .accessoryInline {
            Text(e.ctx.rel.map { $0 <= 0 ? "Classement aujourd'hui" : "Classement dans \($0) j" } ?? "Montée")
        } else {
            ZStack {
                AccessoryWidgetBackground()
                VStack(spacing: -2) {
                    Text(e.ctx.rel.map { "\($0)" } ?? "–").font(.system(size: 17, weight: .heavy)).foregroundColor(mBalle)
                    Text("JOURS").font(.system(size: 8, weight: .bold))
                }
            }
        }
    }
}

// MARK: - Déclarations

func card<V: View>(_ v: V) -> some View { v.containerBackground(Color.clear, for: .widget) }

struct RankWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeRank", provider: MProvider()) { e in card(RankView(e: e)) }
            .configurationDisplayName("Classement").description("Ton classement et l'échelon suivant.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline, .accessoryRectangular])
    }
}
struct GapWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeGap", provider: MProvider()) { e in card(GapView(e: e)) }
            .configurationDisplayName("Points manquants").description("Ce qu'il te manque pour monter.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline])
    }
}
struct NextWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeNext", provider: MProvider()) { e in card(NextView(e: e)) }
            .configurationDisplayName("Prochain match").description("Ton prochain adversaire et tes chances.")
            .supportedFamilies([.accessoryRectangular])
    }
}
struct LiveWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeLive", provider: MProvider()) { e in card(LiveView(e: e)) }
            .configurationDisplayName("Score en direct").description("Le score du match en cours.")
            .supportedFamilies([.accessoryRectangular, .accessoryCircular])
    }
}
struct StartWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeStart", provider: MProvider()) { _ in card(StartView()) }
            .configurationDisplayName("Lancer un match").description("Ouvre Montée sur un nouveau match.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner])
    }
}
struct DefendWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeDefend", provider: MProvider()) { e in card(DefendView(e: e)) }
            .configurationDisplayName("Points à défendre").description("Ce qui sort du calcul ce mois-ci.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline])
    }
}
struct SeasonWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeSeason", provider: MProvider()) { e in card(SeasonView(e: e)) }
            .configurationDisplayName("Bilan de saison").description("Tes victoires et défaites.")
            .supportedFamilies([.accessoryInline])
    }
}
struct ReleaseWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeRelease", provider: MProvider()) { e in card(ReleaseView(e: e)) }
            .configurationDisplayName("Prochain classement").description("Les jours avant la sortie du classement.")
            .supportedFamilies([.accessoryInline, .accessoryCircular])
    }
}

@main
struct MonteeComplications: WidgetBundle {
    var body: some Widget {
        RankWidget()
        GapWidget()
        NextWidget()
        LiveWidget()
        StartWidget()
        DefendWidget()
        SeasonWidget()
        ReleaseWidget()
    }
}
