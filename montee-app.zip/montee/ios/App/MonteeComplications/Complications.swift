import WidgetKit
import SwiftUI

// Montée · complications Apple Watch.
// L'app montre écrit dans le groupe d'apps ce qu'elle reçoit de l'iPhone (classement, adversaires…)
// et le score du match en cours ; les complications ne font que le lire.

let MGROUP = "group.fr.montennis.app"
let mBalle = Color(red: 0.831, green: 0.902, blue: 0.290)
let mGazon = Color(red: 0.435, green: 0.761, blue: 0.561)

struct CCtx: Codable {
    var rank: String = ""
    var next: String = ""
    var pct: Int? = nil
    var gap: Int? = nil
    var short: String = ""
    var plus: Bool = false
    var defend: Int? = nil
    var record: String? = nil
    var rel: Int? = nil
    var form: [String]? = nil
    var streak: String? = nil
    var last: String? = nil
    var racket: CRacket? = nil
    var week: String? = nil
    var opps: [COpp] = []
}
struct CRacket: Codable {
    var name: String
    var pct: Int
    var msg: String
    var hours: String
    var level: String
}
struct COpp: Codable {
    var name: String
    var rank: String
    var p: Int? = nil
    var tag: String? = nil
}
struct CLive: Codable {
    var me: String
    var him: String
    var sets: String
    var srvMe: Bool
    var on: Bool
    /// Entraînement en cours (chrono) plutôt qu'un match
    var train: Bool? = nil
    var t0: Double? = nil
    var paused: Bool? = nil
}

struct MEntry: TimelineEntry {
    let date: Date
    let ctx: CCtx
    let live: CLive?
    let plus: Bool
    var planned: COpp? { ctx.opps.first { ($0.tag ?? "").hasPrefix("Prévu") } }
}

func loadEntry() -> MEntry {
    let d = UserDefaults(suiteName: MGROUP)
    var c = CCtx()
    if let data = d?.data(forKey: "montee.ctx"), let x = try? JSONDecoder().decode(CCtx.self, from: data) { c = x }
    var live: CLive? = nil
    if let data = d?.data(forKey: "montee.liveScore"), let x = try? JSONDecoder().decode(CLive.self, from: data), x.on { live = x }
    let plus = c.plus || (d?.bool(forKey: "montee.plus") ?? false)
    return MEntry(date: Date(), ctx: c, live: live, plus: plus)
}

struct MProvider: TimelineProvider {
    func placeholder(in context: Context) -> MEntry {
        MEntry(date: Date(),
               ctx: CCtx(rank: "15/2", next: "15/1", pct: 70, gap: 75, short: "Il manque 75 pts", plus: true, defend: 120, record: "12 V · 5 D", rel: 12,
                         form: ["V", "V", "D", "V", "V"], streak: "2 victoires d'affilée", last: "V 6-4 6-3 · Théo Durand",
                         racket: CRacket(name: "Raquette n°1", pct: 70, msg: "de jeu sur le cordage", hours: "≈ 14 h", level: "ok"), week: "3 h 20 · 2 séances + 1 match",
                         opps: [COpp(name: "Théo Durand", rank: "15/1", p: 58, tag: "Prévu sam. 7")]),
               live: CLive(me: "30", him: "15", sets: "6-4 3-2", srvMe: true, on: true), plus: true)
    }
    func getSnapshot(in context: Context, completion: @escaping (MEntry) -> Void) {
        completion(context.isPreview ? placeholder(in: context) : loadEntry())
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<MEntry>) -> Void) {
        completion(Timeline(entries: [loadEntry()], policy: .after(Date().addingTimeInterval(3600))))
    }
}

/// Complication réservée à Montée+ : un cadenas tant que l'abonnement n'est pas actif
struct Locked: View {
    @Environment(\.widgetFamily) var family
    var body: some View {
        switch family {
        case .accessoryInline: Text("Montée+")
        case .accessoryRectangular:
            VStack(alignment: .leading) {
                Text("Montée+").font(.headline).foregroundColor(mBalle)
                Text("Abonne-toi dans Montée sur l'iPhone").font(.caption2)
            }
        default: Image(systemName: "lock.fill")
        }
    }
}

// MARK: - 1. Classement (gratuite)

struct RankView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var v: Double { Double(min(100, max(0, e.ctx.pct ?? 0))) / 100 }
    var rank: String { e.ctx.rank.isEmpty ? "–" : e.ctx.rank }
    var body: some View {
        switch family {
        case .accessoryCorner:
            Text(rank).font(.system(size: 18, weight: .bold))
                .widgetLabel { Gauge(value: v) { Text("") }.tint(mBalle) }
        case .accessoryInline:
            Text(e.ctx.next.isEmpty ? "Montée · \(rank)" : "\(rank) → \(e.ctx.next)")
        case .accessoryRectangular:
            VStack(alignment: .leading, spacing: 1) {
                Text("CLASSEMENT").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                Text(e.ctx.next.isEmpty ? rank : "\(rank) → \(e.ctx.next)").font(.system(size: 20, weight: .bold))
                if !e.ctx.short.isEmpty { Text(e.ctx.short).font(.system(size: 12)).lineLimit(1) }
            }
        default:
            Gauge(value: v) { Text("") } currentValueLabel: { Text(rank).font(.system(size: 12, weight: .bold)) }
                .gaugeStyle(.accessoryCircular).tint(mBalle)
        }
    }
}

// MARK: - 2. Points manquants

struct GapView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var gap: Int? { e.ctx.gap }
    var body: some View {
        if !e.plus { Locked() } else {
            switch family {
            case .accessoryCorner:
                Text(gap.map { "−\($0)" } ?? "OK").font(.system(size: 18, weight: .bold)).foregroundColor(mBalle)
                    .widgetLabel { Text(e.ctx.next.isEmpty ? "pts" : "pts pour \(e.ctx.next)") }
            case .accessoryInline:
                Text(gap.map { $0 > 0 ? "Il manque \($0) pts" : "Tu as les points" } ?? (e.ctx.short.isEmpty ? "Montée" : e.ctx.short))
            default:
                ZStack {
                    AccessoryWidgetBackground()
                    VStack(spacing: -2) {
                        Text(gap.map { $0 > 0 ? "−\($0)" : "OK" } ?? "–").font(.system(size: 17, weight: .heavy)).foregroundColor(mBalle)
                        Text("PTS").font(.system(size: 9, weight: .bold))
                    }
                }
            }
        }
    }
}

// MARK: - 3. Prochain match

struct NextView: View {
    let e: MEntry
    var body: some View {
        if !e.plus { Locked() } else if let o = e.planned {
            VStack(alignment: .leading, spacing: 1) {
                Text((o.tag ?? "").replacingOccurrences(of: "Prévu ", with: "").uppercased()).font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                Text(o.name + (o.rank.isEmpty ? "" : " · " + o.rank)).font(.system(size: 15, weight: .bold)).lineLimit(1)
                if let p = o.p { Text("Tu gagnes \(p) % du temps").font(.system(size: 12)).lineLimit(1) }
            }
        } else {
            VStack(alignment: .leading, spacing: 1) {
                Text("PROCHAIN MATCH").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                Text("Aucun match prévu").font(.system(size: 14, weight: .semibold))
                Text("« Je joue contre lui » sur l'iPhone").font(.system(size: 11)).lineLimit(1)
            }
        }
    }
}

// MARK: - 4. Score en direct

struct LiveView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var body: some View {
        if let l = e.live, l.train == true {
            TrainLiveView(l: l)
        } else if !e.plus { Locked() } else if let l = e.live {
            switch family {
            case .accessoryRectangular:
                VStack(alignment: .leading, spacing: 2) {
                    Text("MATCH EN COURS").font(.system(size: 11, weight: .heavy)).foregroundColor(.red)
                    HStack { Text("Toi" + (l.srvMe ? " •" : "")).bold(); Spacer(); Text(l.me).font(.system(size: 16, weight: .heavy)).foregroundColor(mBalle) }
                    HStack { Text("Lui" + (l.srvMe ? "" : " •")).bold(); Spacer(); Text(l.him).font(.system(size: 16, weight: .heavy)) }
                }.font(.system(size: 13))
            default:
                ZStack {
                    AccessoryWidgetBackground()
                    VStack(spacing: -1) {
                        Text(l.me).font(.system(size: 15, weight: .heavy)).foregroundColor(mBalle)
                        Text(l.him).font(.system(size: 13, weight: .bold))
                    }
                }
            }
        } else {
            switch family {
            case .accessoryRectangular:
                VStack(alignment: .leading, spacing: 1) {
                    Text("SCORE EN DIRECT").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                    Text("Pas de match en cours").font(.system(size: 14, weight: .semibold))
                }
            default:
                ZStack { AccessoryWidgetBackground(); Image(systemName: "figure.tennis") }
            }
        }
    }
}

/// Entraînement en cours : le chrono tourne tout seul (gratuit)
struct TrainLiveView: View {
    let l: CLive
    @Environment(\.widgetFamily) var family
    var start: Date { Date(timeIntervalSince1970: l.t0 ?? Date().timeIntervalSince1970) }
    var body: some View {
        switch family {
        case .accessoryRectangular:
            VStack(alignment: .leading, spacing: 1) {
                Text("ENTRAÎNEMENT").font(.system(size: 11, weight: .heavy)).foregroundColor(mGazon)
                if l.paused == true {
                    Text("En pause").font(.system(size: 20, weight: .heavy))
                } else {
                    Text(start, style: .timer).font(.system(size: 22, weight: .heavy)).monospacedDigit()
                }
                Text("sans score · cardio et zones").font(.system(size: 11, weight: .semibold)).foregroundColor(.secondary)
            }
        default:
            ZStack {
                AccessoryWidgetBackground()
                VStack(spacing: 0) {
                    Image(systemName: "heart.fill").font(.system(size: 10, weight: .bold)).foregroundColor(mGazon)
                    if l.paused == true {
                        Text("Pause").font(.system(size: 11, weight: .heavy))
                    } else {
                        Text(start, style: .timer).font(.system(size: 12, weight: .heavy)).monospacedDigit()
                            .multilineTextAlignment(.center).minimumScaleFactor(0.6)
                    }
                }.padding(.horizontal, 3)
            }
        }
    }
}

// MARK: - 5. Lancer un match (gratuite : ouvre l'app sur « Nouveau match »)

struct StartView: View {
    var body: some View {
        ZStack {
            AccessoryWidgetBackground()
            Image(systemName: "figure.tennis").font(.system(size: 20, weight: .bold)).foregroundColor(mBalle)
        }
        .widgetURL(URL(string: "montee://start"))
    }
}

// MARK: - 5 bis. Lancer un entraînement (gratuite)

struct TrainStartView: View {
    var body: some View {
        ZStack {
            AccessoryWidgetBackground()
            Image(systemName: "stopwatch.fill").font(.system(size: 19, weight: .bold)).foregroundColor(mGazon)
        }
        .widgetURL(URL(string: "montee://train"))
    }
}

/// Ta semaine : temps de jeu des 7 derniers jours (gratuite)
struct WeekView: View {
    let e: MEntry
    var body: some View {
        Text((e.ctx.week ?? "").isEmpty ? "Semaine · pas encore de séance" : "Semaine · " + (e.ctx.week ?? ""))
    }
}

// MARK: - 6. Points à défendre

struct DefendView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var body: some View {
        if !e.plus { Locked() } else {
            switch family {
            case .accessoryInline:
                Text(e.ctx.defend.map { "\($0) pts à défendre ce mois-ci" } ?? "Rien à défendre ce mois-ci")
            case .accessoryCorner:
                Text(e.ctx.defend.map { "\($0)" } ?? "0").font(.system(size: 18, weight: .bold)).foregroundColor(mBalle)
                    .widgetLabel { Text("pts à défendre") }
            default:
                ZStack {
                    AccessoryWidgetBackground()
                    VStack(spacing: -2) {
                        Text(e.ctx.defend.map { "\($0)" } ?? "0").font(.system(size: 16, weight: .heavy)).foregroundColor(mBalle)
                        Text("À DÉF.").font(.system(size: 8, weight: .bold))
                    }
                }
            }
        }
    }
}

// MARK: - 7. Bilan de saison · 8. Prochain classement

struct SeasonView: View {
    let e: MEntry
    var body: some View {
        if !e.plus { Locked() } else { Text(e.ctx.record ?? "Pas encore de match") }
    }
}

struct ReleaseView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var body: some View {
        if !e.plus { Locked() } else if family == .accessoryInline {
            Text(e.ctx.rel.map { $0 <= 0 ? "Classement aujourd'hui" : "Classement dans \($0) j" } ?? "Montée")
        } else {
            ZStack {
                AccessoryWidgetBackground()
                VStack(spacing: -2) {
                    Text(e.ctx.rel.map { "\($0)" } ?? "–").font(.system(size: 17, weight: .heavy)).foregroundColor(mBalle)
                    Text("JOURS").font(.system(size: 8, weight: .bold))
                }
            }
        }
    }
}

// MARK: - 9. Ta forme · 10. Ton cordage · 11. Dernier match (3.27)

struct FormView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var f: [String] { e.ctx.form ?? [] }
    var body: some View {
        if !e.plus { Locked() } else if family == .accessoryInline {
            Text(f.isEmpty ? "Pas encore de match" : f.joined() + (e.ctx.streak.map { " · " + $0 } ?? ""))
        } else {
            VStack(alignment: .leading, spacing: 3) {
                Text("TA FORME").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle)
                HStack(spacing: 4) {
                    ForEach(Array(f.enumerated()), id: \.offset) { _, r in
                        Text(r).font(.system(size: 11, weight: .heavy))
                            .frame(width: 20, height: 20)
                            .background(Circle().fill(r == "V" ? mGazon : Color(red: 0.91, green: 0.54, blue: 0.37)))
                            .foregroundColor(.black)
                    }
                }
                if let st = e.ctx.streak { Text(st).font(.system(size: 12)).lineLimit(1) }
            }
        }
    }
}

struct RacketView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var body: some View {
        if !e.plus { Locked() } else if let r = e.ctx.racket {
            switch family {
            case .accessoryRectangular:
                VStack(alignment: .leading, spacing: 2) {
                    Text("CORDAGE · \(r.name.uppercased())").font(.system(size: 11, weight: .heavy)).foregroundColor(mBalle).lineLimit(1)
                    Text(r.hours).font(.system(size: 18, weight: .bold))
                    Text(r.msg).font(.system(size: 12)).lineLimit(1)
                }
            case .accessoryCorner:
                Image(systemName: "tennis.racket").font(.system(size: 18, weight: .bold))
                    .widgetLabel { Gauge(value: Double(min(100, r.pct)) / 100) { Text("") }.tint(r.pct >= 90 ? .orange : mGazon) }
            default:
                Gauge(value: Double(min(100, r.pct)) / 100) { Text("") } currentValueLabel: {
                    Image(systemName: "tennis.racket").font(.system(size: 13, weight: .bold))
                }
                .gaugeStyle(.accessoryCircular).tint(r.pct >= 90 ? .orange : mGazon)
            }
        } else {
            ZStack { AccessoryWidgetBackground(); Image(systemName: "tennis.racket") }
        }
    }
}

struct LastView: View {
    let e: MEntry
    var body: some View {
        if !e.plus { Locked() } else { Text(e.ctx.last ?? "Pas encore de match") }
    }
}

// MARK: - 0. « Montée » : le logo, minimaliste (gratuite) — un tap ouvre l'app

/// Le logo Montée dessiné en vectoriel : balle jaune, coutures, flèche qui monte
struct MLogo: View {
    var body: some View {
        GeometryReader { g in
            let k = min(g.size.width, g.size.height) / 32
            ZStack {
                Circle().fill(mBalle).frame(width: 29 * k, height: 29 * k).widgetAccentable()
                Path { p in
                    p.move(to: CGPoint(x: 4 * k, y: 9.5 * k))
                    p.addCurve(to: CGPoint(x: 4 * k, y: 22.5 * k), control1: CGPoint(x: 7.6 * k, y: 12.5 * k), control2: CGPoint(x: 7.6 * k, y: 19.5 * k))
                    p.move(to: CGPoint(x: 28 * k, y: 9.5 * k))
                    p.addCurve(to: CGPoint(x: 28 * k, y: 22.5 * k), control1: CGPoint(x: 24.4 * k, y: 12.5 * k), control2: CGPoint(x: 24.4 * k, y: 19.5 * k))
                }
                .stroke(Color.white, style: StrokeStyle(lineWidth: 1.6 * k, lineCap: .round))
                Path { p in
                    p.move(to: CGPoint(x: 9.5 * k, y: 19.5 * k))
                    p.addLine(to: CGPoint(x: 16 * k, y: 13 * k))
                    p.addLine(to: CGPoint(x: 22.5 * k, y: 19.5 * k))
                }
                .stroke(Color.black, style: StrokeStyle(lineWidth: 3.2 * k, lineCap: .round, lineJoin: .round))
            }
            .frame(width: 32 * k, height: 32 * k)
            .position(x: g.size.width / 2, y: g.size.height / 2)
        }
    }
}

/// Le raccourci seul : juste le logo, sans chiffre
struct LogoOnlyView: View {
    @Environment(\.widgetFamily) var family
    var body: some View {
        switch family {
        case .accessoryInline:
            HStack(spacing: 3) { Image(systemName: "chevron.up.circle.fill"); Text("montée") }
        case .accessoryCorner:
            MLogo().padding(2)
        default:
            ZStack { AccessoryWidgetBackground(); MLogo().padding(7) }
        }
    }
}

/// Le logo + le suivi du classement
struct LogoView: View {
    let e: MEntry
    @Environment(\.widgetFamily) var family
    var v: CGFloat { CGFloat(min(100, max(0, e.ctx.pct ?? 0))) / 100 }
    var body: some View {
        switch family {
        case .accessoryInline:
            HStack(spacing: 3) {
                Image(systemName: "chevron.up.circle.fill")
                Text(e.ctx.rank.isEmpty ? "montée" : "montée · " + e.ctx.rank)
            }
        case .accessoryCorner:
            MLogo().padding(2)
                .widgetLabel { Text(e.ctx.rank.isEmpty ? "Montée" : (e.ctx.next.isEmpty ? e.ctx.rank : "\(e.ctx.rank) → \(e.ctx.next)")) }
        default:
            ZStack {
                Circle().stroke(Color.white.opacity(0.18), lineWidth: 3.5)
                if v > 0 {
                    Circle().trim(from: 0, to: v)
                        .stroke(mBalle, style: StrokeStyle(lineWidth: 3.5, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                        .widgetAccentable()
                }
                MLogo().padding(8)
            }
        }
    }
}

struct LogoWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeLogo", provider: MProvider()) { _ in card(LogoOnlyView()) }
            .configurationDisplayName("Montée").description("Le logo, pour ouvrir Montée d'un tap.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline])
    }
}
struct LogoRankWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeLogoRank", provider: MProvider()) { e in card(LogoView(e: e)) }
            .configurationDisplayName("Montée · classement").description("Le logo entouré de ta progression vers l'échelon suivant.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline])
    }
}

// MARK: - Déclarations

func card<V: View>(_ v: V) -> some View { v.containerBackground(Color.clear, for: .widget) }

struct RankWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeRank", provider: MProvider()) { e in card(RankView(e: e)) }
            .configurationDisplayName("Classement").description("Ton classement et l'échelon suivant.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline, .accessoryRectangular])
    }
}
struct GapWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeGap", provider: MProvider()) { e in card(GapView(e: e)) }
            .configurationDisplayName("Points manquants").description("Ce qu'il te manque pour monter.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline])
    }
}
struct NextWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeNext", provider: MProvider()) { e in card(NextView(e: e)) }
            .configurationDisplayName("Prochain match").description("Ton prochain adversaire et tes chances.")
            .supportedFamilies([.accessoryRectangular])
    }
}
struct LiveWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeLive", provider: MProvider()) { e in card(LiveView(e: e)) }
            .configurationDisplayName("En direct").description("Le score du match, ou le chrono de l'entraînement en cours.")
            .supportedFamilies([.accessoryRectangular, .accessoryCircular])
    }
}
struct StartWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeStart", provider: MProvider()) { _ in card(StartView()) }
            .configurationDisplayName("Lancer un match").description("Ouvre Montée sur un nouveau match.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner])
    }
}
struct TrainStartWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeTrain", provider: MProvider()) { _ in card(TrainStartView()) }
            .configurationDisplayName("Lancer un entraînement").description("Démarre une séance sans score : cardio et zones.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner])
    }
}
struct WeekWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeWeek", provider: MProvider()) { e in card(WeekView(e: e)) }
            .configurationDisplayName("Ta semaine").description("Ton temps de jeu sur 7 jours, matchs et entraînements.")
            .supportedFamilies([.accessoryInline])
    }
}
struct DefendWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeDefend", provider: MProvider()) { e in card(DefendView(e: e)) }
            .configurationDisplayName("Points à défendre").description("Ce qui sort du calcul ce mois-ci.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryInline])
    }
}
struct SeasonWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeSeason", provider: MProvider()) { e in card(SeasonView(e: e)) }
            .configurationDisplayName("Bilan de saison").description("Tes victoires et défaites.")
            .supportedFamilies([.accessoryInline])
    }
}
struct ReleaseWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeRelease", provider: MProvider()) { e in card(ReleaseView(e: e)) }
            .configurationDisplayName("Prochain classement").description("Les jours avant la sortie du classement.")
            .supportedFamilies([.accessoryInline, .accessoryCircular])
    }
}

struct FormWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeForm", provider: MProvider()) { e in card(FormView(e: e)) }
            .configurationDisplayName("Ta forme").description("Tes 5 derniers matchs et ta série.")
            .supportedFamilies([.accessoryRectangular, .accessoryInline])
    }
}
struct RacketWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeRacket", provider: MProvider()) { e in card(RacketView(e: e)) }
            .configurationDisplayName("Ton cordage").description("L'usure du cordage de ta raquette principale.")
            .supportedFamilies([.accessoryCircular, .accessoryCorner, .accessoryRectangular])
    }
}
struct LastWidget: Widget {
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: "MonteeLast", provider: MProvider()) { e in card(LastView(e: e)) }
            .configurationDisplayName("Dernier match").description("Le résultat de ton dernier match.")
            .supportedFamilies([.accessoryInline])
    }
}

@main
struct MonteeComplications: WidgetBundle {
    var body: some Widget {
        LogoWidget()
        LogoRankWidget()
        RankWidget()
        StartWidget()
        TrainStartWidget()
        LiveWidget()
        WeekWidget()
        PlusComplications().body
    }
}

/// Les complications Montée+ (regroupées : un bloc accepte au plus 10 widgets)
struct PlusComplications: WidgetBundle {
    var body: some Widget {
        GapWidget()
        NextWidget()
        DefendWidget()
        SeasonWidget()
        ReleaseWidget()
        FormWidget()
        RacketWidget()
        LastWidget()
    }
}
