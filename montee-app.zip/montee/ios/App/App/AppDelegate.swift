import UIKit
import Capacitor
import WebKit
import JavaScriptCore
import BackgroundTasks
import UserNotifications
import HealthKit

// Montée — partie native iPhone.
// - TenupPlugin : connexion à Ten'Up dans une vraie page web (WKWebView), puis lecture du
//   palmarès avec la session du joueur, comme le fait le site lui-même.
// - Actualisation silencieuse (à l'ouverture et en arrière-plan) et notifications locales.
// Aucun serveur : les identifiants restent dans la WKWebView, les données sur le téléphone.

let kRefreshTaskId = "fr.montennis.app.refresh"

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: kRefreshTaskId, using: nil) { task in
            if let refresh = task as? BGAppRefreshTask {
                MonteeBackground.handle(task: refresh)
            } else {
                task.setTaskCompleted(success: true)
            }
        }
        // Apple Santé : la surveillance des nouvelles séances doit être lancée dès le démarrage
        MonteeHealth.startObserver()
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        MonteeBackground.schedule()
    }

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        return ApplicationDelegateProxy.shared.application(app, open: url, options: options)
    }

    func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([UIUserActivityRestoring]?) -> Void) -> Bool {
        return ApplicationDelegateProxy.shared.application(application, continue: userActivity, restorationHandler: restorationHandler)
    }
}

// Contrôleur principal : enregistre le plugin Ten'Up auprès de Capacitor,
// et suit le thème de l'app (couleur de fond, icônes de la barre d'état).
class MainViewController: CAPBridgeViewController {
    var barStyle: UIStatusBarStyle = .darkContent

    override open func capacitorDidLoad() {
        bridge?.registerPluginInstance(TenupPlugin())
        applyTheme(color: UIColor(red: 0.965, green: 0.949, blue: 0.925, alpha: 1), light: true)
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { barStyle }

    /// Fond derrière la page (visible quand on tire l'écran) et couleur des icônes de la barre d'état.
    func applyTheme(color: UIColor, light: Bool) {
        barStyle = light ? .darkContent : .lightContent
        view.backgroundColor = color
        webView?.backgroundColor = color
        webView?.isOpaque = false
        webView?.scrollView.backgroundColor = color
        overrideUserInterfaceStyle = light ? .light : .dark
        setNeedsStatusBarAppearanceUpdate()
    }
}

extension UIColor {
    /// Couleur depuis « #RRGGBB ».
    convenience init?(hex: String) {
        var h = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if h.hasPrefix("#") { h.removeFirst() }
        guard h.count == 6, let v = UInt32(h, radix: 16) else { return nil }
        self.init(red: CGFloat((v >> 16) & 0xFF) / 255, green: CGFloat((v >> 8) & 0xFF) / 255, blue: CGFloat(v & 0xFF) / 255, alpha: 1)
    }
}

// MARK: - Mémoire locale partagée entre l'app et l'arrière-plan

enum MonteeStore {
    private static let d = UserDefaults.standard
    static var script: String? {
        get { d.string(forKey: "montee.script") }
        set { d.set(newValue, forKey: "montee.script") }
    }
    static var state: String? {
        get { d.string(forKey: "montee.state") }
        set { d.set(newValue, forKey: "montee.state") }
    }
    static var pending: String? {
        get { d.string(forKey: "montee.pending") }
        set { d.set(newValue, forKey: "montee.pending") }
    }
    static var expiredNotified: Bool {
        get { d.bool(forKey: "montee.expiredNotified") }
        set { d.set(newValue, forKey: "montee.expiredNotified") }
    }
}

// MARK: - Lecture de Ten'Up dans une WKWebView

final class TenupFetcher: NSObject, WKNavigationDelegate {
    static let home = URL(string: "https://tenup.fft.fr/")!
    let webView: WKWebView
    private let script: String
    private var running = false
    private(set) var finished = false
    /// Appelé avec le texte renvoyé par le script ; renvoyer true pour arrêter.
    var onResult: ((String) -> Bool)?

    init(script: String, frame: CGRect = CGRect(x: 0, y: 0, width: 390, height: 844)) {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()   // cookies Ten'Up conservés entre deux lancements
        webView = WKWebView(frame: frame, configuration: config)
        self.script = script
        super.init()
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
    }

    func load(_ url: URL = TenupFetcher.home) {
        webView.load(URLRequest(url: url))
    }

    func stop() {
        finished = true
        webView.stopLoading()
        webView.navigationDelegate = nil
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        runScript()
    }

    /// Exécute le script Montée dans la page, uniquement sur tenup.fft.fr.
    func runScript() {
        guard !running, !finished, let host = webView.url?.host, host.hasSuffix("tenup.fft.fr") else { return }
        running = true
        webView.callAsyncJavaScript(script, arguments: [:], in: nil, in: .page) { [weak self] result in
            guard let self = self else { return }
            self.running = false
            if self.finished { return }
            var text = "MONTEE-ERR erreur inconnue"
            switch result {
            case .success(let value):
                if let s = value as? String { text = s }
            case .failure(let error):
                text = "MONTEE-ERR " + error.localizedDescription
            }
            if self.onResult?(text) == true { self.finished = true }
        }
    }
}

// Fenêtre de connexion : la vraie page Ten'Up, Montée lit le palmarès dès que c'est possible.
final class TenupConnectViewController: UIViewController {
    let fetcher: TenupFetcher
    var onDone: ((String?) -> Void)?
    private let status = UILabel()
    private var timer: Timer?
    private var closed = false

    init(script: String) {
        fetcher = TenupFetcher(script: script)
        super.init(nibName: nil, bundle: nil)
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) non utilisé") }

    override func viewDidLoad() {
        super.viewDidLoad()
        let linen = UIColor(red: 0.965, green: 0.949, blue: 0.925, alpha: 1)
        view.backgroundColor = linen

        let bar = UIView()
        bar.backgroundColor = linen
        let title = UILabel()
        title.text = "Connecte-toi à Ten'Up"
        title.font = .systemFont(ofSize: 17, weight: .semibold)
        status.text = "Montée récupère ton palmarès dès que tu es connecté."
        status.font = .systemFont(ofSize: 13)
        status.textColor = UIColor(red: 0.38, green: 0.36, blue: 0.33, alpha: 1)
        status.numberOfLines = 2
        let close = UIButton(type: .system)
        close.setTitle("Annuler", for: .normal)
        close.titleLabel?.font = .systemFont(ofSize: 17)
        close.tintColor = UIColor(red: 0.12, green: 0.36, blue: 0.25, alpha: 1)
        close.addTarget(self, action: #selector(cancelTapped), for: .touchUpInside)

        let web = fetcher.webView
        for v in [bar, web] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(v) }
        for v in [title, status, close] as [UIView] { v.translatesAutoresizingMaskIntoConstraints = false; bar.addSubview(v) }
        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            title.topAnchor.constraint(equalTo: bar.topAnchor, constant: 14),
            title.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 20),
            close.centerYAnchor.constraint(equalTo: title.centerYAnchor),
            close.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -16),
            status.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 4),
            status.leadingAnchor.constraint(equalTo: bar.leadingAnchor, constant: 20),
            status.trailingAnchor.constraint(equalTo: bar.trailingAnchor, constant: -20),
            status.bottomAnchor.constraint(equalTo: bar.bottomAnchor, constant: -12),
            web.topAnchor.constraint(equalTo: bar.bottomAnchor),
            web.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            web.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            web.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        fetcher.onResult = { [weak self] text in
            guard let self = self else { return true }
            if text.hasPrefix("MONTEE1") { self.finish(text); return true }
            return false
        }
        fetcher.load()
        // La connexion peut se terminer sans rechargement complet : on réessaie régulièrement.
        timer = Timer.scheduledTimer(withTimeInterval: 12, repeats: true) { [weak self] _ in self?.fetcher.runScript() }
    }

    @objc private func cancelTapped() { finish(nil) }

    private func finish(_ text: String?) {
        if closed { return }
        closed = true
        timer?.invalidate()
        timer = nil
        fetcher.stop()
        let callback = onDone
        dismiss(animated: true) { callback?(text) }
    }
}

// Lecture silencieuse (WKWebView invisible), avec délai maximum.
enum TenupSilentRefresh {
    private static var current: TenupFetcher?

    static func run(script: String, timeout: TimeInterval = 25, completion: @escaping (String) -> Void) {
        DispatchQueue.main.async {
            current?.stop()
            let fetcher = TenupFetcher(script: script)
            current = fetcher
            var done = false
            let finish: (String) -> Void = { text in
                if done { return }
                done = true
                fetcher.onResult = nil
                fetcher.stop()
                fetcher.webView.removeFromSuperview()
                if current === fetcher { current = nil }
                completion(text)
            }
            fetcher.onResult = { text in finish(text); return true }
            // Une WKWebView attachée à une fenêtre exécute son JavaScript de façon plus fiable.
            if let window = UIApplication.shared.connectedScenes
                .compactMap({ ($0 as? UIWindowScene)?.windows.first }).first {
                fetcher.webView.isHidden = true
                window.addSubview(fetcher.webView)
            }
            fetcher.load()
            DispatchQueue.main.asyncAfter(deadline: .now() + timeout) { finish("MONTEE-ERR délai dépassé") }
        }
    }
}

// MARK: - Plugin Capacitor appelé depuis l'app web

@objc(TenupPlugin)
public class TenupPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "TenupPlugin"
    public let jsName = "Tenup"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "connect", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "refresh", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "query", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setState", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "takePending", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "logout", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "takeAction", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setWidgets", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "widgetInfo", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setWidgetImages", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "saveFile", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "setBars", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "haptic", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "healthStatus", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "healthRequest", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "healthSettings", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "healthRead", returnType: CAPPluginReturnPromise),
        CAPPluginMethod(name: "healthSync", returnType: CAPPluginReturnPromise)
    ]

    // Widgets : pas encore sur iPhone (première version). On répond « aucun widget posé ».
    @objc func takeAction(_ call: CAPPluginCall) { call.resolve() }
    @objc func setWidgets(_ call: CAPPluginCall) { call.resolve() }
    @objc func widgetInfo(_ call: CAPPluginCall) { call.resolve(["kinds": [String](), "sizes": [String: Any](), "density": UIScreen.main.scale]) }
    @objc func setWidgetImages(_ call: CAPPluginCall) { call.resolve() }

    /// Sauvegarde : fichier temporaire puis feuille de partage iOS (Fichiers, AirDrop, Mail…).
    @objc func saveFile(_ call: CAPPluginCall) {
        let name = call.getString("name") ?? "montee.json"
        let content = call.getString("content") ?? ""
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do {
            try content.write(to: url, atomically: true, encoding: .utf8)
        } catch {
            call.reject("Impossible d'écrire le fichier")
            return
        }
        DispatchQueue.main.async {
            guard let vc = self.bridge?.viewController else { call.reject("pas d'écran"); return }
            let share = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            if let pop = share.popoverPresentationController {
                pop.sourceView = vc.view
                pop.sourceRect = CGRect(x: vc.view.bounds.midX, y: vc.view.bounds.maxY - 80, width: 1, height: 1)
            }
            share.completionWithItemsHandler = { _, done, _, _ in call.resolve(["saved": done, "shared": true]) }
            vc.present(share, animated: true)
        }
    }

    /// Thème : couleur de fond et icônes de la barre d'état.
    @objc func setBars(_ call: CAPPluginCall) {
        let color = UIColor(hex: call.getString("color") ?? "#F6F2EC") ?? .systemBackground
        let light = call.getBool("light") ?? true
        DispatchQueue.main.async {
            (self.bridge?.viewController as? MainViewController)?.applyTheme(color: color, light: light)
            call.resolve()
        }
    }

    /// Retour haptique discret (le Taptic Engine de l'iPhone).
    @objc func haptic(_ call: CAPPluginCall) {
        let style = call.getString("style") ?? "light"
        DispatchQueue.main.async {
            switch style {
            case "success", "warning", "error":
                let g = UINotificationFeedbackGenerator()
                g.notificationOccurred(style == "success" ? .success : style == "warning" ? .warning : .error)
            case "selection":
                UISelectionFeedbackGenerator().selectionChanged()
            case "medium":
                UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            default:
                UIImpactFeedbackGenerator(style: .light).impactOccurred()
            }
            call.resolve()
        }
    }

    @objc func connect(_ call: CAPPluginCall) {
        guard let script = call.getString("script"), !script.isEmpty else { call.reject("script manquant"); return }
        MonteeStore.script = script
        DispatchQueue.main.async {
            let vc = TenupConnectViewController(script: script)
            vc.modalPresentationStyle = .pageSheet
            vc.isModalInPresentation = true
            vc.onDone = { text in
                if let t = text {
                    MonteeStore.expiredNotified = false
                    call.resolve(["data": t])
                } else {
                    call.resolve(["cancelled": true])
                }
            }
            self.bridge?.viewController?.present(vc, animated: true)
        }
    }

    @objc func refresh(_ call: CAPPluginCall) {
        let script = call.getString("script") ?? MonteeStore.script ?? ""
        if script.isEmpty { call.reject("script manquant"); return }
        MonteeStore.script = script
        TenupSilentRefresh.run(script: script) { text in
            call.resolve(["data": text])
        }
    }

    /// Requête ponctuelle sur Ten'Up (recherche de joueur, fiche d'un joueur) : le script n'est pas mémorisé.
    @objc func query(_ call: CAPPluginCall) {
        let script = call.getString("script") ?? ""
        if script.isEmpty { call.reject("script manquant"); return }
        TenupSilentRefresh.run(script: script, timeout: 30) { text in
            call.resolve(["data": text])
        }
    }

    // MARK: Apple Santé (lecture seule des séances d'entraînement)

    @objc func healthStatus(_ call: CAPPluginCall) {
        call.resolve([
            "supported": MonteeHealth.available,
            "granted": MonteeHealth.asked,
            "background": MonteeHealth.asked,
            "bgPossible": true,
            "ios": true
        ])
    }

    @objc func healthRequest(_ call: CAPPluginCall) {
        guard MonteeHealth.available else { call.reject("Apple Santé indisponible sur cet appareil"); return }
        MonteeHealth.request { ok in call.resolve(["granted": ok]) }
    }

    /// iOS n'ouvre pas directement la page Santé de l'app : on ouvre les Réglages de Montée.
    @objc func healthSettings(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) }
            call.resolve()
        }
    }

    @objc func healthRead(_ call: CAPPluginCall) {
        let days = call.getInt("days") ?? 30
        MonteeHealth.read(days: days) { list in
            if let list = list { call.resolve(["sessions": MonteeHealth.json(list)]) }
            else { call.resolve(["error": "lecture impossible"]) }
        }
    }

    @objc func healthSync(_ call: CAPPluginCall) {
        let d = UserDefaults.standard
        d.set(call.getBool("on") ?? false, forKey: "montee.healthOn")
        d.set(call.getBool("notify") ?? true, forKey: "montee.healthNotify")
        if let k = call.getString("known") { d.set(k, forKey: "montee.healthKnown") }
        if let m = call.getString("matchDays") { d.set(m, forKey: "montee.healthMatchDays") }
        if let s = call.getString("since") { d.set(s, forKey: "montee.healthSince") }
        MonteeHealth.startObserver()
        call.resolve()
    }

    @objc func setState(_ call: CAPPluginCall) {
        if let state = call.getString("state") { MonteeStore.state = state }
        if let script = call.getString("script"), !script.isEmpty { MonteeStore.script = script }
        MonteeBackground.schedule()
        call.resolve()
    }

    @objc func takePending(_ call: CAPPluginCall) {
        if let pending = MonteeStore.pending {
            MonteeStore.pending = nil
            call.resolve(["data": pending])
        } else {
            call.resolve()
        }
    }

    @objc func logout(_ call: CAPPluginCall) {
        MonteeStore.state = nil
        MonteeStore.pending = nil
        DispatchQueue.main.async {
            let store = WKWebsiteDataStore.default()
            let types = WKWebsiteDataStore.allWebsiteDataTypes()
            store.fetchDataRecords(ofTypes: types) { records in
                let tenup = records.filter { $0.displayName.contains("fft.fr") || $0.displayName.contains("queue-it") }
                store.removeData(ofTypes: types, for: tenup) { call.resolve() }
            }
        }
    }
}

// MARK: - Arrière-plan : nouveaux matchs et notifications

enum MonteeSummary {
    /// Calcule le résumé avec le même moteur que l'app (engine.js, tenup.js, summary.js).
    static func compute(payload: String, state: String) -> (title: String, body: String)? {
        guard let ctx = JSContext() else { return nil }
        for name in ["engine", "tenup", "summary"] {
            if let url = Bundle.main.url(forResource: name, withExtension: "js", subdirectory: "public"),
               let source = try? String(contentsOf: url, encoding: .utf8) {
                ctx.evaluateScript(source)
            }
        }
        guard let fn = ctx.objectForKeyedSubscript("monteeSummary"), !fn.isUndefined,
              let res = fn.call(withArguments: [payload, state]), !res.isUndefined, !res.isNull,
              let json = res.toString(), let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        if let newState = obj["state"] as? String { MonteeStore.state = newState }
        guard let title = obj["title"] as? String, let body = obj["body"] as? String else { return nil }
        return (title, body)
    }
}

enum MonteeBackground {
    static func schedule() {
        let request = BGAppRefreshTaskRequest(identifier: kRefreshTaskId)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 3 * 3600)
        try? BGTaskScheduler.shared.submit(request)
    }

    static func handle(task: BGAppRefreshTask) {
        schedule()
        guard let script = MonteeStore.script, MonteeStore.state != nil else {
            task.setTaskCompleted(success: true)
            return
        }
        var completed = false
        task.expirationHandler = {
            DispatchQueue.main.async {
                if !completed { completed = true; task.setTaskCompleted(success: false) }
            }
        }
        TenupSilentRefresh.run(script: script, timeout: 22) { text in
            DispatchQueue.main.async {
                if completed { return }
                completed = true
                if text.hasPrefix("MONTEE1") {
                    MonteeStore.pending = text
                    if let note = MonteeSummary.compute(payload: text, state: MonteeStore.state ?? "{}") {
                        notify(title: note.title, body: note.body)
                    }
                } else if text.contains("connecte-toi") && !MonteeStore.expiredNotified {
                    MonteeStore.expiredNotified = true
                    notify(title: "Ten'Up t'a déconnecté", body: "Ouvre Montée et reconnecte-toi pour suivre tes nouveaux matchs.")
                }
                task.setTaskCompleted(success: true)
            }
        }
    }

    static func notify(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default
        let request = UNNotificationRequest(identifier: "montee-\(Int(Date().timeIntervalSince1970))", content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
}

// MARK: - Apple Santé : séances de tennis (lecture seule, rien n'est envoyé ailleurs)

enum MonteeHealth {
    static let store = HKHealthStore()
    static let workoutType = HKObjectType.workoutType()
    static var observer: HKObserverQuery?

    static var available: Bool { HKHealthStore.isHealthDataAvailable() }
    /// iOS ne dit jamais si la lecture a été acceptée : on retient seulement que la demande a été faite.
    static var asked: Bool {
        get { UserDefaults.standard.bool(forKey: "montee.healthAsked") }
        set { UserDefaults.standard.set(newValue, forKey: "montee.healthAsked") }
    }

    static func request(completion: @escaping (Bool) -> Void) {
        store.requestAuthorization(toShare: nil, read: [workoutType]) { ok, _ in
            DispatchQueue.main.async {
                if ok { MonteeHealth.asked = true }
                completion(ok)
            }
        }
    }

    static func typeName(_ t: HKWorkoutActivityType) -> String {
        switch t {
        case .tennis: return "TENNIS"
        case .running: return "RUNNING"
        case .walking: return "WALKING"
        case .cycling: return "BIKING"
        case .traditionalStrengthTraining, .functionalStrengthTraining: return "STRENGTH_TRAINING"
        case .badminton: return "BADMINTON"
        case .squash: return "SQUASH"
        case .racquetball: return "RACQUETBALL"
        case .tableTennis: return "TABLE_TENNIS"
        case .swimming: return "SWIMMING_POOL"
        case .yoga: return "YOGA"
        case .highIntensityIntervalTraining: return "HIGH_INTENSITY_INTERVAL_TRAINING"
        case .soccer: return "SOCCER"
        case .basketball: return "BASKETBALL"
        case .hiking: return "HIKING"
        case .elliptical: return "ELLIPTICAL"
        case .pilates: return "PILATES"
        default: return "OTHER_WORKOUT"
        }
    }

    /// Séances d'entraînement des `days` derniers jours (le tri tennis / autres se fait dans l'app).
    static func read(days: Int, completion: @escaping ([[String: Any]]?) -> Void) {
        guard available else { completion(nil); return }
        let end = Date()
        let start = end.addingTimeInterval(-Double(max(1, days)) * 86400)
        let pred = HKQuery.predicateForSamples(withStart: start, end: end, options: [])
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)
        let q = HKSampleQuery(sampleType: workoutType, predicate: pred, limit: 500, sortDescriptors: [sort]) { _, samples, error in
            if error != nil {
                DispatchQueue.main.async { completion(nil) }
                return
            }
            var out: [[String: Any]] = []
            for s in samples ?? [] {
                guard let w = s as? HKWorkout else { continue }
                let src = w.sourceRevision.source
                var o: [String: Any] = [
                    "id": w.uuid.uuidString,
                    "start": NSNumber(value: Int64(w.startDate.timeIntervalSince1970 * 1000)),
                    "end": NSNumber(value: Int64(w.endDate.timeIntervalSince1970 * 1000)),
                    "tennis": w.workoutActivityType == .tennis,
                    "typeName": MonteeHealth.typeName(w.workoutActivityType),
                    "origin": src.bundleIdentifier,
                    "device": w.device?.name ?? src.name
                ]
                let model = (w.device?.model ?? "") + " " + (w.device?.name ?? "")
                if model.lowercased().contains("watch") { o["deviceType"] = 1 }
                out.append(o)
            }
            DispatchQueue.main.async { completion(out) }
        }
        store.execute(q)
    }

    static func json(_ v: Any) -> String {
        guard JSONSerialization.isValidJSONObject(v),
              let d = try? JSONSerialization.data(withJSONObject: v, options: []),
              let s = String(data: d, encoding: .utf8) else { return "[]" }
        return s
    }

    static func idSet(_ key: String) -> Set<String> {
        guard let s = UserDefaults.standard.string(forKey: key), let d = s.data(using: .utf8),
              let a = try? JSONSerialization.jsonObject(with: d, options: []) as? [String] else { return [] }
        return Set(a)
    }

    /// Nouvelle séance détectée en arrière-plan : notification (iOS réveille l'app, environ toutes les heures au plus).
    static func startObserver() {
        let d = UserDefaults.standard
        let on = available && asked && d.bool(forKey: "montee.healthOn") && d.object(forKey: "montee.healthNotify") as? Bool != false
        if !on {
            if let o = observer { store.stop(o); observer = nil }
            store.disableBackgroundDelivery(for: workoutType) { _, _ in }
            return
        }
        if observer != nil { return }
        let q = HKObserverQuery(sampleType: workoutType, predicate: nil) { _, done, error in
            if error != nil { done(); return }
            MonteeHealth.check { done() }
        }
        observer = q
        store.execute(q)
        store.enableBackgroundDelivery(for: workoutType, frequency: .hourly) { _, _ in }
    }

    static func check(done: @escaping () -> Void) {
        MonteeHealth.read(days: 3) { list in
            guard let list = list else { done(); return }
            let d = UserDefaults.standard
            let known = MonteeHealth.idSet("montee.healthKnown")
            var notified = MonteeHealth.idSet("montee.healthNotified")
            let matchDays = MonteeHealth.idSet("montee.healthMatchDays")
            let since = Double(d.string(forKey: "montee.healthSince") ?? "0") ?? 0
            let f = DateFormatter()
            f.dateFormat = "yyyy-MM-dd"
            f.locale = Locale(identifier: "fr_FR")
            var best: [String: Any]? = nil
            var count = 0
            for o in list {
                guard let id = o["id"] as? String, (o["tennis"] as? Bool) == true else { continue }
                let start = (o["start"] as? NSNumber)?.doubleValue ?? 0
                let end = (o["end"] as? NSNumber)?.doubleValue ?? 0
                if known.contains(id) || notified.contains(id) || start < since || end - start < 600000 { continue }
                if matchDays.contains(f.string(from: Date(timeIntervalSince1970: start / 1000))) { continue }
                count += 1
                notified.insert(id)
                if best == nil || start > ((best?["start"] as? NSNumber)?.doubleValue ?? 0) { best = o }
            }
            if let b = best {
                d.set(MonteeHealth.json(Array(notified)), forKey: "montee.healthNotified")
                let start = Date(timeIntervalSince1970: ((b["start"] as? NSNumber)?.doubleValue ?? 0) / 1000)
                let end = Date(timeIntervalSince1970: ((b["end"] as? NSNumber)?.doubleValue ?? 0) / 1000)
                let mins = max(0, Int(end.timeIntervalSince(start) / 60))
                let dur = mins >= 60 ? "\(mins / 60) h" + (mins % 60 > 0 ? String(format: " %02d", mins % 60) : "") : "\(mins) min"
                let h = DateFormatter()
                h.locale = Locale(identifier: "fr_FR")
                h.dateFormat = "EEEE d MMMM, H 'h'"
                let w0 = h.string(from: start)
                let when = Calendar.current.isDateInToday(start) ? "Aujourd'hui" : Calendar.current.isDateInYesterday(start) ? "Hier" : w0.prefix(1).uppercased() + String(w0.dropFirst())
                MonteeBackground.notify(title: count > 1 ? "\(count) nouvelles séances de tennis" : "Nouvelle séance de tennis",
                                        body: "\(when) · \(dur). Ouvre Montée pour l'ajouter à tes entraînements, avec ta raquette.")
            }
            done()
        }
    }
}
