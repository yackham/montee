import Foundation
import WatchConnectivity
import StoreKit

/// Adversaire proposé sur la montre (envoyé par l'iPhone)
struct WOpp: Codable, Identifiable, Hashable {
    var id: String
    var name: String
    var rank: String
    var p: Int? = nil
    var tip: String? = nil
    var tag: String? = nil
    var hom: Bool? = nil
    var fmt: String? = nil
}

/// Ce que l'iPhone envoie : ton classement, ta progression, tes adversaires, Montée+
struct WCtx: Codable {
    var rank: String = ""
    var next: String = ""
    var pct: Int? = nil
    var short: String = ""
    var plus: Bool = false
    var name: String = ""
    var opps: [WOpp] = []
}

/// Lien avec l'iPhone (WatchConnectivity) + droit à Montée+
final class PhoneLink: NSObject, ObservableObject, WCSessionDelegate {
    static let shared = PhoneLink()
    @Published var ctx = WCtx()
    @Published var ownsPlus = false
    @Published var freeUsed = UserDefaults.standard.bool(forKey: "montee.freeUsed")

    /// Montée+ actif (abonnement vu par l'iPhone ou par la montre), ou 1er match offert pas encore utilisé
    var canPlay: Bool { ctx.plus || ownsPlus || !freeUsed }
    var hasPlus: Bool { ctx.plus || ownsPlus }

    func start() {
        if let d = UserDefaults.standard.data(forKey: "montee.ctx"), let c = try? JSONDecoder().decode(WCtx.self, from: d) { ctx = c }
        if WCSession.isSupported() {
            WCSession.default.delegate = self
            WCSession.default.activate()
        }
        Task { await checkStore() }
    }

    func useFree() {
        if !hasPlus && !freeUsed {
            freeUsed = true
            UserDefaults.standard.set(true, forKey: "montee.freeUsed")
        }
    }

    @MainActor func setOwns(_ v: Bool) { ownsPlus = v }

    func checkStore() async {
        var owns = false
        for await r in Transaction.currentEntitlements {
            if case .verified(let t) = r, t.revocationDate == nil, t.productID.hasPrefix("plus_") {
                if let exp = t.expirationDate, exp < Date() { continue }
                owns = true
            }
        }
        await setOwns(owns)
    }

    private func apply(_ dict: [String: Any]) {
        guard let j = dict["json"] as? String, let d = j.data(using: .utf8),
              let c = try? JSONDecoder().decode(WCtx.self, from: d) else { return }
        UserDefaults.standard.set(d, forKey: "montee.ctx")
        DispatchQueue.main.async { self.ctx = c }
    }

    /// Envoie un match terminé à l'iPhone (livré même si l'iPhone est loin : file d'attente du système)
    func send(match json: String) {
        guard WCSession.isSupported() else { return }
        WCSession.default.transferUserInfo(["match": json])
    }

    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        apply(session.receivedApplicationContext)
        if session.isReachable {
            session.sendMessage(["hello": 1], replyHandler: { r in self.apply(r) }, errorHandler: nil)
        }
    }
    func session(_ session: WCSession, didReceiveApplicationContext applicationContext: [String: Any]) {
        apply(applicationContext)
    }
}
