import Foundation
import WatchKit
import WidgetKit

/// Préparation du match (retenue d'une fois sur l'autre)
final class Draft: ObservableObject {
    static let shared = Draft()
    @Published var hom: Bool { didSet { UserDefaults.standard.set(hom, forKey: "montee.hom") } }
    @Published var fmt: String { didSet { UserDefaults.standard.set(fmt, forKey: "montee.fmt") } }
    /// Ouvert depuis la complication « Lancer un match »
    @Published var openSetup = false
    init() {
        let u = UserDefaults.standard
        hom = (u.object(forKey: "montee.hom") as? Bool) ?? true
        fmt = u.string(forKey: "montee.fmt") ?? "full"
    }
}

/// Match en cours, sauvegardé à chaque point (rien ne se perd si l'app est relancée)
struct Live: Codable {
    var oid: String
    var name: String
    var rank: String
    var hom: Bool
    var fmt: String
    var srv0: Int
    var ev: [Ev] = []
    var t0 = Date()
    var t1: Date? = nil
    var forced: Int? = nil     // résultat choisi si le match s'arrête avant la fin (0 = victoire, 1 = défaite)
    var sent = false
    var changeAt: Date? = nil
    var changeSeen = -1
    var free = false           // ce match utilise le match offert du mois
}

/// Échauffement avant le match : la séance Santé tourne déjà, le serveur se choisit à la fin
struct WarmUp: Codable {
    var opp: WOpp
    var hom: Bool
    var fmt: String
    var t0 = Date()
}

/// Ce que l'iPhone reçoit à la fin du match
struct OutStats: Codable { var me: ServeStats; var him: ServeStats }
struct OutHR: Codable { var avg: Double; var max: Double }
struct OutMatch: Codable {
    var oid: String?
    var name: String
    var rank: String
    var hom: Bool
    var fmt: String
    var result: String
    var score: String
    var minutes: Int
    var date: String
    var serve: OutStats
    var hr: OutHR?
    var kcal: Double?
    var ev: String
}

final class MatchVM: ObservableObject {
    static let shared = MatchVM()
    @Published var live: Live?
    @Published var warmup: WarmUp?
    private let key = "montee.live"
    private let wkey = "montee.warmup"

    init() {
        if let d = UserDefaults.standard.data(forKey: key), let l = try? JSONDecoder().decode(Live.self, from: d) {
            live = l
            if l.t1 == nil { DispatchQueue.main.async { Workout.shared.start() } }
        } else if let d = UserDefaults.standard.data(forKey: wkey), let w = try? JSONDecoder().decode(WarmUp.self, from: d) {
            warmup = w
            DispatchQueue.main.async { Workout.shared.start() }
        }
    }

    private func saveWarm() {
        if let w = warmup, let d = try? JSONEncoder().encode(w) { UserDefaults.standard.set(d, forKey: wkey) }
        else { UserDefaults.standard.removeObject(forKey: wkey) }
    }

    /// Échauffement : la séance Tennis démarre (cardio, calories), le match n'est pas encore compté
    func beginWarmup(opp: WOpp, hom: Bool, fmt: String) {
        warmup = WarmUp(opp: opp, hom: hom, fmt: fmt)
        saveWarm()
        Workout.shared.start()
        buzz(.start)
    }

    func cancelWarmup() {
        Workout.shared.end(save: false)
        warmup = nil
        saveWarm()
    }

    var state: MatchState {
        guard let l = live else { return MatchState() }
        return replay(srv0: l.srv0, fmt: l.fmt, ev: l.ev)
    }

    var showChange: Bool {
        guard let l = live else { return false }
        let M = state
        return M.change && M.rest > 0 && l.changeSeen != l.ev.count
    }

    func elapsed(_ now: Date = Date()) -> String {
        guard let l = live else { return "" }
        let s = Int((l.t1 ?? now).timeIntervalSince(l.t0))
        return s >= 3600 ? String(format: "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60) : String(format: "%d:%02d", s / 60, s % 60)
    }

    private func save() {
        if let l = live, let d = try? JSONEncoder().encode(l) { UserDefaults.standard.set(d, forKey: key) }
        else { UserDefaults.standard.removeObject(forKey: key) }
        shareScore()
    }

    /// Score pour la complication « Score en direct »
    private func shareScore() {
        var dict: [String: Any] = ["on": false, "me": "", "him": "", "sets": "", "srvMe": false]
        if let l = live, l.t1 == nil, l.forced == nil {
            let M = state
            var sets = M.scoreText
            if M.games[0] + M.games[1] > 0 || sets.isEmpty { sets += (sets.isEmpty ? "" : " ") + "\(M.games[0])-\(M.games[1])" }
            dict = ["on": true, "me": M.pointText(0), "him": M.pointText(1), "sets": sets, "srvMe": M.server == 0]
        }
        if let d = try? JSONSerialization.data(withJSONObject: dict) { sharedDefaults?.set(d, forKey: "montee.liveScore") }
        WidgetCenter.shared.reloadTimelines(ofKind: "MonteeLive")
    }

    private func buzz(_ t: WKHapticType) { WKInterfaceDevice.current().play(t) }

    /// Balle de break : double tape (vers le haut pour toi, vers le bas à sauver) ; set ou match : appuyé
    private func buzzImportant(_ i: Importance) {
        let t: WKHapticType = i.level >= 2 ? .notification : (i.mine ? .directionUp : .directionDown)
        for k in 0..<2 {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45 + Double(k) * 0.3) { WKInterfaceDevice.current().play(t) }
        }
    }

    func begin(opp: WOpp, hom: Bool, fmt: String, srv0: Int) {
        let link = PhoneLink.shared
        live = Live(oid: opp.id, name: opp.name, rank: opp.rank, hom: hom, fmt: fmt, srv0: srv0)
        live?.free = !link.hasPlus && !link.freeUsed
        warmup = nil
        saveWarm()
        save()
        link.useFree()
        Workout.shared.start()
        buzz(.start)
    }

    func tap(_ e: Ev) {
        guard var l = live, l.t1 == nil, l.forced == nil else { return }
        l.ev.append(e)
        let M = replay(srv0: l.srv0, fmt: l.fmt, ev: l.ev)
        if M.winner != nil { l.t1 = Date() }
        if M.change { l.changeAt = Date() }
        live = l
        save()
        if M.winner != nil { buzz(.success) }
        else if M.setBreak { buzz(.notification) }
        else if M.change { buzz(.directionUp) }
        else if e == .fault { buzz(M.second ? .retry : .failure) }
        else { buzz(.click) }
        // Point important qui arrive : une vibration à part, juste après celle du point
        if e != .fault, M.winner == nil, let imp = M.importance { buzzImportant(imp) }
    }

    func undo() {
        guard var l = live, !l.ev.isEmpty, !l.sent else { return }
        l.ev.removeLast()
        l.t1 = nil
        l.forced = nil
        live = l
        save()
        buzz(.directionDown)
    }

    func dismissChange() {
        guard var l = live else { return }
        l.changeSeen = l.ev.count
        live = l
        save()
    }

    func switchServer() {
        guard var l = live else { return }
        l.srv0 = 1 - l.srv0
        live = l
        save()
        buzz(.click)
    }

    /// Arrêt avant la fin (abandon, pluie…) : on choisit le résultat
    func stop(result: Int) {
        guard var l = live else { return }
        l.forced = result
        l.t1 = l.t1 ?? Date()
        live = l
        save()
    }

    /// Enregistre : séance Tennis dans Santé, match envoyé à l'iPhone
    func finish() {
        guard var l = live, !l.sent else { return }
        let M = state
        let w = Workout.shared
        let res = l.forced ?? M.winner ?? 0
        var score = M.scoreText
        if l.forced != nil && (M.games[0] + M.games[1]) > 0 { score += (score.isEmpty ? "" : " ") + "\(M.games[0])-\(M.games[1])" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        let oid: String? = (l.oid == "new" || l.oid.hasPrefix("n:")) ? nil : l.oid
        let out = OutMatch(oid: oid, name: l.name, rank: l.rank, hom: l.hom, fmt: l.fmt,
                           result: res == 0 ? "V" : "D", score: score,
                           minutes: max(1, Int((l.t1 ?? Date()).timeIntervalSince(l.t0) / 60)),
                           date: f.string(from: l.t0),
                           serve: OutStats(me: M.stats[0], him: M.stats[1]),
                           hr: w.avg > 0 ? OutHR(avg: w.avg, max: w.maxBpm) : nil,
                           kcal: w.kcal > 0 ? w.kcal : nil,
                           ev: l.ev.map { $0.rawValue }.joined())
        if let d = try? JSONEncoder().encode(out), let j = String(data: d, encoding: .utf8) { PhoneLink.shared.send(match: j) }
        w.end(save: true)
        l.sent = true
        live = l
        save()
        buzz(.success)
    }

    /// Match annulé : rien n'est envoyé, la séance n'est pas gardée
    func cancel() {
        // Annulé avant d'avoir vraiment joué (moins de 3 points) : le match offert du mois est rendu
        if let l = live, l.free, l.ev.count < 3 { PhoneLink.shared.refundFree() }
        Workout.shared.end(save: false)
        live = nil
        save()
    }

    func close() {
        live = nil
        save()
    }
}
