import SwiftUI

extension Color {
    static let balle = Color(red: 0.831, green: 0.902, blue: 0.290)
    static let gazon = Color(red: 0.435, green: 0.761, blue: 0.561)
    static let terre = Color(red: 0.910, green: 0.541, blue: 0.369)
    static let card = Color(white: 0.16)
    static let encre = Color(red: 0.043, green: 0.141, blue: 0.086)
}

/// Classements FFT, du meilleur au moins bon (la couronne fait défiler)
let RANKS = ["-30", "-15", "-4/6", "-2/6", "0", "1/6", "2/6", "3/6", "4/6", "5/6", "15", "15/1", "15/2", "15/3", "15/4", "15/5", "30", "30/1", "30/2", "30/3", "30/4", "30/5", "40", "NC"]

func pct(_ a: Int, _ b: Int) -> String { b == 0 ? "–" : "\(Int((Double(a) * 100 / Double(b)).rounded())) %" }

/// Bouton principal : capsule jaune balle, plus compacte que le style système
struct PrimaryStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .heavy))
            .foregroundColor(.black)
            .frame(maxWidth: .infinity, minHeight: 40)
            .background(Color.balle)
            .clipShape(Capsule())
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}

struct Chip: View {
    let t: String
    let on: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(t).font(.system(size: 13, weight: .bold))
                .foregroundColor(on ? .black : .white)
                .padding(.vertical, 7).frame(maxWidth: .infinity)
                .background(on ? Color.balle : Color.card)
                .clipShape(Capsule())
        }.buttonStyle(.plain)
    }
}

struct BigButton: View {
    let t: String
    let bg: Color
    let fg: Color
    var height: CGFloat = 58
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(t).font(.system(size: 18, weight: .heavy)).foregroundColor(fg)
                .frame(maxWidth: .infinity, minHeight: height)
                .background(bg)
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }.buttonStyle(.plain)
    }
}

struct Quote: View {
    let t: String
    var body: some View {
        HStack(alignment: .top, spacing: 7) {
            Rectangle().fill(Color.balle).frame(width: 3)
            Text(t).font(.system(size: 12.5, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
        }
    }
}

// MARK: - Racine

struct RootView: View {
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var tvm = TrainVM.shared
    var body: some View {
        if vm.live != nil {
            MatchView()
        } else if tvm.live != nil {
            TrainView()
        } else {
            NavigationStack { HomeView() }
                .onOpenURL { u in
                    if u.host == "start" { Draft.shared.openSetup = true }
                    if u.host == "train" { startTraining() }
                }
        }
    }
}

func startTraining() {
    guard MatchVM.shared.live == nil, TrainVM.shared.live == nil else { return }
    Workout.shared.authorize { TrainVM.shared.begin() }
}

/// Bouton de l'Accueil : titre + sous-titre
struct ModeButton: View {
    let t: String
    let s: String
    let main: Bool
    var body: some View {
        VStack(spacing: 1) {
            Text(t).font(.system(size: 15, weight: .heavy))
            Text(s).font(.system(size: 10.5, weight: .semibold)).opacity(0.7)
        }
        .foregroundColor(main ? .black : .white)
        .frame(maxWidth: .infinity, minHeight: 44)
        .background(main ? Color.balle : Color.card)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - 1. Accueil

struct HomeView: View {
    @ObservedObject var link = PhoneLink.shared
    @ObservedObject var draft = Draft.shared
    var body: some View {
        ScrollView {
            VStack(spacing: 10) {
                Text("montée").font(.system(size: 15, weight: .heavy)).foregroundColor(.balle)
                    .frame(maxWidth: .infinity, alignment: .leading)
                ZStack {
                    Circle().stroke(Color.white.opacity(0.12), lineWidth: 9)
                    Circle().trim(from: 0, to: CGFloat(link.ctx.pct ?? 0) / 100)
                        .stroke(Color.balle, style: StrokeStyle(lineWidth: 9, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                    VStack(spacing: 0) {
                        Text(link.ctx.rank.isEmpty ? "–" : link.ctx.rank).font(.system(size: 26, weight: .heavy))
                        if !link.ctx.next.isEmpty { Text("→ " + link.ctx.next).font(.system(size: 11, weight: .bold)).foregroundColor(.secondary) }
                    }
                }.frame(width: 96, height: 96)
                if !link.ctx.short.isEmpty {
                    Text(link.ctx.short).font(.system(size: 13, weight: .bold)).multilineTextAlignment(.center)
                }
                NavigationLink {
                    if link.canPlay { SetupView() } else { PlusView() }
                } label: {
                    ModeButton(t: "Match", s: "on compte les points", main: true)
                }
                .buttonStyle(.plain)
                Button { startTraining() } label: {
                    ModeButton(t: "Entraînement", s: "sans score", main: false)
                }
                .buttonStyle(.plain)
                if let wk = link.ctx.week, !wk.isEmpty {
                    Text("Ta semaine : " + wk).font(.system(size: 11, weight: .semibold)).foregroundColor(.secondary).multilineTextAlignment(.center)
                }
                MetricCards()
                if link.ctx.rank.isEmpty {
                    Text("Ouvre Montée sur ton iPhone pour retrouver ton classement et tes adversaires.")
                        .font(.system(size: 11)).foregroundColor(.secondary).multilineTextAlignment(.center)
                } else if !link.hasPlus && !link.freeUsed {
                    Text("1 match au poignet offert chaque mois.").font(.system(size: 11, weight: .semibold)).foregroundColor(.gazon).multilineTextAlignment(.center)
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .navigationDestination(isPresented: $draft.openSetup) {
            if link.canPlay { SetupView() } else { PlusView() }
        }
        .task { await link.checkStore() }
    }
}

struct PlusView: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text("Montée+").font(.system(size: 20, weight: .heavy)).foregroundColor(.balle)
                Text("Le score au poignet, Faute et Double faute, ton cardio et tes stats de service.")
                    .font(.system(size: 13, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
                Text("Ton match offert du mois est utilisé. Le prochain arrive le 1er du mois, ou abonne-toi dans Montée sur ton iPhone : menu › Montée+.")
                    .font(.system(size: 12)).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
                Button("Déjà abonné ? Vérifier") { Task { await link.checkStore() } }
                    .font(.system(size: 13, weight: .bold))
            }
        }.navigationTitle("Montée+")
    }
}

// MARK: - Cartes de métriques (sous le bouton, on les fait défiler à la couronne)

struct Card<Content: View>: View {
    let title: String
    var color: Color = .balle
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 13, weight: .heavy)).foregroundColor(color)
            content
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.card.opacity(0.7))
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

struct KV: View {
    let k: String
    let v: String
    var color: Color = .white
    var body: some View {
        HStack { Text(k).foregroundColor(.secondary); Spacer(minLength: 4); Text(v).fontWeight(.heavy).foregroundColor(color) }
            .font(.system(size: 12.5, weight: .semibold))
    }
}

struct MetricCards: View {
    @ObservedObject var link = PhoneLink.shared
    var c: WCtx { link.ctx }
    var body: some View {
        VStack(spacing: 8) {
            // 1. Ta forme (gratuite)
            if let f = c.form, !f.isEmpty {
                Card(title: "Ta forme") {
                    HStack(spacing: 5) {
                        ForEach(Array(f.enumerated()), id: \.offset) { _, r in
                            Text(r).font(.system(size: 12, weight: .heavy))
                                .foregroundColor(r == "V" ? .encre : Color(red: 0.16, green: 0.07, blue: 0.02))
                                .frame(width: 24, height: 24)
                                .background(r == "V" ? Color.gazon : Color.terre)
                                .clipShape(Circle())
                        }
                    }
                    if let sn = c.season { Text(sn.replacingOccurrences(of: " sur 12 mois", with: "")).font(.system(size: 20, weight: .heavy)) }
                    if let st = c.streak { Text(st).font(.system(size: 11.5, weight: .semibold)).foregroundColor(.secondary) }
                }
            }
            if link.hasPlus {
                // 2. Ton arme n°1 + tes autres forces
                if let fs = c.forces, let top = fs.first {
                    Card(title: "★ Ton arme n°1") {
                        HStack(spacing: 10) {
                            ZStack {
                                Circle().stroke(Color.white.opacity(0.12), lineWidth: 6)
                                Circle().trim(from: 0, to: CGFloat(top.v) / CGFloat(max(1, top.n)))
                                    .stroke(Color.balle, style: StrokeStyle(lineWidth: 6, lineCap: .round)).rotationEffect(.degrees(-90))
                                Text("\(Int((Double(top.v) * 100 / Double(max(1, top.n))).rounded()))%").font(.system(size: 13, weight: .heavy))
                            }.frame(width: 52, height: 52)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(top.h).font(.system(size: 13, weight: .heavy)).fixedSize(horizontal: false, vertical: true)
                                Text("\(top.v) fois sur \(top.n)").font(.system(size: 11)).foregroundColor(.secondary)
                            }
                        }
                        ForEach(fs.dropFirst(), id: \.self) { x in KV(k: x.t, v: "\(x.v)/\(x.n)", color: .gazon) }
                    }
                }
                // 3. Ton service sur la saison
                if let sv = c.serve {
                    Card(title: "Ton service · \(sv.n) match" + (sv.n > 1 ? "s" : "")) {
                        if let f = sv.first {
                            KV(k: "1res balles", v: "\(f) %", color: .balle)
                            GeometryReader { g in
                                ZStack(alignment: .leading) {
                                    Capsule().fill(Color.white.opacity(0.12))
                                    Capsule().fill(Color.balle).frame(width: g.size.width * CGFloat(f) / 100)
                                }
                            }.frame(height: 5)
                        }
                        if let d = sv.df { KV(k: "Doubles fautes", v: String(format: "%.1f / match", d).replacingOccurrences(of: ".", with: ",")) }
                        if let h = sv.held { KV(k: "Jeux tenus", v: "\(h) %") }
                        if let s2 = sv.sec { KV(k: "Pts sur 2e balle", v: "\(s2) %") }
                        if let t = sv.trend, t != 0 {
                            Text((t > 0 ? "↗ 1res balles : +" : "↘ 1res balles : ") + "\(t) pts sur tes 3 derniers")
                                .font(.system(size: 10.5, weight: .bold)).foregroundColor(t > 0 ? .gazon : .terre)
                        }
                    }
                }
                // 4. Avant ton match
                if let nx = c.nextOpp {
                    Card(title: nx.when.isEmpty ? "Prochain adversaire" : "Ton match · " + nx.when) {
                        Text(nx.name + (nx.rank.isEmpty ? "" : " · " + nx.rank)).font(.system(size: 14, weight: .heavy)).lineLimit(1)
                        if let p = nx.p { KV(k: "Tes chances", v: "\(p) %", color: .balle) }
                        if !nx.h2h.isEmpty { KV(k: "Face-à-face", v: nx.h2h) }
                        if !nx.tip.isEmpty { Quote(t: nx.tip) }
                    }
                }
            } else if c.form != nil {
                Card(title: "Montée+", color: .balle) {
                    Text("Ton arme n°1, ton service sur la saison et la fiche de ton prochain adversaire, ici même.")
                        .font(.system(size: 12, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
                }
            }
            // 5. Calendrier (gratuit)
            if let r = c.rel {
                Card(title: "Calendrier") {
                    HStack(alignment: .firstTextBaseline, spacing: 4) {
                        Text("\(max(0, r))").font(.system(size: 28, weight: .heavy))
                        Text(r == 1 ? "jour" : "jours").font(.system(size: 13, weight: .heavy))
                    }
                    if let l = c.relLabel { Text("avant le classement du " + l).font(.system(size: 11)).foregroundColor(.secondary) }
                    if let d = c.defend, d > 0 { KV(k: "À défendre", v: "−\(d) pts", color: .terre) }
                    if let g = c.gap { KV(k: "Il te manque", v: g > 0 ? "\(g) pts" : "rien", color: .balle) }
                }
            }
        }
    }
}

// MARK: - 2. Type et format

struct SetupView: View {
    @ObservedObject var d = Draft.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Chip(t: "Homologué", on: d.hom) { d.hom = true }
                    Chip(t: "Libre", on: !d.hom) { d.hom = false }
                }
                Text(d.hom ? "Compte pour ton classement" : "Sans effet sur ton classement")
                    .font(.system(size: 11, weight: .semibold)).foregroundColor(.secondary)
                Text("3E SET").font(.system(size: 11, weight: .heavy)).foregroundColor(.secondary).padding(.top, 4)
                HStack(spacing: 6) {
                    Chip(t: "Set classique", on: d.fmt != "stb") { d.fmt = "full" }
                    Chip(t: "Super TB", on: d.fmt == "stb") { d.fmt = "stb" }
                }
                NavigationLink {
                    OppListView()
                } label: {
                    Text("Continuer").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryStyle()).padding(.top, 6)
            }
        }.navigationTitle("Nouveau match")
    }
}

// MARK: - 3. Contre qui ?

struct OppListView: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        List {
            ForEach(link.ctx.opps) { o in
                NavigationLink {
                    ServerView(opp: o)
                } label: {
                    VStack(alignment: .leading, spacing: 2) {
                        if let t = o.tag {
                            Text(t.uppercased()).font(.system(size: 10, weight: .heavy))
                                .foregroundColor(t.hasPrefix("Prévu") ? .balle : .secondary)
                        }
                        HStack {
                            Text(o.name).font(.system(size: 15, weight: .bold)).lineLimit(1)
                            Spacer(minLength: 4)
                            Text(o.rank).font(.system(size: 13, weight: .semibold)).foregroundColor(.secondary)
                        }
                    }
                }
                .listRowBackground(RoundedRectangle(cornerRadius: 12).fill((o.tag ?? "").hasPrefix("Prévu") ? Color.balle.opacity(0.2) : Color.card))
            }
            NavigationLink {
                RankView()
            } label: {
                Label("Nouvel adversaire", systemImage: "plus").font(.system(size: 15, weight: .bold)).foregroundColor(.balle)
            }
        }
        .navigationTitle("Contre qui ?")
    }
}

// MARK: - 4. Nouvel adversaire : classement puis nom

struct RankView: View {
    @ObservedObject var d = Draft.shared
    @ObservedObject var link = PhoneLink.shared
    @State private var rank = ""
    var ranks: [String] { d.hom ? RANKS : RANKS + ["Je ne sais pas"] }
    var body: some View {
        VStack(spacing: 6) {
            Picker("Son classement", selection: $rank) {
                ForEach(ranks, id: \.self) { r in Text(r).tag(r) }
            }
            .pickerStyle(.wheel)
            .frame(height: 104)
            NavigationLink {
                NameView(rank: rank == "Je ne sais pas" ? "" : rank)
            } label: {
                Text("OK").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
            }
            .buttonStyle(PrimaryStyle())
        }
        .navigationTitle("Son classement")
        .onAppear { if rank.isEmpty { rank = ranks.contains(link.ctx.rank) ? link.ctx.rank : "15/4" } }
    }
}

struct NameView: View {
    let rank: String
    @State private var name = ""
    var fallback: String { rank.isEmpty ? "Adversaire" : "Adversaire " + rank }
    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                TextField("Son nom (facultatif)", text: $name)
                HStack(spacing: 6) {
                    NavigationLink {
                        ServerView(opp: WOpp(id: "new", name: fallback, rank: rank))
                    } label: {
                        Text("Passer").font(.system(size: 14, weight: .bold)).frame(maxWidth: .infinity)
                    }
                    NavigationLink {
                        ServerView(opp: WOpp(id: "new", name: name.trimmingCharacters(in: .whitespaces).isEmpty ? fallback : name, rank: rank))
                    } label: {
                        Text("OK").font(.system(size: 14, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                    }
                    .buttonStyle(PrimaryStyle())
                }
            }
        }.navigationTitle("Son nom")
    }
}

// MARK: - 5. Qui sert ?

struct ServerView: View {
    let opp: WOpp
    @ObservedObject var d = Draft.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text(opp.name + (opp.rank.isEmpty ? "" : " · " + opp.rank)).font(.system(size: 14, weight: .bold)).lineLimit(1)
                HStack(spacing: 8) {
                    BigButton(t: "Moi", bg: .gazon, fg: .encre, height: 78) { start(0) }
                    BigButton(t: "Lui", bg: .card, fg: .white, height: 78) { start(1) }
                }
                if let t = opp.tip, !t.isEmpty { Quote(t: t) }
                Text("Lance la séance Tennis").font(.system(size: 11, weight: .semibold)).foregroundColor(.gazon)
            }
        }
        .navigationTitle("Qui sert ?")
        .onAppear {
            if let h = opp.hom { d.hom = h }
            if let f = opp.fmt { d.fmt = f }
        }
    }
    func start(_ s: Int) {
        let o = opp, h = d.hom, f = d.fmt
        Workout.shared.authorize { MatchVM.shared.begin(opp: o, hom: h, fmt: f, srv0: s) }
    }
}

// MARK: - Pendant le match

struct MatchView: View {
    @ObservedObject var vm = MatchVM.shared
    var body: some View {
        let M = vm.state
        if M.winner != nil || vm.live?.forced != nil {
            EndView(M: M)
        } else if vm.showChange {
            ChangeView(M: M)
        } else {
            TabView {
                ScoreView(M: M)
                StatsView(M: M)
                ControlsView()
            }
            .tabViewStyle(.page)
        }
    }
}

struct ScoreView: View {
    let M: MatchState
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var w = Workout.shared
    var body: some View {
        VStack(spacing: 4) {
            HStack {
                TimelineView(.periodic(from: .now, by: 1)) { c in
                    Text(vm.elapsed(c.date)).font(.system(size: 13, weight: .bold)).foregroundColor(.secondary)
                }
                Spacer()
                if w.bpm > 0 { Text("♥ \(Int(w.bpm))").font(.system(size: 13, weight: .bold)).foregroundColor(.red) }
            }
            row(0)
            row(1)
            HStack {
                Text(M.inTB ? (M.superTB ? "Super tie-break" : "Tie-break") : (M.second ? "2e balle" : "1re balle"))
                    .font(.system(size: 11, weight: .heavy))
                    .foregroundColor(M.second ? .terre : .secondary)
                Spacer()
                if !M.last.isEmpty {
                    Button { vm.undo() } label: {
                        Label(M.last, systemImage: "arrow.uturn.backward")
                            .font(.system(size: 11, weight: .heavy))
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Color.card).clipShape(Capsule())
                    }.buttonStyle(.plain)
                }
            }
            Button { vm.tap(.fault) } label: {
                HStack(spacing: 5) {
                    Text(M.second ? "Double faute" : "Faute").font(.system(size: 15, weight: .heavy))
                    Text(M.server == 0 ? "de Toi" : "de Lui").font(.system(size: 11, weight: .bold)).opacity(0.7)
                }
                .foregroundColor(M.second ? Color(red: 0.16, green: 0.07, blue: 0.02) : .terre)
                .frame(maxWidth: .infinity, minHeight: 34)
                .background(M.second ? Color.terre : Color.clear)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.terre, lineWidth: M.second ? 0 : 2))
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }.buttonStyle(.plain)
            HStack(spacing: 6) {
                BigButton(t: "Moi", bg: .gazon, fg: .encre) { vm.tap(.me) }
                BigButton(t: "Lui", bg: .card, fg: .white) { vm.tap(.him) }
            }
        }
    }

    func row(_ who: Int) -> some View {
        HStack(spacing: 8) {
            Text(who == 0 ? "Toi" : "Lui").font(.system(size: 14, weight: .bold))
            if M.server == who { Circle().fill(Color.balle).frame(width: 7, height: 7) }
            Spacer()
            ForEach(Array(M.sets.enumerated()), id: \.offset) { _, s in
                Text("\(who == 0 ? s.a : s.b)").font(.system(size: 18, weight: .heavy)).foregroundColor(.secondary)
            }
            if !M.inTB || !M.superTB {
                Text("\(M.games[who])").font(.system(size: 18, weight: .heavy))
            }
            Text(M.pointText(who)).font(.system(size: 20, weight: .heavy))
                .foregroundColor(who == 0 ? .black : .white)
                .frame(minWidth: 40, minHeight: 28)
                .background(who == 0 ? Color.balle : Color.card)
                .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
        }
    }
}

/// Toi à gauche, lui à droite
struct DuelRows: View {
    let M: MatchState
    var body: some View {
        let a = M.stats[0], b = M.stats[1]
        Grid(alignment: .center, horizontalSpacing: 6, verticalSpacing: 5) {
            GridRow {
                Text("TOI").font(.system(size: 10, weight: .heavy)).foregroundColor(.secondary)
                Text("")
                Text("LUI").font(.system(size: 10, weight: .heavy)).foregroundColor(.secondary)
            }
            line(pct(a.firstIn, a.pts), "1res balles", pct(b.firstIn, b.pts), false)
            line("\(a.df)", "doubles fautes", "\(b.df)", b.df > a.df)
            line(a.games > 0 ? "\(a.held)/\(a.games)" : "–", "jeux tenus", b.games > 0 ? "\(b.held)/\(b.games)" : "–", false)
        }
    }
    func line(_ l: String, _ k: String, _ r: String, _ hot: Bool) -> some View {
        GridRow {
            Text(l).font(.system(size: 16, weight: .heavy)).foregroundColor(.balle)
            Text(k).font(.system(size: 10.5, weight: .semibold)).foregroundColor(.secondary).lineLimit(1).minimumScaleFactor(0.8)
            Text(r).font(.system(size: 16, weight: .heavy)).foregroundColor(hot ? .terre : .white)
        }
    }
}

struct ChangeView: View {
    let M: MatchState
    @ObservedObject var vm = MatchVM.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(M.setBreak ? "Fin du set" : "Changement de côté").font(.system(size: 13, weight: .heavy)).foregroundColor(.balle)
                    Spacer()
                    TimelineView(.periodic(from: .now, by: 1)) { c in
                        let left = max(0, M.rest - Int(c.date.timeIntervalSince(vm.live?.changeAt ?? c.date)))
                        Text(left > 0 ? "\(left) s" : "C'est reparti").font(.system(size: 13, weight: .heavy)).foregroundColor(.gazon)
                    }
                }
                DuelRows(M: M)
                if let t = changeLine(M) { Quote(t: t) }
                Button { vm.dismissChange() } label: {
                    Text("Reprendre").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryStyle())
            }
        }
    }
}

struct StatsView: View {
    let M: MatchState
    @ObservedObject var w = Workout.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text("Au service").font(.system(size: 13, weight: .heavy)).foregroundColor(.balle)
                DuelRows(M: M)
                if w.avg > 0 {
                    Text("Cardio moyen \(Int(w.avg)) · max \(Int(w.maxBpm))").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary)
                }
                if w.kcal > 0 { Text("\(Int(w.kcal)) kcal").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary) }
            }
        }
    }
}

struct ControlsView: View {
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var w = Workout.shared
    @State private var paused = false
    @State private var askEnd = false
    @State private var askCancel = false
    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                Button(paused ? "Reprendre la séance" : "Pause") {
                    if paused { w.resume() } else { w.pause() }
                    paused.toggle()
                }
                Button("Changer le serveur") { vm.switchServer() }
                Button("Arrêter le match") { askEnd = true }.foregroundColor(.terre)
                Button("Annuler le match") { askCancel = true }.foregroundColor(.secondary)
            }
        }
        .confirmationDialog("Le match s'arrête : tu as…", isPresented: $askEnd) {
            Button("Gagné") { vm.stop(result: 0) }
            Button("Perdu") { vm.stop(result: 1) }
        }
        .confirmationDialog("Annuler ce match ? Rien ne sera enregistré.", isPresented: $askCancel) {
            Button("Annuler le match", role: .destructive) { vm.cancel() }
        }
    }
}

// MARK: - Fin du match

struct EndView: View {
    let M: MatchState
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var w = Workout.shared
    var won: Bool { (vm.live?.forced ?? M.winner ?? 0) == 0 }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 6) {
                Text(won ? "Victoire" : "Défaite").font(.system(size: 13, weight: .heavy)).foregroundColor(won ? .balle : .terre)
                Text(scoreLine).font(.system(size: 24, weight: .heavy)).minimumScaleFactor(0.6).lineLimit(1)
                Text("contre " + (vm.live?.name ?? "")).font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary).lineLimit(1)
                kv("Durée" + (w.avg > 0 ? " · cardio" : ""), vm.elapsed() + (w.avg > 0 ? " · \(Int(w.avg))" : ""))
                kv("1res balles", pct(M.stats[0].firstIn, M.stats[0].pts) + " · " + pct(M.stats[1].firstIn, M.stats[1].pts))
                kv("Doubles fautes", "\(M.stats[0].df) · \(M.stats[1].df)")
                if vm.live?.sent == true {
                    Text("✓ Envoyé à l'iPhone · séance Tennis enregistrée").font(.system(size: 12, weight: .bold)).foregroundColor(.gazon)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(vm.live?.hom == false ? "Match libre : sans effet sur le classement." : "Ouvre Montée sur l'iPhone pour l'enregistrer.")
                        .font(.system(size: 11)).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
                    Button("Fermer") { vm.close() }
                } else {
                    Button { vm.finish() } label: {
                        Text("Enregistrer").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                    }
                    .buttonStyle(PrimaryStyle())
                    Button { vm.undo() } label: {
                        Label("Annuler le dernier point", systemImage: "arrow.uturn.backward").font(.system(size: 13, weight: .bold))
                    }
                }
            }
        }
    }
    var scoreLine: String {
        var s = M.scoreText
        if vm.live?.forced != nil && (M.games[0] + M.games[1]) > 0 { s += (s.isEmpty ? "" : " ") + "\(M.games[0])-\(M.games[1])" }
        return s.isEmpty ? "–" : s
    }
    func kv(_ k: String, _ v: String) -> some View {
        HStack { Text(k).foregroundColor(.secondary); Spacer(); Text(v).fontWeight(.bold) }.font(.system(size: 12.5))
    }
}
