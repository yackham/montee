import SwiftUI
import WatchKit

extension Color {
    static let balle = Color(red: 0.831, green: 0.902, blue: 0.290)
    static let gazon = Color(red: 0.435, green: 0.761, blue: 0.561)
    static let terre = Color(red: 0.910, green: 0.541, blue: 0.369)
    static let card = Color(white: 0.16)
    static let encre = Color(red: 0.043, green: 0.141, blue: 0.086)
}

/// Classements FFT, du meilleur au moins bon (la couronne fait défiler)
let RANKS = ["-30", "-15", "-4/6", "-2/6", "0", "1/6", "2/6", "3/6", "4/6", "5/6", "15", "15/1", "15/2", "15/3", "15/4", "15/5", "30", "30/1", "30/2", "30/3", "30/4", "30/5", "40", "NC"]

func pct(_ a: Int, _ b: Int) -> String { b == 0 ? "–" : "\(Int((Double(a) * 100 / Double(b)).rounded())) %" }

/// Bouton principal : capsule jaune balle, plus compacte que le style système
struct PrimaryStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .heavy))
            .foregroundColor(.black)
            .frame(maxWidth: .infinity, minHeight: 40)
            .background(Color.balle)
            .clipShape(Capsule())
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}

/// 3.29 · fond de l'app : dégradé sombre façon Exercice / Bevel
struct AppBackground: View {
    var body: some View {
        RadialGradient(colors: [Color(red: 0.14, green: 0.15, blue: 0.18), Color(red: 0.04, green: 0.05, blue: 0.06)],
                       center: .top, startRadius: 0, endRadius: 260).ignoresSafeArea()
    }
}
let appGradient = RadialGradient(colors: [Color(red: 0.14, green: 0.15, blue: 0.18), Color(red: 0.04, green: 0.05, blue: 0.06)], center: .top, startRadius: 0, endRadius: 260)
extension View {
    func appBackground() -> some View { background(AppBackground()) }
}

/// Carte translucide très arrondie
struct Glass<Content: View>: View {
    var tint: Color? = nil
    @ViewBuilder let content: Content
    var body: some View {
        content
            .padding(.horizontal, 12).padding(.vertical, 10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(tint.map { $0.opacity(0.18) } ?? Color.white.opacity(0.09))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke((tint ?? .white).opacity(tint == nil ? 0.06 : 0.35), lineWidth: 1))
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

/// Pastille verticale avec anneau (montée, forme, semaine)
struct RingPill: View {
    let value: Double
    let text: String
    let label: String
    let color: Color
    var body: some View {
        VStack(spacing: 4) {
            ZStack {
                Circle().stroke(color.opacity(0.22), lineWidth: 5.5)
                Circle().trim(from: 0, to: CGFloat(max(0.02, min(1, value))))
                    .stroke(color, style: StrokeStyle(lineWidth: 5.5, lineCap: .round)).rotationEffect(.degrees(-90))
                Text(text).font(.system(size: 14, weight: .heavy)).minimumScaleFactor(0.6).lineLimit(1).padding(.horizontal, 6)
            }.frame(width: 50, height: 50)
            Text(label).font(.system(size: 10.5, weight: .heavy)).foregroundColor(color).lineLimit(1).minimumScaleFactor(0.8)
        }
        .padding(.vertical, 7)
        .frame(maxWidth: .infinity)
        .background(LinearGradient(colors: [color.opacity(0.22), color.opacity(0.05)], startPoint: .top, endPoint: .bottom))
        .overlay(Capsule().stroke(color.opacity(0.28), lineWidth: 1))
        .clipShape(Capsule())
    }
}

/// Bouton pleine largeur, même hauteur partout ; couleur au choix
struct Wide: ButtonStyle {
    var bg: Color = .card
    var fg: Color = .white
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .heavy))
            .foregroundColor(fg)
            .lineLimit(1).minimumScaleFactor(0.75)
            .frame(maxWidth: .infinity, minHeight: 42)
            .background(bg)
            .clipShape(Capsule())
            .opacity(configuration.isPressed ? 0.7 : 1)
    }
}

/// Une option d'un écran de confirmation
struct ConfirmOption {
    let t: String
    var bg: Color = .balle
    var fg: Color = .black
    let action: () -> Void
}

/// Écran de confirmation plein écran, boutons en couleur (remplace les menus système)
struct ConfirmScreen: View {
    let title: String
    var note: String? = nil
    let options: [ConfirmOption]
    var cancel = "Annuler"
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                Text(title).font(.system(size: 17, weight: .heavy)).multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true)
                if let n = note { Text(n).font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary).multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true) }
                ForEach(0..<options.count, id: \.self) { i in
                    let o = options[i]
                    Button(o.t) { dismiss(); DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { o.action() } }
                        .buttonStyle(Wide(bg: o.bg, fg: o.fg))
                }
                Button(cancel) { dismiss() }.buttonStyle(Wide())
            }.padding(.top, 4)
        }
    }
}

let terreInk = Color(red: 0.16, green: 0.07, blue: 0.02)

struct Chip: View {
    let t: String
    let on: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(t).font(.system(size: 13, weight: .bold))
                .foregroundColor(on ? .black : .white)
                .padding(.vertical, 7).frame(maxWidth: .infinity)
                .background(on ? Color.balle : Color.card)
                .clipShape(Capsule())
        }.buttonStyle(.plain)
    }
}

struct BigButton: View {
    let t: String
    let bg: Color
    let fg: Color
    var height: CGFloat = 58
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(t).font(.system(size: 18, weight: .heavy)).foregroundColor(fg)
                .frame(maxWidth: .infinity, minHeight: height)
                .background(bg)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        }.buttonStyle(.plain)
    }
}

struct Quote: View {
    let t: String
    var body: some View {
        HStack(alignment: .top, spacing: 7) {
            Rectangle().fill(Color.balle).frame(width: 3)
            Text(t).font(.system(size: 12.5, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
        }
    }
}

// MARK: - Racine

struct RootView: View {
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var tvm = TrainVM.shared
    var body: some View {
        if vm.live != nil {
            MatchView()
        } else if vm.warmup != nil {
            WarmupView()
        } else if tvm.live != nil {
            TrainView()
        } else {
            NavigationStack { HomeView() }
                .onOpenURL { u in
                    if u.host == "start" { Draft.shared.openSetup = true }
                    if u.host == "train" { startTraining() }
                }
        }
    }
}

func startTraining() {
    guard MatchVM.shared.live == nil, MatchVM.shared.warmup == nil, TrainVM.shared.live == nil else { return }
    Workout.shared.authorize { TrainVM.shared.begin() }
}

/// Grand bouton de l'accueil : icône à gauche, texte centré
struct HomeButton: View {
    let icon: String
    let t: String
    let s: String
    let main: Bool
    var body: some View {
        ZStack {
            HStack { Image(systemName: icon).font(.system(size: 17, weight: .heavy)).foregroundColor(main ? .black : .gazon); Spacer() }
            VStack(spacing: 0) {
                Text(t).font(.system(size: 17, weight: .heavy))
                Text(s).font(.system(size: 11, weight: .bold)).opacity(0.7)
            }.multilineTextAlignment(.center)
        }
        .foregroundColor(main ? .black : .white)
        .padding(.horizontal, 14).padding(.vertical, 11)
        .background(main ? Color.balle : Color.gazon.opacity(0.18))
        .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(main ? Color.clear : Color.gazon.opacity(0.35), lineWidth: 1))
        .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
    }
}

/// Bouton de l'Accueil : titre + sous-titre
struct ModeButton: View {
    let t: String
    let s: String
    let main: Bool
    var body: some View {
        VStack(spacing: 1) {
            Text(t).font(.system(size: 15, weight: .heavy))
            Text(s).font(.system(size: 10.5, weight: .semibold)).opacity(0.7)
        }
        .foregroundColor(main ? .black : .white)
        .frame(maxWidth: .infinity, minHeight: 44)
        .background(main ? Color.balle : Color.card)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

// MARK: - 1. Accueil

struct HomeView: View {
    @ObservedObject var link = PhoneLink.shared
    @ObservedObject var draft = Draft.shared
    @State private var play = false
    var c: WCtx { link.ctx }
    var formV: Int { (c.form ?? []).filter { $0 == "V" }.count }
    var body: some View {
        ScrollView {
            VStack(spacing: 9) {
                // 3.30 : classement visé, et en face le + pour lancer un match ou un entraînement
                HStack(spacing: 6) {
                    Text(c.rank.isEmpty ? "montée" : (c.next.isEmpty ? c.rank : "\(c.rank) → \(c.next)"))
                        .font(.system(size: 19, weight: .heavy)).lineLimit(1).minimumScaleFactor(0.6)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Button { play = true } label: {
                        Image(systemName: "plus").font(.system(size: 18, weight: .heavy)).foregroundColor(.black)
                            .frame(width: 36, height: 36).background(Color.balle).clipShape(Circle())
                    }.buttonStyle(.plain).accessibilityLabel("Lancer un match ou un entraînement")
                }
                if !c.rank.isEmpty {
                    // Les mêmes 3 anneaux que l'accueil de l'iPhone
                    HStack(spacing: 5) {
                        if let r = c.rings {
                            NavigationLink { FormeDetail() } label: { RingPill(value: Double(r.win) / 100, text: "\(r.win)%", label: "Victoires", color: .gazon) }.buttonStyle(.plain)
                            NavigationLink { FormeDetail() } label: { RingPill(value: Double(r.form) / 100, text: "\(r.form)%", label: "Forme", color: .balle) }.buttonStyle(.plain)
                            NavigationLink { MonteeDetail() } label: { RingPill(value: Double(r.lvlPct) / 100, text: r.lvl, label: r.lvlLabel, color: Color(red: 0.56, green: 0.66, blue: 1)) }.buttonStyle(.plain)
                        } else {
                            NavigationLink { MonteeDetail() } label: { RingPill(value: Double(c.pct ?? 0) / 100, text: "\(c.pct ?? 0)%", label: "Montée", color: .balle) }.buttonStyle(.plain)
                            NavigationLink { FormeDetail() } label: {
                                RingPill(value: (c.form ?? []).isEmpty ? 0 : Double(formV) / Double((c.form ?? []).count), text: (c.form ?? []).isEmpty ? "–" : "\(formV)/\((c.form ?? []).count)", label: "Forme", color: .gazon)
                            }.buttonStyle(.plain)
                        }
                    }
                    if !c.short.isEmpty { Text(c.short).font(.system(size: 13, weight: .bold)).foregroundColor(Color(white: 0.8)).multilineTextAlignment(.center) }
                }
                MetricCards()
                if c.rank.isEmpty {
                    Text("Ouvre Montée sur ton iPhone pour retrouver ton classement et tes adversaires.")
                        .font(.system(size: 11)).foregroundColor(.secondary).multilineTextAlignment(.center)
                }
            }
        }
        .toolbar(.hidden, for: .navigationBar)
        .containerBackground(appGradient, for: .navigation)
        .navigationDestination(isPresented: $draft.openSetup) {
            if link.canPlay { SetupView() } else { PlusView() }
        }
        .sheet(isPresented: $play) {
            PlaySheet { kind in
                play = false
                if kind == "match" { DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { draft.openSetup = true } }
                else { DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { startTraining() } }
            }
        }
        .task { await link.checkStore() }
    }
}

/// 3.30 : le + de l'accueil : Match ou Entraînement
struct PlaySheet: View {
    @ObservedObject var link = PhoneLink.shared
    let pick: (String) -> Void
    var body: some View {
        ScrollView {
            VStack(spacing: 9) {
                Text("Jouer").font(.system(size: 17, weight: .heavy))
                Button { pick("match") } label: { HomeButton(icon: "play.fill", t: "Match", s: "on compte les points", main: true) }.buttonStyle(.plain)
                Button { pick("train") } label: { HomeButton(icon: "heart.fill", t: "Entraînement", s: "sans score · gratuit", main: false) }.buttonStyle(.plain)
                if !link.hasPlus && !link.freeUsed {
                    Text("1 match au poignet offert chaque mois.").font(.system(size: 11, weight: .semibold)).foregroundColor(.gazon).multilineTextAlignment(.center)
                }
            }
        }.containerBackground(appGradient, for: .navigation)
    }
}

/// Couleur d'une stat en % : orange sous le seuil bas, vert au-dessus du seuil haut, bleu entre les deux
func gaugeColor(_ pct: Int, low: Int = 40, high: Int = 60) -> Color {
    pct < low ? .terre : pct >= high ? .gazon : Color(red: 0.56, green: 0.66, blue: 1)
}

/// Mental : 1er set gagné → match, 3e set, tie-breaks… (12 mois)
struct MentalDetail: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 9) {
                DetailTitle(t: "Mental · 12 mois", color: .gazon)
                ForEach(link.ctx.mental ?? [], id: \.self) { m in
                    let p = m.n > 0 ? Int((Double(m.v) * 100 / Double(m.n)).rounded()) : 0
                    VStack(alignment: .leading, spacing: 3) {
                        HStack {
                            Text(m.k).font(.system(size: 12.5, weight: .bold)).lineLimit(1).minimumScaleFactor(0.8)
                            Spacer(minLength: 4)
                            Text("\(m.v)/\(m.n)").font(.system(size: 13, weight: .heavy)).foregroundColor(gaugeColor(p))
                        }
                        BallBar(value: Double(p) / 100, color: gaugeColor(p))
                    }
                }
                Text("D'après les scores de tes matchs.").font(.system(size: 11, weight: .semibold)).foregroundColor(.secondary)
            }
        }.containerBackground(appGradient, for: .navigation)
    }
}

// MARK: - Détails ouverts depuis l'accueil

/// En-tête d'un détail : petit titre en couleur
struct DetailTitle: View {
    let t: String
    let color: Color
    var body: some View { Text(t.uppercased()).font(.system(size: 12, weight: .heavy)).foregroundColor(color).frame(maxWidth: .infinity, alignment: .leading) }
}

/// Barre terminée par une balle de tennis (même dessin que l'iPhone)
struct BallBar: View {
    let value: Double
    var color: Color = .balle
    var body: some View {
        GeometryReader { g in
            let f = CGFloat(max(0, min(1, value))), x = (g.size.width - 18) * f
            ZStack(alignment: .leading) {
                Capsule().fill(Color.white.opacity(0.14)).frame(height: 8)
                Capsule().fill(color).frame(width: x + 9, height: 8)
                ZStack {
                    Circle().fill(color)
                    Path { p in
                        p.move(to: CGPoint(x: 3, y: 4.5)); p.addCurve(to: CGPoint(x: 3, y: 13.5), control1: CGPoint(x: 6.5, y: 7), control2: CGPoint(x: 6.5, y: 11))
                        p.move(to: CGPoint(x: 15, y: 4.5)); p.addCurve(to: CGPoint(x: 15, y: 13.5), control1: CGPoint(x: 11.5, y: 7), control2: CGPoint(x: 11.5, y: 11))
                    }.stroke(Color.black.opacity(0.55), style: StrokeStyle(lineWidth: 1.3, lineCap: .round))
                }.frame(width: 18, height: 18).offset(x: x)
            }.frame(height: 18)
        }.frame(height: 18)
    }
}

struct MonteeDetail: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        let c = link.ctx
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                DetailTitle(t: "Montée", color: .balle)
                Text("\(c.pct ?? 0) %").font(.system(size: 30, weight: .heavy))
                Text("vers " + c.next + (c.relLabel.map { " · sortie le " + $0 } ?? "")).font(.system(size: 12, weight: .bold)).foregroundColor(.secondary)
                BallBar(value: Double(c.pct ?? 0) / 100)
                Glass {
                    VStack(alignment: .leading, spacing: 3) {
                        if !c.short.isEmpty { Text(c.short).font(.system(size: 13, weight: .heavy)) }
                        if let g = c.gap { Text(g > 0 ? "Il te manque \(g) pts" : "Tu as les points").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary) }
                    }
                }
            }
        }.containerBackground(appGradient, for: .navigation)
    }
}

struct FormeDetail: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        let c = link.ctx, f = c.form ?? []
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                DetailTitle(t: "Forme", color: .gazon)
                Text("\(f.filter { $0 == "V" }.count) V sur \(f.count)").font(.system(size: 24, weight: .heavy))
                HStack(spacing: 4) {
                    ForEach(Array(f.enumerated()), id: \.offset) { _, r in
                        Text(r).font(.system(size: 12, weight: .heavy)).foregroundColor(r == "V" ? .encre : terreInk)
                            .frame(width: 26, height: 26).background(r == "V" ? Color.gazon : Color.terre).clipShape(Circle())
                    }
                }
                ForEach(c.recent ?? [], id: \.self) { m in
                    HStack {
                        Text(m.r + " · " + m.opp + (m.rank.isEmpty ? "" : " " + m.rank)).lineLimit(1)
                        Spacer(minLength: 4)
                        Text(m.score).fontWeight(.heavy).lineLimit(1)
                    }.font(.system(size: 12, weight: .semibold))
                    Divider().opacity(0.3)
                }
                if let st = c.streak { Text(st).font(.system(size: 11.5, weight: .semibold)).foregroundColor(.secondary) }
            }
        }.containerBackground(appGradient, for: .navigation)
    }
}

struct ServiceDetail: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        let sv = link.ctx.serve
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                DetailTitle(t: "Ton service", color: Color(red: 0.56, green: 0.66, blue: 1))
                if let sv = sv {
                    Text(sv.first.map { "\($0) %" } ?? "–").font(.system(size: 30, weight: .heavy))
                    Text("de 1res balles · \(sv.n) match" + (sv.n > 1 ? "s" : "") + " à la montre").font(.system(size: 12, weight: .bold)).foregroundColor(.secondary)
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 6), GridItem(.flexible(), spacing: 6)], spacing: 6) {
                        if let b = sv.bpWon { StatTile(k: "Balles de break", v: "\(b) % gagnées", color: .balle) }
                        if let b = sv.bpSaved { StatTile(k: "À sauver", v: "\(b) % sauvées", color: .gazon) }
                        if let h = sv.held { StatTile(k: "Jeux tenus", v: "\(h) %") }
                        if let d = sv.df { StatTile(k: "Doubles fautes", v: String(format: "%.1f", d).replacingOccurrences(of: ".", with: ",")) }
                    }
                    if let t = sv.trend, t != 0 {
                        Text((t > 0 ? "↗ +" : "↘ ") + "\(t) pts de 1res balles sur tes 3 derniers").font(.system(size: 11, weight: .bold)).foregroundColor(t > 0 ? .gazon : .terre)
                    }
                } else {
                    Text("Compte un match à la montre : ton service s'affichera ici.").font(.system(size: 13, weight: .semibold)).foregroundColor(.secondary)
                }
            }
        }.containerBackground(appGradient, for: .navigation)
    }
}

struct OppDetail: View {
    @ObservedObject var link = PhoneLink.shared
    let nx: WNext
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                DetailTitle(t: nx.when.isEmpty ? "Dernière recherche" : "Ton match · " + nx.when, color: .secondary)
                Text(nx.name).font(.system(size: 19, weight: .heavy)).lineLimit(2)
                if !nx.rank.isEmpty { Text(nx.rank).font(.system(size: 12, weight: .bold)).foregroundColor(.secondary) }
                HStack(spacing: 6) {
                    if let p = nx.p { StatTile(k: "Chances", v: "\(p) %", color: .balle) }
                    if !nx.h2h.isEmpty { StatTile(k: "Face-à-face", v: nx.h2h) }
                }
                if !nx.tip.isEmpty { Quote(t: nx.tip + (nx.tipS.isEmpty ? "" : " " + nx.tipS)) }
                NavigationLink {
                    if link.canPlay { ServerView(opp: WOpp(id: (nx.id ?? "").isEmpty ? "new" : nx.id!, name: nx.name, rank: nx.rank, p: nx.p, tip: nx.tip)) } else { PlusView() }
                } label: { Label("Lancer le match", systemImage: "play.fill") }
                .buttonStyle(Wide(bg: .balle, fg: .black))
            }
        }.containerBackground(appGradient, for: .navigation)
    }
}

struct DefendDetail: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        let c = link.ctx, ms = c.defMonths ?? []
        let mx = Double(ms.map { max($0.total, $0.norme) }.max() ?? 1)
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                DetailTitle(t: "À défendre" + ((c.defLabel ?? "").isEmpty ? "" : " · " + (c.defLabel ?? "")), color: .terre)
                Text(((c.defNow ?? 0) > 0 ? "−\(c.defNow ?? 0) pts en " : "Rien en ") + (c.thisMonth ?? "ce moment") + ".\nLes 6 prochains mois :")
                    .font(.system(size: 14, weight: .heavy)).fixedSize(horizontal: false, vertical: true)
                HStack(alignment: .bottom, spacing: 4) {
                    ForEach(Array(ms.enumerated()), id: \.offset) { i, m in
                        VStack(spacing: 2) {
                            RoundedRectangle(cornerRadius: 5).fill(m.lost.isEmpty || i == 0 ? Color.white.opacity(0.14) : (m.total < m.norme ? Color.terre : Color.gazon))
                                .frame(height: max(6, 70 * Double(m.total) / mx))
                            Text(m.m.replacingOccurrences(of: ".", with: "")).font(.system(size: 9.5, weight: .bold)).foregroundColor(.secondary).lineLimit(1).minimumScaleFactor(0.7)
                        }
                    }
                }.frame(height: 86)
                ForEach(Array(ms.enumerated()), id: \.offset) { _, m in
                    ForEach(m.lost, id: \.self) { w in
                        HStack {
                            Text(m.m + " · " + w.opp + " " + w.rank).lineLimit(1)
                            Spacer(minLength: 4)
                            Text("−\(w.pts)").fontWeight(.heavy).foregroundColor(.terre)
                        }.font(.system(size: 12, weight: .semibold))
                    }
                }
                if ms.allSatisfy({ $0.lost.isEmpty }) { Text("Aucune victoire ne sort d'ici 6 mois.").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary) }
            }
        }.containerBackground(appGradient, for: .navigation)
    }
}

struct PlusView: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text("Montée+").font(.system(size: 20, weight: .heavy)).foregroundColor(.balle)
                Text("Le score au poignet, Faute et Double faute, ton cardio et tes stats de service.")
                    .font(.system(size: 13, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
                Text("Ton match offert du mois est utilisé. Le prochain arrive le 1er du mois, ou abonne-toi dans Montée sur ton iPhone : menu › Montée+.")
                    .font(.system(size: 12)).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
                Button("Déjà abonné ? Vérifier") { Task { await link.checkStore() } }
                    .font(.system(size: 13, weight: .bold))
            }
        }.navigationTitle("Montée+")
    }
}

// MARK: - Cartes de métriques (sous le bouton, on les fait défiler à la couronne)

struct Card<Content: View>: View {
    let title: String
    var color: Color = .balle
    @ViewBuilder let content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.system(size: 13, weight: .heavy)).foregroundColor(.secondary).padding(.leading, 4)
            Glass {
                VStack(alignment: .leading, spacing: 6) { content }
            }
        }
        .padding(.top, 4)
    }
}

struct KV: View {
    let k: String
    let v: String
    var color: Color = .white
    var body: some View {
        HStack { Text(k).foregroundColor(.secondary); Spacer(minLength: 4); Text(v).fontWeight(.heavy).foregroundColor(color) }
            .font(.system(size: 12.5, weight: .semibold))
    }
}

struct MetricCards: View {
    @ObservedObject var link = PhoneLink.shared
    var c: WCtx { link.ctx }
    var body: some View {
        VStack(spacing: 8) {
            // 3.30 : Mental (remplace « Ton arme n°1 ») : 3 lignes, le détail en barres
            if let ms = c.mental, !ms.isEmpty {
                NavigationLink { MentalDetail() } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Mental").font(.system(size: 13, weight: .heavy)).foregroundColor(.secondary).padding(.leading, 4)
                        Glass {
                            VStack(spacing: 4) {
                                ForEach(Array(ms.filter { $0.k != "Après avoir perdu le 1er" && $0.k != "Sets gagnés" }.prefix(3)), id: \.self) { m in
                                    let p = m.n > 0 ? Int((Double(m.v) * 100 / Double(m.n)).rounded()) : 0
                                    HStack {
                                        Text(m.k).font(.system(size: 12, weight: .semibold)).lineLimit(1).minimumScaleFactor(0.75)
                                        Spacer(minLength: 4)
                                        Text("\(m.v)/\(m.n)").font(.system(size: 12.5, weight: .heavy)).foregroundColor(gaugeColor(p))
                                    }
                                }
                            }
                        }
                    }.padding(.top, 4)
                }.buttonStyle(.plain)
            }
            if link.hasPlus {
                // Dernière recherche / match programmé : s'ouvre sur sa fiche (et on lance le match)
                if let nx = c.nextOpp {
                    NavigationLink { OppDetail(nx: nx) } label: {
                        Card(title: nx.when.isEmpty ? "Dernière recherche" : "Ton match · " + nx.when) {
                            HStack {
                                VStack(alignment: .leading, spacing: 1) {
                                    Text(nx.name).font(.system(size: 15, weight: .heavy)).lineLimit(1)
                                    Text(nx.rank + (nx.p.map { " · tes chances \($0) %" } ?? "")).font(.system(size: 11.5, weight: .bold)).foregroundColor(.secondary).lineLimit(1)
                                }
                                Spacer(minLength: 2)
                                Image(systemName: "chevron.right").font(.system(size: 12, weight: .heavy)).foregroundColor(.secondary)
                            }
                        }
                    }.buttonStyle(.plain)
                }
            } else if c.form != nil {
                Card(title: "Montée+", color: .balle) {
                    Text("La fiche de ton prochain adversaire et le match au poignet sans limite.")
                        .font(.system(size: 12, weight: .semibold)).fixedSize(horizontal: false, vertical: true)
                }
            }
            // À défendre : rien ce mois-ci, ou combien ; le détail montre les 6 prochains mois
            if c.defMonths != nil {
                NavigationLink { DefendDetail() } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("À défendre").font(.system(size: 13, weight: .heavy)).foregroundColor(.secondary).padding(.leading, 4)
                        Glass(tint: (c.defNow ?? 0) > 0 ? .terre : .gazon) {
                            HStack {
                                VStack(alignment: .leading, spacing: 1) {
                                    Text((c.defNow ?? 0) > 0 ? "−\(c.defNow ?? 0) pts ce mois-ci" : "✓ Rien ce mois-ci").font(.system(size: 14, weight: .heavy)).foregroundColor((c.defNow ?? 0) > 0 ? .terre : .gazon)
                                    if let d = c.defend, d > 0 { Text("ensuite −\(d) pts" + (c.defendWhen.map { " en " + $0 } ?? "")).font(.system(size: 11.5, weight: .bold)).foregroundColor(.secondary) }
                                }
                                Spacer(minLength: 2)
                                Image(systemName: "chevron.right").font(.system(size: 12, weight: .heavy)).foregroundColor(.secondary)
                            }
                        }
                    }.padding(.top, 4)
                }.buttonStyle(.plain)
            }
            // Calendrier (gratuit)
            if let r = c.rel {
                Card(title: "Calendrier") {
                    HStack(alignment: .firstTextBaseline, spacing: 4) {
                        Text("\(max(0, r))").font(.system(size: 28, weight: .heavy))
                        Text(r == 1 ? "jour" : "jours").font(.system(size: 13, weight: .heavy))
                    }
                    if let l = c.relLabel { Text("avant le classement du " + l).font(.system(size: 11)).foregroundColor(.secondary) }
                    if let g = c.gap { KV(k: "Il te manque", v: g > 0 ? "\(g) pts" : "rien", color: .balle) }
                }
            }
        }
    }
}

// MARK: - 2. Type et format

struct SetupView: View {
    @ObservedObject var d = Draft.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Chip(t: "Homologué", on: d.hom) { d.hom = true }
                    Chip(t: "Libre", on: !d.hom) { d.hom = false }
                }
                Text(d.hom ? "Compte pour ton classement" : "Sans effet sur ton classement")
                    .font(.system(size: 11, weight: .semibold)).foregroundColor(.secondary)
                Text("3E SET").font(.system(size: 11, weight: .heavy)).foregroundColor(.secondary).padding(.top, 4)
                HStack(spacing: 6) {
                    Chip(t: "Set classique", on: d.fmt != "stb") { d.fmt = "full" }
                    Chip(t: "Super TB", on: d.fmt == "stb") { d.fmt = "stb" }
                }
                NavigationLink {
                    OppListView()
                } label: {
                    Text("Continuer").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryStyle()).padding(.top, 6)
            }
        }.navigationTitle("Nouveau match")
    }
}

// MARK: - 3. Contre qui ?

struct OppListView: View {
    @ObservedObject var link = PhoneLink.shared
    var body: some View {
        List {
            ForEach(link.ctx.opps) { o in
                NavigationLink {
                    ServerView(opp: o)
                } label: {
                    VStack(alignment: .leading, spacing: 2) {
                        if let t = o.tag {
                            Text(t.uppercased()).font(.system(size: 10, weight: .heavy))
                                .foregroundColor(t.hasPrefix("Prévu") ? .balle : .secondary)
                        }
                        HStack {
                            Text(o.name).font(.system(size: 15, weight: .bold)).lineLimit(1)
                            Spacer(minLength: 4)
                            Text(o.rank).font(.system(size: 13, weight: .semibold)).foregroundColor(.secondary)
                        }
                    }
                }
                .listRowBackground(RoundedRectangle(cornerRadius: 12).fill((o.tag ?? "").hasPrefix("Prévu") ? Color.balle.opacity(0.2) : Color.card))
            }
            NavigationLink {
                RankView()
            } label: {
                Label("Nouvel adversaire", systemImage: "plus").font(.system(size: 15, weight: .bold)).foregroundColor(.balle)
            }
        }
        .navigationTitle("Contre qui ?")
    }
}

// MARK: - 4. Nouvel adversaire : classement puis nom

struct RankView: View {
    @ObservedObject var d = Draft.shared
    @ObservedObject var link = PhoneLink.shared
    @State private var rank = ""
    var ranks: [String] { d.hom ? RANKS : RANKS + ["Je ne sais pas"] }
    var body: some View {
        VStack(spacing: 6) {
            Picker("Son classement", selection: $rank) {
                ForEach(ranks, id: \.self) { r in Text(r).tag(r) }
            }
            .pickerStyle(.wheel)
            .frame(height: 104)
            NavigationLink {
                NameView(rank: rank == "Je ne sais pas" ? "" : rank)
            } label: {
                Text("OK").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
            }
            .buttonStyle(PrimaryStyle())
        }
        .navigationTitle("Son classement")
        .onAppear { if rank.isEmpty { rank = ranks.contains(link.ctx.rank) ? link.ctx.rank : "15/4" } }
    }
}

struct NameView: View {
    let rank: String
    @State private var name = ""
    var fallback: String { rank.isEmpty ? "Adversaire" : "Adversaire " + rank }
    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                TextField("Son nom (facultatif)", text: $name)
                HStack(spacing: 6) {
                    NavigationLink {
                        ServerView(opp: WOpp(id: "new", name: fallback, rank: rank))
                    } label: {
                        Text("Passer").font(.system(size: 14, weight: .bold)).frame(maxWidth: .infinity)
                    }
                    NavigationLink {
                        ServerView(opp: WOpp(id: "new", name: name.trimmingCharacters(in: .whitespaces).isEmpty ? fallback : name, rank: rank))
                    } label: {
                        Text("OK").font(.system(size: 14, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                    }
                    .buttonStyle(PrimaryStyle())
                }
            }
        }.navigationTitle("Son nom")
    }
}

// MARK: - 5. Qui sert ?

/// Choix du serveur : un tap sélectionne, « Lancer le match » valide (plus de départ par erreur)
struct ServeChoice: View {
    @Binding var srv: Int?
    var body: some View {
        HStack(spacing: 8) {
            pick(0, "Moi")
            pick(1, "Lui")
        }
    }
    func pick(_ v: Int, _ t: String) -> some View {
        Button { srv = v; WKInterfaceDevice.current().play(.click) } label: {
            VStack(spacing: 2) {
                Text(t).font(.system(size: 18, weight: .heavy))
                Text(srv == v ? "sert" : " ").font(.system(size: 10.5, weight: .bold)).opacity(0.75)
            }
            // Pas choisi : les deux pareils (gris). Choisi : Moi en vert, Lui en orange (sa couleur dans les stats)
            .foregroundColor(srv == v ? (v == 0 ? .encre : terreInk) : .white)
            .frame(maxWidth: .infinity, minHeight: 56)
            .background(srv == v ? (v == 0 ? Color.gazon : Color.terre) : Color.card)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        }.buttonStyle(.plain)
    }
}

struct ServerView: View {
    let opp: WOpp
    @ObservedObject var d = Draft.shared
    @State private var srv: Int? = nil
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text(opp.name + (opp.rank.isEmpty ? "" : " · " + opp.rank)).font(.system(size: 14, weight: .bold)).lineLimit(1)
                Button { warm() } label: {
                    Label("Échauffement d'abord", systemImage: "figure.tennis").font(.system(size: 14, weight: .heavy))
                        .foregroundColor(.white).frame(maxWidth: .infinity, minHeight: 40)
                        .background(Color.card).clipShape(Capsule())
                }.buttonStyle(.plain)
                Text("Ou directement : qui sert ?").font(.system(size: 11.5, weight: .semibold)).foregroundColor(.secondary)
                ServeChoice(srv: $srv)
                Button { if let s = srv { start(s) } } label: {
                    Text("Lancer le match").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryStyle())
                .disabled(srv == nil)
                .opacity(srv == nil ? 0.35 : 1)
                if let t = opp.tip, !t.isEmpty { Quote(t: t) }
            }
        }
        .navigationTitle("C'est parti")
        .onAppear {
            if let h = opp.hom { d.hom = h }
            if let f = opp.fmt { d.fmt = f }
        }
    }
    func start(_ s: Int) {
        let o = opp, h = d.hom, f = d.fmt
        Workout.shared.authorize { MatchVM.shared.begin(opp: o, hom: h, fmt: f, srv0: s) }
    }
    func warm() {
        let o = opp, h = d.hom, f = d.fmt
        Workout.shared.authorize { MatchVM.shared.beginWarmup(opp: o, hom: h, fmt: f) }
    }
}

/// Pendant l'échauffement : chrono, cardio, puis qui sert et on lance
struct WarmupView: View {
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var w = Workout.shared
    @State private var srv: Int? = nil
    @State private var askCancel = false
    var body: some View {
        let wu = vm.warmup
        ScrollView {
            VStack(alignment: .leading, spacing: 7) {
                Text("Échauffement").font(.system(size: 13, weight: .heavy)).foregroundColor(.balle)
                TimelineView(.periodic(from: .now, by: 1)) { c in
                    let s = Int(c.date.timeIntervalSince(wu?.t0 ?? c.date))
                    HStack(alignment: .firstTextBaseline) {
                        Text(String(format: "%d:%02d", s / 60, s % 60)).font(.system(size: 30, weight: .heavy)).monospacedDigit()
                        Spacer()
                        if w.bpm > 0 { Text("♥ \(Int(w.bpm))").font(.system(size: 14, weight: .bold)).foregroundColor(.red) }
                    }
                }
                Text("contre " + (wu?.opp.name ?? "")).font(.system(size: 11.5, weight: .semibold)).foregroundColor(.secondary).lineLimit(1)
                Text("Qui sert ?").font(.system(size: 13, weight: .heavy)).padding(.top, 2)
                ServeChoice(srv: $srv)
                Button { go() } label: {
                    Text("Lancer le match").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryStyle())
                .disabled(srv == nil)
                .opacity(srv == nil ? 0.35 : 1)
                Button("Annuler") { askCancel = true }.buttonStyle(Wide(fg: .secondary))
            }
        }
        .fullScreenCover(isPresented: $askCancel) {
            ConfirmScreen(title: "Annuler l'échauffement ?", note: "Rien ne sera enregistré.",
                          options: [ConfirmOption(t: "Annuler l'échauffement", bg: .terre, fg: terreInk) { vm.cancelWarmup() }], cancel: "Continuer")
        }
    }
    func go() {
        guard let s = srv, let wu = vm.warmup else { return }
        vm.begin(opp: wu.opp, hom: wu.hom, fmt: wu.fmt, srv0: s)
    }
}

// MARK: - Pendant le match

struct MatchView: View {
    @ObservedObject var vm = MatchVM.shared
    var body: some View {
        let M = vm.state
        if M.winner != nil || vm.live?.forced != nil {
            EndView(M: M)
        } else if vm.showChange {
            ChangeView(M: M)
        } else {
            TabView {
                ScoreView(M: M).containerBackground(appGradient, for: .tabView)
                StatsView(M: M).containerBackground(appGradient, for: .tabView)
                ControlsView().containerBackground(appGradient, for: .tabView)
            }
            .tabViewStyle(.page)
        }
    }
}

struct ScoreView: View {
    let M: MatchState
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var w = Workout.shared
    var body: some View {
        VStack(spacing: 4) {
            HStack {
                TimelineView(.periodic(from: .now, by: 1)) { c in
                    Text(vm.elapsed(c.date)).font(.system(size: 13, weight: .bold)).foregroundColor(.secondary)
                }
                Spacer()
                if w.bpm > 0 { Text("♥ \(Int(w.bpm))").font(.system(size: 13, weight: .bold)).foregroundColor(.red) }
            }
            row(0)
            row(1)
            HStack {
                if let imp = M.importance {
                    // Point important : pastille à la place de « 1re balle »
                    Text(imp.label + (M.second ? " · 2e" : ""))
                        .font(.system(size: imp.level >= 2 ? 12 : 11, weight: .heavy))
                        .foregroundColor(imp.mine ? (imp.level == 1 ? .black : .encre) : Color(red: 0.16, green: 0.07, blue: 0.02))
                        .lineLimit(1).minimumScaleFactor(0.7)
                        .padding(.horizontal, 8).padding(.vertical, 3)
                        .background(imp.mine ? (imp.level == 1 ? Color.balle : Color.gazon) : Color.terre)
                        .clipShape(Capsule())
                } else {
                    Text(M.inTB ? (M.superTB ? "Super tie-break" : "Tie-break") : (M.second ? "2e balle" : "1re balle"))
                        .font(.system(size: 11, weight: .heavy))
                        .foregroundColor(M.second ? .terre : .secondary)
                }
                Spacer()
                if !M.last.isEmpty {
                    Button { vm.undo() } label: {
                        Label(M.last, systemImage: "arrow.uturn.backward")
                            .font(.system(size: 11, weight: .heavy))
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Color.card).clipShape(Capsule())
                    }.buttonStyle(.plain)
                }
            }
            Button { vm.tap(.fault) } label: {
                HStack(spacing: 5) {
                    Text(M.second ? "Double faute" : "Faute").font(.system(size: 15, weight: .heavy))
                    Text(M.server == 0 ? "de Toi" : "de Lui").font(.system(size: 11, weight: .bold)).opacity(0.7)
                }
                .foregroundColor(M.second ? Color(red: 0.16, green: 0.07, blue: 0.02) : .terre)
                .frame(maxWidth: .infinity, minHeight: 34)
                .background(M.second ? Color.terre : Color.clear)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.terre, lineWidth: M.second ? 0 : 2))
                .clipShape(RoundedRectangle(cornerRadius: 14))
            }.buttonStyle(.plain)
            HStack(spacing: 6) {
                BigButton(t: "Moi", bg: .gazon, fg: .encre, height: 56) { vm.tap(.me) }
                BigButton(t: "Lui", bg: Color.white.opacity(0.16), fg: .white, height: 56) { vm.tap(.him) }
            }
        }
    }

    func row(_ who: Int) -> some View {
        HStack(spacing: 8) {
            Text(who == 0 ? "Toi" : "Lui").font(.system(size: 14, weight: .bold))
            if M.server == who { Circle().fill(Color.balle).frame(width: 7, height: 7) }
            Spacer()
            ForEach(Array(M.sets.enumerated()), id: \.offset) { _, s in
                Text("\(who == 0 ? s.a : s.b)").font(.system(size: 18, weight: .heavy)).foregroundColor(.secondary)
            }
            if !M.inTB || !M.superTB {
                Text("\(M.games[who])").font(.system(size: 18, weight: .heavy))
            }
            Text(M.pointText(who)).font(.system(size: 20, weight: .heavy))
                .foregroundColor(who == 0 ? .black : .white)
                .frame(minWidth: 40, minHeight: 28)
                .background(who == 0 ? Color.balle : Color.card)
                .clipShape(RoundedRectangle(cornerRadius: 9, style: .continuous))
        }
        .padding(.leading, 10).padding(.trailing, 4).padding(.vertical, 3)
        .background(Color.white.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}

/// Toi à gauche, lui à droite
struct DuelRows: View {
    let M: MatchState
    var body: some View {
        let a = M.stats[0], b = M.stats[1]
        Grid(alignment: .center, horizontalSpacing: 6, verticalSpacing: 5) {
            GridRow {
                Text("TOI").font(.system(size: 10, weight: .heavy)).foregroundColor(.secondary)
                Text("")
                Text("LUI").font(.system(size: 10, weight: .heavy)).foregroundColor(.secondary)
            }
            line(pct(a.firstIn, a.pts), "1res balles", pct(b.firstIn, b.pts), false)
            line("\(a.df)", "doubles fautes", "\(b.df)", b.df > a.df)
            line(a.games > 0 ? "\(a.held)/\(a.games)" : "–", "jeux tenus", b.games > 0 ? "\(b.held)/\(b.games)" : "–", false)
            if a.bpFaced + b.bpFaced > 0 {
                line(b.bpFaced > 0 ? "\(b.bpFaced - b.bpSaved)/\(b.bpFaced)" : "–", "balles de break gagnées", a.bpFaced > 0 ? "\(a.bpFaced - a.bpSaved)/\(a.bpFaced)" : "–", false)
                line(a.bpFaced > 0 ? "\(a.bpSaved)/\(a.bpFaced)" : "–", "balles de break sauvées", b.bpFaced > 0 ? "\(b.bpSaved)/\(b.bpFaced)" : "–", false)
            }
        }
    }
    func line(_ l: String, _ k: String, _ r: String, _ hot: Bool) -> some View {
        GridRow {
            Text(l).font(.system(size: 16, weight: .heavy)).foregroundColor(.balle)
            Text(k).font(.system(size: 10.5, weight: .semibold)).foregroundColor(.secondary).lineLimit(1).minimumScaleFactor(0.8)
            Text(r).font(.system(size: 16, weight: .heavy)).foregroundColor(hot ? .terre : .white)
        }
    }
}

struct ChangeView: View {
    let M: MatchState
    @ObservedObject var vm = MatchVM.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text(M.setBreak ? "Fin du set" : "Changement de côté").font(.system(size: 13, weight: .heavy)).foregroundColor(.balle)
                TimelineView(.periodic(from: .now, by: 1)) { c in
                    let left = max(0, M.rest - Int(c.date.timeIntervalSince(vm.live?.changeAt ?? c.date)))
                    VStack(alignment: .leading, spacing: 5) {
                        Text(left > 0 ? String(format: "%d:%02d", left / 60, left % 60) : "C'est reparti")
                            .font(.system(size: left > 0 ? 44 : 26, weight: .heavy)).monospacedDigit()
                            .foregroundColor(left > 0 ? .white : .gazon)
                        if M.rest > 0 {
                            GeometryReader { g in
                                ZStack(alignment: .leading) {
                                    Capsule().fill(Color.white.opacity(0.12))
                                    Capsule().fill(left > 10 ? Color.gazon : Color.balle)
                                        .frame(width: g.size.width * CGFloat(left) / CGFloat(max(1, M.rest)))
                                }
                            }.frame(height: 6)
                        }
                    }
                }
                DuelRows(M: M)
                if let t = changeLine(M) { Quote(t: t) }
                Button { vm.dismissChange() } label: {
                    Text("Reprendre").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                }
                .buttonStyle(PrimaryStyle())
            }
        }
    }
}

struct StatsView: View {
    let M: MatchState
    @ObservedObject var w = Workout.shared
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 8) {
                Text("Au service").font(.system(size: 13, weight: .heavy)).foregroundColor(.balle)
                DuelRows(M: M)
                if w.avg > 0 {
                    Text("Cardio moyen \(Int(w.avg)) · max \(Int(w.maxBpm))").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary)
                }
                if w.kcal > 0 { Text("\(Int(w.kcal)) kcal").font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary) }
            }
        }
    }
}

struct ControlsView: View {
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var w = Workout.shared
    @State private var paused = false
    @State private var askEnd = false
    @State private var askCancel = false
    var body: some View {
        ScrollView {
            VStack(spacing: 8) {
                Button(paused ? "Reprendre" : "Pause") {
                    if paused { w.resume() } else { w.pause() }
                    paused.toggle()
                }.buttonStyle(Wide())
                Button("Changer le serveur") { vm.switchServer() }.buttonStyle(Wide())
                Button("Arrêter le match") { askEnd = true }.buttonStyle(Wide(bg: .terre, fg: terreInk))
                Button("Annuler le match") { askCancel = true }.buttonStyle(Wide(fg: .secondary))
            }
        }
        .fullScreenCover(isPresented: $askEnd) {
            ConfirmScreen(title: "Le match s'arrête", note: "Abandon, pluie… Tu as :",
                          options: [ConfirmOption(t: "Gagné", bg: .gazon, fg: .encre) { vm.stop(result: 0) },
                                    ConfirmOption(t: "Perdu", bg: .terre, fg: terreInk) { vm.stop(result: 1) }])
        }
        .fullScreenCover(isPresented: $askCancel) {
            ConfirmScreen(title: "Annuler ce match ?", note: "Rien ne sera enregistré.",
                          options: [ConfirmOption(t: "Annuler le match", bg: .terre, fg: terreInk) { vm.cancel() }], cancel: "Continuer")
        }
    }
}

// MARK: - Fin du match

struct EndView: View {
    let M: MatchState
    @ObservedObject var vm = MatchVM.shared
    @ObservedObject var w = Workout.shared
    var won: Bool { (vm.live?.forced ?? M.winner ?? 0) == 0 }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 6) {
                Text(won ? "Victoire" : "Défaite").font(.system(size: 13, weight: .heavy)).foregroundColor(won ? .balle : .terre)
                Text(scoreLine).font(.system(size: 24, weight: .heavy)).minimumScaleFactor(0.6).lineLimit(1)
                Text("contre " + (vm.live?.name ?? "")).font(.system(size: 12, weight: .semibold)).foregroundColor(.secondary).lineLimit(1)
                kv("Durée" + (w.avg > 0 ? " · cardio" : ""), vm.elapsed() + (w.avg > 0 ? " · \(Int(w.avg))" : ""))
                let me = M.stats[0], him = M.stats[1]
                LazyVGrid(columns: [GridItem(.flexible(), spacing: 6), GridItem(.flexible(), spacing: 6)], spacing: 6) {
                    if him.bpFaced > 0 { StatTile(k: "Balles de break", v: "\(him.bpFaced - him.bpSaved)/\(him.bpFaced) gagnées", color: .balle) }
                    if me.bpFaced > 0 { StatTile(k: "À sauver", v: "\(me.bpSaved)/\(me.bpFaced) sauvées", color: .gazon) }
                    StatTile(k: "1res balles", v: pct(me.firstIn, me.pts))
                    StatTile(k: "Doubles fautes", v: "\(me.df)")
                }
                if vm.live?.sent == true {
                    Text("✓ Envoyé à l'iPhone · séance Tennis enregistrée").font(.system(size: 12, weight: .bold)).foregroundColor(.gazon)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(vm.live?.hom == false ? "Match libre : sans effet sur le classement." : "Ouvre Montée sur l'iPhone pour l'enregistrer.")
                        .font(.system(size: 11)).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
                    Button("Fermer") { vm.close() }.buttonStyle(Wide())
                } else {
                    Button { vm.finish() } label: {
                        Text("Enregistrer").font(.system(size: 15, weight: .heavy)).foregroundColor(.black).frame(maxWidth: .infinity)
                    }
                    .buttonStyle(PrimaryStyle())
                    Button { vm.undo() } label: {
                        Label("Annuler le dernier point", systemImage: "arrow.uturn.backward")
                    }.buttonStyle(Wide())
                }
            }
        }
    }
    var scoreLine: String {
        var s = M.scoreText
        if vm.live?.forced != nil && (M.games[0] + M.games[1]) > 0 { s += (s.isEmpty ? "" : " ") + "\(M.games[0])-\(M.games[1])" }
        return s.isEmpty ? "–" : s
    }
    func kv(_ k: String, _ v: String) -> some View {
        HStack { Text(k).foregroundColor(.secondary); Spacer(); Text(v).fontWeight(.bold) }.font(.system(size: 12.5))
    }
}
