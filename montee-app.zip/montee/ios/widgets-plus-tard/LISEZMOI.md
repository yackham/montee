# Widgets iPhone : en pause pour la version de test

La 3.23 part en test sans les widgets iPhone, pour que le build passe sans réglage chez Apple.
Tout le code est prêt et rangé ici.

Pour les rallumer (après la sortie officielle) :
1. Faire les étapes Apple du guide `GUIDE-SUPPORTER-WIDGETS.md` (groupe d'apps, identifiant `fr.montennis.app.widgets`, profils).
2. Remplacer `ios/App/App.xcodeproj/project.pbxproj` par `project.pbxproj.avec-widgets` (vérifier MARKETING_VERSION).
3. Remplacer `ios/App/App/App.entitlements` par `App.entitlements.avec-widgets`.
4. Dans `web/app.js` : `IOS_WIDGETS: true` (et `SUPPORTER: true` pour les achats).

Le code de l'extension est dans `ios/App/MonteeWidgets/` (non référencé par le projet tant qu'on n'a pas fait l'étape 2).
5. Remettre `AppDelegate.swift.avec-widgets-et-achats` (widgets + StoreKit) et `Info.plist.avec-widgets` (schéma montee://) dans `ios/App/App/`.

Côté Android, les achats sont dans `android/achats-plus-tard/` : remettre `MonteeBilling.java`, `TenupPlugin.java.avec-achats` et la ligne `implementation "com.android.billingclient:billing:8.0.0"` dans `android/app/build.gradle`.
6. (Facultatif) `codemagic.yaml.avec-secours-widgets` ajoute une étape pour construire sans widgets via SANS_WIDGETS_IOS=1.

**Attention (3.25)** : `AppDelegate.swift` contient maintenant Montée+ (StoreKit 2) et la liaison Apple Watch (WatchLink).
Pour rallumer les widgets, ne pas remplacer le fichier par `AppDelegate.swift.avec-widgets-et-achats` : y reporter seulement la partie widgets (MonteeStore, WidgetRenderer, méthodes setWidgets/widgetInfo/renderWidgets…), sans dupliquer MonteeStoreKit ni les méthodes store*.
