# Widgets iPhone : rallumés en 3.26

Depuis la 3.26, les widgets iPhone sont dans le projet principal (cible MonteeWidgetsExtension, groupe d'apps
`group.fr.montennis.app`), avec les complications de la montre (cible MonteeComplications, dans l'app montre).
Les fichiers de ce dossier ne servent plus que d'archive. Ne pas les recopier par-dessus le projet.

En dépannage dans Codemagic : `SANS_WIDGETS_IOS: 1` (sans widgets iPhone) ou `SANS_MONTRE_IOS: 1` (sans montre ni complications).
